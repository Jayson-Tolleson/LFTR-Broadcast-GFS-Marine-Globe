#!/usr/bin/env bash
set -euo pipefail

create_systemd_services_impl() {
  local PYTHON_BIN="${PYTHON_BIN:-python3}"
  local unit="/etc/systemd/system/broadcast.service"
  cat > "$unit" <<EOF
[Unit]
Description=Broadcast Weather Globe
After=network.target

[Service]
Type=simple
User=${APP_USER}
Group=${APP_GROUP}
WorkingDirectory=${APP_DIR}
EnvironmentFile=${APP_DIR}/config/google.env
Environment=PYTHONUNBUFFERED=1
Environment=MALLOC_ARENA_MAX=2
Environment=OMP_NUM_THREADS=1
Environment=OPENBLAS_NUM_THREADS=1
Environment=NUMEXPR_NUM_THREADS=1
ExecStart=${APP_DIR}/venv/bin/${PYTHON_BIN} -m hypercorn --factory server.app_factory:create_app --bind ${APP_BIND_HOST}:${APP_BIND_PORT} --workers ${APP_WORKERS}
Restart=always
RestartSec=3
LimitNOFILE=20000
MemoryMax=10G

[Install]
WantedBy=multi-user.target
EOF

  local sea_unit="/etc/systemd/system/lftr-sea.service"
  cat > "$sea_unit" <<EOF
[Unit]
Description=LFTR FastAPI Sea of Intelligence Engine
After=network.target broadcast.service

[Service]
Type=simple
User=${APP_USER}
Group=${APP_GROUP}
WorkingDirectory=${APP_DIR}
EnvironmentFile=${APP_DIR}/config/google.env
Environment=PYTHONUNBUFFERED=1
Environment=MALLOC_ARENA_MAX=2
Environment=OMP_NUM_THREADS=1
Environment=OPENBLAS_NUM_THREADS=1
Environment=NUMEXPR_NUM_THREADS=1
ExecStart=${APP_DIR}/venv/bin/${PYTHON_BIN} -m uvicorn server_fastapi.main:app --host ${LFTR_FASTAPI_BIND_HOST:-127.0.0.1} --port ${LFTR_FASTAPI_BIND_PORT:-8010} --workers ${LFTR_FASTAPI_WORKERS:-1}
Restart=always
RestartSec=3
LimitNOFILE=20000
MemoryMax=6G

[Install]
WantedBy=multi-user.target
EOF

  systemctl daemon-reload
  systemctl enable broadcast.service
  systemctl restart broadcast.service
  if [[ "${LFTR_FASTAPI_ENABLED:-true}" == "true" ]]; then
    systemctl enable lftr-sea.service
    systemctl restart lftr-sea.service
  fi
}

verify_installation_impl() {
  local fail=0
  curl -fsS "http://localhost:${APP_BIND_PORT}/" >/dev/null || { log_warn "backend root failed"; fail=1; }
  curl -fsS "http://localhost:${APP_BIND_PORT}/gfs" >/dev/null || { log_warn "backend /gfs failed"; fail=1; }
  if [[ "${LFTR_FASTAPI_ENABLED:-true}" == "true" ]]; then
    curl -fsS "http://${LFTR_FASTAPI_BIND_HOST:-127.0.0.1}:${LFTR_FASTAPI_BIND_PORT:-8010}/health" >/dev/null || { log_warn "FastAPI sea engine health failed"; fail=1; }
  fi
  curl -kfsS "https://${DOMAIN}" >/dev/null || log_warn "public https endpoint check failed"

  printf '\n=== INSTALL SUMMARY ===\n'
  printf 'App dir: %s\n' "$APP_DIR"
  printf 'Service: broadcast.service\n'
  printf 'Sea engine: lftr-sea.service on %s:%s\n' "${LFTR_FASTAPI_BIND_HOST:-127.0.0.1}" "${LFTR_FASTAPI_BIND_PORT:-8010}"
  printf 'Domain: %s\n' "$DOMAIN"
  printf 'Routes expected: /, /broadcast, /watch, /gfs, /static/*, /api/*\n'
  if [[ $fail -eq 0 ]]; then
    log_ok "Core local health checks passed"
  fi
}
