# Debugging quick reference

## Service

```bash
sudo systemctl status broadcast --no-pager
journalctl -u broadcast -n 420 --no-pager
journalctl -u broadcast -f
```

## Backend health

```bash
curl -s http://127.0.0.1:8000/gfs/api/config | python3 -m json.tool
```

## GFS frame should be fast

```bash
curl -s "http://127.0.0.1:8000/gfs/api/frame?bbox=-134,22,-106,46&visible_bbox=-126,29,-114,39&scene_tier=world&quality=full" | python3 -m json.tool
```

Expected status: `frame_controller_shell`.

## Inland water

```bash
curl -s "http://127.0.0.1:8000/gfs/api/inland-water/status?bbox=-127,28,-113,40" | python3 -m json.tool
find /home/jayson_tolleson/broadcast -path "*nhdplus_hr*tiles/index.json" -print
find /home/jayson_tolleson/broadcast -path "*nhdplus_hr*" -name "*.json.gz" | head -50
```

## Cache warm

```bash
curl -s "http://127.0.0.1:8000/gfs/api/cache-warm/status" | python3 -m json.tool
```
