# LFTR /gfs + /gfs/api/frame stabilization patch

This build targets the boot/runtime pattern seen in the debug pane and journalctl:

- `/gfs/api/frame` taking 10-14 seconds and occasionally aborting.
- `cfgrib group opened ... datasets loaded` repeating across requests for the same GFS cycle.
- Fast status/scheduler routes waiting behind long sea/cloud/cache executor work.

## Changes

1. `/gfs/api/frame` is now a fast controller/status shell by default.
   - It no longer triggers the legacy heavy composite frame warm unless explicitly enabled.
   - Real render layers still come from `/gfs/api/sea`, `/gfs/api/clouds`, `/gfs/api/boats`, `/gfs/api/bait-advanced`, `/gfs/api/tiles`, etc.
   - Revert/legacy option: set `GFS_FRAME_LIGHTWEIGHT_ONLY=false` and optionally `GFS_FRAME_HEAVY_WARM=true`.

2. Added process-local decoded GFS GRIB snapshot reuse.
   - Keeps the currently decoded cfgrib/xarray groups open for the same GRIB file/path.
   - Reduces repeated `cfgrib group opened` storms in journalctl.
   - TTL: `GFS_DECODE_SNAPSHOT_TTL_SECONDS=900` by default.

3. Avoided default executor starvation for cheap routes.
   - `/gfs/api/frame`, `/gfs/api/cache-warm`, `/gfs/api/cache-warm/status`, and `/gfs/api/inland-water/build-cache` now return directly instead of queueing behind long provider jobs.

## Expected debug behavior

- `/gfs/api/frame` should return quickly with `payload_state: frame_controller_shell`.
- The frame payload should include `frame_sources` explaining that heavy geometry lives in the layer endpoints.
- The repeated cfgrib decode lines should drop sharply after the first cycle decode.
- Inland-water build-cache should report `started`/`deduped` quickly instead of holding the request open.
