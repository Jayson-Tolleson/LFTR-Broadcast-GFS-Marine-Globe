# GFS pipeline overview

`/gfs/api/frame` is a lightweight mission-control/status route in this build. It should not block on decoding all source weather grids.

Heavy render payloads are split into dedicated endpoints:

- `/gfs/api/sea` for FastAPI-derived contour geometry.
- `/gfs/api/clouds` for cloud/rain source payloads.
- `/gfs/api/boats` for ocean-current-backed boat placements.
- `/gfs/api/bait-advanced` for bait polygons.
- `/gfs/api/lightning` for GOES GLM lightning.
- `/gfs/api/inland-water` for high-def inland water.
- `/gfs/api/tiles` and `/gfs/api/cache-warm` for cache-first scene tiles.

The decoded GFS/cfgrib snapshot should be reused for the TTL defined by `GFS_DECODE_SNAPSHOT_TTL_SECONDS`.
