# Inland Waters auto-build bridge

This package keeps the strict high-def-only policy but fixes the missing bridge between the active Inland Waters pill and the post-install viewport source builder.

## What changed

- `/gfs/api/inland-water` now starts a background build when it returns `no_high_def_source` and `auto_build=1` is enabled.
- `static/js/gfs/main.js` now sends `auto_build=1` on Inland Waters geometry requests.
- The route response includes a `build` object with the background job status, pid, bbox, and log path.
- No coarse, seed, or mock shoreline is drawn.
- Runtime display still only reads local `.json.gz` tiles; the source build happens in the background and becomes visible on a later refresh/reload.

## Expected log flow

1. Inland Waters active pill requests `/gfs/api/inland-water?...&auto_build=1`.
2. If no local sidecar exists, the route returns `no_high_def_source` plus `build.status=started`.
3. Background script runs `scripts/install_nhdplus_hr_view_cache.sh` for the visible bbox.
4. After the build completes, `/gfs/api/inland-water/status` should show installed state tiles.
5. Reload or toggle Inland Waters to render polygons.
