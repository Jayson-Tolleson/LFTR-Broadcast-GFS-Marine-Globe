# Inland water first-run behavior

Inland water is strict real-source only. It never draws seed/coarse/mock water.

On a fresh install the first route response may be:

```json
{
  "status": "building",
  "source": "real_usgs_nhd_arcgis_view_tiles_building",
  "cache": {"selected_tiles": 0},
  "polygons": 0,
  "lines": 0
}
```

That means the route is working but no completed local render tiles have been written yet.

The intended first-run flow is:

```text
viewport bbox
→ clip to land/state bbox first
→ fetch real USGS/NHD source squares one at a time
→ append completed render tiles
→ write/update tiles/index.json
→ draw partial water as soon as one tile is readable
```

One readable `.json.gz` tile plus `index.json` is enough for partial drawing. Full coverage does not need to finish first.

## Useful checks

```bash
find /home/jayson_tolleson/broadcast -path "*nhdplus_hr*tiles/index.json" -print
find /home/jayson_tolleson/broadcast -path "*nhdplus_hr*" -name "*.json.gz" | head -50
tail -120 /home/jayson_tolleson/broadcast/data_sources/nhdplus_hr_state_cache/_build_logs/*.log
```
