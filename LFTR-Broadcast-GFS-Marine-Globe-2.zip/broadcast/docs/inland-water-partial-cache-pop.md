# Inland Waters partial cache pop + jet balloon randomization

- Runtime Inland Waters no longer tries to fetch an entire visible bbox source grid before rendering anything.
- On-demand builds now fetch a center-first subset of source squares (`NHD_ARCGIS_MAX_SOURCE_TILES`, default 24) and immediately build/append local json.gz render tiles.
- Tile builds append into the existing long-lived state sidecar instead of wiping it, so cache survives reboot and grows over time.
- Existing cached render tiles are read on boot before starting any new source build.
- Jet balloons are still viewport-distributed, but now randomized inside their viewport cells so they do not appear in a rigid grid or stacked row.
- No seed/coarse/mock inland-water fallback is added.
