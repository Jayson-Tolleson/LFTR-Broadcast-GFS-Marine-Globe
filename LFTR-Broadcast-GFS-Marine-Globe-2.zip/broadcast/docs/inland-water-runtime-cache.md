# Inland Waters runtime viewport cache policy

This package disables install-time Inland Waters data downloads.

Policy:
- No bundled shoreline source data.
- No install-time ArcGIS/TNM/NHD download.
- No seed/coarse/mock fallback shoreline.
- Inland Waters pill starts active and requests real source only.
- If local sidecar tiles are missing, `/gfs/api/inland-water?auto_build=1` starts a background viewport/zoom source-tile build.
- Runtime drawing only reads local `.json.gz` sidecar tiles from `static/data/nhdplus_hr/state_cache/...`.
- Source squares are stored under `data_sources/nhdplus_hr_state_cache` and retained long-term, default 180 days.

Expected first-use behavior:
1. First page load may show `no_high_def_source`.
2. The response should include `build.status=started` or `deduped=true`.
3. Watch build logs under `data_sources/nhdplus_hr_state_cache/_build_logs`.
4. Reload/toggle Inland Waters after build completion to draw polygons.

Useful commands:

```bash
cd ~/broadcast
python3 scripts/check_nhdplus_hr_state_cache.py
find data_sources/nhdplus_hr_state_cache/_build_logs -type f -maxdepth 1 -print -exec tail -40 {} \;
```
