# Pill Control / Route Cleanup

This package makes the GFS pills explicit topic switches:

- Clouds, Rain, Lightning, and Jetstream start enabled because they have live/renderable sources.
- Bait, Boater, and Inland Waters start disabled to avoid requesting data families that are not yet needed.
- Turning a pill off clears all visual elements for that topic and removes that topic from future staged fetch/cache-warm layer lists.
- Inland Waters remains high-definition-only. If NHDPlus HR tiles are not installed, the route returns `no_high_def_source`, the frontend marks the pill unavailable, and no coarse shoreline is drawn.
- Clicking an unavailable pill retries the source check, so installing NHDPlus tiles can be tested without code changes.

Expected high-definition source path:

```txt
static/data/nhdplus_hr/tiles/index.json
static/data/nhdplus_hr/tiles/<lod>/<x>_<y>.json.gz
```
