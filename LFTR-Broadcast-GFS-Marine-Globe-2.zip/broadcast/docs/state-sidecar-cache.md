# State Sidecar Cache for High-Definition Inland Waters

This package adds a long-lived CA/AZ/NV NHDPlus HR sidecar cache path.

Runtime behavior:

- No USGS/TNM fetch during page boot.
- `/gfs/api/inland-water` checks affected states from the visible bbox.
- It reads local state tiles from `static/data/nhdplus_hr/state_cache/<state>/tiles/index.json`.
- It displays full selected tile squares.
- Coarse/seed shoreline remains rejected.

Admin install/build:

```bash
cd ~/broadcast
bash scripts/install_nhdplus_hr_state_cache.sh "ca az nv"
python3 scripts/check_nhdplus_hr_state_cache.py
```

Cache policy:

- `NHDPLUS_STATE_CACHE_DAYS=180` by default.
- Downloaded source packages are reused if still within the retention window.
- Refresh manually, monthly, quarterly, or when a source update is desired.

Status endpoint:

```txt
/gfs/api/inland-water/status?bbox=-126,29,-114,39
```
