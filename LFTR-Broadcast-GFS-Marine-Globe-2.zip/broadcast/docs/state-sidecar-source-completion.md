# LFTR Inland Waters — State Sidecar Source Completion

This package completes the high-def Inland Waters state sidecar path.

Runtime remains strict and fast:

- page boot never downloads from USGS/TNM
- page boot only reads local `json.gz` render tiles
- coarse seed water is rejected
- missing state cache returns `no_high_def_source`

Admin/install source path:

```bash
cd ~/broadcast
bash scripts/install_nhdplus_hr_state_cache.sh "ca az nv"
python3 scripts/check_nhdplus_hr_state_cache.py
sudo systemctl restart broadcast
```

Source order:

1. TNM products API for NHDPlus HR downloadable packages.
2. If TNM returns no usable links or malformed HTTP-200 error bodies, use The National Map NHD ArcGIS MapServer large-scale layers by small bbox tiles:
   - layer 6: Flowline - Large Scale
   - layer 9: Area - Large Scale
   - layer 12: Waterbody - Large Scale

Outputs:

```txt
static/data/nhdplus_hr/state_cache/ca/tiles/index.json
static/data/nhdplus_hr/state_cache/az/tiles/index.json
static/data/nhdplus_hr/state_cache/nv/tiles/index.json
```

Cache retention defaults to 180 days via `NHDPLUS_STATE_CACHE_DAYS=180`.
