#!/usr/bin/env python3
"""Build high-definition Inland Waters json.gz tiles for LFTR.

Input can be app-normalized GeoJSON/GeoJSON.gz or GeoJSON exported from
NHDPlus HR / 3DHP / NHDWaterbody / NHDArea / NHDFlowline layers.

This intentionally uses only local files at runtime. Use this script after
fetching/exporting hydrography data; the app will then read:

  static/data/nhdplus_hr/tiles/index.json
  static/data/nhdplus_hr/tiles/<lod>/tile_*.json.gz

No coarse/seed data is generated.
"""
from __future__ import annotations

import argparse
import gzip
import json
import math
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any, Iterable

LOD_CFG = {
    # Tile sizes are fixed geographic squares. Runtime uses the visible bbox
    # only to select these full squares, then displays the full selected tile
    # contents. This keeps shoreline stable instead of re-clipping on every move.
    "world":    {"tile_deg": 4.0,  "max_points": 160,  "min_poly": 4, "min_line": 2},
    "regional": {"tile_deg": 2.0,  "max_points": 420,  "min_poly": 4, "min_line": 2},
    "local":    {"tile_deg": 1.0,  "max_points": 900,  "min_poly": 4, "min_line": 2},
    "harbor":   {"tile_deg": 0.25, "max_points": 1800, "min_poly": 4, "min_line": 2},
}
ACCEPTED_SOURCE = "USGS NHDPlus HR high-detail vector tile"


def load_json(path: Path) -> Any:
    if path.suffix == ".gz":
        with gzip.open(path, "rt", encoding="utf-8") as f:
            return json.load(f)
    return json.loads(path.read_text())


def write_json_gz(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with gzip.open(tmp, "wt", encoding="utf-8", compresslevel=7) as f:
        json.dump(payload, f, separators=(",", ":"))
    os.replace(tmp, path)


def norm_num(v: Any, default: float = float("nan")) -> float:
    try:
        x = float(v)
        return x if math.isfinite(x) else default
    except Exception:
        return default


def normalize_path(raw: Any) -> list[dict[str, float]]:
    out: list[dict[str, float]] = []
    for p in raw or []:
        if isinstance(p, dict):
            lat = norm_num(p.get("lat"))
            lng = norm_num(p.get("lng", p.get("lon")))
        elif isinstance(p, (list, tuple)) and len(p) >= 2:
            lng = norm_num(p[0])
            lat = norm_num(p[1])
        else:
            continue
        if -90 <= lat <= 90 and -180 <= lng <= 180:
            if not out or abs(out[-1]["lat"] - lat) > 1e-9 or abs(out[-1]["lng"] - lng) > 1e-9:
                out.append({"lat": round(lat, 7), "lng": round(lng, 7)})
    if len(out) >= 3 and abs(out[0]["lat"] - out[-1]["lat"]) < 1e-9 and abs(out[0]["lng"] - out[-1]["lng"]) < 1e-9:
        out.pop()
    return out


def path_bbox(path: list[dict[str, float]]) -> tuple[float, float, float, float] | None:
    if not path:
        return None
    lats = [p["lat"] for p in path]
    lngs = [p["lng"] for p in path]
    return min(lngs), min(lats), max(lngs), max(lats)


def bbox_intersects(a: tuple[float, float, float, float], b: tuple[float, float, float, float]) -> bool:
    aw, as_, ae, an = a
    bw, bs, be, bn = b
    return not (ae < bw or aw > be or an < bs or as_ > bn)


def thin_path(path: list[dict[str, float]], cap: int) -> list[dict[str, float]]:
    if len(path) <= cap:
        return path
    stride = max(1, math.ceil(len(path) / cap))
    out = path[::stride]
    if out[-1] != path[-1]:
        out.append(path[-1])
    return out


def iter_geojson_features(data: Any, source_name: str) -> Iterable[dict[str, Any]]:
    if isinstance(data, dict) and ("polygons" in data or "lines" in data):
        for item in data.get("polygons") or []:
            item = dict(item)
            item["_geometry_type"] = "polygon"
            yield item
        for item in data.get("lines") or []:
            item = dict(item)
            item["_geometry_type"] = "line"
            yield item
        return
    feats = data.get("features", []) if isinstance(data, dict) else []
    for feat in feats:
        props = feat.get("properties") or {}
        geom = feat.get("geometry") or {}
        gt = geom.get("type")
        coords = geom.get("coordinates") or []
        name = props.get("gnis_name") or props.get("GNIS_Name") or props.get("name") or props.get("Name") or "Unnamed inland water"
        kind = props.get("ftype") or props.get("FType") or props.get("kind") or props.get("type") or "water"
        fcode = props.get("fcode") or props.get("FCode")
        source_class = props.get("source_class") or props.get("source") or source_name or ACCEPTED_SOURCE
        base = {"name": name, "kind": str(kind).lower(), "fcode": fcode, "source_class": str(source_class), "source_path": source_name}
        if gt == "Polygon":
            for ring in coords[:1]:
                p = normalize_path(ring)
                if len(p) >= 3:
                    yield {**base, "_geometry_type": "polygon", "path": p}
        elif gt == "MultiPolygon":
            for poly in coords:
                if poly:
                    p = normalize_path(poly[0])
                    if len(p) >= 3:
                        yield {**base, "_geometry_type": "polygon", "path": p}
        elif gt == "LineString":
            p = normalize_path(coords)
            if len(p) >= 2:
                yield {**base, "_geometry_type": "line", "path": p}
        elif gt == "MultiLineString":
            for line in coords:
                p = normalize_path(line)
                if len(p) >= 2:
                    yield {**base, "_geometry_type": "line", "path": p}


def project_bbox(features: list[dict[str, Any]], explicit: str | None) -> tuple[float, float, float, float]:
    if explicit:
        w, s, e, n = [float(x.strip()) for x in explicit.split(",")]
        return w, s, e, n
    boxes = [path_bbox(f.get("path") or []) for f in features]
    boxes = [b for b in boxes if b]
    if not boxes:
        raise SystemExit("No valid features found after high-definition quality filtering")
    return min(b[0] for b in boxes), min(b[1] for b in boxes), max(b[2] for b in boxes), max(b[3] for b in boxes)



def tile_range_for_bbox(root: tuple[float, float, float, float], tile_deg: float) -> tuple[range, range]:
    w, s, e, n = root
    ix0 = math.floor(w / tile_deg)
    ix1 = math.ceil(e / tile_deg) - 1
    iy0 = math.floor(s / tile_deg)
    iy1 = math.ceil(n / tile_deg) - 1
    return range(ix0, ix1 + 1), range(iy0, iy1 + 1)


def tile_bbox_from_index(ix: int, iy: int, tile_deg: float) -> tuple[float, float, float, float]:
    w = ix * tile_deg
    s = iy * tile_deg
    return w, s, w + tile_deg, s + tile_deg


def tile_relpath(lod: str, ix: int, iy: int, tile_deg: float) -> str:
    scale = int(round(1.0 / tile_deg)) if tile_deg < 1 else 1
    if scale > 1:
        return f"{lod}/d{scale}/x{ix}_y{iy}.json.gz"
    return f"{lod}/x{ix}_y{iy}.json.gz"


def build_tiles(features: list[dict[str, Any]], out_dir: Path, bbox: tuple[float, float, float, float], *, append: bool = False) -> dict[str, Any]:
    existing_tiles: list[dict[str, Any]] = []
    existing_summary: dict[str, Any] = {}
    existing_bbox: list[float] | None = None
    index_path = out_dir / "index.json"
    if append and index_path.exists():
        try:
            old = json.loads(index_path.read_text())
            if isinstance(old, dict):
                existing_tiles = list(old.get("tiles") or [])
                existing_summary = dict(old.get("summary") or {})
                if isinstance(old.get("bbox"), list) and len(old.get("bbox")) == 4:
                    existing_bbox = [float(x) for x in old.get("bbox")]
        except Exception:
            existing_tiles = []
            existing_summary = {}
            existing_bbox = None
    elif out_dir.exists():
        shutil.rmtree(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    if existing_bbox:
        merged_bbox = [min(existing_bbox[0], bbox[0]), min(existing_bbox[1], bbox[1]), max(existing_bbox[2], bbox[2]), max(existing_bbox[3], bbox[3])]
    else:
        merged_bbox = list(bbox)
    manifest: dict[str, Any] = {
        "schema": "lftr_nhdplus_hr_tiles_v2_full_square_grid",
        "bbox": merged_bbox,
        "tile_policy": "fixed geographic square tiles; view bbox selects intersecting squares; runtime displays full selected tiles",
        "append_mode": bool(append),
        "tiles": [],
        "summary": dict(existing_summary),
    }
    existing_by_path = {str(t.get("path")): t for t in existing_tiles if isinstance(t, dict) and t.get("path")}
    written_paths: set[str] = set()
    for lod, cfg in LOD_CFG.items():
        tile_deg = float(cfg["tile_deg"])
        cap = int(cfg["max_points"])
        x_range, y_range = tile_range_for_bbox(bbox, tile_deg)
        wrote = 0
        for ix in x_range:
            for iy in y_range:
                tb = tile_bbox_from_index(ix, iy, tile_deg)
                polys, lines = [], []
                for feat in features:
                    pb = path_bbox(feat.get("path") or [])
                    if not pb or not bbox_intersects(pb, tb):
                        continue
                    item = {k: v for k, v in feat.items() if not k.startswith("_")}
                    src_path = item.get("path") or []
                    item["source_path_points"] = len(src_path)
                    item["render_path_points"] = min(len(src_path), cap)
                    item["path"] = thin_path(src_path, cap)
                    item["lod_tier"] = lod
                    item["tile_bbox"] = list(tb)
                    item["shoreline_truth"] = "high_def_source_vector_retained"
                    if feat.get("_geometry_type") == "polygon":
                        polys.append(item)
                    else:
                        lines.append(item)
                if not polys and not lines:
                    continue
                rel = tile_relpath(lod, ix, iy, tile_deg)
                payload = {
                    "schema": "lftr_nhdplus_hr_tile_v2_full_square",
                    "lod": lod,
                    "tile": {"x": ix, "y": iy, "tile_deg": tile_deg},
                    "bbox": list(tb),
                    "source": "nhdplus_hr_high_def_local_full_square_tile",
                    "polygons": polys,
                    "lines": lines,
                    "count": len(polys) + len(lines),
                }
                write_json_gz(out_dir / rel, payload)
                manifest["tiles"].append({"lod": lod, "path": rel, "bbox": list(tb), "tile_deg": tile_deg, "x": ix, "y": iy, "polygons": len(polys), "lines": len(lines), "bytes_gz": (out_dir / rel).stat().st_size})
                written_paths.add(rel)
                wrote += 1
        old_tiles = int((manifest["summary"].get(lod) or {}).get("tiles") or 0)
        manifest["summary"][lod] = {"tiles": old_tiles + wrote if append else wrote, "tile_deg": tile_deg, "x_count": len(list(x_range)), "y_count": len(list(y_range)), "new_tiles": wrote}
    if append:
        for rel, tile in existing_by_path.items():
            if rel not in written_paths and (out_dir / rel).exists():
                manifest["tiles"].append(tile)
    manifest["tiles"].sort(key=lambda t: (str(t.get("lod")), str(t.get("path"))))
    tmp_index = out_dir / "index.json.tmp"
    tmp_index.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    os.replace(tmp_index, out_dir / "index.json")
    return manifest


def export_fgdb_layers_to_geojson(src: Path, work: Path) -> list[Path]:
    ogr2ogr = shutil.which("ogr2ogr")
    if not ogr2ogr:
        raise SystemExit("ogr2ogr not found. Install gdal-bin first, or pass --source-geojson.")
    layer_names = ["NHDWaterbody", "NHDArea", "NHDFlowline"]
    out_files: list[Path] = []
    for layer in layer_names:
        out = work / f"{layer}.geojson"
        cmd = [ogr2ogr, "-f", "GeoJSON", "-t_srs", "EPSG:4326", str(out), str(src), layer]
        try:
            subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            if out.exists() and out.stat().st_size > 100:
                out_files.append(out)
        except subprocess.CalledProcessError as exc:
            print(f"[warn] skipped layer {layer}: {exc.stderr[:300]}", file=sys.stderr)
    if not out_files:
        raise SystemExit(f"No NHDWaterbody/NHDArea/NHDFlowline layers exported from {src}")
    return out_files


def main() -> int:
    ap = argparse.ArgumentParser(description="Build LFTR high-definition NHDPlus HR inland-water json.gz tiles")
    ap.add_argument("--source-geojson", action="append", default=[], help="GeoJSON/GeoJSON.gz input. May be repeated.")
    ap.add_argument("--source-gdb", action="append", default=[], help="FileGDB .gdb directory or other OGR-readable source containing NHD layers.")
    ap.add_argument("--out", default="static/data/nhdplus_hr/tiles", help="Output tile directory")
    ap.add_argument("--bbox", default=None, help="Optional tile project bbox west,south,east,north. If omitted, feature bbox is used.")
    ap.add_argument("--min-polygon-points", type=int, default=int(os.getenv("NHD_MIN_POLYGON_POINTS", "12")))
    ap.add_argument("--min-line-points", type=int, default=int(os.getenv("NHD_MIN_LINE_POINTS", "8")))
    ap.add_argument("--append", action="store_true", help="Append/merge new render tiles into an existing sidecar cache instead of wiping it.")
    args = ap.parse_args()

    inputs: list[Path] = [Path(x) for x in args.source_geojson]
    with tempfile.TemporaryDirectory(prefix="lftr_nhd_") as td:
        work = Path(td)
        for gdb in args.source_gdb:
            inputs.extend(export_fgdb_layers_to_geojson(Path(gdb), work))
        if not inputs:
            raise SystemExit("Pass --source-geojson or --source-gdb. No coarse fallback will be generated.")
        features: list[dict[str, Any]] = []
        for path in inputs:
            data = load_json(path)
            for feat in iter_geojson_features(data, str(path)):
                p = feat.get("path") or []
                if feat.get("_geometry_type") == "polygon" and len(p) < args.min_polygon_points:
                    continue
                if feat.get("_geometry_type") == "line" and len(p) < args.min_line_points:
                    continue
                src = " ".join(str(feat.get(k, "")) for k in ("source", "source_class", "source_path")).lower()
                if any(bad in src for bad in ("seed", "bootstrap", "demo", "coarse", "approx")):
                    continue
                if not any(ok in src for ok in ("nhd", "nhdplus", "3dhp", "osm", "hydrolakes", "waterbody", "flowline", "area")):
                    feat["source_class"] = ACCEPTED_SOURCE
                features.append(feat)
        root_bbox = project_bbox(features, args.bbox)
        manifest = build_tiles(features, Path(args.out), root_bbox, append=bool(args.append))
        print(json.dumps({"status": "ok", "features": len(features), "tiles": len(manifest["tiles"]), "out": str(args.out), "summary": manifest["summary"], "append": bool(args.append)}, indent=2))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
