#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path

ROOT = Path('static/data/nhdplus_hr/state_cache')
STATES = ('ca','az','nv')

def main() -> int:
    out = {"status":"ok", "root": str(ROOT), "states": {}, "installed_states": []}
    total_tiles = 0
    total_bytes = 0
    for st in STATES:
        idx = ROOT / st / 'tiles' / 'index.json'
        tiles = 0
        bytes_gz = 0
        if idx.exists():
            try:
                data = json.loads(idx.read_text())
                tiles = len(data.get('tiles') or [])
            except Exception:
                tiles = 0
            out['installed_states'].append(st)
        for f in (ROOT / st / 'tiles').rglob('*.json.gz') if (ROOT / st / 'tiles').exists() else []:
            try: bytes_gz += f.stat().st_size
            except OSError: pass
        total_tiles += tiles
        total_bytes += bytes_gz
        out['states'][st] = {"installed": idx.exists(), "tiles": tiles, "bytes_gz": bytes_gz, "index": str(idx)}
    out['total_tiles'] = total_tiles
    out['total_bytes_gz'] = total_bytes
    out['cache_policy'] = 'long-lived state sidecar; refresh manually or every 180 days; never fetch on page boot'
    print(json.dumps(out, indent=2))
    return 0 if out['installed_states'] else 1

if __name__ == '__main__':
    raise SystemExit(main())
