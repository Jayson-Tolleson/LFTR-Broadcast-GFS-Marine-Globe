#!/usr/bin/env python3
"""Debug TNM product responses for NHDPlus HR state sidecar installs."""
from __future__ import annotations
import json, urllib.parse, urllib.request
from pathlib import Path

OUT = Path("/tmp/tnm_debug")
OUT.mkdir(parents=True, exist_ok=True)
DATASETS = [
    "National Hydrography Dataset Plus High Resolution (NHDPlus HR)",
    "National Hydrography Dataset Plus High Resolution",
    "NHDPlus High Resolution",
    "NHDPlus HR",
    "National Hydrography Dataset (NHD) Best Resolution",
    "National Hydrography Dataset",
]
FORMATS = ["FileGDB", "Shapefile", "GeoPackage", ""]
BASE = "https://tnmaccess.nationalmap.gov/api/v1/products"

def fetch(url: str, label: str) -> None:
    print("\n" + "=" * 88)
    print(label)
    print(url)
    req = urllib.request.Request(url, headers={"User-Agent": "LFTR-TNM-debug/1.0", "Accept": "application/json,text/plain,*/*"})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            body = r.read()
            ctype = r.headers.get("Content-Type")
            status = getattr(r, "status", None)
    except Exception as e:
        print("REQUEST ERROR", repr(e)); return
    print("HTTP:", status, "Content-Type:", ctype, "bytes:", len(body))
    raw = OUT / f"{label}.raw.txt"
    raw.write_bytes(body)
    text = body.decode("utf-8", errors="replace")
    print(text[:1200])
    try:
        data = json.loads(text)
    except Exception as e:
        print("JSON ERROR", repr(e)); return
    items = data.get("items") or data.get("products") or data.get("results") or []
    print("keys", sorted(data.keys()), "items", len(items))
    (OUT / f"{label}.json").write_text(json.dumps(data, indent=2)[:200000])

def main() -> int:
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--bbox", default="-124.6,32.4,-114.0,42.1")
    args = ap.parse_args()
    i = 0
    for ds in DATASETS:
        for fmt in FORMATS:
            i += 1
            params = {"datasets": ds, "bbox": args.bbox, "outputFormat": "JSON", "max": "10"}
            if fmt: params["prodFormats"] = fmt
            fetch(BASE + "?" + urllib.parse.urlencode(params), f"attempt_{i:02d}_{fmt or 'any'}")
    print("DONE", OUT)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
