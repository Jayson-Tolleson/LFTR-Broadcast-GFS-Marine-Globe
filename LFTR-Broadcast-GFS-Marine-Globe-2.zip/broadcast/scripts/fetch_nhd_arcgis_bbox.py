#!/usr/bin/env python3
"""Fetch high-detail NHD geometry from The National Map ArcGIS service by bbox.

This is an admin/offline sidecar source fetcher. It is NOT used during page boot.
It is a strict real-source path, not mock/coarse fallback: it queries small
geographic tiles from the public NHD MapServer, converts Esri features to
app-ready GeoJSON, and writes one GeoJSON/GeoJSON.gz source file for
scripts/build_nhdplus_hr_tiles.py.

Default layers are NHD Large Scale flowlines, areas, and waterbodies:
  6  Flowline - Large Scale
  9  Area - Large Scale
  12 Waterbody - Large Scale
"""
from __future__ import annotations
import argparse, gzip, json, math, os, sys, time, urllib.parse, urllib.request
from pathlib import Path
from typing import Any

SERVICE = "https://hydro.nationalmap.gov/arcgis/rest/services/nhd/MapServer"
DEFAULT_LAYERS = {
    6:  {"name": "NHDFlowline Large Scale", "kind": "river", "geometry": "line"},
    9:  {"name": "NHDArea Large Scale", "kind": "area", "geometry": "polygon"},
    12: {"name": "NHDWaterbody Large Scale", "kind": "waterbody", "geometry": "polygon"},
}


def parse_bbox(s: str) -> tuple[float, float, float, float]:
    vals = [float(x.strip()) for x in str(s).split(",")]
    if len(vals) != 4:
        raise ValueError("bbox must be west,south,east,north")
    w, south, e, n = vals
    if not (w < e and south < n):
        raise ValueError(f"invalid bbox {s!r}")
    return w, south, e, n


def split_bbox(bbox: str, step_deg: float) -> list[tuple[float, float, float, float]]:
    w, s, e, n = parse_bbox(bbox)
    out: list[tuple[float, float, float, float]] = []
    y = s
    while y < n - 1e-9:
        y2 = min(n, y + step_deg)
        x = w
        while x < e - 1e-9:
            x2 = min(e, x + step_deg)
            out.append((x, y, x2, y2))
            x = x2
        y = y2
    return out


def prioritize_tiles_center_first(tiles: list[tuple[float, float, float, float]], bbox: str) -> list[tuple[float, float, float, float]]:
    """Return source tiles nearest the viewport center first.

    Runtime Inland Waters should pop a useful partial cache quickly, not wait for
    a whole 480-tile world-view scrape.  Fetching center-first lets the first
    batch draw around the camera, while later viewport moves can expand the
    long-lived sidecar.
    """
    w, s, e, n = parse_bbox(bbox)
    cx = (w + e) * 0.5
    cy = (s + n) * 0.5
    def score(tb: tuple[float, float, float, float]) -> tuple[float, float]:
        tw, ts, te, tn = tb
        tx = (tw + te) * 0.5
        ty = (ts + tn) * 0.5
        return ((tx - cx) ** 2 + (ty - cy) ** 2, abs(tx - cx) + abs(ty - cy))
    return sorted(tiles, key=score)


def request_json(url: str, *, retries: int = 2, timeout: int = 60, debug_dir: Path | None = None) -> dict[str, Any] | None:
    last: Exception | None = None
    for attempt in range(retries + 1):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "LFTR-NHD-ArcGIS-sidecar/1.0", "Accept": "application/json,*/*"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                body = r.read()
                text = body.decode("utf-8", errors="replace")
                try:
                    return json.loads(text)
                except Exception as exc:
                    if debug_dir:
                        debug_dir.mkdir(parents=True, exist_ok=True)
                        p = debug_dir / f"arcgis_non_json_{int(time.time()*1000)}.txt"
                        p.write_text("URL: " + url + "\n\n" + text[:200000], encoding="utf-8")
                        print(f"[arcgis] non-json saved {p}")
                    last = exc
        except Exception as exc:
            last = exc
        if attempt < retries:
            time.sleep(0.8 * (attempt + 1))
    print(f"[arcgis] request failed after retries: {last} url={url[:240]}", file=sys.stderr)
    return None


def esri_polygon_to_features(geom: dict[str, Any], attrs: dict[str, Any], layer_info: dict[str, str], layer_id: int) -> list[dict[str, Any]]:
    feats = []
    for ring in geom.get("rings") or []:
        if not isinstance(ring, list) or len(ring) < 4:
            continue
        coords = []
        for pt in ring:
            if isinstance(pt, (list, tuple)) and len(pt) >= 2:
                coords.append([float(pt[0]), float(pt[1])])
        if len(coords) >= 4:
            feats.append({
                "type": "Feature",
                "properties": props_from_attrs(attrs, layer_info, layer_id),
                "geometry": {"type": "Polygon", "coordinates": [coords]},
            })
    return feats


def esri_polyline_to_features(geom: dict[str, Any], attrs: dict[str, Any], layer_info: dict[str, str], layer_id: int) -> list[dict[str, Any]]:
    feats = []
    for path in geom.get("paths") or []:
        if not isinstance(path, list) or len(path) < 2:
            continue
        coords = []
        for pt in path:
            if isinstance(pt, (list, tuple)) and len(pt) >= 2:
                coords.append([float(pt[0]), float(pt[1])])
        if len(coords) >= 2:
            feats.append({
                "type": "Feature",
                "properties": props_from_attrs(attrs, layer_info, layer_id),
                "geometry": {"type": "LineString", "coordinates": coords},
            })
    return feats


def props_from_attrs(attrs: dict[str, Any], layer_info: dict[str, str], layer_id: int) -> dict[str, Any]:
    def pick(*names: str) -> Any:
        lower = {str(k).lower(): v for k, v in attrs.items()}
        for name in names:
            if name in attrs:
                return attrs.get(name)
            if name.lower() in lower:
                return lower.get(name.lower())
        return None
    name = pick("GNIS_NAME", "gnis_name", "Name") or "Unnamed inland water"
    ftype = pick("FTYPE", "FType", "FTypeDesc") or layer_info.get("kind") or "water"
    fcode = pick("FCODE", "FCode")
    oid = pick("OBJECTID", "ObjectID", "FID")
    return {
        "name": name,
        "gnis_name": name,
        "kind": str(ftype).lower(),
        "fcode": fcode,
        "objectid": oid,
        "source": "USGS NHD ArcGIS high-detail state sidecar",
        "source_class": layer_info.get("name") or f"NHD layer {layer_id}",
        "shoreline_truth": "nhd_high_detail_vector_service",
        "geometry_quality": "high_detail_nhd_ready",
    }


def query_layer(layer_id: int, layer_info: dict[str, str], bbox: tuple[float, float, float, float], *, page_size: int, max_records: int, debug_dir: Path) -> list[dict[str, Any]]:
    """Query a single NHD ArcGIS layer using the proven GeoJSON envelope contract.

    The hydro.nationalmap.gov NHD service accepts f=geojson with comma-envelope
    geometry. Earlier versions used f=json + selected outFields + Esri envelope
    JSON, which returned 400 "Failed to execute query" on the server.
    """
    w, s, e, n = bbox
    envelope = f"{w:.8f},{s:.8f},{e:.8f},{n:.8f}"
    features: list[dict[str, Any]] = []
    offset = 0
    empty_pages = 0
    while offset < max_records:
        params = {
            "f": "geojson",
            "where": "1=1",
            "geometry": envelope,
            "geometryType": "esriGeometryEnvelope",
            "inSR": "4326",
            "spatialRel": "esriSpatialRelIntersects",
            "outSR": "4326",
            "outFields": "*",
            "returnGeometry": "true",
            "resultRecordCount": str(page_size),
            "resultOffset": str(offset),
        }
        url = f"{SERVICE}/{layer_id}/query?" + urllib.parse.urlencode(params)
        data = request_json(url, debug_dir=debug_dir)
        if not data:
            break
        if data.get("error"):
            # Some NHD ArcGIS layers reject larger resultRecordCount values with
            # a generic 400. Retry the same envelope with a very small page size
            # before giving up. This uses the exact f=geojson comma-envelope
            # contract verified from the server.
            err = data.get("error")
            if page_size > 50:
                small_params = dict(params)
                small_params["resultRecordCount"] = "50"
                small_url = f"{SERVICE}/{layer_id}/query?" + urllib.parse.urlencode(small_params)
                small = request_json(small_url, debug_dir=debug_dir)
                if small and not small.get("error"):
                    data = small
                else:
                    debug_dir.mkdir(parents=True, exist_ok=True)
                    p = debug_dir / f"arcgis_error_layer_{layer_id}_{int(time.time()*1000)}.json"
                    p.write_text(json.dumps({"url": url, "retry_url": small_url, "error": err, "retry_error": (small or {}).get("error")}, indent=2), encoding="utf-8")
                    print(f"[arcgis] layer={layer_id} error={err} saved={p}", file=sys.stderr)
                    break
            else:
                debug_dir.mkdir(parents=True, exist_ok=True)
                p = debug_dir / f"arcgis_error_layer_{layer_id}_{int(time.time()*1000)}.json"
                p.write_text(json.dumps({"url": url, "error": err}, indent=2), encoding="utf-8")
                print(f"[arcgis] layer={layer_id} error={err} saved={p}", file=sys.stderr)
                break
        rows = data.get("features") or []
        if not rows:
            empty_pages += 1
            if empty_pages >= 1:
                break
        empty_pages = 0
        for row in rows:
            geom = row.get("geometry") or {}
            props = props_from_attrs(row.get("properties") or {}, layer_info, layer_id)
            # The service already returns valid GeoJSON geometry. Keep it directly.
            gtype = geom.get("type")
            coords = geom.get("coordinates")
            if not gtype or coords is None:
                continue
            if layer_info.get("geometry") == "polygon" and gtype not in {"Polygon", "MultiPolygon"}:
                continue
            if layer_info.get("geometry") == "line" and gtype not in {"LineString", "MultiLineString"}:
                continue
            features.append({"type": "Feature", "properties": props, "geometry": geom})
        print(f"[arcgis] layer={layer_id} bbox={w:.3f},{s:.3f},{e:.3f},{n:.3f} offset={offset} rows={len(rows)} features={len(features)}")
        # ArcGIS GeoJSON uses exceededTransferLimit when more pages are available.
        if len(rows) < page_size and not data.get("exceededTransferLimit"):
            break
        if not data.get("exceededTransferLimit") and len(rows) == 0:
            break
        offset += page_size
    return features


def write_geojson(path: Path, features: list[dict[str, Any]], meta: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {"type": "FeatureCollection", "metadata": meta, "features": features}
    if path.suffix == ".gz":
        tmp = path.with_suffix(path.suffix + ".tmp")
        with gzip.open(tmp, "wt", encoding="utf-8", compresslevel=7) as f:
            json.dump(payload, f, separators=(",", ":"))
        os.replace(tmp, path)
    else:
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(json.dumps(payload, separators=(",", ":")), encoding="utf-8")
        os.replace(tmp, path)


def main() -> int:
    ap = argparse.ArgumentParser(description="Fetch NHD high-detail ArcGIS features by bbox into app-ready GeoJSON")
    ap.add_argument("--bbox", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--tile-deg", type=float, default=1.0, help="Query source service in small bbox squares")
    ap.add_argument("--page-size", type=int, default=100)
    ap.add_argument("--max-records-per-layer-tile", type=int, default=1200)
    ap.add_argument("--layers", default="6,9,12", help="Comma-separated NHD MapServer layer ids; default large-scale flowline, area, waterbody")
    ap.add_argument("--cache-days", type=int, default=180)
    ap.add_argument("--max-source-tiles", type=int, default=0, help="Fetch at most this many source bbox tiles, center-first. 0 means all.")
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()
    out = Path(args.out)
    meta_path = out.with_suffix(out.suffix + ".meta.json")
    if out.exists() and out.stat().st_size > 0 and not args.force:
        age_days = (time.time() - out.stat().st_mtime) / 86400.0
        if age_days <= args.cache_days:
            print(json.dumps({"status": "cache_hit", "out": str(out), "age_days": round(age_days, 2), "cache_days": args.cache_days}, indent=2))
            return 0
    debug_dir = out.parent / "_arcgis_debug"
    layers = []
    for raw in str(args.layers).split(","):
        raw = raw.strip()
        if not raw:
            continue
        lid = int(raw)
        layers.append((lid, DEFAULT_LAYERS.get(lid, {"name": f"NHD layer {lid}", "kind": "water", "geometry": "polygon"})))
    all_tiles = prioritize_tiles_center_first(split_bbox(args.bbox, args.tile_deg), args.bbox)
    total_tiles_available = len(all_tiles)
    if int(args.max_source_tiles or 0) > 0:
        tiles = all_tiles[: max(1, int(args.max_source_tiles))]
    else:
        tiles = all_tiles
    print(f"[arcgis] source tile plan selected={len(tiles)} available={total_tiles_available} tile_deg={args.tile_deg} center_first=true")
    all_features: list[dict[str, Any]] = []
    seen: set[str] = set()
    for ti, tb in enumerate(tiles, 1):
        print(f"[arcgis tile {ti}/{len(tiles)}] bbox={','.join(f'{v:.6f}' for v in tb)}")
        for lid, info in layers:
            feats = query_layer(lid, info, tb, page_size=args.page_size, max_records=args.max_records_per_layer_tile, debug_dir=debug_dir)
            for feat in feats:
                props = feat.get("properties") or {}
                geom = feat.get("geometry") or {}
                key = f"{lid}:{props.get('objectid')}:{geom.get('type')}:{str(geom.get('coordinates'))[:160]}"
                if key in seen:
                    continue
                seen.add(key)
                all_features.append(feat)
    meta = {
        "status": "ok" if all_features else "empty",
        "source": "USGS The National Map NHD ArcGIS MapServer state sidecar real_source",
        "service": SERVICE,
        "bbox": args.bbox,
        "tile_deg": args.tile_deg,
        "source_tiles_selected": len(tiles),
        "source_tiles_available": total_tiles_available,
        "max_source_tiles": int(args.max_source_tiles or 0),
        "partial_cache": bool(int(args.max_source_tiles or 0) > 0 and len(tiles) < total_tiles_available),
        "layers": [lid for lid, _ in layers],
        "features": len(all_features),
        "cache_days": args.cache_days,
        "fetched_at": int(time.time()),
    }
    write_geojson(out, all_features, meta)
    meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")
    print(json.dumps(meta, indent=2))
    return 0 if all_features else 3


if __name__ == "__main__":
    raise SystemExit(main())
