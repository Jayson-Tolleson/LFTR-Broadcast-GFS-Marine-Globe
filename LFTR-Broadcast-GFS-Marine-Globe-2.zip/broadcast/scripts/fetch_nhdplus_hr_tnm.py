#!/usr/bin/env python3
"""Find/download NHDPlus HR products from The National Map Access API.

Admin/offline helper only. It is intentionally defensive because TNM sometimes
returns HTTP 200 with a malformed non-JSON Lambda error body. Non-JSON payloads
are saved and treated as empty search results instead of crashing.
"""
from __future__ import annotations
import argparse, json, math, re, sys, time, urllib.parse, urllib.request
from pathlib import Path
from typing import Any

TNM_PRODUCTS = "https://tnmaccess.nationalmap.gov/api/v1/products"
DATASET_CANDIDATES = [
    "National Hydrography Dataset Plus High Resolution (NHDPlus HR)",
    "National Hydrography Dataset Plus High Resolution",
    "NHDPlus High Resolution",
    "NHDPlus HR",
]
FORMAT_CANDIDATES = ["FileGDB", "Shapefile", "GeoPackage", ""]
LOD_TILE_DEG = {"world": 4.0, "regional": 2.0, "local": 1.0, "harbor": 0.25}


def parse_bbox(s: str) -> tuple[float, float, float, float]:
    w, south, e, n = [float(x.strip()) for x in s.split(",")]
    return w, south, e, n


def tile_squares_for_bbox(bbox_s: str, lod: str = "world", tile_deg: float | None = None) -> list[str]:
    w, s, e, n = parse_bbox(bbox_s)
    step = float(tile_deg or LOD_TILE_DEG.get(lod, 4.0))
    ix0 = math.floor(w / step); ix1 = math.ceil(e / step) - 1
    iy0 = math.floor(s / step); iy1 = math.ceil(n / step) - 1
    return [",".join(f"{v:.6f}" for v in (ix * step, iy * step, (ix + 1) * step, (iy + 1) * step)) for ix in range(ix0, ix1 + 1) for iy in range(iy0, iy1 + 1)]


def split_bbox(bbox_s: str, step_deg: float) -> list[str]:
    w, s, e, n = parse_bbox(bbox_s)
    out: list[str] = []
    y = s
    while y < n - 1e-9:
        y2 = min(n, y + step_deg)
        x = w
        while x < e - 1e-9:
            x2 = min(e, x + step_deg)
            out.append(",".join(f"{v:.6f}" for v in (x, y, x2, y2)))
            x = x2
        y = y2
    return out


def get_json(url: str, debug_dir: Path) -> dict[str, Any]:
    req = urllib.request.Request(url, headers={"User-Agent": "LFTR-NHDPlusHR/1.0", "Accept": "application/json,text/plain,*/*"})
    try:
        with urllib.request.urlopen(req, timeout=90) as r:
            body = r.read()
            text = body.decode("utf-8", errors="replace")
            ctype = r.headers.get("Content-Type", "")
    except Exception as exc:
        print(f"[tnm] request failed {exc} url={url[:220]}", file=sys.stderr)
        return {"items": [], "error": "request_failed", "detail": repr(exc)}
    try:
        return json.loads(text)
    except Exception:
        debug_dir.mkdir(parents=True, exist_ok=True)
        p = debug_dir / f"tnm_non_json_{len(list(debug_dir.glob('tnm_non_json_*.txt'))) + 1:03d}.txt"
        p.write_text("URL: " + url + "\n\nContent-Type: " + ctype + "\n\n" + text, encoding="utf-8")
        print(f"[tnm] non-json response saved: {p}")
        print(f"[tnm] preview: {text[:260].replace(chr(10), ' ')}")
        return {"items": [], "error": "non_json_tnm_response", "raw_debug": str(p)}


def extract_download_url(item: dict[str, Any]) -> str | None:
    for k in ("downloadURL", "downloadUrl", "download", "url", "URL", "sourceUrl"):
        v = item.get(k)
        if isinstance(v, str) and v.startswith("http"):
            return v
    # Some TNM payloads nest links.
    for v in item.values():
        if isinstance(v, dict):
            found = extract_download_url(v)
            if found:
                return found
        elif isinstance(v, list):
            for x in v:
                if isinstance(x, dict):
                    found = extract_download_url(x)
                    if found:
                        return found
                elif isinstance(x, str) and x.startswith("http") and ("download" in x.lower() or x.lower().endswith((".zip", ".7z"))):
                    return x
    return None


def main() -> int:
    ap = argparse.ArgumentParser(description="Search/download NHDPlus HR source products via TNM Access API")
    ap.add_argument("--bbox", required=True, help="view bbox west,south,east,north")
    ap.add_argument("--out", default="data_sources/nhdplus_hr", help="Download/output directory")
    ap.add_argument("--limit", type=int, default=8)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--full-tile-squares", action="store_true", help="snap bbox to fixed tile squares and query TNM once per full square")
    ap.add_argument("--split-deg", type=float, default=1.0, help="fallback TNM bbox split size when not using full tile squares")
    ap.add_argument("--lod", default="world", choices=sorted(LOD_TILE_DEG))
    ap.add_argument("--tile-deg", type=float, default=None)
    ap.add_argument("--cache-days", type=int, default=180)
    args = ap.parse_args()
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    debug_dir = out / "_tnm_debug"
    if args.full_tile_squares:
        query_bboxes = tile_squares_for_bbox(args.bbox, args.lod, args.tile_deg)
    else:
        query_bboxes = split_bbox(args.bbox, args.split_deg)
    all_downloads: list[str] = []
    responses = []
    attempts = 0
    for idx, qb in enumerate(query_bboxes, 1):
        for dataset in DATASET_CANDIDATES:
            for fmt in FORMAT_CANDIDATES:
                attempts += 1
                params = {"datasets": dataset, "bbox": qb, "outputFormat": "JSON", "max": str(args.limit)}
                if fmt:
                    params["prodFormats"] = fmt
                url = TNM_PRODUCTS + "?" + urllib.parse.urlencode(params)
                print(f"[tnm tile {idx}/{len(query_bboxes)}] dataset={dataset!r} fmt={fmt or 'any'} bbox={qb}")
                data = get_json(url, debug_dir)
                response_path = out / f"tnm_products_response_tile_{idx:03d}_{attempts:04d}.json"
                response_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
                responses.append(str(response_path))
                items = data.get("items") or data.get("products") or data.get("results") or []
                for item in items if isinstance(items, list) else []:
                    candidate = extract_download_url(item if isinstance(item, dict) else {})
                    if candidate and candidate not in all_downloads:
                        all_downloads.append(candidate)
                if all_downloads:
                    break
            if all_downloads:
                break
    plan = {"status": "ok" if all_downloads else "empty", "bbox": args.bbox, "query_bboxes": query_bboxes, "attempts": attempts, "candidates": len(all_downloads), "responses": responses[-20:], "downloads": all_downloads[:args.limit], "note": "If empty, installer will use ArcGIS NHD large-scale service fallback."}
    (out / "tnm_download_plan.json").write_text(json.dumps(plan, indent=2), encoding="utf-8")
    print(json.dumps(plan, indent=2))
    if args.dry_run:
        return 0
    for i, dl in enumerate(all_downloads[:args.limit], 1):
        name = re.sub(r"[^A-Za-z0-9_.-]+", "_", dl.rsplit("/", 1)[-1] or f"nhdplus_hr_{i}.zip")
        path = out / name
        if path.exists() and path.stat().st_size > 0:
            age_days = (time.time() - path.stat().st_mtime) / 86400.0
            if age_days <= float(args.cache_days):
                print(f"[download] cache-hit {path} age_days={age_days:.1f} keep_days={args.cache_days}")
                continue
            print(f"[download] cache-stale {path} age_days={age_days:.1f}; refreshing")
        print(f"[download] {dl} -> {path}")
        urllib.request.urlretrieve(dl, path)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
