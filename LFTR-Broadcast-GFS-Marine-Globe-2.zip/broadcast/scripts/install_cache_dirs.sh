#!/usr/bin/env bash
set -euo pipefail
APP_DIR="${APP_DIR:-/home/jayson_tolleson/broadcast}"
APP_USER="${APP_USER:-jayson_tolleson}"
mkdir -p "$APP_DIR/.cache/gfs_tiles" "$APP_DIR/.cache/gfs_tiles/tiles" "$APP_DIR/.cache/gfs_tiles/frames" "$APP_DIR/.cache/gfs_tiles/metadata" "$APP_DIR/.cache/gfs_tiles/failures" "$APP_DIR/data_sources/nhdplus_hr_state_cache" "$APP_DIR/static/data/nhdplus_hr/state_cache"
chown -R "$APP_USER:$APP_USER" "$APP_DIR/.cache" 2>/dev/null || true
chmod -R u+rwX,g+rwX "$APP_DIR/.cache" 2>/dev/null || true
echo "[OK] LFTR GFS cache dirs ready at $APP_DIR/.cache/gfs_tiles"
