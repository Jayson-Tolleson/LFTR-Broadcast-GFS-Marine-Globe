#!/usr/bin/env bash
set -euo pipefail

# Build long-lived high-definition inland-water state sidecar caches.
# This is an admin/offline job. It must NOT run during page boot.
# Primary target: CA, AZ, NV.
# Real source modes, no mock/coarse fallback:
#   arcgis  = USGS/National Map NHD Large Scale ArcGIS service by small bbox tiles (default).
#   tnm     = TNM downloadable NHDPlus HR products only.
#   auto    = TNM first, then ArcGIS real-source path if TNM returns no usable package.
# All modes produce local high-def GeoJSON/FileGDB sources, then local json.gz render tiles.

STATES="${1:-${NHDPLUS_STATES:-ca az nv}}"
LOD="${NHDPLUS_LOD:-world}"
LIMIT="${NHDPLUS_TNM_LIMIT:-8}"
CACHE_DAYS="${NHDPLUS_STATE_CACHE_DAYS:-180}"
SRC_ROOT="${NHDPLUS_SRC_ROOT:-data_sources/nhdplus_hr_state_cache}"
OUT_ROOT="${NHDPLUS_OUT_ROOT:-static/data/nhdplus_hr/state_cache}"
TNM_SPLIT_DEG="${NHDPLUS_TNM_SPLIT_DEG:-1.0}"
ARCGIS_TILE_DEG="${NHD_ARCGIS_TILE_DEG:-0.5}"
ARCGIS_LAYERS="${NHD_ARCGIS_LAYERS:-6,9,12}"
DRY_RUN_FLAG="${NHDPLUS_DRY_RUN:+--dry-run}"
SOURCE_MODE="${NHDPLUS_SOURCE_MODE:-arcgis}"

bbox_for_state() {
  case "$1" in
    ca|CA) echo "-124.6,32.4,-114.0,42.1" ;;
    az|AZ) echo "-115.1,31.2,-109.0,37.1" ;;
    nv|NV) echo "-120.1,35.0,-114.0,42.1" ;;
    *) echo "Unknown state '$1'. Supported: ca az nv" >&2; return 2 ;;
  esac
}

mkdir -p "$SRC_ROOT" "$OUT_ROOT"

echo "LFTR high-def inland-water state sidecar cache installer"
echo "states=$STATES lod=$LOD cache_days=$CACHE_DAYS"
echo "source=$SRC_ROOT output=$OUT_ROOT"
echo "source_mode=$SOURCE_MODE no_mock_no_coarse_fallback"

for st in $STATES; do
  st_lc="$(echo "$st" | tr '[:upper:]' '[:lower:]')"
  bbox="$(bbox_for_state "$st_lc")"
  src="$SRC_ROOT/$st_lc"
  extract="$src/extracted"
  out="$OUT_ROOT/$st_lc/tiles"
  arcgis_src="$src/arcgis_nhd_large_scale.geojson.gz"
  mkdir -p "$src" "$extract" "$out"
  echo ""
  echo "=== $st_lc bbox=$bbox ==="

  if [[ "$SOURCE_MODE" == "tnm" || "$SOURCE_MODE" == "auto" ]]; then
    # TNM products are used only as real downloadable NHDPlus HR packages. The
    # fetcher saves malformed HTTP-200 TNM error bodies and exits cleanly.
    python3 scripts/fetch_nhdplus_hr_tnm.py       --bbox="$bbox"       --out="$src"       --limit "$LIMIT"       --cache-days "$CACHE_DAYS"       --split-deg "$TNM_SPLIT_DEG"       $DRY_RUN_FLAG || true
  else
    echo "[source] skipping TNM because source_mode=$SOURCE_MODE"
  fi

  if [[ -n "${NHDPLUS_DRY_RUN:-}" ]]; then
    echo "dry-run only for $st_lc; skipping extract/build"
    continue
  fi

  shopt -s nullglob
  for z in "$src"/*.zip; do
    marker="$extract/.$(basename "$z").unzipped"
    if [[ -f "$marker" ]]; then
      echo "[extract] cached $(basename "$z")"
      continue
    fi
    echo "[extract] $z"
    unzip -oq "$z" -d "$extract"
    touch "$marker"
  done

  mapfile -t GDBS < <(find "$extract" -type d -name '*.gdb' | sort)
  mapfile -t GEOJSONS < <(find "$extract" -type f \( -name '*.geojson' -o -name '*.geojson.gz' -o -name '*.json' -o -name '*.json.gz' \) | sort)

  # If no package exists yet, fetch real NHD large-scale vector geometry directly
  # by small bbox tiles from The National Map ArcGIS service. This is a strict
  # real-source path, not a visual/mock fallback.
  if [[ "$SOURCE_MODE" == "arcgis" || "$SOURCE_MODE" == "auto" ]] && (( ${#GDBS[@]} == 0 && ${#GEOJSONS[@]} == 0 )); then
    echo "[source] building $st_lc from USGS NHD ArcGIS large-scale real source"
    python3 scripts/fetch_nhd_arcgis_bbox.py \
      --bbox="$bbox" \
      --out="$arcgis_src" \
      --tile-deg "$ARCGIS_TILE_DEG" \
      --layers "$ARCGIS_LAYERS" \
      --cache-days "$CACHE_DAYS" \
      --page-size "${NHD_ARCGIS_PAGE_SIZE:-100}" \
      --max-records-per-layer-tile "${NHD_ARCGIS_MAX_RECORDS_PER_TILE:-1200}" || true
    if [[ -f "$arcgis_src" ]]; then
      GEOJSONS+=("$arcgis_src")
    fi
  fi

  if (( ${#GDBS[@]} > 0 )); then
    args=()
    for g in "${GDBS[@]}"; do args+=(--source-gdb "$g"); done
    echo "[build] $st_lc from FileGDB count=${#GDBS[@]}"
    python3 scripts/build_nhdplus_hr_tiles.py "${args[@]}" --out "$out" --bbox "$bbox"
  elif (( ${#GEOJSONS[@]} > 0 )); then
    args=()
    for g in "${GEOJSONS[@]}"; do args+=(--source-geojson "$g"); done
    echo "[build] $st_lc from GeoJSON count=${#GEOJSONS[@]}"
    python3 scripts/build_nhdplus_hr_tiles.py "${args[@]}" --out "$out" --bbox "$bbox"
  else
    echo "[warn] No real high-detail source found for $st_lc. Check $src/tnm_download_plan.json and $src/_arcgis_debug"
    continue
  fi

  if [[ -f "$out/index.json" ]]; then
    echo "[ok] installed $st_lc state cache: $out/index.json"
  else
    echo "[warn] build finished without $out/index.json"
  fi
  shopt -u nullglob
done

python3 scripts/check_nhdplus_hr_state_cache.py || true
