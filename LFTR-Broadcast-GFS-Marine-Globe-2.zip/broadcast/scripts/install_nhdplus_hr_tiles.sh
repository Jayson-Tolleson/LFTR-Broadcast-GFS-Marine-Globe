#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
VIEW_BBOX="${1:--126,29,-114,39}"
LOD="${NHDPLUS_LOD:-world}"
OUT="static/data/nhdplus_hr/tiles"
SRC_DIR="data_sources/nhdplus_hr"
mkdir -p "$SRC_DIR" "$OUT"
cat <<EOF
LFTR high-definition Inland Waters tile installer

Policy:
  view bbox -> full NHDPlus HR tile squares -> request source products for those squares
  build local json.gz tiles -> runtime displays full selected tiles
  no coarse/seed fallback data is generated

View bbox: $VIEW_BBOX
LOD:       $LOD
EOF
python3 scripts/plan_nhdplus_hr_tile_squares.py --bbox="$VIEW_BBOX" --lod "$LOD" --out "$SRC_DIR/tile_square_plan.json"
python3 scripts/fetch_nhdplus_hr_tnm.py --bbox="$VIEW_BBOX" --out "$SRC_DIR" --limit "${NHDPLUS_TNM_LIMIT:-12}" --full-tile-squares --lod "$LOD" ${NHDPLUS_DRY_RUN:+--dry-run}
cat <<EOF

Downloaded/source files are in: $SRC_DIR

Next, extract one downloaded FileGDB .zip, then build local display tiles, for example:

  unzip data_sources/nhdplus_hr/<downloaded-file>.zip -d data_sources/nhdplus_hr/extracted
  python3 scripts/build_nhdplus_hr_tiles.py \
    --source-gdb data_sources/nhdplus_hr/extracted/<something>.gdb \
    --out $OUT \
    --bbox "$VIEW_BBOX"

Or, if you already have high-detail GeoJSON:

  python3 scripts/build_nhdplus_hr_tiles.py \
    --source-geojson /path/to/inland_water.geojson \
    --out $OUT \
    --bbox "$VIEW_BBOX"

Check installation:

  test -f static/data/nhdplus_hr/tiles/index.json && echo "NHDPlus HR tiles installed"
EOF
