#!/usr/bin/env bash
set -euo pipefail

# Progressive, first-run Inland Waters sidecar builder.
# It fetches the current viewport as small real USGS/NHD ArcGIS source squares,
# and after EACH successful source square it appends render tiles + rewrites
# index.json.  The web route can therefore draw partial inland water as soon as
# one useful tile completes; it does not wait for every source square.

BBOX="${1:-${NHDPLUS_VIEW_BBOX:-${NHDPLUS_INITIAL_BBOX:--126,29,-114,39}}}"
CACHE_DAYS="${NHDPLUS_STATE_CACHE_DAYS:-180}"
SRC_ROOT="${NHDPLUS_SRC_ROOT:-data_sources/nhdplus_hr_state_cache}"
OUT_ROOT="${NHDPLUS_OUT_ROOT:-static/data/nhdplus_hr/state_cache}"
ARCGIS_TILE_DEG="${NHD_ARCGIS_TILE_DEG:-0.5}"
ARCGIS_LAYERS="${NHD_ARCGIS_LAYERS:-6,9,12}"
PAGE_SIZE="${NHD_ARCGIS_PAGE_SIZE:-100}"
MAX_RECORDS="${NHD_ARCGIS_MAX_RECORDS_PER_TILE:-1200}"
NHD_MIN_POLYGON_POINTS="${NHD_MIN_POLYGON_POINTS:-12}"
NHD_MIN_LINE_POINTS="${NHD_MIN_LINE_POINTS:-8}"
export NHD_MIN_POLYGON_POINTS NHD_MIN_LINE_POINTS
MAX_SOURCE_TILES="${NHD_ARCGIS_MAX_SOURCE_TILES:-${NHD_VIEW_MAX_SOURCE_TILES:-24}}"
PROGRESSIVE="${NHD_PROGRESSIVE_TILE_BUILD:-1}"

parse_bbox() {
  IFS=',' read -r W S E N <<< "$1"
  python3 - <<PY
w=float('$W'); s=float('$S'); e=float('$E'); n=float('$N')
assert w < e and s < n, 'invalid bbox'
print(f'{w},{s},{e},{n}')
PY
}

bbox_intersects_py() {
  python3 - "$1" "$2" <<'PY'
import sys
aw,as_,ae,an=[float(x) for x in sys.argv[1].split(',')]
bw,bs,be,bn=[float(x) for x in sys.argv[2].split(',')]
print('1' if not (ae < bw or aw > be or an < bs or as_ > bn) else '0')
PY
}

bbox_intersection_py() {
  python3 - "$1" "$2" <<'PY'
import sys
aw,as_,ae,an=[float(x) for x in sys.argv[1].split(',')]
bw,bs,be,bn=[float(x) for x in sys.argv[2].split(',')]
w=max(aw,bw); s=max(as_,bs); e=min(ae,be); n=min(an,bn)
if not (w < e and s < n):
    sys.exit(1)
print(f"{w:.6f},{s:.6f},{e:.6f},{n:.6f}")
PY
}

state_bbox() {
  case "$1" in
    ca) echo "-124.6,32.4,-114.0,42.1" ;;
    az) echo "-115.1,31.2,-109.0,37.1" ;;
    nv) echo "-120.1,35.0,-114.0,42.1" ;;
    *) return 1 ;;
  esac
}

plan_source_tiles() {
  python3 - "$1" "$2" "$3" <<'PY'
import math, sys
bbox=sys.argv[1]
step=float(sys.argv[2])
limit=max(1, int(float(sys.argv[3] or '24')))
w,s,e,n=[float(x) for x in bbox.split(',')]
cx=(w+e)/2; cy=(s+n)/2
tiles=[]
y=s
while y < n - 1e-9:
    y2=min(n, y+step)
    x=w
    while x < e - 1e-9:
        x2=min(e, x+step)
        tx=(x+x2)/2; ty=(y+y2)/2
        tiles.append(((tx-cx)**2+(ty-cy)**2, abs(tx-cx)+abs(ty-cy), x,y,x2,y2))
        x=x2
    y=y2
tiles.sort()
for _,__,x,y,x2,y2 in tiles[:limit]:
    print(f"{x:.6f},{y:.6f},{x2:.6f},{y2:.6f}")
PY
}

count_index_tiles() {
  python3 - "$1" <<'PY'
import json, sys
from pathlib import Path
p=Path(sys.argv[1])/'index.json'
try:
    data=json.loads(p.read_text())
    print(len(data.get('tiles') or []))
except Exception:
    print(0)
PY
}

BBOX="$(parse_bbox "$BBOX")"
mkdir -p "$SRC_ROOT" "$OUT_ROOT"

echo "LFTR progressive Inland Waters view sidecar builder"
echo "bbox=$BBOX"
echo "source_tile_deg=$ARCGIS_TILE_DEG cache_days=$CACHE_DAYS layers=$ARCGIS_LAYERS max_source_tiles=$MAX_SOURCE_TILES progressive=$PROGRESSIVE min_poly=$NHD_MIN_POLYGON_POINTS min_line=$NHD_MIN_LINE_POINTS"
echo "policy=first usable source square writes/updates index.json immediately; no mock/coarse fallback"

ANY=0
TOTAL_WRITTEN=0
for st in ca az nv; do
  sb="$(state_bbox "$st")"
  if [[ "$(bbox_intersects_py "$BBOX" "$sb")" != "1" ]]; then
    echo "[skip] $st not affected by bbox"
    continue
  fi
  # Build only the portion of the viewport that intersects the affected state.
  # Earlier first-run builds planned from the full ocean-heavy world bbox, so the
  # first 20+ source squares could be offshore and produce zero readable NHD
  # tiles.  State-clipping makes the first source square land-biased and lets one
  # successful tile draw quickly.
  BUILD_BBOX="$(bbox_intersection_py "$BBOX" "$sb")"
  ANY=1
  src="$SRC_ROOT/$st"
  out="$OUT_ROOT/$st/tiles"
  mkdir -p "$src" "$out"
  echo ""
  echo "=== $st affected; progressive fetch/build requested_bbox=$BBOX state_bbox=$BUILD_BBOX ==="

  if [[ "$PROGRESSIVE" != "1" && "$PROGRESSIVE" != "true" ]]; then
    source_file="$src/view_${BBOX//,/_}_arcgis_nhd_large_scale.geojson.gz"
    python3 scripts/fetch_nhd_arcgis_bbox.py \
      --bbox="$BUILD_BBOX" \
      --out="$source_file" \
      --tile-deg "$ARCGIS_TILE_DEG" \
      --layers "$ARCGIS_LAYERS" \
      --cache-days "$CACHE_DAYS" \
      --page-size "$PAGE_SIZE" \
      --max-records-per-layer-tile "$MAX_RECORDS" \
      --max-source-tiles "$MAX_SOURCE_TILES" || true
    if [[ -s "$source_file" ]]; then
      python3 scripts/build_nhdplus_hr_tiles.py --source-geojson "$source_file" --out "$out" --bbox "$BUILD_BBOX" --append || true
    fi
    continue
  fi

  i=0
  while IFS= read -r tb; do
    [[ -n "$tb" ]] || continue
    i=$((i+1))
    safe_tb="${tb//,/_}"
    source_file="$src/view_${safe_tb}_arcgis_nhd_large_scale.geojson.gz"
    before="$(count_index_tiles "$out")"
    echo "[progressive $st $i/$MAX_SOURCE_TILES] fetch source square $tb"
    if python3 scripts/fetch_nhd_arcgis_bbox.py \
      --bbox="$tb" \
      --out="$source_file" \
      --tile-deg "$ARCGIS_TILE_DEG" \
      --layers "$ARCGIS_LAYERS" \
      --cache-days "$CACHE_DAYS" \
      --page-size "$PAGE_SIZE" \
      --max-records-per-layer-tile "$MAX_RECORDS" \
      --max-source-tiles 1; then
        if [[ -s "$source_file" ]]; then
          echo "[progressive $st $i] append render tiles from $source_file"
          python3 scripts/build_nhdplus_hr_tiles.py \
            --source-geojson "$source_file" \
            --out "$out" \
            --bbox "$tb" \
            --append || true
          after="$(count_index_tiles "$out")"
          echo "[progressive $st $i] index tiles before=$before after=$after out=$out/index.json"
          if [[ "$after" -gt "$before" ]]; then
            TOTAL_WRITTEN=$((TOTAL_WRITTEN + after - before))
            # Keep going to improve coverage, but index.json is already readable now.
          fi
        fi
    else
      echo "[progressive $st $i] source square empty or failed; continuing"
    fi
  done < <(plan_source_tiles "$BUILD_BBOX" "$ARCGIS_TILE_DEG" "$MAX_SOURCE_TILES")
done

if [[ "$ANY" != "1" ]]; then
  echo "[warn] bbox does not intersect CA/AZ/NV; nothing built"
fi

echo "[progressive] complete; newly written/updated render tiles estimate=$TOTAL_WRITTEN"
python3 scripts/check_nhdplus_hr_state_cache.py || true
