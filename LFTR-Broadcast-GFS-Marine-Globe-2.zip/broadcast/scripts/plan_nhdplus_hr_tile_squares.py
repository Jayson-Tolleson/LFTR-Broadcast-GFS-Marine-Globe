#!/usr/bin/env python3
"""Plan full NHDPlus HR shoreline tile squares from a visible bbox.

The app runtime should not request a clipped shoreline bbox. It should:
  view bbox -> intersecting full tile squares -> request/build/display full tiles.
"""
from __future__ import annotations
import argparse, json, math
from pathlib import Path

LOD_TILE_DEG = {"world": 4.0, "regional": 2.0, "local": 1.0, "harbor": 0.25}


def parse_bbox(s: str) -> tuple[float, float, float, float]:
    w, south, e, n = [float(x.strip()) for x in s.split(",")]
    if e <= w or n <= south:
        raise SystemExit(f"Invalid bbox: {s}")
    return w, south, e, n


def tile_squares(bbox: tuple[float, float, float, float], tile_deg: float) -> list[dict]:
    w, s, e, n = bbox
    ix0 = math.floor(w / tile_deg); ix1 = math.ceil(e / tile_deg) - 1
    iy0 = math.floor(s / tile_deg); iy1 = math.ceil(n / tile_deg) - 1
    out = []
    for ix in range(ix0, ix1 + 1):
        for iy in range(iy0, iy1 + 1):
            tb = [ix * tile_deg, iy * tile_deg, (ix + 1) * tile_deg, (iy + 1) * tile_deg]
            out.append({"x": ix, "y": iy, "tile_deg": tile_deg, "bbox": tb, "bbox_string": ",".join(f"{v:.6f}" for v in tb)})
    return out


def main() -> int:
    ap = argparse.ArgumentParser(description="Plan full square NHDPlus HR tile requests from a view bbox")
    ap.add_argument("--bbox", required=True, help="view bbox west,south,east,north")
    ap.add_argument("--lod", default="world", choices=sorted(LOD_TILE_DEG))
    ap.add_argument("--tile-deg", type=float, default=None, help="override tile square size in degrees")
    ap.add_argument("--out", default=None, help="optional JSON output path")
    args = ap.parse_args()
    bbox = parse_bbox(args.bbox)
    tile_deg = float(args.tile_deg or LOD_TILE_DEG[args.lod])
    squares = tile_squares(bbox, tile_deg)
    union = [min(t["bbox"][0] for t in squares), min(t["bbox"][1] for t in squares), max(t["bbox"][2] for t in squares), max(t["bbox"][3] for t in squares)] if squares else list(bbox)
    payload = {"schema":"lftr_nhdplus_hr_tile_square_plan_v1", "input_bbox": list(bbox), "lod": args.lod, "tile_deg": tile_deg, "tile_count": len(squares), "tile_union_bbox": union, "tiles": squares}
    txt = json.dumps(payload, indent=2)
    if args.out:
        path = Path(args.out); path.parent.mkdir(parents=True, exist_ok=True); path.write_text(txt, encoding="utf-8")
    print(txt)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
