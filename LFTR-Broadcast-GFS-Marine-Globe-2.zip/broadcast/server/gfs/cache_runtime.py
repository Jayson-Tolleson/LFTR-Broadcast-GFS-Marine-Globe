"""Singleton runtime for LFTR /gfs cache-first engine."""
from __future__ import annotations

import os

from .cache_index import CacheIndex, FRESH_TARGET_SEC, STALE_AFTER_SEC, EXPIRED_AFTER_SEC
from .cache_store import CacheStore, utc_now_iso
from .intelligence_frame import IntelligenceFrameBuilder
from .tile_queue import TileQueue
from .tile_scheduler import TileScheduler
from .tile_workers import TileWorkers
from .ws_updates import GFSUpdateHub


class GFSCacheRuntime:
    def __init__(self, root: str | None = None, pad_factor: float | None = None) -> None:
        root = root or os.getenv("GFS_CACHE_DIR", ".cache/gfs_tiles")
        pad_factor = float(pad_factor if pad_factor is not None else os.getenv("GFS_VIEWPORT_PAD_FACTOR", "1.25"))
        self.store = CacheStore(root)
        self.index = CacheIndex(self.store)
        self.queue = TileQueue()
        self.hub = GFSUpdateHub()
        self.scheduler = TileScheduler(self.queue, self.index, self.hub, pad_factor=pad_factor)
        self.workers = TileWorkers(self.queue, self.store, self.index, self.hub, concurrency=int(os.getenv("GFS_TILE_WORKERS", "4")))
        self.frame_builder = IntelligenceFrameBuilder(self.store, self.index, self.scheduler, pad_factor=pad_factor)
        self.running = False

    async def start(self) -> None:
        if self.running:
            return
        await self.store.ensure_dirs()
        await self.index.load()
        await self.scheduler.start()
        await self.workers.start()
        self.running = True

    async def stop(self) -> None:
        await self.scheduler.stop()
        await self.workers.stop()
        self.running = False

    def health(self) -> dict:
        status_counts = self.index.status_counts()
        q = self.queue.stats()
        return {
            "enabled": True,
            "server_time": utc_now_iso(),
            "gfs_cache": {
                "enabled": True,
                "running": self.running,
                "loaded": self.index.loaded,
                "cache_path": str(self.store.root),
                "tiles_total": len(self.index.records),
                "fresh_tiles": status_counts.get("fresh", 0),
                "warm_tiles": status_counts.get("warm", 0),
                "stale_tiles": status_counts.get("stale", 0),
                "expired_tiles": status_counts.get("expired", 0),
                "failed_tiles": status_counts.get("failed", 0),
                "fresh_target_sec": FRESH_TARGET_SEC,
                "stale_after_sec": STALE_AFTER_SEC,
                "expired_after_sec": EXPIRED_AFTER_SEC,
                "queue_pending": q["pending"],
                "active_jobs": q["active"],
                "workers": self.workers.concurrency,
                "clients_connected": self.hub.client_count(),
            },
        }

    def cache_status(self) -> dict:
        q = self.queue.stats()
        return {
            "server_time": utc_now_iso(),
            "cache_path": str(self.store.root),
            "tiles_total": len(self.index.records),
            "by_status": self.index.status_counts(),
            "by_pill": self.index.by_pill_counts(),
            "queue": q,
            "clients_connected": self.hub.client_count(),
        }


_runtime: GFSCacheRuntime | None = None


def get_gfs_cache_runtime() -> GFSCacheRuntime:
    global _runtime
    if _runtime is None:
        _runtime = GFSCacheRuntime()
    return _runtime
