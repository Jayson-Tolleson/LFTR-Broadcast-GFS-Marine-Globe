from __future__ import annotations

import gzip
import json
import math
import os
import time
from pathlib import Path
from typing import Any

VIRIDIAN = "#40826D"
_INLAND_WATER_ROUTE_CACHE: dict[str, tuple[float, dict[str, Any]]] = {}
_INLAND_WATER_ROUTE_TTL_SEC = 3600.0
_INLAND_WATER_MISS_TTL_SEC = 3.0  # do not let no-data memory misses mask newly written disk sidecar tiles
STATE_CACHE_RETENTION_DAYS = 180
def _env_float(name: str, fallback: float) -> float:
    try:
        value = float(os.getenv(name, str(fallback)))
        return value if math.isfinite(value) else fallback
    except Exception:
        return fallback


def _env_int(name: str, fallback: int) -> int:
    try:
        value = int(float(os.getenv(name, str(fallback))))
        return value if value > 0 else fallback
    except Exception:
        return fallback


SURFACE_TEMP_CANDIDATES: list[tuple[str, list[str]]] = [
    ("surface", ["t0m", "TMP:surface", "TMP_surface", "skt", "SKT", "t", "TMP", "tmp"]),
    ("2m", ["t2m", "TMP", "t", "tmp"]),
]

# Production inland-water policy: do not draw approximate/demo shoreline.
# A feature must come from an accepted high-detail source and carry enough
# vertices to visually justify a shoreline claim.
MIN_HIGH_DEF_POLYGON_POINTS = max(8, _env_int("LFTR_INLAND_WATER_MIN_POLYGON_POINTS", 12))
MIN_HIGH_DEF_LINE_POINTS = max(4, _env_int("LFTR_INLAND_WATER_MIN_LINE_POINTS", 8))
# Draw only the most important inland-water features by default.  The high-detail
# NHD/NHDPlus sidecar tiles can contain thousands of small reaches/ponds; keeping
# the largest 25% by polygon area or line length gives a cleaner map and makes the
# hover/description layer focus on prominent water bodies.
INLAND_WATER_PROMINENCE_FRACTION = max(0.05, min(1.0, _env_float("LFTR_INLAND_WATER_PROMINENCE_FRACTION", 0.25)))
INLAND_WATER_MIN_PROMINENT_FEATURES = max(1, _env_int("LFTR_INLAND_WATER_MIN_PROMINENT_FEATURES", 8))
ACCEPTED_HIGH_DEF_SOURCE_HINTS = ("nhdplus", "3dhp", "nhdwaterbody", "nhdarea", "nhdflowline", "osm", "hydrolakes", "waterbody")
REJECT_SOURCE_HINTS = ("bootstrap", "seed", "demo", "coarse", "approx")
STATE_BBOXES = {
    "ca": {"west": -124.6, "south": 32.4, "east": -114.0, "north": 42.1},
    "az": {"west": -115.1, "south": 31.2, "east": -109.0, "north": 37.1},
    "nv": {"west": -120.1, "south": 35.0, "east": -114.0, "north": 42.1},
}
PRIMARY_STATE_CACHE_ORDER = ("ca", "az", "nv")

# High-definition-only inland water: coarse/seed geometry is intentionally not shipped.


def _num(v: Any, fallback: float = 0.0) -> float:
    try:
        out = float(v)
        return out if math.isfinite(out) else fallback
    except Exception:
        return fallback


def _bbox_dict(bbox: dict[str, float] | None) -> dict[str, float]:
    b = bbox or {"west": -180, "south": -80, "east": 180, "north": 80}
    return {"west": _num(b.get("west"), -180), "south": _num(b.get("south"), -80), "east": _num(b.get("east"), 180), "north": _num(b.get("north"), 80)}


def _point_in_bbox(lat: float, lng: float, bbox: dict[str, float], pad: float = 0.0) -> bool:
    west, east = bbox["west"] - pad, bbox["east"] + pad
    south, north = bbox["south"] - pad, bbox["north"] + pad
    return south <= lat <= north and west <= lng <= east


def _path_intersects(path: list[dict[str, Any]], bbox: dict[str, float]) -> bool:
    if not path:
        return False
    for p in path:
        if _point_in_bbox(_num(p.get("lat")), _num(p.get("lng", p.get("lon"))), bbox, pad=0.05):
            return True
    lats = [_num(p.get("lat"), float("nan")) for p in path]
    lngs = [_num(p.get("lng", p.get("lon")), float("nan")) for p in path]
    lats = [x for x in lats if math.isfinite(x)]
    lngs = [x for x in lngs if math.isfinite(x)]
    if not lats or not lngs:
        return False
    return not (max(lats) < bbox["south"] or min(lats) > bbox["north"] or max(lngs) < bbox["west"] or min(lngs) > bbox["east"])


def _normalize_path(raw: Any) -> list[dict[str, float]]:
    out: list[dict[str, float]] = []
    for p in raw or []:
        if isinstance(p, dict):
            lat = _num(p.get("lat"), float("nan"))
            lng = _num(p.get("lng", p.get("lon")), float("nan"))
        elif isinstance(p, (list, tuple)) and len(p) >= 2:
            lng = _num(p[0], float("nan"))
            lat = _num(p[1], float("nan"))
        else:
            continue
        if math.isfinite(lat) and math.isfinite(lng) and -90 <= lat <= 90 and -180 <= lng <= 180:
            prev = out[-1] if out else None
            if not prev or abs(prev["lat"] - lat) > 1e-8 or abs(prev["lng"] - lng) > 1e-8:
                out.append({"lat": lat, "lng": lng})
    if len(out) >= 2 and abs(out[0]["lat"] - out[-1]["lat"]) < 1e-8 and abs(out[0]["lng"] - out[-1]["lng"]) < 1e-8:
        out.pop()
    return out


def _lod_tier(scene_tier: str | None, lod: str | None = None) -> str:
    raw_lod = str(lod or "auto").lower()
    raw = str(scene_tier or "world").lower() if raw_lod in {"auto", ""} else raw_lod
    if raw in {"harbor", "close", "micro", "2048"}:
        return "harbor"
    if raw in {"local", "1024", "full"}:
        return "local"
    if raw in {"regional", "512"}:
        return "regional"
    if raw in {"world", "coarse", "256", "auto"}:
        return "world"
    return "world"


def _lod_max_points(scene_tier: str | None, lod: str | None = None) -> int:
    tier = _lod_tier(scene_tier, lod)
    return {"world": 160, "regional": 420, "local": 900, "harbor": 1800}.get(tier, 160)


def _lod_grid(scene_tier: str | None, lod: str | None = None) -> int:
    tier = _lod_tier(scene_tier, lod)
    return {"world": 256, "regional": 512, "local": 1024, "harbor": 2048}.get(tier, 256)


def _thin_path_for_lod(path: list[dict[str, float]], scene_tier: str | None, lod: str | None = None) -> list[dict[str, float]]:
    if len(path) <= 2:
        return path
    cap = _lod_max_points(scene_tier, lod)
    if len(path) <= cap:
        return path
    stride = max(1, math.ceil(len(path) / cap))
    out = path[::stride]
    if path[-1] not in out:
        out.append(path[-1])
    return out



def _path_bounds(path: list[dict[str, float]]) -> tuple[float, float, float, float] | None:
    lats = [p["lat"] for p in path if math.isfinite(float(p.get("lat", float("nan"))))]
    lngs = [p["lng"] for p in path if math.isfinite(float(p.get("lng", float("nan"))))]
    if not lats or not lngs:
        return None
    return min(lats), min(lngs), max(lats), max(lngs)


def _path_length_km(path: list[dict[str, float]]) -> float:
    if len(path) < 2:
        return 0.0
    total = 0.0
    for a, b in zip(path, path[1:]):
        lat1 = math.radians(float(a["lat"])); lat2 = math.radians(float(b["lat"]))
        lon1 = math.radians(float(a["lng"])); lon2 = math.radians(float(b["lng"]))
        mean_lat = (lat1 + lat2) * 0.5
        x = (lon2 - lon1) * math.cos(mean_lat)
        y = lat2 - lat1
        total += 6371.0088 * math.sqrt(x * x + y * y)
    return total


def _polygon_area_sqkm(path: list[dict[str, float]]) -> float:
    if len(path) < 3:
        return 0.0
    lat0 = math.radians(sum(float(p["lat"]) for p in path) / len(path))
    pts: list[tuple[float, float]] = []
    for p in path:
        x = 6371.0088 * math.radians(float(p["lng"])) * math.cos(lat0)
        y = 6371.0088 * math.radians(float(p["lat"]))
        pts.append((x, y))
    area = 0.0
    for (x1, y1), (x2, y2) in zip(pts, pts[1:] + pts[:1]):
        area += x1 * y2 - x2 * y1
    return abs(area) * 0.5


def _feature_prominence(item: dict[str, Any], *, is_line: bool = False) -> float:
    path = _normalize_path(item.get("source_path") or item.get("path") or [])
    if is_line:
        return _path_length_km(path)
    area = _polygon_area_sqkm(path)
    # Tiny/skinny polygons can still be meaningful coves or reservoirs, so keep a
    # little perimeter signal behind area without letting it dominate true lakes.
    return area + (_path_length_km(path) * 0.015)


def _prominence_filter(items: list[dict[str, Any]], *, is_line: bool = False, fraction: float | None = None) -> list[dict[str, Any]]:
    if not items:
        return []
    frac = INLAND_WATER_PROMINENCE_FRACTION if fraction is None else max(0.05, min(1.0, float(fraction)))
    if frac >= 0.999:
        return items
    ranked: list[tuple[float, int, dict[str, Any]]] = []
    for idx, item in enumerate(items):
        score = _feature_prominence(item, is_line=is_line)
        ranked.append((score, idx, item))
    ranked.sort(key=lambda x: (x[0], -x[1]), reverse=True)
    keep_n = max(INLAND_WATER_MIN_PROMINENT_FEATURES, math.ceil(len(ranked) * frac))
    keep_n = min(len(ranked), keep_n)
    keep_ids = {id(item) for _, _, item in ranked[:keep_n]}
    out = [item for item in items if id(item) in keep_ids]
    for item in out:
        item["prominence_score"] = round(_feature_prominence(item, is_line=is_line), 4)
        item["prominence_filter"] = f"top_{int(round(frac * 100))}_percent_by_{'length' if is_line else 'area'}"
    return out

def _accepted_high_def_item(item: dict[str, Any], *, is_line: bool = False) -> bool:
    path = _normalize_path(item.get("path") or [])
    need = MIN_HIGH_DEF_LINE_POINTS if is_line else MIN_HIGH_DEF_POLYGON_POINTS
    if len(path) < need:
        return False
    src = " ".join(str(item.get(k, "")) for k in ("source_class", "source", "source_path", "shoreline_truth", "geometry_quality")).lower()
    if any(h in src for h in REJECT_SOURCE_HINTS):
        return False
    if not any(h in src for h in ACCEPTED_HIGH_DEF_SOURCE_HINTS):
        return False
    return True


def _annotate_geometry(items: list[dict[str, Any]], *, scene_tier: str | None, lod: str | None, is_line: bool = False) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for item in items:
        raw_path = item.get("path") or []
        path = _normalize_path(raw_path)
        render_path = _thin_path_for_lod(path, scene_tier, lod)
        min_len = 2 if is_line else 3
        if len(render_path) < min_len:
            render_path = path
        annotated = dict(item)
        annotated["path"] = render_path
        annotated["source_path_points"] = len(path)
        annotated["render_path_points"] = len(render_path)
        annotated["lod_grid"] = _lod_grid(scene_tier, lod)
        annotated["lod_tier"] = _lod_tier(scene_tier, lod)
        annotated["shoreline_truth"] = "high_def_source_vector_retained" if _accepted_high_def_item(item, is_line=is_line) else "rejected_low_detail_or_untrusted_source"
        if _accepted_high_def_item(item, is_line=is_line):
            out.append(annotated)
    return out


def _geometry_diagnostics(polygons: list[dict[str, Any]], lines: list[dict[str, Any]], source: str, scene_tier: str | None, lod: str | None) -> dict[str, Any]:
    counts = [int(x.get("source_path_points") or len(x.get("path") or [])) for x in polygons + lines]
    render_counts = [int(x.get("render_path_points") or len(x.get("path") or [])) for x in polygons + lines]
    avg = (sum(counts) / len(counts)) if counts else 0.0
    lower_source = str(source).lower()
    quality = "high_detail_nhd_ready" if counts and avg >= 60 and not any(h in lower_source for h in REJECT_SOURCE_HINTS) else "no_accepted_high_def_shoreline"
    return {
        "geometry_quality": quality,
        "source_path_points_total": sum(counts),
        "render_path_points_total": sum(render_counts),
        "avg_source_path_points": round(avg, 2),
        "min_source_path_points": min(counts) if counts else 0,
        "max_source_path_points": max(counts) if counts else 0,
        "lod_tier": _lod_tier(scene_tier, lod),
        "lod_grid": _lod_grid(scene_tier, lod),
        "honest_shoreline_mode": "high_def_only; seed_or_coarse_sources_rejected; draw_nothing_until_nhdplus_hr_tiles_or_geojson_installed",
        "quality_gate": {"polygon_min_points": MIN_HIGH_DEF_POLYGON_POINTS, "line_min_points": MIN_HIGH_DEF_LINE_POINTS, "accepted_sources": list(ACCEPTED_HIGH_DEF_SOURCE_HINTS)},
    }


def _read_json_or_gzip(path: Path) -> Any:
    if path.suffix == ".gz":
        with gzip.open(path, "rt", encoding="utf-8") as fh:
            return json.load(fh)
    return json.loads(path.read_text())


def _features_from_geojson_data(data: Any, source_path: str) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    polygons: list[dict[str, Any]] = []
    lines: list[dict[str, Any]] = []
    features = data.get("features", []) if isinstance(data, dict) else []
    for feat in features:
        props = feat.get("properties") or {}
        geom = feat.get("geometry") or {}
        gtype = geom.get("type")
        coords = geom.get("coordinates") or []
        name = props.get("gnis_name") or props.get("name") or props.get("Name") or "Unnamed inland water"
        kind = props.get("kind") or props.get("ftype") or props.get("FType") or props.get("type") or "water"
        fcode = props.get("fcode") or props.get("FCode")
        source_class = props.get("source_class") or props.get("source") or "NHDPlus HR GeoJSON high detail"
        if gtype == "Polygon":
            for ring in coords[:1]:
                p = _normalize_path(ring)
                if len(p) >= 3:
                    polygons.append({"kind": str(kind).lower(), "name": name, "source_class": source_class, "fcode": fcode, "path": p, "source_path": source_path})
        elif gtype == "MultiPolygon":
            for poly in coords:
                if poly:
                    p = _normalize_path(poly[0])
                    if len(p) >= 3:
                        polygons.append({"kind": str(kind).lower(), "name": name, "source_class": source_class, "fcode": fcode, "path": p, "source_path": source_path})
        elif gtype == "LineString":
            p = _normalize_path(coords)
            if len(p) >= 2:
                lines.append({"kind": str(kind).lower(), "name": name, "source_class": source_class or "NHDFlowline high detail", "fcode": fcode, "path": p, "source_path": source_path})
        elif gtype == "MultiLineString":
            for line in coords:
                p = _normalize_path(line)
                if len(p) >= 2:
                    lines.append({"kind": str(kind).lower(), "name": name, "source_class": source_class or "NHDFlowline high detail", "fcode": fcode, "path": p, "source_path": source_path})
    return polygons, lines


def _bbox_intersects_bbox(a: dict[str, float], b: dict[str, float]) -> bool:
    return not (a["east"] < b["west"] or a["west"] > b["east"] or a["north"] < b["south"] or a["south"] > b["north"])


def _affected_states(bbox: dict[str, float]) -> list[str]:
    """Return preferred state sidecar caches that intersect the viewport bbox."""
    affected = [st for st in PRIMARY_STATE_CACHE_ORDER if _bbox_intersects_bbox(STATE_BBOXES[st], bbox)]
    return affected


def _state_cache_root(static_dir: Path) -> Path:
    return static_dir / "data" / "nhdplus_hr" / "state_cache"


def _state_tiles_root(static_dir: Path, state: str) -> Path:
    return _state_cache_root(static_dir) / state.lower() / "tiles"


def _tile_roots_for_bbox(static_dir: Path, bbox: dict[str, float]) -> list[tuple[str, Path]]:
    roots: list[tuple[str, Path]] = []
    global_root = _nhdplus_tiles_root(static_dir)
    if (global_root / "index.json").exists() or any(global_root.glob("*/*.json.gz")):
        roots.append(("global", global_root))
    for st in _affected_states(bbox):
        root = _state_tiles_root(static_dir, st)
        if (root / "index.json").exists() or any(root.glob("*/*.json.gz")):
            roots.append((st, root))
    return roots


def _state_cache_status(static_dir: Path, bbox: dict[str, float] | None = None) -> dict[str, Any]:
    b = _bbox_dict(bbox) if bbox else None
    affected = _affected_states(b) if b else list(PRIMARY_STATE_CACHE_ORDER)
    states = {}
    for st in PRIMARY_STATE_CACHE_ORDER:
        root = _state_tiles_root(static_dir, st)
        index = root / "index.json"
        tile_count = 0
        bytes_gz = 0
        if index.exists():
            try:
                data = json.loads(index.read_text())
                tiles = data.get("tiles", []) if isinstance(data, dict) else []
                tile_count = len(tiles)
            except Exception:
                tile_count = 0
        discovered_gz_tiles = 0
        if root.exists():
            for f in root.rglob("*.json.gz"):
                try:
                    discovered_gz_tiles += 1
                    bytes_gz += f.stat().st_size
                except Exception:
                    pass
        states[st] = {
            "installed": index.exists() or discovered_gz_tiles > 0,
            "index_exists": index.exists(),
            "affected_by_bbox": st in affected,
            "tiles": tile_count,
            "discovered_gz_tiles": discovered_gz_tiles,
            "partial_tiles_readable": bool(discovered_gz_tiles > 0),
            "bytes_gz": bytes_gz,
            "path": str(index),
            "retention_days": STATE_CACHE_RETENTION_DAYS,
        }
    global_installed = (_nhdplus_tiles_root(static_dir) / "index.json").exists()
    return {
        "status": "ok",
        "policy": "viewport cache-first: boot reads matching local json.gz first, then live-builds missing real NHD ArcGIS source tiles for the viewport/zoom and keeps them long-term",
        "primary_states": list(PRIMARY_STATE_CACHE_ORDER),
        "affected_states": affected,
        "global_tiles_installed": global_installed,
        "states": states,
        "accepted_runtime_sources": ["state_cache/<state>/tiles/index.json", "state_cache/<state>/tiles/**/*.json.gz", "tiles/index.json", "inland_water.geojson(.gz)"],
        "partial_draw_policy": "one completed json.gz tile plus/with a refreshed index is enough for partial drawing; all selected tiles are not required",
        "cache_retention_days": STATE_CACHE_RETENTION_DAYS,
    }



def _nhdplus_tiles_root(static_dir: Path) -> Path:
    return static_dir / "data" / "nhdplus_hr" / "tiles"


def _high_def_source_installed(static_dir: Path, bbox: dict[str, float] | None = None) -> bool:
    root = static_dir / "data" / "nhdplus_hr"
    b = _bbox_dict(bbox) if bbox else None
    if b and _tile_roots_for_bbox(static_dir, b):
        return True
    if (root / "tiles" / "index.json").exists():
        return True
    for st in PRIMARY_STATE_CACHE_ORDER:
        if (_state_tiles_root(static_dir, st) / "index.json").exists():
            return True
    for p in (
        root / "inland_water.geojson",
        root / "inland_water.geojson.gz",
        root / "ca" / "inland_water.geojson",
        root / "az" / "inland_water.geojson",
        root / "nv" / "inland_water.geojson",
    ):
        if p.exists():
            return True
    return False


def _tile_candidates_from_manifest(static_dir: Path, bbox: dict[str, float], tier: str, max_tiles: int = 12) -> tuple[list[Path], list[dict[str, Any]], dict[str, float] | None]:
    """Return full installed NHDPlus/state-cache tile squares intersecting bbox.

    Runtime reads local sidecar/global tile manifests only. The bbox chooses
    full tile squares; returned geometry is not clipped back to the viewport.
    State sidecars are preferred for CA/AZ/NV so we can download/build one
    whole state once and keep it for a long time.
    """
    selected_paths: list[Path] = []
    selected_meta: list[dict[str, Any]] = []
    seen: set[str] = set()

    def add_tile(root_label: str, root: Path, rel: str, tb: list[float] | tuple[float, float, float, float], lod: str, extra: dict[str, Any] | None = None) -> None:
        path = root / rel
        key = str(path.resolve())
        if key in seen or not path.exists():
            return
        tile_bbox = {"west": float(tb[0]), "south": float(tb[1]), "east": float(tb[2]), "north": float(tb[3])}
        if not _bbox_intersects_bbox(tile_bbox, bbox):
            return
        seen.add(key)
        selected_paths.append(path)
        selected_meta.append({
            "root": root_label,
            "lod": lod,
            "path": rel,
            "full_path": str(path),
            "bbox": [tile_bbox["west"], tile_bbox["south"], tile_bbox["east"], tile_bbox["north"]],
            **(extra or {}),
        })

    roots = _tile_roots_for_bbox(static_dir, bbox)
    # If no affected state cache is installed, still allow a legacy/global root
    # scan. Missing source should be instant.
    if not roots:
        root = _nhdplus_tiles_root(static_dir)
        if root.exists():
            roots = [("global", root)]

    for root_label, root in roots:
        manifest = root / "index.json"
        if manifest.exists():
            try:
                data = json.loads(manifest.read_text())
                tiles = data.get("tiles", []) if isinstance(data, dict) else []
                for tile in tiles:
                    if not isinstance(tile, dict):
                        continue
                    tb = tile.get("bbox")
                    rel = tile.get("path")
                    lod = str(tile.get("lod") or tile.get("tier") or tier).lower()
                    if not tb or not rel or (lod != tier and lod != "auto"):
                        continue
                    add_tile(root_label, root, str(rel), tb, lod, {"polygons": tile.get("polygons", 0), "lines": tile.get("lines", 0), "bytes_gz": tile.get("bytes_gz", 0)})
                    if len(selected_paths) >= max_tiles:
                        break
            except Exception:
                pass
        elif (root / tier).exists():
            for path in sorted((root / tier).rglob("*.json.gz")):
                try:
                    data = _read_json_or_gzip(path)
                    tb = data.get("bbox") if isinstance(data, dict) else None
                    if not tb:
                        continue
                    rel = str(path.relative_to(root))
                    add_tile(root_label, root, rel, tb, tier, {"polygons": len(data.get("polygons") or []), "lines": len(data.get("lines") or []), "bytes_gz": path.stat().st_size})
                    if len(selected_paths) >= max_tiles:
                        break
                except Exception:
                    continue
        if len(selected_paths) >= max_tiles:
            break

    if not selected_meta:
        return [], [], None
    union = {
        "west": min(float(t["bbox"][0]) for t in selected_meta),
        "south": min(float(t["bbox"][1]) for t in selected_meta),
        "east": max(float(t["bbox"][2]) for t in selected_meta),
        "north": max(float(t["bbox"][3]) for t in selected_meta),
    }
    return selected_paths, selected_meta, union

def _tile_json_gz_features(static_dir: Path, bbox: dict[str, float], scene_tier: str | None, lod: str | None, max_tiles: int = 12) -> tuple[list[dict[str, Any]], list[dict[str, Any]], str, list[dict[str, Any]], dict[str, float] | None]:
    tier = _lod_tier(scene_tier, lod)
    polys: list[dict[str, Any]] = []
    lines: list[dict[str, Any]] = []
    paths, selected_tiles, tile_union_bbox = _tile_candidates_from_manifest(static_dir, bbox, tier, max_tiles=max_tiles)
    for path in paths:
        try:
            data = _read_json_or_gzip(path)
        except Exception:
            continue
        tile_bbox = data.get("bbox") if isinstance(data, dict) else None
        if isinstance(data, dict) and ("polygons" in data or "lines" in data):
            for item in data.get("polygons") or []:
                item = dict(item)
                item.setdefault("source_class", "NHDPlus HR json.gz tile high detail")
                item.setdefault("source_path", str(path))
                item.setdefault("tile_bbox", tile_bbox)
                polys.append(item)
            for item in data.get("lines") or []:
                item = dict(item)
                item.setdefault("source_class", "NHDPlus HR json.gz tile high detail")
                item.setdefault("source_path", str(path))
                item.setdefault("tile_bbox", tile_bbox)
                lines.append(item)
        else:
            p, l = _features_from_geojson_data(data, str(path))
            for item in p + l:
                item.setdefault("tile_bbox", tile_bbox)
            polys.extend(p); lines.extend(l)
    return polys, lines, f"nhdplus_hr_json_gz_full_tiles:{len(paths)}" if paths else "no_nhdplus_hr_tiles", selected_tiles, tile_union_bbox

def _geojson_features(static_dir: Path) -> tuple[list[dict[str, Any]], list[dict[str, Any]], str]:
    roots = [
        static_dir / "data" / "nhdplus_hr" / "inland_water.geojson",
        static_dir / "data" / "nhdplus_hr" / "inland_water.geojson.gz",
        static_dir / "data" / "nhdplus_hr" / "ca" / "inland_water.geojson",
        static_dir / "data" / "nhdplus_hr" / "az" / "inland_water.geojson",
        static_dir / "data" / "nhdplus_hr" / "nv" / "inland_water.geojson",
    ]
    polygons: list[dict[str, Any]] = []
    lines: list[dict[str, Any]] = []
    used: list[str] = []
    for path in roots:
        if not path.exists():
            continue
        try:
            data = _read_json_or_gzip(path)
            p, l = _features_from_geojson_data(data, str(path))
        except Exception:
            continue
        polygons.extend(p); lines.extend(l); used.append(str(path))
    if used:
        return polygons, lines, ";".join(used)
    return [], [], "no_high_def_nhdplus_hr_source_installed"


def inland_water_payload(static_dir: Path, bbox: dict[str, float] | None, *, source: str = "auto", geometry: str = "vector", lod: str = "auto", scene_tier: str | None = None, max_tiles: int = 12) -> dict[str, Any]:
    b = _bbox_dict(bbox)
    if not _high_def_source_installed(static_dir, b):
        return {
            "ok": True,
            "status": "no_high_def_source",
            "source": "no_high_def_nhdplus_hr_source_installed_manifest_missing",
            "source_path": "none",
            "bbox": [b["west"], b["south"], b["east"], b["north"]],
            "query_bbox": [b["west"], b["south"], b["east"], b["north"]],
            "tile_bbox": None,
            "tile_square_mode": "manifest_missing_instant_no_data",
            "selected_tiles": [],
            "affected_states": _affected_states(b),
            "state_cache_status": _state_cache_status(static_dir, b),
            "polygons": [],
            "lines": [],
            "temperature_points": [],
            "temperature_point_count": 0,
            "count": 0,
            "cache": {"hit": False, "mode": "instant_manifest_missing", "ttl_seconds": 900, "retention_days": STATE_CACHE_RETENTION_DAYS},
            "message": "Install/build high-detail state sidecar tiles at static/data/nhdplus_hr/state_cache/{ca,az,nv}/tiles/index.json, or global tiles/index.json. Coarse seed data is intentionally rejected.",
            "contract": "lftr_inland_water_v3_full_tile_square_high_def_only",
        }
    try:
        mt = max(1, min(int(max_tiles or 12), 128))
    except Exception:
        mt = 12
    cache_key = ":".join(f"{b[k]:.4f}" for k in ("west", "south", "east", "north")) + f":{source}:{geometry}:{lod}:{scene_tier or 'auto'}:tiles{mt}"
    now = time.monotonic()
    cached = _INLAND_WATER_ROUTE_CACHE.get(cache_key)
    if cached:
        age = now - cached[0]
        cached_payload = cached[1]
        cached_status = str(cached_payload.get("status") or "") if isinstance(cached_payload, dict) else ""
        cached_count = int((cached_payload.get("count") or 0) if isinstance(cached_payload, dict) else 0)
        # Positive/renderable memory cache is useful.  But a previous no-data miss
        # must not mask a render cache that was written by the background builder
        # a few seconds later.  Re-check disk almost immediately for misses.
        ttl = _INLAND_WATER_MISS_TTL_SEC if cached_status == "no_high_def_source" or cached_count <= 0 else _INLAND_WATER_ROUTE_TTL_SEC
        if age < ttl:
            out = dict(cached_payload)
            out["cache"] = {"hit": True, "key": f"inland-water:{cache_key}", "ttl_seconds": int(ttl), "mode": "memory_full_tile_square_cache" if cached_count > 0 else "short_memory_miss_cache_disk_recheck_soon"}
            return out

    tile_polys, tile_lines, tile_source, selected_tiles, tile_union_bbox = _tile_json_gz_features(static_dir, b, scene_tier, lod, max_tiles=mt)
    geo_polys, geo_lines, geo_source = ([], [], "geojson_not_used_when_tile_manifest_present") if selected_tiles else _geojson_features(static_dir)
    cached_polys = tile_polys + geo_polys
    cached_lines = tile_lines + geo_lines
    source = tile_source if tile_polys or tile_lines or selected_tiles else geo_source
    polygons = cached_polys
    lines = cached_lines
    # Full-tile mode: bbox chooses the tile squares, but we return every accepted
    # high-definition feature inside those tiles. Do not clip features back to the
    # visible bbox, otherwise lakes/river reaches get partial and visually weird.
    clipped_polys_raw = polygons if selected_tiles else [p for p in polygons if _path_intersects(p.get("path") or [], b)]
    clipped_lines_raw = lines if selected_tiles else [l for l in lines if _path_intersects(l.get("path") or [], b)]
    accepted_polys = _annotate_geometry(clipped_polys_raw, scene_tier=scene_tier, lod=lod, is_line=False)
    accepted_lines = _annotate_geometry(clipped_lines_raw, scene_tier=scene_tier, lod=lod, is_line=True)
    clipped_polys = _prominence_filter(accepted_polys, is_line=False)
    clipped_lines = _prominence_filter(accepted_lines, is_line=True)
    diagnostics = _geometry_diagnostics(clipped_polys, clipped_lines, source, scene_tier, lod)
    diagnostics["prominence_filter"] = {
        "enabled": INLAND_WATER_PROMINENCE_FRACTION < 0.999,
        "fraction": INLAND_WATER_PROMINENCE_FRACTION,
        "polygon_basis": "area_sqkm_plus_small_perimeter_signal",
        "line_basis": "length_km",
        "polygons_before": len(accepted_polys),
        "polygons_after": len(clipped_polys),
        "lines_before": len(accepted_lines),
        "lines_after": len(clipped_lines),
        "min_features": INLAND_WATER_MIN_PROMINENT_FEATURES,
    }
    # Temperature labels are real-only. Do not emit bootstrap/estimated 68°F
    # points from geometry. Real labels arrive only when live surface-temperature
    # candidates or observed/gauge values are available.
    temperature_points: list[dict[str, Any]] = []
    out = {
        "ok": True,
        "status": "ok" if (clipped_polys or clipped_lines) else "no_high_def_source",
        "source": "nhdplus_hr_json_gz_or_geojson_high_def" if (clipped_polys or clipped_lines) else "no_high_def_nhdplus_hr_source_installed",
        "source_path": source,
        "bbox": [tile_union_bbox["west"], tile_union_bbox["south"], tile_union_bbox["east"], tile_union_bbox["north"]] if tile_union_bbox else [b["west"], b["south"], b["east"], b["north"]],
        "query_bbox": [b["west"], b["south"], b["east"], b["north"]],
        "tile_bbox": [tile_union_bbox["west"], tile_union_bbox["south"], tile_union_bbox["east"], tile_union_bbox["north"]] if tile_union_bbox else None,
        "selected_tiles": selected_tiles,
        "affected_states": _affected_states(b),
        "state_cache_status": _state_cache_status(static_dir, b),
        "tile_square_mode": "full_selected_tile_squares_displayed" if selected_tiles else "direct_geojson_bbox_selection",
        "query": {"source": source, "geometry": geometry, "lod": lod, "scene_tier": scene_tier or "auto", "max_tiles": mt},
        "geometry_mode": geometry,
        "style": {"fillColor": "rgba(0,160,210,0.045)", "strokeColor": VIRIDIAN, "strokeOpacity": 0.78, "fillOpacity": 0.045, "strokeWidth": 0.72, "extrudedHeight": 0},
        "polygons": clipped_polys,
        "lines": clipped_lines,
        "temperature_points": temperature_points,
        "temperature_point_count": len(temperature_points),
        "count": len(clipped_polys) + len(clipped_lines),
        "unfiltered_count": len(accepted_polys) + len(accepted_lines),
        "prominence_filter": diagnostics.get("prominence_filter"),
        "diagnostics": diagnostics,
        "geometry_quality": diagnostics.get("geometry_quality"),
        "cache": {"hit": False, "key": f"inland-water:{cache_key}", "ttl_seconds": int(_INLAND_WATER_ROUTE_TTL_SEC), "mode": "memory_bbox_tile_cache", "retention_days": STATE_CACHE_RETENTION_DAYS},
        "tile_cache_contract": "high-def-only local NHDPlus HR state sidecar/global json.gz tiles; view bbox selects full tile squares; full tiles are displayed; seed/coarse data rejected; cache retained long-term",
        "message": None if (clipped_polys or clipped_lines) else "Install high-detail state sidecar tiles at static/data/nhdplus_hr/state_cache/{ca,az,nv}/tiles/index.json or global tiles/index.json. Coarse seed data is intentionally rejected.",
        "contract": "lftr_inland_water_v3_full_tile_square_high_def_only",
    }
    # Only keep renderable payloads in long-lived memory.  Missing-source/no-data
    # responses are intentionally short-lived so freshly written disk sidecar
    # tiles can pop on the next viewport refresh or reload.
    if out.get("status") != "no_high_def_source" and int(out.get("count") or 0) > 0:
        _INLAND_WATER_ROUTE_CACHE[cache_key] = (now, out)
    else:
        _INLAND_WATER_ROUTE_CACHE[cache_key] = (now, out)
    return out


def _centroid(path: list[dict[str, Any]]) -> tuple[float, float] | None:
    pts = [(float(p["lat"]), float(p["lng"])) for p in path if isinstance(p, dict) and "lat" in p and "lng" in p]
    if not pts:
        return None
    return sum(p[0] for p in pts) / len(pts), sum(p[1] for p in pts) / len(pts)


def _path_sample_points(path: list[dict[str, Any]], *, max_points: int = 5) -> list[tuple[float, float]]:
    pts = [(float(p["lat"]), float(p["lng"])) for p in path if isinstance(p, dict) and "lat" in p and "lng" in p]
    if not pts:
        return []
    if len(pts) <= max_points:
        return pts
    out: list[tuple[float, float]] = []
    for i in range(max_points):
        idx = round(i * (len(pts) - 1) / max(1, max_points - 1))
        out.append(pts[idx])
    return out


def _temperature_point(item: dict[str, Any], lat: float, lng: float, temp_f: float | None, source: str | None, confidence: str | None, idx: int = 0) -> dict[str, Any]:
    name = item.get("name") or "Inland water"
    return {
        "id": f"{str(name).lower().replace(' ', '-')[:48]}-{idx}",
        "name": name,
        "kind": item.get("kind"),
        "lat": round(float(lat), 6),
        "lng": round(float(lng), 6),
        "water_temp_f": round(float(temp_f), 1) if temp_f is not None else None,
        "source": source or "estimated_surface_temp",
        "confidence": confidence or "low",
    }


def _meters_to_lat_deg(meters: float) -> float:
    return float(meters) / 111320.0


def _meters_to_lon_deg(meters: float, lat: float) -> float:
    return float(meters) / max(1e-6, 111320.0 * max(0.15, math.cos(math.radians(lat))))


def _ellipse_zone(lat: float, lng: float, radius_m: float, *, aspect: float = 1.6, angle_deg: float = 0.0, points: int = 10) -> list[dict[str, float]]:
    pts: list[dict[str, float]] = []
    ang = math.radians(angle_deg)
    for i in range(points):
        t = (math.pi * 2.0 * i) / points
        x = math.cos(t) * radius_m * aspect
        y = math.sin(t) * radius_m
        xr = (x * math.cos(ang)) - (y * math.sin(ang))
        yr = (x * math.sin(ang)) + (y * math.cos(ang))
        pts.append({
            "lat": round(lat + _meters_to_lat_deg(yr), 6),
            "lng": round(lng + _meters_to_lon_deg(xr, lat), 6),
        })
    return pts


def _segment_zone(a: tuple[float, float], b: tuple[float, float], width_m: float) -> list[dict[str, float]]:
    lat1, lon1 = a
    lat2, lon2 = b
    dx = (lon2 - lon1) * math.cos(math.radians((lat1 + lat2) * 0.5))
    dy = (lat2 - lat1)
    mag = math.hypot(dx, dy)
    if mag <= 1e-9:
        return _ellipse_zone(lat1, lon1, width_m * 0.9, aspect=1.3, angle_deg=0.0, points=8)
    px = -dy / mag
    py = dx / mag
    off_lat = _meters_to_lat_deg(width_m)
    off_lon = _meters_to_lon_deg(width_m, (lat1 + lat2) * 0.5)
    return [
        {"lat": round(lat1 + py * off_lat, 6), "lng": round(lon1 + px * off_lon, 6)},
        {"lat": round(lat2 + py * off_lat, 6), "lng": round(lon2 + px * off_lon, 6)},
        {"lat": round(lat2 - py * off_lat, 6), "lng": round(lon2 - px * off_lon, 6)},
        {"lat": round(lat1 - py * off_lat, 6), "lng": round(lon1 - px * off_lon, 6)},
    ]


def _inland_bait_zones_for_item(item: dict[str, Any], temp_f: float, score: float, source: str | None, confidence: str | None) -> list[dict[str, Any]]:
    path = item.get("path") or []
    pts = [(float(p["lat"]), float(p["lng"])) for p in path if isinstance(p, dict) and "lat" in p and "lng" in p]
    if len(pts) < 2:
        return []
    zones: list[dict[str, Any]] = []
    base_radius = 180 + max(0.0, score - 1.0) * 90.0
    width_m = 110 + max(0.0, score - 1.0) * 55.0
    name = item.get("name") or "Inland water"
    kind = str(item.get("kind") or "water").lower()
    if kind in {"reservoir", "lake", "pond"}:
        samples = _path_sample_points(path, max_points=4 if score >= 3 else 3)
        centroid = _centroid(path)
        for idx, (plat, plng) in enumerate(samples):
            zone_kind = "shoreline_bait_zone"
            angle = (idx * 37.0) % 180.0
            zones.append({
                "id": f"{str(name).lower().replace(' ', '-')[:40]}-lake-zone-{idx}",
                "name": name,
                "kind": zone_kind,
                "path": _ellipse_zone(plat, plng, base_radius * (0.95 + idx * 0.10), aspect=1.8, angle_deg=angle, points=10),
                "bait_score": round(score, 2),
                "water_temp_est_f": round(temp_f, 1),
                "source": source or "estimated_surface_temp",
                "confidence": confidence or "low",
                "reason": "shoreline structure + freshwater thermal bait heuristic",
            })
        if centroid and score >= 2.2:
            zones.append({
                "id": f"{str(name).lower().replace(' ', '-')[:40]}-lake-core",
                "name": name,
                "kind": "open_water_bait_zone",
                "path": _ellipse_zone(centroid[0], centroid[1], base_radius * 0.72, aspect=1.45, angle_deg=12.0, points=9),
                "bait_score": round(max(1.0, score - 0.25), 2),
                "water_temp_est_f": round(temp_f, 1),
                "source": source or "estimated_surface_temp",
                "confidence": confidence or "low",
                "reason": "open-water suspended bait possibility",
            })
    else:
        segment_count = min(4, max(2, len(pts) - 1))
        if len(pts) - 1 <= segment_count:
            indices = list(range(len(pts) - 1))
        else:
            indices = [round(i * (len(pts) - 2) / max(1, segment_count - 1)) for i in range(segment_count)]
        seen = set()
        for idx in indices:
            if idx in seen or idx >= len(pts) - 1:
                continue
            seen.add(idx)
            a = pts[idx]
            b = pts[idx + 1]
            zones.append({
                "id": f"{str(name).lower().replace(' ', '-')[:40]}-river-zone-{idx}",
                "name": name,
                "kind": "channel_bait_zone",
                "path": _segment_zone(a, b, width_m),
                "bait_score": round(score, 2),
                "water_temp_est_f": round(temp_f, 1),
                "source": source or "estimated_surface_temp",
                "confidence": confidence or "low",
                "reason": "current seam / bend reach + freshwater thermal bait heuristic",
            })
    return zones


def _dist2(a: tuple[float, float], b: tuple[float, float]) -> float:
    return (a[0] - b[0]) ** 2 + ((a[1] - b[1]) * math.cos(math.radians((a[0] + b[0]) / 2))) ** 2


def nearest_water(static_dir: Path, lat: float, lon: float, bbox: dict[str, float] | None = None) -> dict[str, Any] | None:
    b = _bbox_dict(bbox or {"west": lon - 0.8, "south": lat - 0.8, "east": lon + 0.8, "north": lat + 0.8})
    payload = inland_water_payload(static_dir, b)
    candidates = []
    for item in payload.get("polygons", []) + payload.get("lines", []):
        c = _centroid(item.get("path") or [])
        if c:
            candidates.append((_dist2((lat, lon), c), c, item))
    if not candidates:
        return None
    candidates.sort(key=lambda x: x[0])
    d2, c, item = candidates[0]
    return {**item, "centroid": {"lat": c[0], "lng": c[1]}, "distance_deg2": d2}


def _k_to_f(k: float | None) -> float | None:
    if k is None or not math.isfinite(k):
        return None
    return round(((k - 273.15) * 9.0 / 5.0) + 32.0, 1)


def _sample_nearest(lat2d: Any, lon2d: Any, arr: Any, lat: float, lon: float) -> float | None:
    try:
        import numpy as np
        la = np.asarray(lat2d, dtype=float)
        lo = np.asarray(lon2d, dtype=float)
        va = np.asarray(arr, dtype=float)
        if la.shape != va.shape or lo.shape != va.shape or va.size == 0:
            return None
        # normalize 0..360 longitude grids if needed
        target_lon = lon if np.nanmin(lo) < 0 else (lon + 360 if lon < 0 else lon)
        d = np.square(la - lat) + np.square((lo - target_lon) * np.cos(np.radians(lat)))
        idx = np.unravel_index(np.nanargmin(d), d.shape)
        v = float(va[idx])
        return v if math.isfinite(v) else None
    except Exception:
        return None


def sample_surface_temperature(svc: Any, bbox: dict[str, float], lat: float, lon: float, live: bool = False) -> dict[str, Any]:
    result = {"requested_candidates": ["t0m", "TMP:surface", "skt", "t2m"], "used": None, "value_k": None, "value_f": None, "source": "not_sampled"}
    if not live:
        result["source"] = "set_live=1_to_fetch_ncss_candidate_surface_temperature"
        return result
    try:
        ingest = svc.ingest_latest_model_fields(bbox)
        groups = ingest.get("groups") or {}
        sample_ds = groups.get("surface") or groups.get("2m") or groups.get("10m") or groups.get("isobaricInhPa")
        lat2d, lon2d = svc.ensure_lat_lon_2d(sample_ds)
        for group_name, names in SURFACE_TEMP_CANDIDATES:
            ds = groups.get(group_name)
            da = svc.safe_data_var(ds, names)
            da = svc.squeeze_forecast_array(da)
            if da is None:
                continue
            vals = getattr(da, "values", None)
            k = _sample_nearest(lat2d, lon2d, vals, lat, lon)
            if k is not None:
                result.update({"used": f"{group_name}:{names[0]}", "value_k": round(k, 2), "value_f": _k_to_f(k), "source": "gfs_ncss_surface_candidate"})
                return result
    except Exception as exc:
        result.update({"source": "gfs_ncss_surface_candidate_failed", "error": str(exc)})
    return result


def inland_conditions_payload(static_dir: Path, svc: Any, bbox: dict[str, float] | None, lat: float, lon: float, live: bool = False) -> dict[str, Any]:
    b = _bbox_dict(bbox or {"west": lon - 0.2, "south": lat - 0.2, "east": lon + 0.2, "north": lat + 0.2})
    water = nearest_water(static_dir, lat, lon, b)
    temp = sample_surface_temperature(svc, b, lat, lon, live=live)
    water_temp_f = temp.get("value_f")
    confidence = "medium" if water_temp_f is not None and live else "unavailable"
    temp_points = []
    if water_temp_f is not None and live:
        temp_points.append(_temperature_point(water or {"name": "viewport inland water", "kind": "sample"}, lat, lon, water_temp_f, temp.get("used") or temp.get("source"), confidence, 0))
    return {
        "ok": True,
        "status": "ok",
        "source": "usgs_nhdplus_hr_plus_gfs_ncss_surface_candidates",
        "bbox": [b["west"], b["south"], b["east"], b["north"]],
        "query": {"lat": lat, "lon": lon},
        "inland_water": bool(water),
        "nearest_water": water,
        "surface_temperature": temp,
        "water_temp_f": water_temp_f,
        "water_temp_est_f": None,
        "water_temp_confidence": confidence,
        "temperature_points": temp_points,
        "temperature_point_count": len(temp_points),
        "note": "Real-only temperature policy: no bootstrap 68°F and no estimated labels. t0m/TMP:surface/skt labels appear only when live candidate sampling succeeds.",
        "contract": "lftr_inland_conditions_v2_real_temperature_only",
    }


def inland_bait_payload(static_dir: Path, svc: Any, bbox: dict[str, float] | None, lat: float | None = None, lon: float | None = None, live: bool = False) -> dict[str, Any]:
    b = _bbox_dict(bbox)
    water = inland_water_payload(static_dir, b)
    targets = []
    temperature_points: list[dict[str, Any]] = []
    zones: list[dict[str, Any]] = []
    for item in water.get("polygons", []) + water.get("lines", []):
        c = _centroid(item.get("path") or [])
        if not c:
            continue

        # Default: fast geometry-only bait. Do not call GFS/NCSS and do not
        # manufacture 68°F temps unless live=1 explicitly succeeds.
        temp: float | None = None
        source: str | None = None
        confidence: str | None = "unavailable"
        if live:
            cond = inland_conditions_payload(static_dir, svc, {"west": c[1] - 0.15, "south": c[0] - 0.15, "east": c[1] + 0.15, "north": c[0] + 0.15}, c[0], c[1], live=True)
            temp = cond.get("water_temp_f") if cond.get("water_temp_f") is not None else None
            source = cond.get("surface_temperature", {}).get("used") or cond.get("surface_temperature", {}).get("source")
            confidence = cond.get("water_temp_confidence")

        kind = str(item.get("kind") or "water").lower()
        type_bonus = 0.45 if kind in {"reservoir", "lake", "pond"} else 0.25
        if temp is not None:
            temp_score = max(0.0, 1.0 - abs(float(temp) - 67.0) / 24.0)
            score = max(1.0, min(5.0, 1.0 + 4.0 * (0.58 * temp_score + type_bonus * 0.22)))
        else:
            # Honest non-temperature freshwater structure score.
            score = max(1.0, min(5.0, 2.2 + type_bonus))

        target = {
            "name": item.get("name"),
            "kind": item.get("kind"),
            "centroid": {"lat": c[0], "lng": c[1]},
            "bait_score": round(score, 2),
            "temperature_source": source,
            "confidence": confidence,
            "reasons": ["NHD/NHDPlus HR waterbody geometry", "freshwater structure heuristic", "temperature omitted unless live t0m/TMP:surface/skt sampling succeeds"],
        }
        if temp is not None:
            target["water_temp_f"] = round(float(temp), 1)
        targets.append(target)

        zones.extend(_inland_bait_zones_for_item(item, float(temp) if temp is not None else 67.0, score, source, confidence))
        # Strip non-real temp fields from zones when no real sample exists.
        if temp is None:
            for z in zones[-6:]:
                z.pop("water_temp_est_f", None)
                z["source"] = "freshwater_structure_no_temperature"
                z["confidence"] = "temperature_unavailable"

        if temp is not None:
            sample_count = 5 if item.get("kind") in {"reservoir", "lake", "pond"} else 4
            for idx, (plat, plng) in enumerate(_path_sample_points(item.get("path") or [], max_points=sample_count)):
                temperature_points.append(_temperature_point(item, plat, plng, float(temp), source, confidence, idx))
    return {
        "ok": True,
        "status": "ok",
        "source": "inland_water_conditions_bait_v3_real_temperature_only",
        "bbox": water.get("bbox"),
        "targets": targets,
        "zones": zones,
        "temperature_points": temperature_points,
        "count": len(targets),
        "zone_count": len(zones),
        "temperature_point_count": len(temperature_points),
        "temperature_policy": "no estimated labels; no fallback 68F; real temps only when live candidate sampling succeeds",
        "contract": "lftr_inland_bait_v3_real_temperature_only",
    }
