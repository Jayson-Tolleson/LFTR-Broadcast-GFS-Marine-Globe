from __future__ import annotations

import asyncio
import logging
import math
import os
import subprocess
import time
from pathlib import Path
from typing import Any, Callable

from quart import Blueprint, current_app, jsonify, request, websocket

from server.gfs_service import GFSService
from server.gfs.sky import sky_payload
from server.gfs.inland_water import inland_water_payload, inland_conditions_payload, inland_bait_payload, _state_cache_status

log = logging.getLogger("server.gfs.routes")
_INLAND_BUILD_JOBS: dict[str, dict[str, Any]] = {}


def _parse_bbox() -> dict[str, float] | None:
    raw = (request.args.get("bbox") or "").strip()
    if not raw:
        return None
    try:
        west, south, east, north = [float(x.strip()) for x in raw.split(",")[:4]]
        return {"west": west, "south": south, "east": east, "north": north}
    except Exception:
        return None


def _parse_visible_bbox() -> dict[str, float] | None:
    raw = (request.args.get("visible_bbox") or request.args.get("visibleBbox") or "").strip()
    if raw:
        try:
            west, south, east, north = [float(x.strip()) for x in raw.split(",")[:4]]
            return {"west": west, "south": south, "east": east, "north": north}
        except Exception:
            pass
    vp = (request.args.get("viewport") or "").strip()
    if vp:
        try:
            import json
            data = json.loads(vp)
            vb = data.get("visibleBbox") or data.get("visible_bbox")
            if isinstance(vb, dict):
                return {"west": float(vb["west"]), "south": float(vb["south"]), "east": float(vb["east"]), "north": float(vb["north"])}
            return {"west": float(data["west"]), "south": float(data["south"]), "east": float(data["east"]), "north": float(data["north"])}
        except Exception:
            return None
    return None


def _bbox_to_query(bbox: dict[str, float] | None) -> str:
    b = bbox or {"west": -126.0, "south": 29.0, "east": -114.0, "north": 39.0}
    return f"{float(b['west']):.4f},{float(b['south']):.4f},{float(b['east']):.4f},{float(b['north']):.4f}"


def _inland_build_key(bbox: dict[str, float] | None, tier: str | None) -> str:
    b = bbox or {}
    return ":".join([
        f"{float(b.get('west', -126.0)):.2f}",
        f"{float(b.get('south', 29.0)):.2f}",
        f"{float(b.get('east', -114.0)):.2f}",
        f"{float(b.get('north', 39.0)):.2f}",
        str(tier or 'world'),
    ])


def _launch_inland_view_build(static_dir: Path, bbox: dict[str, float] | None, scene_tier: str | None = None) -> dict[str, Any]:
    """Start a post-install, viewport-scoped real NHD sidecar build.

    This is intentionally not called by the installer by default and is never a
    fake/coarse fallback. On page load/viewport change it fetches real NHD
    ArcGIS source squares only for the current view/zoom, writes long-lived
    source cache files, then builds local json.gz sidecar tiles. The Inland
    Waters route always reads matching disk tiles first, then starts this live
    viewport build for missing squares.
    """
    bbox_q = _bbox_to_query(bbox)
    key = _inland_build_key(bbox, scene_tier)
    now = time.time()
    existing = _INLAND_BUILD_JOBS.get(key)
    if existing and existing.get("running") and now - float(existing.get("started_at") or 0) < 1800:
        return {**existing, "deduped": True}
    app_root = static_dir.parent
    script = app_root / "scripts" / "install_nhdplus_hr_view_cache.sh"
    if not script.exists():
        return {"status": "error", "running": False, "error": "install_nhdplus_hr_view_cache.sh_missing", "script": str(script)}
    log_dir = app_root / "data_sources" / "nhdplus_hr_state_cache" / "_build_logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_path = log_dir / ("inland_build_" + key.replace(":", "_").replace(",", "_") + ".log")
    env = os.environ.copy()
    env.setdefault("NHDPLUS_STATE_CACHE_DAYS", "180")
    # Smaller source squares on close zoom keep individual ArcGIS requests fast.
    tier = str(scene_tier or "world").lower()
    if tier in {"harbor", "local"}:
        env.setdefault("NHD_ARCGIS_TILE_DEG", "0.25")
        env.setdefault("NHD_ARCGIS_PAGE_SIZE", "50")
        env.setdefault("NHD_ARCGIS_MAX_SOURCE_TILES", "24")
    elif tier in {"regional"}:
        env.setdefault("NHD_ARCGIS_TILE_DEG", "0.5")
        env.setdefault("NHD_ARCGIS_PAGE_SIZE", "80")
        env.setdefault("NHD_ARCGIS_MAX_SOURCE_TILES", "32")
    else:
        env.setdefault("NHD_ARCGIS_TILE_DEG", "0.5")
        env.setdefault("NHD_ARCGIS_PAGE_SIZE", "100")
        env.setdefault("NHD_ARCGIS_MAX_SOURCE_TILES", "24")
    env.setdefault("NHD_ARCGIS_MAX_RECORDS_PER_TILE", "1200")
    env["NHDPLUS_VIEW_BBOX"] = bbox_q
    cmd = ["bash", str(script), bbox_q]
    with open(log_path, "ab") as fh:
        fh.write((f"\\n=== inland build start {time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())} bbox={bbox_q} tier={tier} ===\\n").encode())
        proc = subprocess.Popen(cmd, cwd=str(app_root), stdout=fh, stderr=subprocess.STDOUT, env=env, start_new_session=True)
    job = {"status": "started", "running": True, "pid": proc.pid, "bbox": bbox_q, "scene_tier": tier, "key": key, "started_at": now, "log": str(log_path), "source": "real_usgs_nhd_arcgis_view_tiles_only"}
    _INLAND_BUILD_JOBS[key] = job
    return job


def _svc(static_dir: Path) -> GFSService:
    svc = current_app.extensions.get("gfs_service")
    if svc is None:
        svc = GFSService(str(static_dir))
        current_app.extensions["gfs_service"] = svc
    return svc


async def _call_sync(fn: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
    return await asyncio.to_thread(fn, *args, **kwargs)


def _json_clean(value: Any, depth: int = 0) -> Any:
    """Return a JSON-safe object so endpoint errors do not become nginx 502s.

    This intentionally accepts numpy scalars/arrays, NaN/Inf, Path objects, sets,
    and other accidental provider objects that can leak out of NCSS/netCDF paths.
    """
    if depth > 32:
        return str(value)
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    # numpy scalar/array compatibility without importing numpy.
    if hasattr(value, "item"):
        try:
            return _json_clean(value.item(), depth + 1)
        except Exception:
            pass
    if hasattr(value, "tolist"):
        try:
            return _json_clean(value.tolist(), depth + 1)
        except Exception:
            pass
    if isinstance(value, dict):
        out: dict[str, Any] = {}
        for k, v in value.items():
            try:
                key = str(k)
            except Exception:
                key = repr(k)
            out[key] = _json_clean(v, depth + 1)
        return out
    if isinstance(value, (list, tuple, set)):
        return [_json_clean(v, depth + 1) for v in value]
    try:
        return str(value)
    except Exception:
        return repr(value)


def _json(payload: Any, status: int = 200):
    return jsonify(_json_clean(payload)), status


def _endpoint_shell(endpoint: str, exc: Exception, bbox: dict[str, float] | None = None) -> dict[str, Any]:
    return {
        "ok": False,
        "endpoint": endpoint,
        "source": f"{endpoint.strip('/').replace('/', '_')}_error_caught",
        "payload_state": "provider_failed",
        "bbox": bbox,
        "error": str(exc),
        "note": "Endpoint caught exception and returned JSON status 200 so the browser does not see GET non-ok/502.",
    }


def create_gfs_blueprint(static_dir: Path) -> Blueprint:
    bp = Blueprint("gfs", __name__)

    @bp.get("/gfs")
    async def gfs_page():
        from quart import send_file
        return await send_file(str(static_dir / "indexgfs.html"))

    @bp.get("/gfs/api/health")
    async def health():
        return jsonify(await _call_sync(_svc(static_dir).health_payload))

    @bp.get("/gfs/api/config")
    async def config():
        payload = await _call_sync(_svc(static_dir).config_payload)
        # Frontend currently opens /ws/gfs, so advertise that exact endpoint.
        if isinstance(payload, dict):
            payload["ws_base"] = "/ws/gfs"
        return jsonify(payload)

    @bp.get("/gfs/api/status")
    async def status():
        return jsonify(await _call_sync(_svc(static_dir).status_payload))

    @bp.get("/gfs/api/sky")
    async def sky():
        try:
            lat = float(request.args.get("lat", ""))
            lon = float(request.args.get("lon", ""))
        except Exception:
            return _json({
                "ok": False,
                "schema": "lftr_gfs_sky_v1",
                "error": "invalid_lat_lon",
                "note": "Provide numeric lat and lon query params."
            }, 400)
        if not (math.isfinite(lat) and math.isfinite(lon)) or abs(lat) > 90 or abs(lon) > 540:
            return _json({
                "ok": False,
                "schema": "lftr_gfs_sky_v1",
                "error": "invalid_lat_lon",
                "note": "lat must be -90..90 and lon should be a finite longitude."
            }, 400)
        payload = sky_payload(lat, lon)
        log.debug("[gfs/sky] updated mode=%s sun=%.2f lat=%.3f lon=%.3f", payload.get("mode"), payload.get("sun_elevation_deg"), payload.get("lat"), payload.get("lon"))
        return _json(payload)

    @bp.get("/gfs/api/weather")
    async def weather():
        return jsonify(await _call_sync(_svc(static_dir).generate_weather_payload, _parse_bbox()))

    @bp.get("/gfs/api/clouds")
    async def clouds():
        bbox = _parse_bbox()
        try:
            payload = await _call_sync(_svc(static_dir).cloud_tiles_payload, bbox, _parse_visible_bbox())
            return _json(payload)
        except Exception as exc:
            log.exception("/gfs/api/clouds failed")
            shell = _endpoint_shell("/gfs/api/clouds", exc, bbox)
            shell.update({"items": [], "tiles": [], "cloud_regions": [], "precip_columns": [], "features": []})
            return _json(shell)

    @bp.get("/gfs/api/frame")
    async def frame():
        bbox = _parse_bbox()
        try:
            # frame_payload is intentionally lightweight/controller-only by
            # default, so avoid the shared executor.  This keeps /gfs/api/frame
            # responsive even while sea/cloud/tile warmers occupy worker threads.
            return _json(_svc(static_dir).frame_payload(bbox, _parse_visible_bbox()))
        except Exception as exc:
            log.exception("/gfs/api/frame failed")
            shell = _endpoint_shell("/gfs/api/frame", exc, bbox)
            shell.update({"frame": {}, "weather": {}, "clouds": {"items": [], "tiles": [], "cloud_regions": [], "payload_state": "provider_failed"}})
            return _json(shell)


    @bp.get("/gfs/api/sea")
    async def sea():
        """Quart fallback for the FastAPI sea-of-intelligence sidecar.

        Some installs proxy /gfs/api/sea to the sidecar, but if that proxy is
        absent or only active at world zoom the frontend never receives the
        bilinear-derived marching-square contour features. Keep this endpoint in
        the main app too so clouds/rain/bait can always request the derived
        contour contract.
        """
        raw_bbox = request.args.get("bbox") or ""
        bbox = _parse_bbox()
        try:
            grid_size = int(request.args.get("grid_size") or request.args.get("gridSize") or 256)
        except Exception:
            grid_size = 256
        layers_raw = (request.args.get("layers") or "").strip()
        layers = [x.strip() for x in layers_raw.split(",") if x.strip()] if layers_raw else None
        try:
            from server_fastapi.sea_engine import SeaOfIntelligenceEngine, parse_bbox as parse_sea_bbox
            engine = current_app.extensions.get("sea_intelligence_engine")
            if engine is None:
                engine = SeaOfIntelligenceEngine(grid_size=grid_size)
                current_app.extensions["sea_intelligence_engine"] = engine
            parsed = parse_sea_bbox(raw_bbox or [bbox["west"], bbox["south"], bbox["east"], bbox["north"]]) if bbox else parse_sea_bbox(raw_bbox)
            payload = await engine.derive_all(parsed, grid_size=grid_size, layers=layers)
            payload["endpoint"] = "/gfs/api/sea"
            payload["served_by"] = "quart_fallback_route"
            payload.setdefault("truth_contract", {})["quart_route_available"] = True
            return _json(payload)
        except Exception as exc:
            log.exception("/gfs/api/sea failed")
            shell = _endpoint_shell("/gfs/api/sea", exc, bbox)
            shell.update({"layers": {}, "summary": {}, "payload_state": "sea_engine_failed"})
            return _json(shell)

    @bp.get("/gfs/api/tile-plan")
    async def tile_plan():
        try:
            max_tiles = int(request.args.get("max_tiles") or request.args.get("limit") or 512)
        except Exception:
            max_tiles = 512
        return _json(await _call_sync(_svc(static_dir).tile_plan_payload, _parse_bbox(), max_tiles))

    @bp.get("/gfs/api/tiles")
    @bp.get("/gfs/api/tile-intel")
    async def tiles_intel():
        try:
            max_tiles = int(request.args.get("max_tiles") or request.args.get("limit") or 512)
        except Exception:
            max_tiles = 512
        try:
            return _json(await _call_sync(_svc(static_dir).tiles_intel_payload, _parse_bbox(), max_tiles, _parse_visible_bbox()))
        except Exception as exc:
            log.exception("/gfs/api/tiles failed")
            return _json({
                "ok": False,
                "schema": "lftr_scene_tiles_point_cache_v1_error_caught",
                "source": "tiles_endpoint_error_caught",
                "payload_state": "read_failed",
                "error": str(exc),
                "tiles": [],
                "count": 0,
                "note": "tiles endpoint caught exception and returned JSON status 200 instead of nginx/Quart 500",
            })

    @bp.get("/gfs/api/cache-warm")
    @bp.post("/gfs/api/cache-warm")
    async def cache_warm():
        try:
            max_tiles = int(request.args.get("max_tiles") or request.args.get("limit") or 512)
        except Exception:
            max_tiles = 512
        reason = (request.args.get("reason") or "website_load").strip() or "website_load"
        layers = [x.strip() for x in (request.args.get("layers") or request.args.get("pills") or "").split(",") if x.strip()]
        bbox = _parse_bbox()
        try:
            # Scheduling is cheap and starts its own background worker; do not
            # queue this behind long provider tasks in the default executor.
            return _json(_svc(static_dir).schedule_globe_cache_warm(bbox, max_tiles, reason, _parse_visible_bbox(), layers))
        except Exception as exc:
            log.exception("/gfs/api/cache-warm failed")
            shell = _endpoint_shell("/gfs/api/cache-warm", exc, bbox)
            shell.update({"scheduled": False, "reason": "error_caught", "tiles": max_tiles, "warm": {"running": False, "error": str(exc)}})
            return _json(shell)

    @bp.get("/gfs/api/cache-warm/status")
    async def cache_warm_status():
        return _json(_svc(static_dir).cache_warm_status_payload())

    @bp.get("/gfs/api/cache/status")
    async def cache_status():
        return _json(await _call_sync(_svc(static_dir).cache_status_payload))

    @bp.post("/gfs/api/cache/warm")
    async def cache_warm_post():
        body = await request.get_json(force=True, silent=True) or {}
        bbox = body.get("bbox") or _parse_bbox()
        try:
            max_tiles = int(body.get("max_tiles") or body.get("limit") or request.args.get("max_tiles") or 512)
        except Exception:
            max_tiles = 512
        reason = str(body.get("reason") or request.args.get("reason") or "manual_warm")
        raw_layers = body.get("layers") or request.args.get("layers") or ""
        if isinstance(raw_layers, (list, tuple)):
            layers = [str(x).strip() for x in raw_layers if str(x).strip()]
        else:
            layers = [x.strip() for x in str(raw_layers).split(",") if x.strip()]
        return jsonify(await _call_sync(_svc(static_dir).schedule_globe_cache_warm, bbox, max_tiles, reason, _parse_visible_bbox(), layers))

    @bp.get("/gfs/api/tile-intel/<tile_id>")
    async def one_tile_intel(tile_id: str):
        return jsonify(await _call_sync(_svc(static_dir).tile_intel_payload, tile_id, 300, _parse_visible_bbox()))

    @bp.get("/gfs/api/ocean")
    async def ocean():
        bbox = _parse_bbox()
        try:
            return _json(await _call_sync(_svc(static_dir).ocean_payload, bbox, _parse_visible_bbox()))
        except Exception as exc:
            log.exception("/gfs/api/ocean failed")
            shell = _endpoint_shell("/gfs/api/ocean", exc, bbox)
            shell.update({"points": [], "boats": [], "items": []})
            return _json(shell)

    @bp.get("/gfs/api/ocean-points")
    async def ocean_points():
        lod = (request.args.get("lod") or "auto").strip() or "auto"
        bbox = _parse_bbox()
        try:
            return _json(await _call_sync(_svc(static_dir).ocean_points_payload, bbox, lod, _parse_visible_bbox()))
        except Exception as exc:
            log.exception("/gfs/api/ocean-points failed")
            shell = _endpoint_shell("/gfs/api/ocean-points", exc, bbox)
            shell.update({"points": [], "items": [], "grid": {"real_grid": False, "reason": "error_caught"}})
            return _json(shell)

    @bp.get("/gfs/api/boats")
    async def boats():
        bbox = _parse_bbox()
        try:
            return _json(await _call_sync(_svc(static_dir).boats_payload, bbox, _parse_visible_bbox()))
        except Exception as exc:
            log.exception("/gfs/api/boats failed")
            shell = _endpoint_shell("/gfs/api/boats", exc, bbox)
            shell.update({"boats": [], "items": [], "count": 0})
            return _json(shell)

    @bp.get("/gfs/api/lightning")
    async def lightning():
        try:
            minutes = int(request.args.get("minutes") or request.args.get("window_minutes") or 20)
        except Exception:
            minutes = 20
        bbox = _parse_bbox()
        try:
            return _json(await _call_sync(_svc(static_dir).lightning_payload, bbox, _parse_visible_bbox(), minutes))
        except Exception as exc:
            log.exception("/gfs/api/lightning failed")
            shell = _endpoint_shell("/gfs/api/lightning", exc, bbox)
            shell.update({"schema": "lftr_lightning_v1", "flashes": [], "items": [], "regions": [], "fallback_used": False})
            return _json(shell)

    @bp.get("/gfs/api/scene")
    async def scene():
        return jsonify(await _call_sync(_svc(static_dir).get_scene_payload, _parse_bbox()))

    @bp.get("/gfs/api/hazards")
    async def hazards():
        return jsonify(await _call_sync(_svc(static_dir).hazards_payload))

    @bp.get("/gfs/api/diagnostics")
    async def diagnostics():
        return jsonify(await _call_sync(_svc(static_dir).diagnostics_payload))

    @bp.get("/gfs/api/fish")
    async def fish():
        return jsonify(await _call_sync(_svc(static_dir).fish_payload))

    @bp.get("/gfs/api/sources")
    @bp.get("/gfs/api/source-diagnostics")
    async def sources():
        return jsonify(await _call_sync(_svc(static_dir).source_diagnostics_payload, _parse_bbox()))

    @bp.get("/gfs/api/locations")
    async def locations():
        payload = await _call_sync(_svc(static_dir).fish_payload)
        # Compatibility: some UI callers expect `locations`, while
        # the service payload returns `items`. Keep both keys during cleanup.
        if isinstance(payload, dict):
            items = payload.get("items")
            if isinstance(items, list) and not isinstance(payload.get("locations"), list):
                payload["locations"] = items
        return jsonify(payload)

    @bp.get("/gfs/api/source-check")
    async def source_check():
        svc = _svc(static_dir)
        return jsonify(await _call_sync(svc.validate_bbox_real_fields, _parse_bbox()))

    @bp.get("/gfs/api/payload-debug")
    @bp.get("/gfs/api/provider-debug")
    async def payload_debug():
        svc = _svc(static_dir)
        bbox = _parse_bbox()
        # Do not let provider-debug default to the whole globe.  HYCOM's NCSS
        # request grid uses 0..360 longitude and full-world bboxes are slow and
        # easy to turn into invalid west==east constraints.  Use the same SoCal
        # startup bbox unless a bbox query param is supplied.
        if bbox is None:
            bbox = {"west": -126.0, "south": 29.0, "east": -114.0, "north": 39.0}
        try:
            deep = str(request.args.get("deep") or "0").lower() in {"1", "true", "yes"}
            if deep:
                payload = await _call_sync(svc.payload_debug_payload, bbox)
            else:
                payload = {
                    "ok": True,
                    "endpoint": request.path,
                    "mode": "cheap_debug_status_no_provider_fetch",
                    "bbox": bbox,
                    "cache_warm": await _call_sync(svc.cache_warm_status_payload),
                    "cache_status": await _call_sync(svc.cache_status_payload),
                    "note": "Use ?deep=1 for heavy provider checks. Default is cheap so debug cannot stall page load.",
                }
        except Exception as exc:
            log.exception("/gfs/api/provider-debug failed")
            payload = {
                "ok": False,
                "endpoint": request.path,
                "error": str(exc),
                "bbox": bbox,
                "note": "provider-debug caught an exception and returned JSON status 200 instead of HTTP 500",
            }
        return _json(payload)

    @bp.get("/gfs/api/bait")
    @bp.get("/gfs/api/bait-advanced")
    @bp.get("/gfs/api/bait/advanced")
    async def bait():
        bbox = _parse_bbox()
        try:
            return _json(await _call_sync(_svc(static_dir).bait_advanced_payload, bbox, _parse_visible_bbox()))
        except Exception as exc:
            log.exception("/gfs/api/bait-advanced failed")
            shell = _endpoint_shell("/gfs/api/bait-advanced", exc, bbox)
            shell.update({"bait": {"polygons": [], "bait_score": []}, "bait_score": [], "polygons": []})
            return _json(shell)




    @bp.get("/gfs/api/inland-water")
    async def inland_water():
        bbox = _parse_bbox()
        try:
            try:
                max_tiles = int(request.args.get("max_tiles") or request.args.get("limit") or 96)
            except Exception:
                max_tiles = 96
            # Cache-first/tile-aligned mode is now the default for the visible pill.
            # The direct bbox helper remains available with tile_cache=0 for debugging.
            source = request.args.get("source") or "auto"
            geometry = request.args.get("geometry") or "vector"
            lod = request.args.get("lod") or "auto"
            scene_tier = request.args.get("scene_tier") or request.args.get("tier") or None
            use_tile_cache = str(request.args.get("tile_cache", request.args.get("cache", "1"))).lower() not in {"0", "false", "no", "off"}
            if use_tile_cache:
                payload = await _call_sync(_svc(static_dir).inland_water_tiles_payload, bbox, max_tiles, _parse_visible_bbox(), source=source, geometry=geometry, lod=lod, scene_tier=scene_tier)
            else:
                payload = await _call_sync(inland_water_payload, static_dir, bbox, source=source, geometry=geometry, lod=lod, scene_tier=scene_tier)

            # Post-install viewport/zoom source build bridge.
            # If no high-def local sidecar tiles exist yet, the Inland Waters pill
            # should actively request real source construction for this viewport.
            # This is a background build only; the response remains fast and does
            # not draw mock/coarse/fallback shoreline.
            try:
                auto_build = str(request.args.get("auto_build", request.args.get("build", "1"))).lower() not in {"0", "false", "no", "off"}
                if auto_build and isinstance(payload, dict) and str(payload.get("status")) == "no_high_def_source":
                    build_bbox = _parse_visible_bbox() or bbox
                    job = _launch_inland_view_build(static_dir, build_bbox, scene_tier)
                    payload = dict(payload)
                    payload["build"] = {
                        "status": job.get("status"),
                        "running": bool(job.get("running")),
                        "deduped": bool(job.get("deduped")),
                        "pid": job.get("pid"),
                        "bbox": job.get("bbox"),
                        "scene_tier": job.get("scene_tier"),
                        "log": job.get("log"),
                        "source": job.get("source"),
                        "trigger": "inland-water-route-auto-build-on-missing-source",
                        "progressive": True,
                        "partial_draw_policy": "draws as soon as one completed json.gz tile and index.json are written; does not wait for all selected tiles",
                    }
                    if bool(job.get("running")):
                        payload["status"] = "building"
                        payload["source"] = "real_usgs_nhd_arcgis_view_tiles_building"
                    payload["message"] = (payload.get("message") or "High-def Inland Waters source missing.") + " Background real NHD source-tile build has been requested; partial tiles will draw as they complete."
            except Exception as build_exc:
                log.info("/gfs/api/inland-water auto-build skipped: %s", build_exc)

            return _json(payload)
        except Exception as exc:
            log.exception("/gfs/api/inland-water failed")
            shell = _endpoint_shell("/gfs/api/inland-water", exc, bbox)
            shell.update({"polygons": [], "lines": [], "count": 0, "status": "error"})
            return _json(shell)


    @bp.get("/gfs/api/inland-water/status")
    async def inland_water_status():
        bbox = _parse_bbox()
        try:
            payload = await _call_sync(_state_cache_status, static_dir, bbox)
            try:
                tier = request.args.get("scene_tier") or request.args.get("tier") or None
                key = _inland_build_key(bbox, tier)
                job = _INLAND_BUILD_JOBS.get(key)
                if job:
                    payload = dict(payload)
                    payload["build"] = {**job, "deduped": True, "progressive": True}
                    payload["partial_draw_policy"] = "one completed json.gz tile plus index.json is enough to draw partial inland water"
            except Exception:
                pass
            return _json(payload)
        except Exception as exc:
            log.exception("/gfs/api/inland-water/status failed")
            shell = _endpoint_shell("/gfs/api/inland-water/status", exc, bbox)
            shell.update({"status": "error"})
            return _json(shell)




    @bp.post("/gfs/api/inland-water/build-cache")
    @bp.get("/gfs/api/inland-water/build-cache")
    async def inland_water_build_cache():
        bbox = _parse_visible_bbox() or _parse_bbox()
        scene_tier = request.args.get("scene_tier") or request.args.get("tier") or None
        try:
            # This only launches/dedupes a subprocess and should return
            # immediately.  Calling it directly prevents the request from being
            # delayed behind slow sea/cloud/cache executor work.
            job = _launch_inland_view_build(static_dir, bbox, scene_tier)
            return _json({
                "status": job.get("status") or "started",
                "running": bool(job.get("running")),
                "deduped": bool(job.get("deduped")),
                "pid": job.get("pid"),
                "bbox": job.get("bbox") or _bbox_to_query(bbox),
                "scene_tier": job.get("scene_tier") or scene_tier or "world",
                "log": job.get("log"),
                "source": job.get("source") or "real_usgs_nhd_arcgis_view_tiles_only",
                "policy": "runtime viewport/zoom live-build for missing real NHD source squares; saved json.gz cache pops first on boot/reload; no installer download; no seed/coarse fallback",
            })
        except Exception as exc:
            log.exception("/gfs/api/inland-water/build-cache failed")
            shell = _endpoint_shell("/gfs/api/inland-water/build-cache", exc, bbox)
            shell.update({"status": "error", "running": False})
            return _json(shell)


    @bp.get("/gfs/api/inland-water/diagnostics")
    async def inland_water_diagnostics():
        bbox = _parse_bbox()
        try:
            source = request.args.get("source") or "auto"
            geometry = request.args.get("geometry") or "vector"
            lod = request.args.get("lod") or "auto"
            scene_tier = request.args.get("scene_tier") or request.args.get("tier") or None
            payload = await _call_sync(inland_water_payload, static_dir, bbox, source=source, geometry=geometry, lod=lod, scene_tier=scene_tier)
            return _json({
                "ok": True,
                "status": "ok",
                "bbox": payload.get("bbox"),
                "source": payload.get("source"),
                "source_path": payload.get("source_path"),
                "query": payload.get("query"),
                "geometry_quality": payload.get("geometry_quality"),
                "diagnostics": payload.get("diagnostics"),
                "polygon_count": len(payload.get("polygons") or []),
                "line_count": len(payload.get("lines") or []),
                "temperature_point_count": len(payload.get("temperature_points") or []),
                "contract": "lftr_inland_water_diagnostics_v2_honest_shoreline",
            })
        except Exception as exc:
            log.exception("/gfs/api/inland-water/diagnostics failed")
            shell = _endpoint_shell("/gfs/api/inland-water/diagnostics", exc, bbox)
            shell.update({"status": "error", "diagnostics": {}})
            return _json(shell)

    @bp.get("/gfs/api/inland-conditions")
    async def inland_conditions():
        bbox = _parse_bbox()
        try:
            if request.args.get("lat") is not None and request.args.get("lon") is not None:
                lat = float(request.args.get("lat"))
                lon = float(request.args.get("lon"))
            else:
                b = bbox or {"west": -118.6, "south": 33.4, "east": -117.4, "north": 34.2}
                lat = (float(b["south"]) + float(b["north"])) / 2.0
                lon = (float(b["west"]) + float(b["east"])) / 2.0
            live = str(request.args.get("live") or request.args.get("ncss") or "").lower() in {"1", "true", "yes", "y"}
            return _json(await _call_sync(inland_conditions_payload, static_dir, _svc(static_dir), bbox, lat, lon, live))
        except Exception as exc:
            log.exception("/gfs/api/inland-conditions failed")
            shell = _endpoint_shell("/gfs/api/inland-conditions", exc, bbox)
            shell.update({"inland_water": False, "water_temp_est_f": None, "temperature_points": [], "status": "error"})
            return _json(shell)

    @bp.get("/gfs/api/inland-bait")
    async def inland_bait():
        bbox = _parse_bbox()
        try:
            lat_raw = request.args.get("lat")
            lon_raw = request.args.get("lon")
            lat = float(lat_raw) if lat_raw is not None else None
            lon = float(lon_raw) if lon_raw is not None else None
            live = str(request.args.get("live") or request.args.get("ncss") or "").lower() in {"1", "true", "yes", "y"}
            return _json(await _call_sync(inland_bait_payload, static_dir, _svc(static_dir), bbox, lat, lon, live))
        except Exception as exc:
            log.exception("/gfs/api/inland-bait failed")
            shell = _endpoint_shell("/gfs/api/inland-bait", exc, bbox)
            shell.update({"targets": [], "temperature_points": [], "count": 0, "status": "error"})
            return _json(shell)

    @bp.get("/gfs/api/location/<location_id>")
    async def location_detail(location_id: str):
        return jsonify(await _call_sync(_svc(static_dir).location_payload, location_id))

    @bp.get("/gfs/api/intelligence/node/<node_id>")
    @bp.get("/gfs/api/location/<node_id>/intelligence")
    async def node_intelligence(node_id: str):
        svc = _svc(static_dir)
        payload = await _call_sync(svc.node_intelligence_payload, node_id)
        return jsonify(payload)

    @bp.get("/gfs/api/location/<location_id>/live-intel")
    async def location_live_intel(location_id: str):
        return jsonify(await _call_sync(_svc(static_dir).location_live_intel_payload, location_id))

    @bp.get("/gfs/api/location/<location_id>/environment")
    @bp.get("/gfs/api/location/<location_id>/weather")
    async def location_environment(location_id: str):
        return jsonify(await _call_sync(_svc(static_dir).location_environment_payload, location_id))

    @bp.get("/gfs/api/location/<location_id>/media")
    @bp.get("/gfs/api/location/<location_id>/videos")
    @bp.get("/gfs/api/location/<location_id>/live")
    async def location_media(location_id: str):
        return jsonify(await _call_sync(_svc(static_dir).location_media, location_id))

    @bp.post("/gfs/api/location/<location_id>/report")
    @bp.post("/gfs/api/location/<location_id>/reports")
    async def location_report(location_id: str):
        body = await request.get_json(force=True, silent=True) or {}
        text = str(body.get("report_text") or body.get("text") or "")
        return jsonify(await _call_sync(_svc(static_dir).upsert_report, location_id, text))

    @bp.post("/gfs/api/location/<location_id>/live")
    async def location_live_update(location_id: str):
        body = await request.get_json(force=True, silent=True) or {}
        active = bool(body.get("active"))
        stream_url = str(body.get("stream_url") or body.get("url") or "")
        return jsonify(await _call_sync(_svc(static_dir).upsert_live, location_id, active, stream_url))

    @bp.post("/gfs/api/location/<location_id>/upload")
    async def location_upload(location_id: str):
        files = await request.files
        f = files.get("file")
        if not f:
            return jsonify({"ok": False, "error": "file required"}), 400
        raw = f.read()
        if asyncio.iscoroutine(raw):
            raw = await raw
        return jsonify(await _call_sync(_svc(static_dir).save_upload_video, location_id, f.filename or "upload.mp4", raw))

    @bp.get("/gfs/api/tile/<layer>/<int:z>/<int:x>/<int:y>.json")
    async def tile_json(layer: str, z: int, x: int, y: int):
        return jsonify(await _call_sync(_svc(static_dir).tile_layer_payload, layer, z, x, y))

    @bp.websocket("/ws/gfs")
    async def ws_gfs():
        ws = websocket._get_current_object()
        try:
            await ws.send_json({"type": "connected", "service": "gfs", "mode": "nonblocking_cache_first_ws"})
        except Exception:
            return
        while True:
            try:
                raw = await websocket.receive()
            except Exception:
                break
            try:
                import json as _json
                msg = _json.loads(raw) if isinstance(raw, str) else (raw or {})
            except Exception:
                try:
                    await ws.send_json({"type": "ignored", "reason": "bad_json"})
                except Exception:
                    break
                continue
            kind = (msg or {}).get("type") or "ping"
            if kind == "ping":
                try:
                    await ws.send_json({"type": "pong", "ts": int(asyncio.get_event_loop().time() * 1000)})
                except Exception:
                    break
            elif kind == "viewport" and isinstance((msg or {}).get("bbox"), dict):
                try:
                    bbox = (msg or {}).get("bbox")
                    reason = str((msg or {}).get("reason") or "steady")
                    svc = _svc(static_dir)
                    ack = await _call_sync(svc.note_viewport_priority, bbox, reason)
                    # Websocket viewport notes must stay cheap.  Do not launch large
                    # live tile warm jobs from the websocket path; the HTTP cache-warm
                    # scheduler handles that and dedupes already-running jobs.
                    await ws.send_json({"type": "viewport_ack", "cache_warm_started": False, **ack})
                except Exception as exc:
                    log.exception("gfs websocket viewport priority failed")
                    try:
                        await ws.send_json({"type": "error", "message": str(exc)})
                    except Exception:
                        break
            elif kind in {"snapshot", "get_snapshot", "subscribe"}:
                try:
                    payload = await _call_sync(_svc(static_dir).ws_snapshot)
                    if asyncio.iscoroutine(payload):
                        payload = await payload
                    await ws.send_json(payload)
                except Exception as exc:
                    log.exception("gfs websocket snapshot failed")
                    try:
                        await ws.send_json({"type": "error", "message": str(exc)})
                    except Exception:
                        break
            else:
                try:
                    await ws.send_json({"type": "ignored", "reason": "unknown_type", "kind": kind})
                except Exception:
                    break

    @bp.websocket("/gfs/ws")
    @bp.websocket("/gfs/ws/")
    async def ws_gfs_alias():
        await ws_gfs()

    return bp
