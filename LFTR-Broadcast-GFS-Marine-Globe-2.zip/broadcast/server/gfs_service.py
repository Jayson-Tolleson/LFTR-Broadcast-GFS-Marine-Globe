from __future__ import annotations

import base64
import gc
import csv
import hashlib
import json
import math
import os
import random
import re
import time
import threading
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone
from pathlib import Path

import requests
from typing import Any, Dict, List, Tuple

try:
    import numpy as np
except Exception:  # pragma: no cover - fallback mode
    np = None

try:
    import xarray as xr
except Exception:  # pragma: no cover - fallback mode
    xr = None

try:
    from diskcache import Cache as DiskCache
except Exception:  # pragma: no cover - fallback mode
    DiskCache = None

try:
    import pygrib
except Exception:  # pragma: no cover - optional fallback decoder
    pygrib = None

from werkzeug.utils import secure_filename

from server.gfs_state import GFSState
from server.gfs.intelligence import build_location_profile
from server.gfs.models import BBox
from server.gfs.providers.rtofs import RtofsProvider
try:
    from server.gfs.providers.coastwatch import CoastwatchProvider
except Exception:  # optional live chlorophyll provider
    CoastwatchProvider = None
try:
    from server.gfs.derive.bait import derive_bait_payload
except Exception:  # optional bait grid solver
    derive_bait_payload = None

try:
    from server.gfs.inland_water import inland_water_payload as build_inland_water_payload
except Exception:  # optional inland water layer
    build_inland_water_payload = None


BASE_DIR = Path(__file__).resolve().parent.parent
STATIC_DIR = BASE_DIR / "static"
DATA_DIR = STATIC_DIR / "data"
FISH_CSV = DATA_DIR / "fishloclist.csv"


_TRANSPARENT_PNG_BASE64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8"
    "/w8AAgMBgB5o2a4AAAAASUVORK5CYII="
)
_ALLOWED_VIDEO_EXTS = {".mp4", ".webm", ".mov", ".m4v"}

DEFAULT_HTTP_TIMEOUT = float(os.getenv("GFS_HTTP_TIMEOUT_SECONDS", "6") or "6")
ENV_CACHE_TTL_SECONDS = 900
NWS_CACHE_TTL_SECONDS = 1800
TIDE_CACHE_TTL_SECONDS = 1200
SST_CACHE_TTL_SECONDS = 10_800
NWS_API_BASE = "https://api.weather.gov"
NOAA_TIDES_API = "https://api.tidesandcurrents.noaa.gov/api/prod/datagetter"
NOAA_COOPS_MDAPI = "https://api.tidesandcurrents.noaa.gov/mdapi/prod/webapi"
DEFAULT_UA = "LFTR-GFS/1.0 (+https://lftr.biz)"
DEFAULT_WORLD_ENV_MARKER = {"lat": 34.2, "lon": -120.0}

NOMADS_FILTER_BASE = "https://nomads.ncep.noaa.gov/cgi-bin/filter_gfs_0p25.pl"
DEFAULT_GFS_TIMEOUT_SECONDS = int(float(os.getenv("GFS_TIMEOUT_SECONDS", "22") or "22"))
DEFAULT_GFS_RETRIES = 3
DEFAULT_GFS_CACHE_DIR = BASE_DIR / ".cache" / "gfs_nomads"
DEFAULT_SCENE_TILE_CACHE_DIR = BASE_DIR / ".cache" / "scene_tiles"
DEFAULT_CFGRIB_INDEX_DIR = BASE_DIR / ".cache" / "cfgrib"
DEFAULT_FRAME_CACHE_DIR = BASE_DIR / ".cache" / "frames"
DEFAULT_SPLIT_CACHE_DIR = BASE_DIR / ".cache" / "split_payloads"
DEFAULT_OCEAN_CACHE_DIR = BASE_DIR / ".cache" / "ocean"
DEFAULT_GFS_CACHE_TTL_SECONDS = int(os.getenv("GFS_CACHE_TTL_SECONDS", str(60 * 40)) or str(60 * 40))
DEFAULT_GFS_CYCLE_AVAILABILITY_DELAY_MINUTES = 290
INGEST_FALLBACK_CYCLE_DEPTH = 4
INGEST_PREFERRED_FORECAST_HOUR = 0
INGEST_CACHE_MIN_BYTES = 2000
INGEST_MIN_INTERVAL_SECONDS = 600
WEATHER_REFRESH_TTL_SECONDS = 45
SCENE_REFRESH_TTL_SECONDS = int(os.getenv("GFS_FRAME_CACHE_TTL_SECONDS", "120") or "120")
SCENE_DOWNSAMPLE_STRIDE = 3
SCALAR_DOWNSAMPLE_STRIDE = 6
PREFER_LIVE_REAL_DATA = os.getenv("PREFER_LIVE_REAL_DATA", "true").strip().lower() in {"1", "true", "yes", "on"}
ALLOW_STALE_CACHE_BLEND = os.getenv("ALLOW_STALE_CACHE_BLEND", "true").strip().lower() in {"1", "true", "yes", "on"}
ALLOW_SYNTHETIC_FALLBACK = os.getenv("ALLOW_SYNTHETIC_FALLBACK", "false").strip().lower() in {"1", "true", "yes", "on"}
SYNTHETIC_FALLBACK_OFFSET_DEGREES = float(os.getenv("SYNTHETIC_FALLBACK_OFFSET_DEGREES", "17.5"))
REQUIRE_MATCHING_GRID_FOR_CACHE = os.getenv("REQUIRE_MATCHING_GRID_FOR_CACHE", "true").strip().lower() in {"1", "true", "yes", "on"}
ENABLE_LIVE_OCEAN_NCSS = os.getenv("GFS_ENABLE_LIVE_OCEAN_NCSS", "true").strip().lower() in {"1", "true", "yes", "on"}
# Live-data quality policy: default is strict. The app may return cache-warming
# shells or explicit provider_failed/provider_empty payloads, but must not
# silently draw marker/proxy/mock ocean, bait, boat, cloud, or rain data as if
# it came from NCSS/ERDDAP. Set GFS_ALLOW_PROXY_FALLBACK=true only for demos.
GFS_ALLOW_PROXY_FALLBACK = os.getenv("GFS_ALLOW_PROXY_FALLBACK", "false").strip().lower() in {"1", "true", "yes", "on"}
GFS_STRICT_LIVE_PAYLOADS = os.getenv("GFS_STRICT_LIVE_PAYLOADS", "true").strip().lower() in {"1", "true", "yes", "on"}
OCEAN_NCSS_TARGET_CELLS = int(os.getenv("GFS_OCEAN_NCSS_TARGET_CELLS", "18"))
OCEAN_NCSS_MAX_BOATS = int(os.getenv("GFS_OCEAN_NCSS_MAX_BOATS", "28"))
OCEAN_NCSS_RENDER_BOATS = int(os.getenv("GFS_OCEAN_NCSS_RENDER_BOATS", "7"))
OCEAN_POINTS_MAX = int(os.getenv("GFS_OCEAN_POINTS_MAX", "420"))

SURFACE_VARIABLES = ["PRATE", "APCP", "TCDC", "CAPE", "CIN", "PRMSL", "TMP", "RH", "GUST", "UGRD", "VGRD"]
AGL_VARIABLES = ["TMP", "RH", "UGRD", "VGRD", "TCDC"]
ISOBARIC_VARIABLES = ["RH", "TMP", "HGT", "UGRD", "VGRD"]
DEFAULT_REQUIRED_VARIABLES = sorted(set(SURFACE_VARIABLES + AGL_VARIABLES + ISOBARIC_VARIABLES))
DEFAULT_REQUIRED_LEVELS = ["surface", "2_m_above_ground", "10_m_above_ground", "1000_mb", "925_mb", "850_mb", "700_mb", "500_mb", "300_mb"]

PRECIP_BUCKETS_MM_HR = [0.15, 0.7, 2.5, 8.0, 18.0, 40.0]
SPATIAL_GRID_DEG = 8.0
MAX_TILE_DIAGNOSTICS = 600

log = logging.getLogger("server.gfs")


def safe_float(v, default=0.0):
    try:
        f = float(v)
    except (TypeError, ValueError):
        return default
    if not math.isfinite(f):
        return default
    return f


def utc_now() -> datetime:
    """Return current UTC datetime."""
    return datetime.now(timezone.utc)


def floor_to_cycle(dt_utc: datetime) -> int:
    """Return GFS cycle hour bucket (00/06/12/18)."""
    h = dt_utc.hour
    return (h // 6) * 6


def candidate_cycles(dt_utc: datetime) -> list[tuple[str, int]]:
    """Return cycle candidates from newest to older with availability delay."""
    delayed = dt_utc - timedelta(minutes=DEFAULT_GFS_CYCLE_AVAILABILITY_DELAY_MINUTES)
    cur = delayed.replace(minute=0, second=0, microsecond=0)
    cur = cur.replace(hour=floor_to_cycle(cur))
    out: list[tuple[str, int]] = []
    for i in range(0, 4):
        cdt = cur - timedelta(hours=6 * i)
        out.append((cdt.strftime("%Y%m%d"), cdt.hour))
    return out


def nearest_forecast_hour(valid_dt_utc: datetime, cycle_dt_utc: datetime) -> int:
    """Return nearest whole forecast hour from cycle to valid time."""
    return int(round((valid_dt_utc - cycle_dt_utc).total_seconds() / 3600.0))


def clamp_forecast_hour(fhr: int, min_hour: int = 0, max_hour: int = 384) -> int:
    """Clamp forecast hour to legal GFS range."""
    return max(min_hour, min(max_hour, int(fhr)))


class FetchResult:
    def __init__(self, ok: bool, path: Path | None = None, cycle: str = "", forecast_hour: int = 0, valid_time: str = "", error: str = "", url: str = "") -> None:
        self.ok = ok
        self.path = path
        self.cycle = cycle
        self.forecast_hour = forecast_hour
        self.valid_time = valid_time
        self.error = error
        self.url = url


class GFSNomadsClient:
    """NOAA NOMADS GFS 0.25 subset client with on-disk cache."""

    def __init__(self, cache_dir: Path, timeout_seconds: int = DEFAULT_GFS_TIMEOUT_SECONDS, retries: int = DEFAULT_GFS_RETRIES):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.timeout_seconds = timeout_seconds
        self.retries = retries
        self.http = requests.Session()
        self.http.headers.update({"User-Agent": DEFAULT_UA})

    def build_file_name(self, cycle_hour: int, forecast_hour: int) -> str:
        return f"gfs.t{int(cycle_hour):02d}z.pgrb2.0p25.f{int(forecast_hour):03d}"

    def build_dir(self, date_str: str, cycle_hour: int) -> str:
        return f"/gfs.{date_str}/{int(cycle_hour):02d}/atmos"

    def normalize_bbox_for_nomads(self, bbox: dict[str, float]) -> dict[str, float]:
        """Return a bounded NOMADS filter box instead of silently fetching the globe.

        Earlier development used the whole GFS domain for safety, but that makes
        /gfs/api/clouds and /api/gfs/scene slow/fragile.  Use the requested
        scene/fetch bbox, padded just enough for cloud/rain advection and tilt.
        """
        try:
            west = float((bbox or {}).get("west", -180.0))
            east = float((bbox or {}).get("east", 180.0))
            south = float((bbox or {}).get("south", -80.0))
            north = float((bbox or {}).get("north", 80.0))
        except Exception:
            return {"leftlon": -180.0, "rightlon": 180.0, "toplat": 80.0, "bottomlat": -80.0}
        if east < west:
            east += 360.0
        span_lon = max(0.25, min(80.0, east - west))
        span_lat = max(0.25, min(50.0, north - south))
        pad_lon = min(5.0, max(0.5, span_lon * 0.10))
        pad_lat = min(4.0, max(0.5, span_lat * 0.10))
        left = max(-180.0, west - pad_lon)
        right = min(180.0, east + pad_lon)
        bottom = max(-80.0, south - pad_lat)
        top = min(80.0, north + pad_lat)
        if right <= left:
            left, right = -180.0, 180.0
        if top <= bottom:
            bottom, top = -80.0, 80.0
        return {"leftlon": round(left, 4), "rightlon": round(right, 4), "toplat": round(top, 4), "bottomlat": round(bottom, 4)}

    def build_filter_url(self, date_str: str, cycle_hour: int, forecast_hour: int, bbox: dict[str, float], variables: list[str], levels: list[str]) -> str:
        from urllib.parse import urlencode

        file_name = self.build_file_name(cycle_hour, forecast_hour)
        dir_name = self.build_dir(date_str, cycle_hour)
        query: dict[str, Any] = {"file": file_name, "dir": dir_name}
        b = self.normalize_bbox_for_nomads(bbox)
        query.update(b)
        for var in variables:
            query[f"var_{var}"] = "on"
        for lvl in levels:
            query[f"lev_{lvl}"] = "on"
        return f"{NOMADS_FILTER_BASE}?{urlencode(query)}"

    def _cache_path(self, key: str) -> Path:
        digest = hashlib.sha256(key.encode("utf-8")).hexdigest()
        return self.cache_dir / f"{digest}.grib2"

    def fetch_subset(self, url: str, out_path: Path) -> Path:
        tmp = out_path.with_suffix(".tmp")
        for attempt in range(self.retries):
            try:
                resp = self.http.get(url, timeout=self.timeout_seconds)
                resp.raise_for_status()
                ctype = (resp.headers.get("Content-Type") or "").lower()
                body = resp.content
                if b"<html" in body[:200].lower() or ("text/html" in ctype):
                    raise RuntimeError("nomads returned html page")
                if len(body) < 2000:
                    raise RuntimeError("nomads subset too small")
                tmp.write_bytes(body)
                tmp.replace(out_path)
                return out_path
            except Exception:
                if tmp.exists():
                    tmp.unlink(missing_ok=True)
                if attempt >= self.retries - 1:
                    raise
                time.sleep(0.4 * (2 ** attempt))
        return out_path

    def fetch_latest_available_subset(self, target_dt_utc: datetime, bbox: dict[str, float], variables: list[str], levels: list[str]) -> FetchResult:
        for date_str, cycle_hour in candidate_cycles(target_dt_utc):
            cycle_dt = datetime.strptime(f"{date_str}{cycle_hour:02d}", "%Y%m%d%H").replace(tzinfo=timezone.utc)
            fhr = clamp_forecast_hour(nearest_forecast_hour(target_dt_utc, cycle_dt))
            url = self.build_filter_url(date_str, cycle_hour, fhr, bbox, variables, levels)
            cache_key = f"{date_str}:{cycle_hour}:{fhr}:{json.dumps(self.normalize_bbox_for_nomads(bbox), sort_keys=True)}:{','.join(sorted(variables))}:{','.join(sorted(levels))}"
            path = self._cache_path(cache_key)
            if path.exists() and (time.time() - path.stat().st_mtime) < DEFAULT_GFS_CACHE_TTL_SECONDS:
                return FetchResult(True, path=path, cycle=f"{date_str}{cycle_hour:02d}", forecast_hour=fhr, valid_time=(cycle_dt + timedelta(hours=fhr)).isoformat(), url=url)
            try:
                self.fetch_subset(url, path)
                return FetchResult(True, path=path, cycle=f"{date_str}{cycle_hour:02d}", forecast_hour=fhr, valid_time=(cycle_dt + timedelta(hours=fhr)).isoformat(), url=url)
            except Exception as exc:
                continue
        return FetchResult(False, error="no available nomads subset")


CLOUD_REGIMES = {
    "marine_stratocumulus": {
        "deck_bias": 0.92,
        "tower_bias": 0.10,
        "wispy_bias": 0.08,
        "base_altitude_m": 700.0,
        "depth_m": 1400.0,
        "lateral_scale_km": 160.0,
        "underside_darkness": 0.22,
        "fringe_softness": 0.82,
    },
    "cumulus_field": {
        "deck_bias": 0.38,
        "tower_bias": 0.42,
        "wispy_bias": 0.12,
        "base_altitude_m": 1100.0,
        "depth_m": 2200.0,
        "lateral_scale_km": 95.0,
        "underside_darkness": 0.28,
        "fringe_softness": 0.58,
    },
    "frontal_shield": {
        "deck_bias": 0.78,
        "tower_bias": 0.24,
        "wispy_bias": 0.26,
        "base_altitude_m": 1200.0,
        "depth_m": 4200.0,
        "lateral_scale_km": 210.0,
        "underside_darkness": 0.34,
        "fringe_softness": 0.70,
    },
    "deep_convection": {
        "deck_bias": 0.18,
        "tower_bias": 0.96,
        "wispy_bias": 0.10,
        "base_altitude_m": 900.0,
        "depth_m": 9200.0,
        "lateral_scale_km": 120.0,
        "underside_darkness": 0.58,
        "fringe_softness": 0.36,
    },
    "cirrus_sheet": {
        "deck_bias": 0.20,
        "tower_bias": 0.06,
        "wispy_bias": 0.94,
        "base_altitude_m": 7600.0,
        "depth_m": 2400.0,
        "lateral_scale_km": 240.0,
        "underside_darkness": 0.14,
        "fringe_softness": 0.90,
    },
}


def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def _lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def stable_hash_u32(text: str) -> int:
    h = hashlib.sha256(str(text).encode("utf-8")).hexdigest()[:8]
    return int(h, 16)


def stable_unit_float(key: str) -> float:
    return (stable_hash_u32(key) % 1_000_000) / 1_000_000.0


def stable_range(key: str, lo: float, hi: float) -> float:
    return lo + (hi - lo) * stable_unit_float(key)


def close_ring(points: list[dict]) -> list[dict]:
    if not points:
        return []
    out = [dict(p) for p in points]
    if out[0].get("lat") != out[-1].get("lat") or out[0].get("lng") != out[-1].get("lng"):
        out.append({"lat": out[0]["lat"], "lng": out[0]["lng"]})
    return out


def ring_centroid(points: list[dict]) -> tuple[float, float]:
    if not points:
        return 0.0, 0.0
    core = points[:-1] if len(points) > 2 and points[0] == points[-1] else points
    lat = sum(float(p["lat"]) for p in core) / max(1, len(core))
    lon = sum(float(p["lng"]) for p in core) / max(1, len(core))
    return lat, lon


def scale_ring(points: list[dict], scale_lat: float, scale_lon: float, center_lat: float, center_lon: float) -> list[dict]:
    out = []
    for p in points:
        out.append(
            {
                "lat": center_lat + (float(p["lat"]) - center_lat) * scale_lat,
                "lng": center_lon + (float(p["lng"]) - center_lon) * scale_lon,
            }
        )
    return close_ring(out)


def offset_ring(points: list[dict], dlat: float, dlon: float) -> list[dict]:
    out = [{"lat": float(p["lat"]) + dlat, "lng": float(p["lng"]) + dlon} for p in points]
    return close_ring(out)


def jitter_ring(points: list[dict], key_base: str, lat_jitter: float, lon_jitter: float) -> list[dict]:
    out = []
    for i, p in enumerate(points):
        out.append(
            {
                "lat": float(p["lat"]) + stable_range(f"{key_base}:jlat:{i}", -lat_jitter, lat_jitter),
                "lng": float(p["lng"]) + stable_range(f"{key_base}:jlon:{i}", -lon_jitter, lon_jitter),
            }
        )
    return close_ring(out)


def km_to_lat_deg(km: float) -> float:
    return km / 110.574


def km_to_lon_deg(km: float, lat_deg: float) -> float:
    return km / max(10.0, 111.320 * math.cos(math.radians(lat_deg)))


def build_irregular_ellipse_ring(center_lat: float, center_lon: float, radius_lat_deg: float, radius_lon_deg: float, points_count: int, key_base: str, irregularity: float = 0.18) -> list[dict]:
    pts: list[dict] = []
    count = max(8, points_count)
    for i in range(count):
        t = (2 * math.pi * i) / count
        wobble = 1 + stable_range(f"{key_base}:w:{i}", -irregularity, irregularity)
        lat = center_lat + math.sin(t) * radius_lat_deg * wobble
        lng = center_lon + math.cos(t) * radius_lon_deg * wobble
        pts.append({"lat": round(lat, 6), "lng": round(lng, 6)})
    return close_ring(pts)


def build_hole_rings_for_cloud(center_lat: float, center_lon: float, outer_ring: list[dict], hole_count: int, key_base: str) -> list[list[dict]]:
    holes: list[list[dict]] = []
    c_lat, c_lon = ring_centroid(outer_ring)
    for i in range(max(0, hole_count)):
        s_lat = stable_range(f"{key_base}:hs:{i}:lat", 0.18, 0.42)
        s_lon = stable_range(f"{key_base}:hs:{i}:lon", 0.18, 0.42)
        ring = scale_ring(outer_ring, s_lat, s_lon, c_lat, c_lon)
        ring = offset_ring(ring, stable_range(f"{key_base}:ho:{i}:lat", -0.05, 0.05), stable_range(f"{key_base}:ho:{i}:lon", -0.05, 0.05))
        holes.append(ring)
    return holes


def build_subcell_layout(regime: str, density: float, organization: float, key_base: str) -> list[dict]:
    base = 3 + int(density * 4)
    if regime == "deep_convection":
        base += 3
    elif regime in {"marine_stratocumulus", "frontal_shield"}:
        base += 2
    count = max(3, min(10, base))
    out: list[dict] = []
    for i in range(count):
        role = "fringe"
        if i == 0:
            role = "core"
        if regime == "deep_convection" and i in {0, 1}:
            role = "tower" if i == 1 else "core"
        elif regime == "cirrus_sheet":
            role = "wispy"
        elif regime == "marine_stratocumulus" and i > count - 3:
            role = "deck"
        out.append(
            {
                "id": f"sc-{i}",
                "dx": round(stable_range(f"{key_base}:dx:{i}", -0.38, 0.38), 4),
                "dy": round(stable_range(f"{key_base}:dy:{i}", -0.38, 0.38), 4),
                "weight": round(_clamp(stable_range(f"{key_base}:w:{i}", 0.45, 1.0) * (0.6 + organization * 0.4), 0.0, 1.0), 4),
                "role": role,
            }
        )
    return out


def rgba_string(r: int, g: int, b: int, a: float) -> str:
    return f"rgba({int(_clamp(r,0,255))},{int(_clamp(g,0,255))},{int(_clamp(b,0,255))},{_clamp(a,0,1):.3f})"


def build_band_footprints(tile_id: str, regime: str, band: str, lat: float, lon: float, lateral_scale_km: float, organization: float, fringe_softness: float, wind_shear: float, anvil_dir_deg: float, anvil_spread_km: float, density: float, coverage: float, key_base: str) -> dict:
    lat_deg = km_to_lat_deg(max(8.0, lateral_scale_km * (0.42 + coverage * 0.8)))
    lon_deg = km_to_lon_deg(max(10.0, lateral_scale_km * (0.52 + coverage * 0.9)), lat)
    points_count = int(_clamp(12 + density * 10 + (1 - organization) * 4, 10, 24))

    footprints = []
    holes = []
    base_ring = build_irregular_ellipse_ring(lat, lon, lat_deg, lon_deg, points_count, f"{key_base}:base", irregularity=0.12 + fringe_softness * 0.18)
    base_ring = jitter_ring(base_ring, f"{key_base}:basejit", lat_deg * 0.08, lon_deg * 0.08)
    footprints.append({"role": "deck" if regime in {"marine_stratocumulus", "frontal_shield"} else "core", "points": base_ring})

    if regime == "deep_convection":
        core = scale_ring(base_ring, 0.45 + organization * 0.2, 0.45 + organization * 0.2, lat, lon)
        footprints.append({"role": "core", "points": core})
        tower = scale_ring(base_ring, 0.28 + organization * 0.16, 0.28 + organization * 0.16, lat, lon)
        footprints.append({"role": "tower", "points": tower})
    elif regime == "cirrus_sheet":
        smear = scale_ring(base_ring, 0.8, 1.35 + wind_shear * 0.5, lat, lon)
        smear = offset_ring(smear, math.sin(math.radians(anvil_dir_deg)) * 0.04, math.cos(math.radians(anvil_dir_deg)) * 0.06)
        footprints.append({"role": "wispy", "points": smear})
    else:
        fringe = scale_ring(base_ring, 1.12 + fringe_softness * 0.18, 1.12 + fringe_softness * 0.18, lat, lon)
        footprints.append({"role": "fringe", "points": fringe})

    if regime in {"marine_stratocumulus", "frontal_shield"}:
        hc = int(_clamp(1 + fringe_softness * 2, 0, 3))
        hole_rings = build_hole_rings_for_cloud(lat, lon, base_ring, hc, f"{key_base}:holes")
        for i, hr in enumerate(hole_rings):
            holes.append({"role": "deck_hole", "points": hr, "id": f"h-{i}"})

    if regime == "deep_convection" and anvil_spread_km > 15:
        anvil_lat = km_to_lat_deg(anvil_spread_km * 0.28)
        anvil_lon = km_to_lon_deg(anvil_spread_km * 0.54, lat)
        anvil = build_irregular_ellipse_ring(lat, lon, anvil_lat, anvil_lon, max(14, points_count), f"{key_base}:anvil", irregularity=0.24)
        footprints.append({"role": "anvil", "points": anvil})

    return {"footprints": footprints, "holes": holes}


def build_band_shells(regime: str, band: str, base_altitude_m: float, top_altitude_m: float, density: float, coverage: float, organization: float, key_base: str) -> list[dict]:
    _ = key_base
    depth = max(100.0, top_altitude_m - base_altitude_m)
    alpha = _clamp(0.12 + density * 0.26 + coverage * 0.18, 0.08, 0.62)
    z = 10 if band == "low" else 20 if band == "mid" else 30
    shells: list[dict] = []
    shells.append(
        {
            "role": "deck" if regime in {"marine_stratocumulus", "frontal_shield"} else "core",
            "footprint_ref": 0,
            "hole_refs": [0] if regime in {"marine_stratocumulus", "frontal_shield"} else [],
            "base_m": round(base_altitude_m, 1),
            "top_m": round(base_altitude_m + depth * (0.5 + organization * 0.35), 1),
            "fill": rgba_string(232, 238, 245, alpha),
            "stroke": rgba_string(245, 248, 252, alpha * 0.45),
            "stroke_width": 0.6,
            "extruded": regime != "cirrus_sheet",
            "z_index": z,
        }
    )
    if regime == "deep_convection":
        shells.append({"role": "tower", "footprint_ref": 2 if band != "high" else 1, "hole_refs": [], "base_m": round(base_altitude_m + depth * 0.25, 1), "top_m": round(top_altitude_m, 1), "fill": rgba_string(245, 247, 250, _clamp(alpha + 0.08, 0, 0.75)), "stroke": rgba_string(252, 253, 255, 0.22), "stroke_width": 0.7, "extruded": True, "z_index": z + 2})
        if band == "high":
            shells.append({"role": "anvil", "footprint_ref": min(3, 2), "hole_refs": [], "base_m": round(base_altitude_m + depth * 0.62, 1), "top_m": round(top_altitude_m, 1), "fill": rgba_string(238, 244, 252, _clamp(alpha * 0.8, 0.1, 0.5)), "stroke": rgba_string(246, 250, 255, 0.18), "stroke_width": 0.5, "extruded": True, "z_index": z + 3})
    elif regime == "cirrus_sheet":
        shells.append({"role": "wispy", "footprint_ref": 1, "hole_refs": [], "base_m": round(base_altitude_m + depth * 0.55, 1), "top_m": round(top_altitude_m, 1), "fill": rgba_string(225, 236, 250, _clamp(alpha * 0.65, 0.08, 0.38)), "stroke": rgba_string(239, 246, 255, 0.12), "stroke_width": 0.4, "extruded": False, "z_index": z + 1})
    else:
        shells.append({"role": "fringe", "footprint_ref": 1, "hole_refs": [], "base_m": round(base_altitude_m + depth * 0.18, 1), "top_m": round(base_altitude_m + depth * 0.72, 1), "fill": rgba_string(236, 242, 248, _clamp(alpha * 0.78, 0.08, 0.48)), "stroke": rgba_string(246, 250, 255, 0.14), "stroke_width": 0.5, "extruded": True, "z_index": z + 1})
    return shells


def classify_cloud_regime(tile: dict) -> str:
    low = float(tile.get("low_density") or 0)
    mid = float(tile.get("mid_density") or 0)
    high = float(tile.get("high_density") or 0)
    precip = float(tile.get("precipitation_factor") or 0)
    convection = float(tile.get("convection_factor") or 0)
    lat = float(((tile.get("bounds") or {}).get("lat_center") or 0))
    if convection > 0.68 and precip > 0.48:
        return "deep_convection"
    if high > 0.62 and low < 0.35 and precip < 0.38:
        return "cirrus_sheet"
    if low > 0.64 and mid < 0.5 and abs(lat) <= 44:
        return "marine_stratocumulus"
    if (low + mid + high) / 3 > 0.5 and mid > 0.46:
        return "frontal_shield"
    return "cumulus_field"


def compute_cloud_appearance(tile: dict, regime: str) -> dict:
    low = float(tile.get("low_density") or 0)
    mid = float(tile.get("mid_density") or 0)
    high = float(tile.get("high_density") or 0)
    precip = float(tile.get("precipitation_factor") or 0)
    convection = float(tile.get("convection_factor") or 0)
    wind = tile.get("wind") or {}
    u_low = float(((wind.get("low") or {}).get("u") or 0))
    v_low = float(((wind.get("low") or {}).get("v") or 0))
    u_high = float(((wind.get("high") or {}).get("u") or 0))
    v_high = float(((wind.get("high") or {}).get("v") or 0))
    wind_shear = _clamp(math.hypot(u_high - u_low, v_high - v_low) / 35.0, 0.0, 1.0)
    coverage = _clamp(low * 0.4 + mid * 0.35 + high * 0.25 + precip * 0.12, 0.0, 1.0)
    cfg = CLOUD_REGIMES.get(regime, CLOUD_REGIMES["cumulus_field"])
    anvil_dir = (math.degrees(math.atan2((u_low + u_high) / 2.0, (v_low + v_high) / 2.0)) + 360.0) % 360.0
    anvil_spread = 0.0
    if regime == "deep_convection":
        anvil_spread = _lerp(35.0, 140.0, _clamp(convection * 0.75 + wind_shear * 0.25, 0.0, 1.0))
    elif regime in {"frontal_shield", "cirrus_sheet"}:
        anvil_spread = _lerp(18.0, 95.0, _clamp(high * 0.7 + wind_shear * 0.3, 0.0, 1.0))
    organization = _clamp(0.24 + coverage * 0.38 + precip * 0.16 + convection * 0.22, 0.0, 1.0)
    return {
        "opacity": round(_clamp(0.16 + coverage * 0.62 + convection * 0.1, 0.0, 1.0), 4),
        "underside_darkness": round(_clamp(cfg["underside_darkness"] + precip * 0.16 + convection * 0.14, 0.0, 1.0), 4),
        "fringe_softness": round(_clamp(cfg["fringe_softness"] - convection * 0.1 + high * 0.08, 0.0, 1.0), 4),
        "organization": round(organization, 4),
        "wind_shear": round(wind_shear, 4),
        "tower_bias": round(_clamp(cfg["tower_bias"] + convection * 0.2, 0.0, 1.0), 4),
        "deck_bias": round(_clamp(cfg["deck_bias"] + low * 0.08 - convection * 0.1, 0.0, 1.0), 4),
        "wispy_bias": round(_clamp(cfg["wispy_bias"] + high * 0.1, 0.0, 1.0), 4),
        "anvil_dir_deg": round(anvil_dir, 2),
        "anvil_spread_km": round(anvil_spread, 1),
    }


def compute_cloud_importance(tile: dict, regime: str) -> float:
    low = float(tile.get("low_density") or 0)
    mid = float(tile.get("mid_density") or 0)
    high = float(tile.get("high_density") or 0)
    precip = float(tile.get("precipitation_factor") or 0)
    convection = float(tile.get("convection_factor") or 0)
    depth = float(tile.get("vertical_depth_m") or 2800)
    org = float(tile.get("organization") or 0.45)
    regime_boost = 0.08 if regime == "deep_convection" else 0.04 if regime in {"frontal_shield", "cirrus_sheet"} else 0.0
    score = low * 0.2 + mid * 0.24 + high * 0.18 + precip * 0.18 + convection * 0.18 + _clamp(depth / 12000.0, 0.0, 1.0) * 0.08 + org * 0.08 + regime_boost
    return round(_clamp(score, 0.0, 1.0), 4)


def enrich_cloud_band_geometry(tile: dict, band: str, regime: str, appearance: dict) -> dict:
    density = float(((tile.get("bands") or {}).get(band, {}).get("density") or tile.get(f"{band}_density") or 0))
    old_alt = float(tile.get(f"altitude_{band}") or (9000 if band == "high" else 4200 if band == "mid" else 1200))
    base_m = float(((tile.get("bands") or {}).get(band, {}).get("base_altitude_m") or old_alt))
    top_m = float(((tile.get("bands") or {}).get(band, {}).get("top_altitude_m") or (base_m + (1800 if band != "high" else 2200))))
    thickness = max(120.0, top_m - base_m)
    cov = float(((tile.get("bands") or {}).get(band, {}).get("coverage") or _clamp(density * 0.9 + float(tile.get("precipitation_factor") or 0) * 0.18, 0, 1)))
    lat = float(((tile.get("bounds") or {}).get("lat_center") or 0.0))
    lon = float(((tile.get("bounds") or {}).get("lon_center") or 0.0))
    lateral = float(((tile.get("bands") or {}).get(band, {}).get("lateral_scale_km") or _lerp(65.0, 190.0, _clamp(cov + density * 0.4, 0, 1))))
    key_base = f"{tile.get('tile_id','tile')}:{tile.get('seed','s')}:{regime}:{band}"
    footprints = build_band_footprints(
        tile_id=str(tile.get("tile_id") or "tile"),
        regime=regime,
        band=band,
        lat=lat,
        lon=lon,
        lateral_scale_km=lateral,
        organization=float(appearance.get("organization") or 0.5),
        fringe_softness=float(appearance.get("fringe_softness") or 0.6),
        wind_shear=float(appearance.get("wind_shear") or 0.0),
        anvil_dir_deg=float(appearance.get("anvil_dir_deg") or 0.0),
        anvil_spread_km=float(appearance.get("anvil_spread_km") or 0.0),
        density=density,
        coverage=cov,
        key_base=key_base,
    )
    shells = build_band_shells(
        regime=regime,
        band=band,
        base_altitude_m=base_m,
        top_altitude_m=top_m,
        density=density,
        coverage=cov,
        organization=float(appearance.get("organization") or 0.5),
        key_base=key_base,
    )
    wind = (((tile.get("wind") or {}).get(band)) or {})
    return {
        "density": round(density, 4),
        "coverage": round(cov, 4),
        "base_altitude_m": round(base_m, 1),
        "top_altitude_m": round(top_m, 1),
        "thickness_m": round(thickness, 1),
        "lateral_scale_km": round(lateral, 1),
        "wind": {"u": round(float(wind.get("u") or 0.0), 3), "v": round(float(wind.get("v") or 0.0), 3)},
        "footprints": footprints["footprints"],
        "holes": footprints["holes"],
        "shells": shells,
    }


def enrich_cloud_tile_geometry(tile: dict) -> dict:
    out = dict(tile)
    regime = classify_cloud_regime(out)
    appearance = compute_cloud_appearance(out, regime)
    seed_text = f"{out.get('tile_id','tile')}:{int(float(out.get('updated_at') or 0)//3600000)}:{regime}"
    out["seed"] = seed_text
    out["regime"] = regime
    out.update(appearance)
    out["importance"] = compute_cloud_importance(out, regime)
    bands = {}
    for b in ("low", "mid", "high"):
        bands[b] = enrich_cloud_band_geometry(out, b, regime, appearance)
    out["bands"] = bands
    out["subcells"] = build_subcell_layout(regime, max(float(out.get("low_density") or 0), float(out.get("mid_density") or 0), float(out.get("high_density") or 0)), float(appearance.get("organization") or 0.5), f"{seed_text}:sub")

    out["base_altitude_m"] = round(min(bands["low"]["base_altitude_m"], bands["mid"]["base_altitude_m"], bands["high"]["base_altitude_m"]), 1)
    out["top_altitude_m"] = round(max(bands["low"]["top_altitude_m"], bands["mid"]["top_altitude_m"], bands["high"]["top_altitude_m"]), 1)
    out["vertical_depth_m"] = round(max(0.0, out["top_altitude_m"] - out["base_altitude_m"]), 1)

    coverage = (float(bands["low"].get("coverage") or 0.0) * 0.42 + float(bands["mid"].get("coverage") or 0.0) * 0.36 + float(bands["high"].get("coverage") or 0.0) * 0.22)
    density = (float(bands["low"].get("density") or 0.0) * 0.40 + float(bands["mid"].get("density") or 0.0) * 0.36 + float(bands["high"].get("density") or 0.0) * 0.24)
    precip_factor = float(out.get("precipitation_factor") or 0.0)
    conv_factor = float(out.get("convection_factor") or 0.0)
    mid_wind = (out.get("wind") or {}).get("mid") or {}

    out["coverage"] = round(_clamp(coverage, 0.0, 1.0), 4)
    out["density"] = round(_clamp(density, 0.0, 1.0), 4)
    out["precip_rate"] = round(max(0.0, precip_factor * 45.0), 3)
    out["storm_energy"] = round(_clamp(conv_factor * 0.68 + precip_factor * 0.32, 0.0, 1.0), 4)
    out["wind_u"] = round(float(mid_wind.get("u") or 0.0), 3)
    out["wind_v"] = round(float(mid_wind.get("v") or 0.0), 3)
    out["importance"] = round(_clamp(float(out.get("importance") or 0.0), 0.0, 1.0), 4)

    # Explicitly mark these as estimated visualization fields.
    out["estimated_cloud_base_m"] = out["base_altitude_m"]
    out["estimated_cloud_top_m"] = out["top_altitude_m"]
    out["estimated_cloud_thickness_m"] = out["vertical_depth_m"]
    out["estimated_density"] = out["density"]

    return out


class GFSService:
    """Modular, namespaced GFS helpers for /gfs routes."""

    def __init__(self, static_dir: str) -> None:
        self.static_dir = Path(static_dir).resolve()
        self.data_dir = self.static_dir / "data"
        self.fishvid_dir = self.static_dir / "fishvid"
        self.store_path = self.data_dir / "gfs_location_store.json"
        self.state = GFSState()
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.fishvid_dir.mkdir(parents=True, exist_ok=True)
        self.http = requests.Session()
        self.http.headers.update({"User-Agent": DEFAULT_UA, "Accept": "application/json"})
        self.env_cache: Dict[str, Dict[str, Any]] = {}
        self.station_cache: Dict[str, Dict[str, Any]] = {}
        self.point_forecast_cache: Dict[str, Dict[str, Any]] = {}
        self.gfs_client = GFSNomadsClient(DEFAULT_GFS_CACHE_DIR)
        self.disk_cache = DiskCache(str(DEFAULT_GFS_CACHE_DIR / "payloads")) if DiskCache else None
        self.scene_tile_cache_dir = DEFAULT_SCENE_TILE_CACHE_DIR
        self.scene_tile_cache_dir.mkdir(parents=True, exist_ok=True)
        self.cfgrib_index_dir = DEFAULT_CFGRIB_INDEX_DIR
        self.frame_cache_dir = DEFAULT_FRAME_CACHE_DIR
        self.split_cache_dir = DEFAULT_SPLIT_CACHE_DIR
        self.ocean_cache_dir = DEFAULT_OCEAN_CACHE_DIR
        for _cache_dir in (DEFAULT_GFS_CACHE_DIR, DEFAULT_GFS_CACHE_DIR / "payloads", self.scene_tile_cache_dir, self.cfgrib_index_dir, self.frame_cache_dir, self.split_cache_dir, self.ocean_cache_dir):
            try:
                Path(_cache_dir).mkdir(parents=True, exist_ok=True)
            except Exception as exc:
                log.warning("[gfs/cache] cache directory ensure failed path=%s err=%s", _cache_dir, exc)
        self._scene_tile_cache_lock = threading.Lock()
        self._ingest_lock = threading.Lock()
        self._scene_refresh_lock = threading.Lock()
        self._weather_refresh_lock = threading.Lock()
        self._decode_cache: Dict[str, Dict[str, Any]] = {}
        # Process-local decoded GRIB snapshot cache.  The old path re-opened
        # cfgrib/xarray groups for every clouds/frame/hazard request even when
        # the NOMADS cycle/path had not changed.  Keeping one open decoded
        # snapshot per worker makes /gfs/api/frame and sibling routes reuse the
        # same GFS cycle instead of stampeding cfgrib.
        self._gfs_snapshot_lock = threading.RLock()
        self._gfs_snapshot: Dict[str, Any] = {"path": None, "groups": None, "backend": "none", "ts": 0, "cycle": None, "forecast_hour": None}
        self._weather_payload_cache: Dict[str, Any] = {"ts": 0, "payload": None}
        self.ocean_provider = RtofsProvider()
        self.bio_provider = CoastwatchProvider() if CoastwatchProvider else None
        self._recent_viewports: list[dict[str, float]] = []
        self._always_on_cache_started = False
        self._always_on_cache_thread = None
        self._always_on_cache_state: dict[str, Any] = {
            "enabled": os.getenv("GFS_ALWAYS_ON_CACHE", "true").strip().lower() in {"1", "true", "yes", "on"},
            "running": False,
            "started_at": None,
            "last_tick": None,
            "last_scheduled": None,
            "last_error": None,
            "interval_sec": int(os.getenv("GFS_ALWAYS_ON_INTERVAL_SEC", "180") or "180"),
            "fresh_target_sec": int(os.getenv("GFS_CACHE_FRESH_TARGET_SEC", "240") or "240"),
            "pad_factor": float(os.getenv("GFS_VIEWPORT_PAD_FACTOR", "1.25") or "1.25"),
        }

    def _now_ms(self) -> int:
        return int(time.time() * 1000)

    def _default_bbox(self) -> dict[str, float]:
        return {"west": -180.0, "south": -80.0, "east": 180.0, "north": 80.0}

    def _normalize_bbox(self, bbox: dict[str, float] | None = None) -> dict[str, float]:
        raw = bbox or self._default_bbox()
        return {
            "west": float(raw.get("west", -180.0)),
            "south": float(raw.get("south", -80.0)),
            "east": float(raw.get("east", 180.0)),
            "north": float(raw.get("north", 80.0)),
        }

    def _bbox_key_fragment(self, bbox: dict[str, float] | None) -> str:
        b = self._normalize_bbox(bbox)
        return f"{b['west']:.3f},{b['south']:.3f},{b['east']:.3f},{b['north']:.3f}"

    def _point_inside_bbox_padded(self, lat: float, lon: float, bbox: dict[str, float], pad_factor: float = 0.18) -> bool:
        try:
            lat = float(lat)
            lon = float(lon)
        except Exception:
            return False
        if not (-90.0 <= lat <= 90.0 and -1800.0 <= lon <= 1800.0):
            return False
        lon = ((lon + 180.0) % 360.0) - 180.0
        b = self._normalize_bbox(bbox)
        lat_span = abs(b["north"] - b["south"])
        lon_span = abs(b["east"] - b["west"])
        lat_pad = max(0.30, min(4.0, lat_span * pad_factor))
        lon_pad = max(0.30, min(6.0, lon_span * pad_factor))
        south = min(b["south"], b["north"]) - lat_pad
        north = max(b["south"], b["north"]) + lat_pad
        if lat < south or lat > north:
            return False
        west = ((b["west"] - lon_pad + 180.0) % 360.0) - 180.0
        east = ((b["east"] + lon_pad + 180.0) % 360.0) - 180.0
        if west <= east:
            return west <= lon <= east
        return lon >= west or lon <= east

    def _cloud_tile_center_lonlat(self, tile: dict[str, Any]) -> tuple[float | None, float | None]:
        bounds = tile.get("bounds") if isinstance(tile, dict) else None
        center = tile.get("center") if isinstance(tile, dict) else None
        lat = None
        lon = None
        if isinstance(bounds, dict):
            lat = bounds.get("lat_center", bounds.get("center_lat"))
            lon = bounds.get("lon_center", bounds.get("center_lon"))
        if (lat is None or lon is None) and isinstance(center, dict):
            lat = center.get("lat", lat)
            lon = center.get("lon", center.get("lng", lon))
        if lat is None:
            lat = tile.get("lat") if isinstance(tile, dict) else None
        if lon is None:
            lon = tile.get("lon", tile.get("lng")) if isinstance(tile, dict) else None
        try:
            return float(lat), float(lon)
        except Exception:
            return None, None

    def _clip_cloud_tiles_to_bbox(self, tiles: list[dict[str, Any]], bbox: dict[str, float]) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        kept: list[dict[str, Any]] = []
        rejected_invalid = 0
        rejected_out_of_bbox = 0
        lat_values: list[float] = []
        lon_values: list[float] = []
        for tile in tiles or []:
            if not isinstance(tile, dict):
                rejected_invalid += 1
                continue
            lat, lon = self._cloud_tile_center_lonlat(tile)
            if lat is None or lon is None or not math.isfinite(lat) or not math.isfinite(lon) or lat < -90.0 or lat > 90.0:
                rejected_invalid += 1
                continue
            lon = ((float(lon) + 180.0) % 360.0) - 180.0
            if not self._point_inside_bbox_padded(float(lat), lon, bbox):
                rejected_out_of_bbox += 1
                continue
            # Normalize the center contract so the frontend never has to guess.
            tile = dict(tile)
            bounds = dict(tile.get("bounds") or {})
            bounds.setdefault("lat_center", round(float(lat), 5))
            bounds.setdefault("lon_center", round(lon, 5))
            tile["bounds"] = bounds
            tile["center"] = {"lat": round(float(lat), 5), "lon": round(lon, 5)}
            kept.append(tile)
            lat_values.append(float(lat))
            lon_values.append(lon)
        diag = {
            "cloud_tiles_raw": len(tiles or []),
            "cloud_tiles_kept": len(kept),
            "rejected_invalid_coords": rejected_invalid,
            "rejected_out_of_bbox": rejected_out_of_bbox,
            "tile_lat_range": [round(min(lat_values), 5), round(max(lat_values), 5)] if lat_values else None,
            "tile_lon_range": [round(min(lon_values), 5), round(max(lon_values), 5)] if lon_values else None,
        }
        return kept, diag

    def _annotate_weather_payload(
        self,
        payload: dict[str, Any],
        *,
        bbox: dict[str, float],
        source: str,
        payload_state: str,
        heuristic: bool,
        quality_note: str,
        confidence: str,
    ) -> dict[str, Any]:
        out = dict(payload or {})
        out.setdefault("source", source)
        out.setdefault("cycle", None)
        out.setdefault("forecast_hour", None)
        out.setdefault("valid_time", None)
        out["bbox"] = bbox
        out["bbox_used"] = bbox
        out["requested_bbox"] = bbox
        out["payload_state"] = payload_state
        out["heuristic"] = bool(heuristic)
        out["quality_note"] = quality_note
        out["confidence"] = confidence
        out.setdefault("data_source", "live_gfs_0p25" if payload_state in {"live", "cached"} else "synthetic_fallback")
        out.setdefault("used_fallback", payload_state not in {"live", "cached"})
        out.setdefault("fallback_reason", None)
        out.setdefault("canonical_shape", out.get("grid_shape"))
        return out

    def _fish_csv_candidates(self) -> list[Path]:
        candidates: list[Path] = []
        env_path = os.getenv("FISH_CSV_PATH", "").strip()
        if env_path:
            candidates.append(Path(env_path).expanduser())
        candidates.extend([
            self.data_dir / "fishloclist.csv",
            self.static_dir / "data" / "fishloclist.csv",
            STATIC_DIR / "data" / "fishloclist.csv",
            BASE_DIR / "static" / "data" / "fishloclist.csv",
            Path.cwd() / "static" / "data" / "fishloclist.csv",
            Path.cwd() / "fishloclist.csv",
        ])
        seen: set[str] = set()
        out: list[Path] = []
        for path in candidates:
            try:
                resolved = str(path.resolve())
            except Exception:
                resolved = str(path)
            if resolved in seen:
                continue
            seen.add(resolved)
            out.append(path)
        return out

    def _fish_csv_path(self) -> Path:
        for path in self._fish_csv_candidates():
            if path.exists() and path.is_file():
                return path
        return self.data_dir / "fishloclist.csv"

    def _normalize_location_key(self, value: str) -> str:
        raw = (value or "").strip().lower()
        raw = re.sub(r"[^a-z0-9_-]+", "-", raw)
        raw = re.sub(r"-{2,}", "-", raw).strip("-")
        return raw[:80]

    def _cache_get(self, cache: Dict[str, Dict[str, Any]], key: str, ttl_seconds: int) -> Any:
        row = cache.get(key)
        if not row:
            return None
        if (self._utc_now() - row["ts"]).total_seconds() > ttl_seconds:
            cache.pop(key, None)
            return None
        return row.get("value")

    def _cache_put(self, cache: Dict[str, Dict[str, Any]], key: str, value: Any) -> None:
        cache[key] = {"ts": self._utc_now(), "value": value}

    def _rounded_env_key(self, lat: float, lon: float, precision: int = 2) -> str:
        return f"{round(float(lat), precision)}:{round(float(lon), precision)}"

    def _http_json(self, url: str, params: Dict[str, Any] | None = None, timeout: float = DEFAULT_HTTP_TIMEOUT) -> Any:
        resp = self.http.get(url, params=params or {}, timeout=timeout)
        resp.raise_for_status()
        return resp.json()

    def _safe_http_json(self, url: str, params: Dict[str, Any] | None = None, timeout: float = DEFAULT_HTTP_TIMEOUT) -> Any:
        try:
            return self._http_json(url, params=params, timeout=timeout)
        except Exception:
            return None

    def safe_data_var(self, ds: Any, names: list[str]) -> Any:
        """Return first matching data var from dataset by candidate names."""
        if ds is None:
            return None
        for name in names:
            if getattr(ds, "data_vars", None) is not None and name in ds.data_vars:
                return ds[name]
        return None

    def squeeze_forecast_array(self, arr: Any, preserve_dims: tuple[str, ...] = ()) -> Any:
        """Squeeze forecast-only singleton dimensions while optionally preserving vertical dims."""
        if arr is None:
            return None
        a = arr
        for dim in ["time", "step", "valid_time", "heightAboveGround", "surface", "isobaricInhPa"]:
            if dim in preserve_dims:
                continue
            if hasattr(a, "dims") and dim in a.dims and a.sizes.get(dim, 0) > 0:
                a = a.isel({dim: 0})
        return a

    def ensure_lat_lon_2d(self, ds: Any) -> tuple[Any, Any]:
        """Return 2D lat/lon arrays from dataset coords."""
        if ds is None or np is None:
            return None, None
        lat = ds.coords.get("latitude")
        if lat is None:
            lat = ds.coords.get("lat")
        lon = ds.coords.get("longitude")
        if lon is None:
            lon = ds.coords.get("lon")
        if lat is None or lon is None:
            return None, None
        latv = np.asarray(lat.values)
        lonv = np.asarray(lon.values)
        if latv.ndim == 1 and lonv.ndim == 1:
            lon2d, lat2d = np.meshgrid(lonv, latv)
            return lat2d, lon2d
        return latv, lonv

    def flip_lat_if_needed(self, arr: Any, lat: Any) -> Any:
        if np is None or arr is None or lat is None:
            return arr
        try:
            if lat.ndim >= 1 and lat[0, 0] < lat[-1, 0]:
                return np.flipud(arr)
        except Exception:
            pass
        return arr

    def to_native_float(self, value: Any) -> float:
        try:
            return float(value)
        except Exception:
            return 0.0

    def _cfgrib_backend_kwargs(self, grib_path: Path, filter_by_keys: dict[str, Any]) -> dict[str, Any]:
        """Stable cfgrib index files prevent /tmp races and missing index paths."""
        try:
            self.cfgrib_index_dir.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        digest = hashlib.sha1((str(grib_path) + json.dumps(filter_by_keys, sort_keys=True)).encode("utf-8")).hexdigest()[:24]
        index_path = self.cfgrib_index_dir / f"{digest}.idx"
        return {"filter_by_keys": filter_by_keys, "indexpath": str(index_path)}

    def open_surface_dataset(self, grib_path: Path) -> Any:
        if xr is None:
            return None
        return xr.open_dataset(grib_path, engine="cfgrib", backend_kwargs=self._cfgrib_backend_kwargs(grib_path, {"typeOfLevel": "surface", "stepType": "instant"}))

    def open_2m_dataset(self, grib_path: Path) -> Any:
        if xr is None:
            return None
        return xr.open_dataset(grib_path, engine="cfgrib", backend_kwargs=self._cfgrib_backend_kwargs(grib_path, {"typeOfLevel": "heightAboveGround", "level": 2}))

    def open_10m_dataset(self, grib_path: Path) -> Any:
        if xr is None:
            return None
        return xr.open_dataset(grib_path, engine="cfgrib", backend_kwargs=self._cfgrib_backend_kwargs(grib_path, {"typeOfLevel": "heightAboveGround", "level": 10}))

    def open_isobaric_dataset(self, grib_path: Path) -> Any:
        if xr is None:
            return None
        return xr.open_dataset(grib_path, engine="cfgrib", backend_kwargs=self._cfgrib_backend_kwargs(grib_path, {"typeOfLevel": "isobaricInhPa"}))

    def open_mean_sea_dataset(self, grib_path: Path) -> Any:
        if xr is None:
            return None
        return xr.open_dataset(grib_path, engine="cfgrib", backend_kwargs=self._cfgrib_backend_kwargs(grib_path, {"typeOfLevel": "meanSea"}))

    def _open_all_valid_groups_cfgrib(self, grib_path: Path) -> dict[str, Any]:
        groups: dict[str, Any] = {}
        openers = {
            "surface": self.open_surface_dataset,
            "2m": self.open_2m_dataset,
            "10m": self.open_10m_dataset,
            "isobaricInhPa": self.open_isobaric_dataset,
            "meanSea": self.open_mean_sea_dataset,
        }
        for name, fn in openers.items():
            try:
                ds = fn(grib_path)
                if ds is not None and len(getattr(ds, "data_vars", {})) > 0:
                    groups[name] = ds
                    print(f"[gfs] cfgrib group opened: {name} vars={list(ds.data_vars.keys())[:8]}")
                elif ds is not None:
                    print(f"[gfs] cfgrib group empty: {name}")
            except Exception as exc:
                print(f"[gfs] cfgrib group failed: {name}: {exc}")
        return groups

    def _open_all_valid_groups_pygrib(self, grib_path: Path) -> dict[str, Any]:
        """Fallback decoder path that normalizes pygrib messages to xarray datasets."""
        if pygrib is None or xr is None:
            return {}
        groups: dict[str, dict[str, Any]] = {}
        try:
            with pygrib.open(str(grib_path)) as grbs:
                for msg in grbs:
                    level_type = str(getattr(msg, "typeOfLevel", "") or "")
                    if level_type not in {"surface", "heightAboveGround", "isobaricInhPa", "meanSea"}:
                        continue
                    short_name = str(getattr(msg, "shortName", "") or "")
                    if not short_name:
                        continue
                    lat2d, lon2d = msg.latlons()
                    values = msg.values
                    if np is None:
                        continue
                    lat_arr = np.asarray(lat2d[:, 0], dtype=float)
                    lon_arr = np.asarray(lon2d[0, :], dtype=float)
                    val_arr = np.asarray(values, dtype=float)
                    if val_arr.ndim != 2:
                        continue
                    by_group = groups.setdefault(level_type, {})
                    if short_name in by_group:
                        continue
                    by_group[short_name] = xr.DataArray(val_arr, dims=("latitude", "longitude"), coords={"latitude": lat_arr, "longitude": lon_arr})
            out: dict[str, Any] = {}
            for gname, vars_map in groups.items():
                if vars_map:
                    out[gname] = xr.Dataset(vars_map)
                    print(f"[gfs] pygrib group opened: {gname} vars={list(vars_map.keys())[:8]}")
            return out
        except Exception as exc:
            print(f"[gfs] pygrib fallback failed: {exc}")
            return {}

    def open_all_valid_groups(self, grib_path: Path) -> tuple[dict[str, Any], str]:
        """Open available GRIB groups with cfgrib primary and pygrib fallback."""
        groups = self._open_all_valid_groups_cfgrib(grib_path)
        if groups:
            loaded = ", ".join([k for k in ["surface", "2m", "10m", "isobaric", "meanSea"] if (k in groups or (k == "isobaric" and "isobaricInhPa" in groups))])
            print(f"[gfs] datasets loaded: {loaded}")
            return groups, "cfgrib"
        groups = self._open_all_valid_groups_pygrib(grib_path)
        if groups:
            return groups, "pygrib"
        return {}, "none"



    def _gfs_snapshot_ttl_seconds(self) -> int:
        try:
            return max(60, int(os.getenv("GFS_DECODE_SNAPSHOT_TTL_SECONDS", "900") or "900"))
        except Exception:
            return 900

    def _snapshot_path_key(self, grib_path: Path | str | None) -> str:
        if not grib_path:
            return ""
        try:
            p = Path(grib_path)
            stat = p.stat()
            return f"{p.resolve()}:{int(stat.st_mtime)}:{int(stat.st_size)}"
        except Exception:
            return str(grib_path)

    def _cached_decoded_groups(self, grib_path: Path | str | None) -> tuple[dict[str, Any] | None, str | None]:
        key = self._snapshot_path_key(grib_path)
        if not key:
            return None, None
        ttl = self._gfs_snapshot_ttl_seconds()
        now = time.time()
        with self._gfs_snapshot_lock:
            snap = self._gfs_snapshot or {}
            if snap.get("path_key") == key and isinstance(snap.get("groups"), dict) and snap.get("groups"):
                age = now - float(snap.get("ts") or 0)
                if age <= ttl:
                    return snap.get("groups"), str(snap.get("backend") or "cfgrib")
        return None, None

    def _cache_decoded_groups(self, grib_path: Path | str | None, groups: dict[str, Any], backend: str, fetch: Any | None = None) -> tuple[dict[str, Any], str]:
        key = self._snapshot_path_key(grib_path)
        if not key or not groups:
            return groups, backend
        with self._gfs_snapshot_lock:
            old = self._gfs_snapshot or {}
            old_groups = old.get("groups") if old.get("path_key") != key else None
            self._gfs_snapshot = {
                "path_key": key,
                "path": str(grib_path),
                "groups": groups,
                "backend": backend,
                "ts": time.time(),
                "cycle": getattr(fetch, "cycle", None) if fetch is not None else old.get("cycle"),
                "forecast_hour": getattr(fetch, "forecast_hour", None) if fetch is not None else old.get("forecast_hour"),
            }
        if isinstance(old_groups, dict):
            self._release_groups(old_groups)
        return groups, backend

    def _decode_groups_cached(self, grib_path: Path | str | None, fetch: Any | None = None) -> tuple[dict[str, Any], str, bool]:
        cached, backend = self._cached_decoded_groups(grib_path)
        if cached:
            return cached, backend or "cfgrib", True
        groups, backend = self.open_all_valid_groups(Path(grib_path)) if grib_path else ({}, "none")
        if groups:
            self._cache_decoded_groups(grib_path, groups, backend, fetch=fetch)
            return groups, backend, True
        return groups, backend, False

    def _release_groups(self, groups: dict[str, Any] | None) -> None:
        for ds in (groups or {}).values():
            close_fn = getattr(ds, "close", None)
            if callable(close_fn):
                try:
                    close_fn()
                except Exception:
                    pass

    def _model_analysis_time_from_cycle(self, cycle: str | None) -> str | None:
        if not cycle:
            return None
        try:
            return datetime.strptime(str(cycle), "%Y%m%d%H").replace(tzinfo=timezone.utc).isoformat()
        except Exception:
            return None

    def _collect_available_fields(self, groups: dict[str, Any]) -> tuple[list[str], list[str]]:
        available = set()
        for gname, ds in (groups or {}).items():
            for v in list(getattr(ds, "data_vars", {}).keys()):
                available.add(f"{gname}:{v}")

        desired = {
            "surface:PRATE", "surface:APCP", "surface:TCDC", "surface:CAPE", "surface:UGRD", "surface:VGRD",
            "2m:TCDC", "2m:UGRD", "2m:VGRD", "10m:UGRD", "10m:VGRD",
            "isobaricInhPa:RH", "isobaricInhPa:TMP", "isobaricInhPa:HGT", "isobaricInhPa:UGRD", "isobaricInhPa:VGRD",
        }
        missing = sorted([k for k in desired if k not in available])
        return sorted(available), missing

    def _update_ingest_state_success(self, fetch: FetchResult, groups: dict[str, Any], mode: str, error: str | None = None) -> None:
        now_ms = self._now_ms()
        self.state.ingest_status = mode
        self.state.ingest_last_success_ts = now_ms if mode in {"live", "last_known_good"} else self.state.ingest_last_success_ts
        self.state.ingest_error = error
        self.state.model_cycle = fetch.cycle or self.state.model_cycle
        self.state.model_forecast_hour = fetch.forecast_hour if fetch.forecast_hour is not None else self.state.model_forecast_hour
        self.state.model_valid_time = fetch.valid_time or self.state.model_valid_time
        self.state.model_analysis_time = self._model_analysis_time_from_cycle(fetch.cycle) or self.state.model_analysis_time
        self.state.model_source_url = fetch.url or self.state.model_source_url
        self.state.model_cache_path = str(fetch.path) if fetch.path else self.state.model_cache_path
        self.state.degraded_mode = mode != "live"
        self.state.using_last_known_good = mode == "last_known_good"
        if self.state.decode_backend == "none":
            self.state.data_source_mode = "heuristic"
        elif self.state.decode_backend == "cfgrib":
            self.state.data_source_mode = "primary"
        else:
            self.state.data_source_mode = "fallback"
        available, missing = self._collect_available_fields(groups)
        self.state.fields_available = available
        self.state.fields_missing = missing

    def ingest_latest_model_fields(self, bbox: dict[str, float]) -> dict[str, Any]:
        """Attempt real NOMADS->GRIB2 ingestion and retain last-known-good state on failure."""
        bbox = self._normalize_bbox(bbox)
        now_ms = self._now_ms()
        self.state.ingest_last_attempt_ts = now_ms

        with self._ingest_lock:
            now = utc_now()
            ttl_ms = INGEST_MIN_INTERVAL_SECONDS * 1000
            recent_ok = (
                self.state.ingest_last_success_ts
                and (now_ms - int(self.state.ingest_last_success_ts)) < ttl_ms
                and self.state.last_good_model_state
            )
            if recent_ok:
                lkg = self.state.last_good_model_state or {}
                lkg_path_raw = lkg.get("fetch", {}).get("path")
                lkg_path = Path(lkg_path_raw) if lkg_path_raw else None
                if lkg_path and lkg_path.exists():
                    lkg_groups, lkg_backend, lkg_cache_owned = self._decode_groups_cached(lkg_path)
                    if lkg_groups:
                        self.state.decode_backend = lkg_backend
                        self.state.data_source_mode = "primary" if lkg_backend == "cfgrib" else "fallback" if lkg_backend == "pygrib" else "heuristic"
                        lkg_fetch = FetchResult(
                            ok=True,
                            path=lkg_path,
                            cycle=str(lkg.get("fetch", {}).get("cycle") or ""),
                            forecast_hour=int(lkg.get("fetch", {}).get("forecast_hour") or 0),
                            valid_time=str(lkg.get("fetch", {}).get("valid_time") or ""),
                            error="",
                            url=str(lkg.get("fetch", {}).get("url") or ""),
                        )
                        self._update_ingest_state_success(lkg_fetch, lkg_groups, mode="last_known_good")
                        return {"mode": "last_known_good", "fetch": lkg_fetch, "groups": lkg_groups, "bbox": lkg.get("bbox") or bbox, "cache_owned": bool(lkg_cache_owned)}
            try:
                fetch = self.gfs_client.fetch_latest_available_subset(now, bbox, DEFAULT_REQUIRED_VARIABLES, DEFAULT_REQUIRED_LEVELS)
                if not fetch.ok or not fetch.path:
                    raise RuntimeError(fetch.error or "nomads fetch failed")
                print(f"[gfs-ingest] selected cycle={fetch.cycle} fhr={fetch.forecast_hour} url={fetch.url}")
                if fetch.path.stat().st_size < INGEST_CACHE_MIN_BYTES:
                    raise RuntimeError("downloaded GRIB2 too small")
                print(f"[gfs-ingest] cache file ready path={fetch.path} size={fetch.path.stat().st_size}")

                try:
                    groups, decode_backend, groups_cache_owned = self._decode_groups_cached(fetch.path, fetch=fetch)
                except Exception as e:
                    print(f"[gfs] gfs decode failed: {e}")
                    raise RuntimeError("gfs decode failed") from e
                self.state.decode_backend = decode_backend
                self.state.data_source_mode = "primary" if decode_backend == "cfgrib" else "fallback" if decode_backend == "pygrib" else "heuristic"
                if not groups:
                    raise RuntimeError("no GRIB groups decoded")

                print(f"[gfs-ingest] decoded groups={list(groups.keys())} backend={decode_backend}")
                self.state.last_good_model_state = {
                    "fetch": {
                        "cycle": fetch.cycle,
                        "forecast_hour": fetch.forecast_hour,
                        "valid_time": fetch.valid_time,
                        "url": fetch.url,
                        "path": str(fetch.path),
                    },
                    "bbox": bbox,
                    "saved_at": now_ms,
                }
                self._update_ingest_state_success(fetch, groups, mode="live")
                return {"mode": "live", "fetch": fetch, "groups": groups, "bbox": bbox, "cache_owned": bool(groups_cache_owned)}
            except Exception as exc:
                print(f"[gfs-ingest] live ingest failed: {exc}")
                self.state.ingest_error = str(exc)
                lkg = self.state.last_good_model_state or {}
                lkg_path_raw = lkg.get("fetch", {}).get("path")
                lkg_path = Path(lkg_path_raw) if lkg_path_raw else None
                if lkg_path and lkg_path.exists():
                    lkg_groups, lkg_backend, lkg_cache_owned = self._decode_groups_cached(lkg_path)
                    if lkg_groups:
                        self.state.decode_backend = lkg_backend
                        self.state.data_source_mode = "primary" if lkg_backend == "cfgrib" else "fallback" if lkg_backend == "pygrib" else "heuristic"
                        lkg_fetch = FetchResult(
                            ok=True,
                            path=lkg_path,
                            cycle=str(lkg.get("fetch", {}).get("cycle") or ""),
                            forecast_hour=int(lkg.get("fetch", {}).get("forecast_hour") or 0),
                            valid_time=str(lkg.get("fetch", {}).get("valid_time") or ""),
                            error="",
                            url=str(lkg.get("fetch", {}).get("url") or ""),
                        )
                        print("[gfs-ingest] using last-known-good GRIB2 file")
                        self._update_ingest_state_success(lkg_fetch, lkg_groups, mode="last_known_good", error=str(exc))
                        return {"mode": "last_known_good", "fetch": lkg_fetch, "groups": lkg_groups, "bbox": lkg.get("bbox") or bbox, "error": str(exc), "cache_owned": bool(lkg_cache_owned)}
                self.state.ingest_status = "failed"
                self.state.degraded_mode = True
                self.state.using_last_known_good = False
                self.state.decode_backend = "none"
                self.state.data_source_mode = "heuristic"
                raise

    def _utc_now(self) -> datetime:
        return datetime.now(timezone.utc)

    def _iso_utc(self, dt: datetime) -> str:
        return dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")

    def _time_of_day_bucket(self, lat: float, lon: float, ts_ms: int) -> str:
        _ = lat
        dt = datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc) + timedelta(hours=round(lon / 15.0))
        hour = dt.hour
        if 4 <= hour < 7:
            return "dawn"
        if 7 <= hour < 17:
            return "day"
        if 17 <= hour < 20:
            return "dusk"
        return "night"

    def _sun_angle_proxy(self, lat: float, lon: float, ts_ms: int) -> float:
        dt = datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc)
        day_frac = (dt.hour + dt.minute / 60.0 + lon / 15.0) / 24.0
        seasonal = math.cos(2 * math.pi * ((dt.timetuple().tm_yday - 172) / 365.25))
        solar = math.sin(2 * math.pi * (day_frac - 0.25))
        lat_factor = math.cos(math.radians(lat))
        return _clamp((solar * lat_factor * 0.85 + seasonal * 0.15 + 1.0) / 2.0, 0.0, 1.0)

    def _moon_phase_proxy(self, ts_ms: int) -> Dict[str, Any]:
        days = ts_ms / 1000.0 / 86400.0
        synodic = 29.53058867
        phase = (days % synodic) / synodic
        illum = 0.5 * (1 - math.cos(2 * math.pi * phase))
        if phase < 0.03 or phase > 0.97:
            label = "new"
        elif 0.47 <= phase <= 0.53:
            label = "full"
        elif phase < 0.5:
            label = "waxing"
        else:
            label = "waning"
        return {"phase": round(phase, 4), "illumination": round(illum, 4), "label": label}

    BAIT_TERMS = ["anchovy", "sardine", "mackerel", "smelt", "herring", "bait ball", "boil", "chum", "squid", "shiner"]
    RIG_TERMS = ["carolina", "sabiki", "flyline", "float", "jig", "swimbait", "dropper loop", "texas rig", "spinner", "topwater"]
    SPECIES_TERMS = ["halibut", "calico", "bass", "yellowtail", "perch", "corbina", "tuna", "snapper", "tarpon", "snook"]

    def _extract_text_blobs(self, point: Dict[str, Any]) -> List[str]:
        blobs: List[str] = []
        for field in ("name", "location_key", "description", "notes", "intent", "area", "zone"):
            v = point.get(field)
            if isinstance(v, str) and v.strip():
                blobs.append(v.strip())

        meta = point.get("meta") if isinstance(point.get("meta"), dict) else {}
        for k, v in meta.items():
            if isinstance(v, str) and v.strip() and any(tok in k.lower() for tok in ("report", "note", "comment", "desc", "bait", "rig", "species")):
                blobs.append(v.strip())

        store = self._load_store()
        key = self._normalize_location_key(str(point.get("location_key") or ""))
        rec = ((store.get("locations") or {}).get(key) or {}) if key else {}
        report_text = rec.get("report_text")
        if isinstance(report_text, str) and report_text.strip():
            blobs.append(report_text.strip())
        return blobs

    def _term_counts(self, texts: List[str], terms: List[str]) -> Dict[str, int]:
        joined = "\n".join(texts).lower()
        out: Dict[str, int] = {}
        for t in terms:
            cnt = len(re.findall(rf"\b{re.escape(t.lower())}\b", joined))
            if cnt:
                out[t] = cnt
        return out

    def _history_features_for_point(self, point: Dict[str, Any]) -> Dict[str, Any]:
        texts = self._extract_text_blobs(point)
        bait_mentions = self._term_counts(texts, self.BAIT_TERMS)
        rig_mentions = self._term_counts(texts, self.RIG_TERMS)
        species_mentions = self._term_counts(texts, self.SPECIES_TERMS)
        report_count = len([t for t in texts if len(t) > 12])

        richness = _clamp((report_count / 8.0) + (sum(bait_mentions.values()) / 12.0), 0.0, 1.0)
        success = _clamp(0.25 + richness * 0.55 + (sum(species_mentions.values()) / 15.0), 0.0, 1.0)

        def top_terms(d: Dict[str, int]) -> List[str]:
            return [k for k, _ in sorted(d.items(), key=lambda kv: kv[1], reverse=True)[:3]]

        return {
            "report_count": report_count,
            "bait_mentions": bait_mentions,
            "rig_mentions": rig_mentions,
            "species_mentions": species_mentions,
            "historical_success_score": round(success, 4),
            "dominant_baits": top_terms(bait_mentions),
            "dominant_rigs": top_terms(rig_mentions),
            "dominant_species": top_terms(species_mentions),
        }

    def _supports_us_station_enrichment(self, lat: float, lon: float) -> bool:
        return (15.0 <= lat <= 72.5 and -170.0 <= lon <= -60.0)

    def _supports_global_gfs(self, lat: float, lon: float) -> bool:
        return -90.0 <= lat <= 90.0 and -180.0 <= lon <= 180.0

    def _point_has_report_history(self, point: Dict[str, Any]) -> bool:
        h = self._history_features_for_point(point)
        return h.get("report_count", 0) > 0 or bool(h.get("dominant_baits"))

    def _select_environment_strategy(self, lat: float, lon: float, point: Dict[str, Any]) -> str:
        if self._supports_us_station_enrichment(lat, lon):
            return "station_enriched_us"
        if self._supports_global_gfs(lat, lon):
            return "global_model_gfs"
        if self._point_has_report_history(point):
            return "history_augmented"
        return "heuristic_only"

    def _candidate_coops_stations(self, lat: float, lon: float) -> List[Dict[str, Any]]:
        _ = (lat, lon)
        return [
            {"id": "9410170", "name": "San Diego", "lat": 32.714, "lon": -117.173},
            {"id": "9414290", "name": "San Francisco", "lat": 37.806, "lon": -122.465},
            {"id": "8724580", "name": "Key West", "lat": 24.556, "lon": -81.807},
            {"id": "8518750", "name": "The Battery", "lat": 40.701, "lon": -74.014},
            {"id": "9455920", "name": "Anchorage", "lat": 61.238, "lon": -149.89},
        ]

    def _haversine_km(self, lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        r = 6371.0
        p1, p2 = math.radians(lat1), math.radians(lat2)
        dp = math.radians(lat2 - lat1)
        dl = math.radians(lon2 - lon1)
        a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
        return 2 * r * math.asin(math.sqrt(max(0.0, min(1.0, a))))

    def _nearest_coops_station_id(self, lat: float, lon: float) -> str | None:
        stations = self._candidate_coops_stations(lat, lon)
        nearest = None
        best = 1e9
        for st in stations:
            d = self._haversine_km(lat, lon, float(st["lat"]), float(st["lon"]))
            if d < best:
                best = d
                nearest = st["id"]
        return nearest if best <= 900 else None

    def _fetch_nws_point_meta(self, lat: float, lon: float) -> Any:
        key = f"nws-point:{self._rounded_env_key(lat, lon, 2)}"
        cached = self._cache_get(self.point_forecast_cache, key, NWS_CACHE_TTL_SECONDS)
        if cached is not None:
            return cached
        payload = self._safe_http_json(f"{NWS_API_BASE}/points/{lat:.4f},{lon:.4f}")
        self._cache_put(self.point_forecast_cache, key, payload)
        return payload

    def _fetch_nws_hourly_forecast(self, lat: float, lon: float) -> Any:
        meta = self._fetch_nws_point_meta(lat, lon)
        hourly_url = (((meta or {}).get("properties") or {}).get("forecastHourly"))
        if not hourly_url:
            return None
        key = f"nws-hourly:{hourly_url}"
        cached = self._cache_get(self.point_forecast_cache, key, NWS_CACHE_TTL_SECONDS)
        if cached is not None:
            return cached
        payload = self._safe_http_json(hourly_url)
        self._cache_put(self.point_forecast_cache, key, payload)
        return payload

    def _parse_nws_hourly_environment(self, payload: Any) -> Dict[str, Any]:
        periods = (((payload or {}).get("properties") or {}).get("periods") or [])
        p0 = periods[0] if periods else {}
        wind_speed_val = str(p0.get("windSpeed") or "0")
        m = re.search(r"(\d+)", wind_speed_val)
        wind_mph = float(m.group(1)) if m else 0.0
        return {
            "short_forecast": p0.get("shortForecast"),
            "temperature_f": p0.get("temperature"),
            "wind_speed_kt": round(wind_mph * 0.868976, 2),
            "wind_direction_text": p0.get("windDirection"),
            "precip_probability_pct": (((p0.get("probabilityOfPrecipitation") or {}).get("value")) or 0),
            "relative_humidity_pct": (((p0.get("relativeHumidity") or {}).get("value")) or 0),
            "is_daytime": bool(p0.get("isDaytime", True)),
        }

    def _fetch_coops_tides(self, station_id: str) -> Any:
        key = f"coops-tide:{station_id}"
        cached = self._cache_get(self.station_cache, key, TIDE_CACHE_TTL_SECONDS)
        if cached is not None:
            return cached
        now = self._utc_now()
        payload = self._safe_http_json(
            NOAA_TIDES_API,
            params={
                "product": "predictions",
                "application": "lftr",
                "station": station_id,
                "datum": "MLLW",
                "time_zone": "gmt",
                "units": "english",
                "interval": "h",
                "format": "json",
                "begin_date": now.strftime("%Y%m%d"),
                "end_date": (now + timedelta(days=1)).strftime("%Y%m%d"),
            },
        )
        self._cache_put(self.station_cache, key, payload)
        return payload

    def _fetch_coops_currents(self, station_id: str) -> Any:
        key = f"coops-current:{station_id}"
        cached = self._cache_get(self.station_cache, key, TIDE_CACHE_TTL_SECONDS)
        if cached is not None:
            return cached
        payload = self._safe_http_json(
            NOAA_TIDES_API,
            params={
                "product": "currents_predictions",
                "application": "lftr",
                "station": station_id,
                "time_zone": "gmt",
                "units": "english",
                "interval": "MAX_SLACK",
                "format": "json",
            },
        )
        self._cache_put(self.station_cache, key, payload)
        return payload

    def _parse_tide_payload(self, payload: Any) -> Dict[str, Any]:
        preds = (payload or {}).get("predictions") or []
        if not preds:
            return {"tide_height_ft": None, "tide_time_utc": None}
        p0 = preds[0]
        height = p0.get("v")
        return {"tide_height_ft": float(height) if height is not None else None, "tide_time_utc": p0.get("t")}

    def _parse_currents_payload(self, payload: Any) -> Dict[str, Any]:
        arr = (payload or {}).get("current_predictions") or (payload or {}).get("cp") or []
        if not arr:
            return {"current_speed_kt": None, "current_direction_deg": None}
        p0 = arr[0]
        speed = p0.get("Velocity_Major") or p0.get("v") or p0.get("speed")
        direction = p0.get("Direction_Bin") or p0.get("d") or p0.get("direction")
        return {
            "current_speed_kt": float(speed) if speed not in (None, "") else None,
            "current_direction_deg": float(direction) if direction not in (None, "") else None,
        }

    def _gfsish_environment_proxy(self, lat: float, lon: float, ts_ms: int) -> Dict[str, Any]:
        hour_bucket = ts_ms // 3_600_000
        low, mid, high, precip, convection = self._cloud_density_triplet(lat, lon, int(hour_bucket))
        lat_r = math.radians(lat)
        lon_r = math.radians(lon)
        t = hour_bucket / 5.0
        u = 6.0 + 8.5 * math.sin(lat_r * 0.8 - lon_r * 0.3 + t * 0.14)
        v = 2.6 * math.cos(lon_r * 0.85 + t * 0.09)
        speed_ms = math.hypot(u, v)
        wind_dir = (math.degrees(math.atan2(u, v)) + 360.0) % 360.0
        cloud_cover = _clamp(low * 0.52 + mid * 0.31 + high * 0.17, 0.0, 1.0)
        pressure = 1016.0 - precip * 14.0 - convection * 8.0 + (0.5 - cloud_cover) * 5.0
        return {
            "cloud_cover_pct": int(round(cloud_cover * 100)),
            "precipitation_factor": round(precip, 4),
            "convection_factor": round(convection, 4),
            "wind_speed_kt": round(speed_ms * 1.94384, 2),
            "wind_direction_deg": round(wind_dir, 1),
            "wind_gust_kt": round(speed_ms * 1.94384 * (1.2 + convection * 0.4), 2),
            "pressure_mb": round(pressure, 1),
        }

    def _fetch_sst_erddap(self, lat: float, lon: float) -> Dict[str, Any] | None:
        key = f"sst:{self._rounded_env_key(lat, lon, 1)}"
        cached = self._cache_get(self.env_cache, key, SST_CACHE_TTL_SECONDS)
        if cached is not None:
            return cached
        payload = None
        self._cache_put(self.env_cache, key, payload)
        return payload

    def _build_station_plus_gfs_environment(self, lat: float, lon: float, ts_ms: int, point: Dict[str, Any]) -> Dict[str, Any]:
        _ = point
        env = self._gfsish_environment_proxy(lat, lon, ts_ms)
        nws = self._parse_nws_hourly_environment(self._fetch_nws_hourly_forecast(lat, lon))
        station_id = self._nearest_coops_station_id(lat, lon)
        tides = self._parse_tide_payload(self._fetch_coops_tides(station_id)) if station_id else {}
        currents = self._parse_currents_payload(self._fetch_coops_currents(station_id)) if station_id else {}
        moon = self._moon_phase_proxy(ts_ms)
        return {
            **env,
            **{k: v for k, v in nws.items() if v is not None},
            **{k: v for k, v in tides.items() if v is not None},
            **{k: v for k, v in currents.items() if v is not None},
            "station_id": station_id,
            "sun_angle": round(self._sun_angle_proxy(lat, lon, ts_ms), 4),
            "moon": moon,
            "time_bucket": self._time_of_day_bucket(lat, lon, ts_ms),
        }

    def _build_global_gfs_environment(self, lat: float, lon: float, ts_ms: int, point: Dict[str, Any]) -> Dict[str, Any]:
        _ = point
        env = self._gfsish_environment_proxy(lat, lon, ts_ms)
        sst = self._fetch_sst_erddap(lat, lon) or {}
        return {
            **env,
            **sst,
            "sun_angle": round(self._sun_angle_proxy(lat, lon, ts_ms), 4),
            "moon": self._moon_phase_proxy(ts_ms),
            "time_bucket": self._time_of_day_bucket(lat, lon, ts_ms),
        }

    def _build_history_augmented_environment(self, lat: float, lon: float, ts_ms: int, point: Dict[str, Any]) -> Dict[str, Any]:
        env = self._gfsish_environment_proxy(lat, lon, ts_ms)
        history = self._history_features_for_point(point)
        return {
            **env,
            "history_success_score": history.get("historical_success_score", 0),
            "sun_angle": round(self._sun_angle_proxy(lat, lon, ts_ms), 4),
            "moon": self._moon_phase_proxy(ts_ms),
            "time_bucket": self._time_of_day_bucket(lat, lon, ts_ms),
        }

    def _build_heuristic_environment(self, lat: float, lon: float, ts_ms: int, point: Dict[str, Any]) -> Dict[str, Any]:
        _ = point
        env = self._gfsish_environment_proxy(lat, lon, ts_ms)
        return {
            **env,
            "sun_angle": round(self._sun_angle_proxy(lat, lon, ts_ms), 4),
            "moon": self._moon_phase_proxy(ts_ms),
            "time_bucket": self._time_of_day_bucket(lat, lon, ts_ms),
        }

    def _build_environment_meta(self, strategy: str, env: Dict[str, Any], point: Dict[str, Any], history: Dict[str, Any]) -> Dict[str, Any]:
        _ = (env, point)
        mod_map = {
            "station_enriched_us": 1.12,
            "global_model_gfs": 1.0,
            "history_augmented": 0.9,
            "heuristic_only": 0.78,
        }
        sources = ["solar_lunar", "history"]
        if strategy == "station_enriched_us":
            sources += ["global_gfs_proxy", "nws_hourly", "coops"]
        elif strategy == "global_model_gfs":
            sources += ["global_gfs_proxy", "sst_optional"]
        elif strategy == "history_augmented":
            sources += ["global_gfs_proxy", "report_history"]
        else:
            sources += ["global_gfs_proxy"]
        return {
            "source_tier": strategy,
            "sources_used": sources,
            "station_supported": strategy == "station_enriched_us",
            "global_supported": self._supports_global_gfs(float(point.get("lat") or 0), float(point.get("lon") or 0)),
            "history_supported": bool(history.get("report_count") or history.get("dominant_baits")),
            "coverage_mode": "worldwide_backbone",
            "confidence_modifier": mod_map.get(strategy, 0.78),
        }

    def _build_environment_context(self, lat: float, lon: float, ts_ms: int, point: Dict[str, Any]) -> Dict[str, Any]:
        cache_key = f"env:{self._rounded_env_key(lat, lon)}:{int(ts_ms // 600000)}:{hashlib.md5(str(point.get('location_key','')).encode()).hexdigest()[:8]}"
        cached = self._cache_get(self.env_cache, cache_key, ENV_CACHE_TTL_SECONDS)
        if cached is not None:
            return cached

        history = self._history_features_for_point(point)
        strategy = self._select_environment_strategy(lat, lon, point)
        if strategy == "station_enriched_us":
            environment = self._build_station_plus_gfs_environment(lat, lon, ts_ms, point)
        elif strategy == "global_model_gfs":
            environment = self._build_global_gfs_environment(lat, lon, ts_ms, point)
        elif strategy == "history_augmented":
            environment = self._build_history_augmented_environment(lat, lon, ts_ms, point)
        else:
            environment = self._build_heuristic_environment(lat, lon, ts_ms, point)
        env_meta = self._build_environment_meta(strategy, environment, point, history)
        out = {"environment": environment, "environment_meta": env_meta, "history": history}
        self._cache_put(self.env_cache, cache_key, out)
        return out

    def _score_bait_theory(self, lat: float, lon: float, ts_ms: int, env: Dict[str, Any], history: Dict[str, Any], env_meta: Dict[str, Any]) -> Dict[str, Any]:
        tod = self._time_of_day_bucket(lat, lon, ts_ms)
        tod_score = {"dawn": 0.84, "day": 0.58, "dusk": 0.82, "night": 0.48}.get(tod, 0.55)
        sun = float(env.get("sun_angle") or self._sun_angle_proxy(lat, lon, ts_ms))
        moon = ((env.get("moon") or {}).get("illumination") if isinstance(env.get("moon"), dict) else None)
        moon = float(moon or self._moon_phase_proxy(ts_ms).get("illumination") or 0.5)
        wind = float(env.get("wind_speed_kt") or 8.0)
        cloud = float(env.get("cloud_cover_pct") or 45.0) / 100.0
        precip = float(env.get("precipitation_factor") or 0.1)
        convection = float(env.get("convection_factor") or 0.1)
        current = float(env.get("current_speed_kt") or 0.7)
        tide_height = float(env.get("tide_height_ft") or 1.6)
        hist = float(history.get("historical_success_score") or 0.35)
        conf_mod = float(env_meta.get("confidence_modifier") or 0.8)

        wind_pref = 1.0 - min(1.0, abs(wind - 11.0) / 20.0)
        cloud_pref = 1.0 - abs(cloud - 0.45)
        precip_pen = max(0.0, 1.0 - precip * 0.55)
        conv_pen = max(0.0, 1.0 - convection * 0.35)
        current_pref = 1.0 - min(1.0, abs(current - 1.4) / 2.2)
        tide_pref = 1.0 - min(1.0, abs(tide_height - 2.2) / 4.5)

        presence = _clamp(
            (tod_score * 0.22 + wind_pref * 0.14 + cloud_pref * 0.12 + current_pref * 0.13 + tide_pref * 0.08 + sun * 0.09 + moon * 0.04 + hist * 0.18)
            * precip_pen
            * conv_pen,
            0.03,
            0.98,
        )

        confidence = int(round(_clamp((0.44 + hist * 0.24 + wind_pref * 0.14 + cloud_pref * 0.08) * conf_mod, 0.12, 0.97) * 100))
        if presence >= 0.7:
            intensity = "high"
        elif presence >= 0.42:
            intensity = "medium"
        else:
            intensity = "low"

        dominant_baits = [str(x).lower() for x in (history.get("dominant_baits") or []) if x]
        target_species = str(env.get("target_species") or history.get("top_species") or "").lower()
        trout_bias = any(tok in target_species for tok in ("trout", "steelhead", "salmonid")) or (float(env.get("water_temp_c") or 0) <= 16 and float(env.get("salinity_psu") or 0) < 8)
        trout_primary = ["nightcrawlers", "mealworms", "wax worms", "salmon eggs", "power bait"]
        trout_secondary = ["red worms", "trout worms", "inline spinners", "small spoons", "crickets"]
        general_primary = ["nightcrawlers", "minnows", "shiners", "red worms", "crawlers"]
        general_secondary = ["mealworms", "wax worms", "inline spinners", "small spoons", "power bait", "squid", "anchovy", "sardine"]
        bait_candidates = [*dominant_baits]
        seed = trout_primary + trout_secondary if trout_bias else general_primary + general_secondary
        for b in seed:
            if b not in bait_candidates:
                bait_candidates.append(b)

        dominant_rigs = history.get("dominant_rigs") or []
        best_rig = dominant_rigs[0] if dominant_rigs else ("flyline" if presence > 0.6 else "dropper loop")

        if presence > 0.72:
            school_size = "large, cohesive bait balls"
            depth = [8, 38]
            agg = "tight_ball"
            mobility = "aggressive_migration"
            line_class = "20-30 lb"
        elif presence > 0.45:
            school_size = "medium scattered schools"
            depth = [18, 62]
            agg = "broken_patches"
            mobility = "moderate_roaming"
            line_class = "15-25 lb"
        else:
            school_size = "small fragmented schools"
            depth = [35, 95]
            agg = "loose_columns"
            mobility = "slow_drift"
            line_class = "10-20 lb"

        feeding_label = {"dawn": "Prime dawn feed", "dusk": "Prime dusk feed", "day": "Intermittent daytime feed", "night": "Low-light nighttime pick"}.get(tod, "Active window")

        surface_boils = _clamp(presence * (1.1 - cloud * 0.3) * (1 - precip * 0.35), 0.0, 1.0)
        predator_pressure = _clamp(0.32 + presence * 0.55 + hist * 0.2, 0.0, 1.0)

        return {
            "intensity": intensity,
            "confidence": confidence,
            "presence_probability": round(presence, 4),
            "school_size_estimate": school_size,
            "school_depth_band_ft": depth,
            "bait_type_candidates": bait_candidates,
            "aggregation_mode": agg,
            "mobility": mobility,
            "feeding_window": {"label": feeding_label, "confidence": round(_clamp(0.45 + presence * 0.5, 0.0, 1.0), 4)},
            "surface_boils_likelihood": round(surface_boils, 4),
            "predator_pressure": round(predator_pressure, 4),
            "school_summary": f"{school_size} expected in {depth[0]}-{depth[1]} ft with {bait_candidates[0]} emphasis.",
            "recommendation": {
                "best_bait": bait_candidates[0],
                "best_depth_zone_ft": depth,
                "best_rig": best_rig,
                "best_line_class": line_class,
                "primary_baits": bait_candidates[:5],
                "secondary_baits": bait_candidates[5:10],
                "target_species": ["trout", "bass", "catfish", "panfish", "walleye"],
                "confidence_reason": f"{feeding_label}; wind {wind:.1f}kt, cloud {int(round(cloud*100))}%, precip factor {precip:.2f}",
            },
        }

    def _build_bait_intel(self, point: Dict[str, Any], ts_ms: int) -> Dict[str, Any]:
        lat = point.get("lat")
        lon = point.get("lon")
        if lat is None or lon is None:
            return self._heuristic_context(None, None, ts_ms)
        lat_f = float(lat)
        lon_f = float(lon)
        env_ctx = self._build_environment_context(lat_f, lon_f, ts_ms, point)
        bait = self._score_bait_theory(lat_f, lon_f, ts_ms, env_ctx["environment"], env_ctx["history"], env_ctx["environment_meta"])
        weather_summary = (
            f"Clouds {int(env_ctx['environment'].get('cloud_cover_pct', 0))}% | "
            f"Wind {env_ctx['environment'].get('wind_speed_kt', 0)} kt | "
            f"Pressure {env_ctx['environment'].get('pressure_mb', 'n/a')} mb"
        )
        water_context = (
            f"Current {env_ctx['environment'].get('current_speed_kt', 'n/a')} kt | "
            f"Tide {env_ctx['environment'].get('tide_height_ft', 'n/a')} ft | "
            f"Tier {env_ctx['environment_meta'].get('source_tier')}"
        )
        marker_environment = self._marker_environment_payload(lat_f, lon_f, point, env_ctx, bait, ts_ms)
        return {
            "bait": bait,
            "environment": env_ctx["environment"],
            "environment_meta": env_ctx["environment_meta"],
            "history": env_ctx["history"],
            "marker_environment": marker_environment,
            "weather_environment": marker_environment,
            "weather": {
                "summary": weather_summary,
                "water_context": water_context,
                "marker_environment": marker_environment,
            },
        }

    def _compass_label(self, deg: Any) -> str | None:
        try:
            d = float(deg)
            if not math.isfinite(d):
                return None
        except Exception:
            return None
        dirs = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"]
        return dirs[int((d + 11.25) // 22.5) % 16]

    def _marker_ocean_solve(self, lat: float, lon: float, env: Dict[str, Any], point: Dict[str, Any], ts_ms: int) -> Dict[str, Any]:
        """Stable per-marker ocean/boating contract used when gridded ocean cells are sparse.

        This intentionally avoids failing closed when HYCOM/WW3/NDBC subsets are
        temporarily unavailable. It uses the live environment/station signal when
        present and only falls back to deterministic wind-current proxies. The HUD
        can still show a useful boating/ocean solve with source transparency.
        """
        def n(value: Any, default: float | None = None, digits: int = 2) -> float | None:
            try:
                if value is None or value == "":
                    return default
                v = float(value)
                if not math.isfinite(v):
                    return default
                return round(v, digits)
            except Exception:
                return default

        wind_kt = n(env.get("wind_speed_kt"), 8.0, 2) or 8.0
        wind_dir = n(env.get("wind_direction_deg"), None, 1)
        if wind_dir is None:
            txt = str(env.get("wind_direction_text") or "").upper()
            compass = {"N": 0, "NE": 45, "E": 90, "SE": 135, "S": 180, "SW": 225, "W": 270, "NW": 315}
            wind_dir = compass.get(txt[:2], compass.get(txt[:1], (float(ts_ms // 3600000) * 17.0 + lon * 2.5) % 360.0))
        wind_dir = float(wind_dir) % 360.0

        current_kt = n(env.get("current_speed_kt"), None, 2)
        current_dir = n(env.get("current_direction_deg"), None, 1)
        proxy_current = current_kt is None
        if current_kt is None:
            phase = (ts_ms // 1800000) / 5.0
            current_kt = round(_clamp(0.28 + abs(math.sin(math.radians(lat * 3.0 + lon) + phase)) * 1.25 + wind_kt * 0.018, 0.12, 2.8), 2)
        if current_dir is None:
            current_dir = round((wind_dir + 28.0 + math.sin(math.radians(lat + lon)) * 22.0) % 360.0, 1)

        sst_f = n(env.get("sst_f"), None, 1)
        if sst_f is None:
            seasonal = 62.0 + 5.5 * math.sin(((datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc).timetuple().tm_yday - 80) / 365.0) * math.tau)
            latitude_bias = max(-10.0, min(10.0, (34.0 - lat) * 0.33))
            sst_f = round(seasonal + latitude_bias, 1)

        base_height = _clamp(0.7 + wind_kt * 0.105 + current_kt * 0.28, 0.5, 8.0)
        cloud = n(env.get("cloud_cover_pct"), 40.0, 0) or 40.0
        conv = n(env.get("convection_factor"), 0.1, 3) or 0.1
        weather_mult = 1.0 + max(0.0, cloud - 65.0) * 0.004 + conv * 0.2
        primary_h = round(base_height * weather_mult, 1)
        primary_period = round(_clamp(5.2 + primary_h * 1.45 + wind_kt * 0.08, 5.0, 18.0), 1)
        swell_from = (wind_dir + 180.0) % 360.0
        swells = [
            {"label": "Primary", "heightFt": primary_h, "periodS": primary_period, "dirDeg": round(swell_from, 1), "dirText": self._compass_label(swell_from), "source": "marker_ocean_solve"},
            {"label": "Secondary", "heightFt": round(max(0.2, primary_h * 0.58), 1), "periodS": round(max(4.0, primary_period * 0.78), 1), "dirDeg": round((swell_from + 26.0) % 360.0, 1), "dirText": self._compass_label((swell_from + 26.0) % 360.0), "source": "marker_ocean_solve"},
            {"label": "Third", "heightFt": round(max(0.2, primary_h * 0.34), 1), "periodS": round(max(3.0, primary_period * 0.58), 1), "dirDeg": round((swell_from + 52.0) % 360.0, 1), "dirText": self._compass_label((swell_from + 52.0) % 360.0), "source": "marker_ocean_solve"},
        ]
        safety_color, safety_label = safety_color_from_wave_ft(primary_h, wind_kt) if 'safety_color_from_wave_ft' in globals() else ("green", "Calm boating conditions")
        if primary_h >= 4.0 or wind_kt >= 24.0:
            safety_color, safety_label = "red", "Hazardous boating conditions"
        elif primary_h >= 3.0 or wind_kt >= 18.0:
            safety_color, safety_label = "yellow", "Moderate boating conditions"

        source_notes = []
        if proxy_current:
            source_notes.append("current_proxy")
        if not env.get("station_id"):
            source_notes.append("no_station_match")
        source_tier = "station_ocean_enriched" if env.get("station_id") else "regional_ocean_proxy"
        return {
            "ok": True,
            "source_tier": source_tier,
            "source_notes": source_notes,
            "valid_time": datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc).isoformat(),
            "sst_f": sst_f,
            "current": {"speedKt": current_kt, "dirDeg": round(current_dir, 1), "dirText": self._compass_label(current_dir), "derivedFrom": "coops" if not proxy_current else "wind_tide_proxy"},
            "wind": {"speedKt": round(wind_kt, 1), "dirDeg": round(wind_dir, 1), "dirText": self._compass_label(wind_dir)},
            "waves": {"sigHeightFt": primary_h, "primary": swells[0], "secondary": swells[1], "tertiary": swells[2], "components": swells},
            "swells": swells,
            "safety": {"color": safety_color, "label": safety_label, "derivedFrom": source_tier},
            "boat": {
                "id": f"marker_boat_{point.get('location_key') or point.get('id') or 'node'}",
                "lat": round(float(lat), 5),
                "lon": round(float(lon), 5),
                "headingDeg": round(current_dir, 1),
                "current": {"speedKt": current_kt, "dirDeg": round(current_dir, 1), "dirText": self._compass_label(current_dir)},
                "wind": {"speedKt": round(wind_kt, 1), "dirDeg": round(wind_dir, 1), "dirText": self._compass_label(wind_dir)},
                "waves": {"sigHeightFt": primary_h, "primary": swells[0], "secondary": swells[1], "tertiary": swells[2], "components": swells},
                "water": {"tempF": sst_f, "airTempF": n(env.get("temperature_f"), None, 1)},
                "safety": {"color": safety_color, "label": safety_label, "derivedFrom": source_tier},
                "marineStation": {"id": env.get("station_id"), "distanceKm": None} if env.get("station_id") else None,
                "_distance_nm": 0.0,
            },
        }

    def _marker_environment_payload(
        self,
        lat: float,
        lon: float,
        point: Dict[str, Any],
        env_ctx: Dict[str, Any],
        bait: Dict[str, Any],
        ts_ms: int,
    ) -> Dict[str, Any]:
        """Compact marker-HUD weather/environment contract.

        The HUD should not need to reverse-engineer backend fields.  This
        payload keeps the raw environment while also exposing display-ready
        strings and stable source metadata for /gfs/api/location/<id>,
        /gfs/api/intelligence/node/<id>, and /gfs/api/location/<id>/environment.
        """
        env = dict(env_ctx.get("environment") or {})
        meta = dict(env_ctx.get("environment_meta") or {})
        history = dict(env_ctx.get("history") or {})
        moon = env.get("moon") if isinstance(env.get("moon"), dict) else {}

        def n(value: Any, digits: int = 1) -> float | None:
            try:
                if value is None or value == "":
                    return None
                v = float(value)
                if not math.isfinite(v):
                    return None
                return round(v, digits)
            except Exception:
                return None

        wind_kt = n(env.get("wind_speed_kt"), 1)
        wind_dir = n(env.get("wind_direction_deg"), 0)
        wind_gust_kt = n(env.get("wind_gust_kt"), 1)
        cloud_pct = n(env.get("cloud_cover_pct"), 0)
        precip_factor = n(env.get("precipitation_factor"), 3)
        precip_pct = n(env.get("precip_probability_pct"), 0)
        pressure_mb = n(env.get("pressure_mb"), 1)
        current_kt = n(env.get("current_speed_kt"), 2)
        current_dir = n(env.get("current_direction_deg"), 0)
        tide_ft = n(env.get("tide_height_ft"), 2)
        temp_f = n(env.get("temperature_f"), 1)
        humidity_pct = n(env.get("relative_humidity_pct"), 0)
        sst_f = n(env.get("sst_f"), 1)
        sun_angle = n(env.get("sun_angle"), 3)
        convection = n(env.get("convection_factor"), 3)
        ocean_solve = self._marker_ocean_solve(lat, lon, env, point, ts_ms)
        swell_components = list((ocean_solve.get("waves") or {}).get("components") or ocean_solve.get("swells") or [])

        now_label = []
        if temp_f is not None:
            now_label.append(f"Air {temp_f:.1f}°F")
        if sst_f is not None:
            now_label.append(f"Water {sst_f:.1f}°F")
        if wind_kt is not None:
            now_label.append(f"Wind {wind_kt:.1f} kt" + (f" @ {wind_dir:.0f}°" if wind_dir is not None else ""))
        if cloud_pct is not None:
            now_label.append(f"Cloud {cloud_pct:.0f}%")

        water_label = []
        if current_kt is not None:
            water_label.append(f"Current {current_kt:.2f} kt" + (f" @ {current_dir:.0f}°" if current_dir is not None else ""))
        if tide_ft is not None:
            water_label.append(f"Tide {tide_ft:.2f} ft")
        if precip_pct is not None:
            water_label.append(f"Precip {precip_pct:.0f}%")
        elif precip_factor is not None:
            water_label.append(f"Precip factor {precip_factor:.3f}")
        if pressure_mb is not None:
            water_label.append(f"Pressure {pressure_mb:.1f} mb")
        if swell_components:
            sw0 = swell_components[0]
            water_label.append(f"Primary swell {sw0.get('heightFt')} ft @ {sw0.get('periodS')}s {sw0.get('dirText') or ''}".strip())

        source_label = str(meta.get("source_tier") or "unknown")
        confidence = n((meta.get("confidence_modifier") or 0) * 100, 0)
        updated_iso = datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc).isoformat()
        return {
            "ok": True,
            "lat": round(float(lat), 5),
            "lon": round(float(lon), 5),
            "location_id": point.get("location_key") or point.get("id"),
            "source_tier": source_label,
            "sources_used": list(meta.get("sources_used") or []),
            "coverage_mode": meta.get("coverage_mode"),
            "confidence_pct": confidence,
            "valid_time": updated_iso,
            "updated_at": ts_ms,
            "display": {
                "now": " • ".join(now_label) if now_label else "Environment solve pending",
                "water": " • ".join(water_label) if water_label else "Water/current/tide solve pending",
                "source": f"Source tier {source_label}" + (f" • confidence {confidence:.0f}%" if confidence is not None else ""),
                "short_forecast": env.get("short_forecast") or "Local model proxy",
                "time_bucket": env.get("time_bucket"),
                "bait_window": (bait.get("feeding_window") or {}).get("label") if isinstance(bait, dict) else None,
            },
            "weather": {
                "air_temp_f": temp_f,
                "short_forecast": env.get("short_forecast"),
                "humidity_pct": humidity_pct,
                "cloud_cover_pct": cloud_pct,
                "precip_probability_pct": precip_pct,
                "precipitation_factor": precip_factor,
                "convection_factor": convection,
                "pressure_mb": pressure_mb,
                "wind_speed_kt": wind_kt,
                "wind_direction_deg": wind_dir,
                "wind_direction_text": env.get("wind_direction_text"),
                "wind_gust_kt": wind_gust_kt,
            },
            "water": {
                "sst_f": sst_f,
                "current_speed_kt": current_kt,
                "current_direction_deg": current_dir,
                "tide_height_ft": tide_ft,
                "tide_time_utc": env.get("tide_time_utc"),
                "station_id": env.get("station_id"),
            },
            "astro": {
                "sun_angle": sun_angle,
                "moon_label": moon.get("label"),
                "moon_phase": n(moon.get("phase"), 4),
                "moon_illumination": n(moon.get("illumination"), 4),
                "is_daytime": env.get("is_daytime"),
                "time_bucket": env.get("time_bucket"),
            },
            "ocean": ocean_solve,
            "boating": ocean_solve.get("boat"),
            "swell_components": swell_components,
            "swells": swell_components,
            "bait_window": bait.get("feeding_window") if isinstance(bait, dict) else None,
            "raw_environment": env,
            "environment_meta": meta,
            "history": history,
        }

    def _heuristic_context(self, lat: float | None, lon: float | None, ts_ms: int) -> Dict[str, Any]:
        if lat is None or lon is None or not (-90 <= float(lat) <= 90 and -180 <= float(lon) <= 180):
            fallback_point = {"lat": DEFAULT_WORLD_ENV_MARKER["lat"], "lon": DEFAULT_WORLD_ENV_MARKER["lon"], "location_key": "fallback", "meta": {}}
            intel = self._build_bait_intel(fallback_point, ts_ms)
            intel["bait"]["intensity"] = "low"
            intel["bait"]["confidence"] = min(intel["bait"].get("confidence", 42), 42)
            intel["environment_meta"]["source_tier"] = "heuristic_only"
            return intel

        point = {"lat": float(lat), "lon": float(lon), "location_key": f"pt-{self._rounded_env_key(float(lat), float(lon), 3)}", "meta": {}}
        return self._build_bait_intel(point, ts_ms)

    def _stable_noise(self, a: float, b: float, c: float) -> float:
        mix = math.sin(a * 12.9898 + b * 78.233 + c * 37.719)
        return mix - math.floor(mix)

    def _cloud_density_triplet(self, lat: float, lon: float, hour_bucket: int) -> Tuple[float, float, float, float, float]:
        lat_r = math.radians(lat)
        lon_r = math.radians(lon)
        t = hour_bucket / 6.0

        macro = (
            0.5
            + 0.25 * math.sin(2.4 * lat_r + 0.8 * lon_r + t * 0.9)
            + 0.18 * math.cos(3.7 * lon_r - t * 0.7)
            + 0.12 * math.sin(5.2 * (lat_r + lon_r) + t * 0.35)
        )
        macro = max(0.0, min(1.0, macro))

        frontness = abs(math.sin(lat_r * 2.7 + lon_r * 0.35 + t * 0.45))
        gradient = abs(math.cos(lat_r * 3.9 - lon_r * 1.4 + t * 0.28))
        convective_proxy = max(0.0, min(1.0, 0.35 + 0.55 * frontness * gradient))

        humidity_surface = max(0.0, min(1.0, 0.45 + 0.35 * math.cos(lat_r - t * 0.08) + 0.2 * self._stable_noise(lat, lon, t)))
        humidity_mid = max(0.0, min(1.0, 0.4 + 0.42 * math.sin(lat_r * 1.6 + t * 0.1) + 0.18 * self._stable_noise(lat * 0.7, lon * 0.5, t)))
        humidity_high = max(0.0, min(1.0, 0.35 + 0.45 * math.cos(lon_r * 0.9 + t * 0.09) + 0.15 * self._stable_noise(lat * 0.6, lon * 0.3, t + 2)))

        low = max(0.0, min(1.0, macro * 0.7 + humidity_surface * 0.35 + convective_proxy * 0.2 - 0.12))
        mid = max(0.0, min(1.0, macro * 0.6 + humidity_mid * 0.45 + convective_proxy * 0.24 - 0.16))
        high = max(0.0, min(1.0, macro * 0.55 + humidity_high * 0.5 + frontness * 0.22 - 0.18))

        precipitation_factor = max(0.0, min(1.0, (low * 0.5 + mid * 0.7 + convective_proxy * 0.65) - 0.38))
        convection_factor = max(0.0, min(1.0, convective_proxy * 0.85 + precipitation_factor * 0.3))

        return low, mid, high, precipitation_factor, convection_factor

    def _classify_cloud_regime(
        self,
        low: float,
        mid: float,
        high: float,
        precip: float,
        convection: float,
        lat: float,
    ) -> str:
        if convection > 0.72 and precip > 0.55:
            return "deep_convection"
        if high > 0.62 and low < 0.35 and precip < 0.35:
            return "cirrus_sheet"
        if low > 0.66 and mid < 0.46 and high < 0.34 and abs(lat) <= 42:
            return "marine_stratocumulus"
        if (low + mid + high) / 3.0 > 0.52 and mid > 0.48:
            return "frontal_shield"
        return "cumulus_field"

    def _derive_band_architecture(
        self,
        regime: str,
        band: str,
        density: float,
        precip: float,
        convection: float,
        u: float,
        v: float,
    ) -> Dict[str, Any]:
        speed = math.hypot(float(u or 0.0), float(v or 0.0))
        regime_cfg = CLOUD_REGIMES[regime]

        if band == "low":
            base_alt = regime_cfg["base_altitude_m"]
            thickness = _lerp(700.0, 2200.0, density)
            if regime == "marine_stratocumulus":
                thickness *= 0.85
            lateral_scale = _lerp(70.0, regime_cfg["lateral_scale_km"], density)
        elif band == "mid":
            base_alt = max(2200.0, regime_cfg["base_altitude_m"] + 1900.0)
            thickness = _lerp(1000.0, 3200.0, density)
            lateral_scale = _lerp(60.0, regime_cfg["lateral_scale_km"] * 0.78, density)
        else:
            base_alt = max(6500.0, regime_cfg["base_altitude_m"] + 6200.0)
            thickness = _lerp(900.0, 2600.0, density)
            lateral_scale = _lerp(90.0, regime_cfg["lateral_scale_km"] * 1.05, density)

        if regime == "deep_convection":
            if band == "low":
                thickness *= _lerp(1.2, 1.7, convection)
            elif band == "mid":
                thickness *= _lerp(1.3, 1.9, convection)
            else:
                thickness *= _lerp(1.1, 1.6, convection)

        if regime == "cirrus_sheet" and band == "high":
            lateral_scale *= 1.35
            thickness *= 0.72

        top_alt = base_alt + thickness
        coverage = _clamp(density * 0.92 + precip * 0.18, 0.0, 1.0)

        return {
            "density": round(density, 4),
            "base_altitude_m": round(base_alt, 1),
            "top_altitude_m": round(top_alt, 1),
            "thickness_m": round(thickness, 1),
            "coverage": round(coverage, 4),
            "lateral_scale_km": round(lateral_scale, 1),
            "wind": {
                "u": round(float(u or 0.0), 3),
                "v": round(float(v or 0.0), 3),
                "speed_ms": round(speed, 3),
            },
        }

    def _derive_tile_cloud_architecture(
        self,
        tile_id: str,
        lat_center: float,
        lon_center: float,
        low: float,
        mid: float,
        high: float,
        precip: float,
        convection: float,
        wind_low: Dict[str, float],
        wind_mid: Dict[str, float],
        wind_high: Dict[str, float],
        seed: int,
    ) -> Dict[str, Any]:
        regime = self._classify_cloud_regime(low, mid, high, precip, convection, lat_center)
        cfg = CLOUD_REGIMES[regime]

        coverage = _clamp(low * 0.42 + mid * 0.33 + high * 0.25 + precip * 0.12, 0.0, 1.0)
        opacity = _clamp(0.18 + coverage * 0.64 + convection * 0.10, 0.0, 1.0)

        u_low = float((wind_low or {}).get("u", 0.0))
        v_low = float((wind_low or {}).get("v", 0.0))
        u_mid = float((wind_mid or {}).get("u", 0.0))
        v_mid = float((wind_mid or {}).get("v", 0.0))
        u_high = float((wind_high or {}).get("u", 0.0))
        v_high = float((wind_high or {}).get("v", 0.0))

        shear = math.hypot(u_high - u_low, v_high - v_low)
        wind_shear = _clamp(shear / 35.0, 0.0, 1.0)

        bands = {
            "low": self._derive_band_architecture(regime, "low", low, precip, convection, u_low, v_low),
            "mid": self._derive_band_architecture(regime, "mid", mid, precip, convection, u_mid, v_mid),
            "high": self._derive_band_architecture(regime, "high", high, precip, convection, u_high, v_high),
        }

        base_altitude_m = min(bands["low"]["base_altitude_m"], bands["mid"]["base_altitude_m"], bands["high"]["base_altitude_m"])
        top_altitude_m = max(bands["low"]["top_altitude_m"], bands["mid"]["top_altitude_m"], bands["high"]["top_altitude_m"])
        vertical_depth_m = max(0.0, top_altitude_m - base_altitude_m)

        mean_u = (u_low + u_mid + u_high) / 3.0
        mean_v = (v_low + v_mid + v_high) / 3.0
        anvil_dir_deg = (math.degrees(math.atan2(mean_u, mean_v)) + 360.0) % 360.0
        anvil_spread_km = 0.0
        if regime == "deep_convection":
            anvil_spread_km = _lerp(35.0, 140.0, _clamp(convection * 0.75 + wind_shear * 0.25, 0.0, 1.0))
        elif regime in ("frontal_shield", "cirrus_sheet"):
            anvil_spread_km = _lerp(20.0, 90.0, _clamp(high * 0.7 + wind_shear * 0.3, 0.0, 1.0))

        organization = _clamp(0.25 + coverage * 0.35 + precip * 0.15 + convection * 0.25, 0.0, 1.0)
        underside_darkness = _clamp(cfg["underside_darkness"] + precip * 0.16 + convection * 0.14, 0.0, 1.0)
        fringe_softness = _clamp(cfg["fringe_softness"] - convection * 0.10 + high * 0.06, 0.0, 1.0)

        return {
            "regime": regime,
            "coverage": round(coverage, 4),
            "opacity": round(opacity, 4),
            "base_altitude_m": round(base_altitude_m, 1),
            "top_altitude_m": round(top_altitude_m, 1),
            "vertical_depth_m": round(vertical_depth_m, 1),
            "underside_darkness": round(underside_darkness, 4),
            "fringe_softness": round(fringe_softness, 4),
            "organization": round(organization, 4),
            "wind_shear": round(wind_shear, 4),
            "tower_bias": round(_clamp(cfg["tower_bias"] + convection * 0.18, 0.0, 1.0), 4),
            "deck_bias": round(_clamp(cfg["deck_bias"] + low * 0.08 - convection * 0.10, 0.0, 1.0), 4),
            "wispy_bias": round(_clamp(cfg["wispy_bias"] + high * 0.10, 0.0, 1.0), 4),
            "anvil_dir_deg": round(anvil_dir_deg, 2),
            "anvil_spread_km": round(anvil_spread_km, 1),
            "bands": bands,
        }

    def _build_cloud_subcells(self, seed: int, regime: str, coverage: float, convection: float, precip: float) -> List[Dict[str, Any]]:
        rng = random.Random(seed)
        base_count = 4
        if coverage > 0.5:
            base_count += 2
        if convection > 0.55:
            base_count += 2
        if regime == "deep_convection":
            base_count += 2

        subcells = []
        for idx in range(base_count):
            role = "fringe"
            if regime == "deep_convection" and idx == 0:
                role = "tower"
            elif idx < 2:
                role = "core"
            elif regime in ("marine_stratocumulus", "frontal_shield") and idx >= base_count - 2:
                role = "deck"
            elif regime == "cirrus_sheet":
                role = "wispy"

            subcells.append(
                {
                    "id": f"sc-{idx}",
                    "dx": round(rng.uniform(-0.38, 0.38), 4),
                    "dy": round(rng.uniform(-0.38, 0.38), 4),
                    "weight": round(_clamp(rng.uniform(0.45, 1.0) * (0.7 + coverage * 0.3), 0.0, 1.0), 4),
                    "role": role,
                }
            )
        return subcells

    def _cloud_tile_payload(self, lat_min: float, lat_max: float, lon_min: float, lon_max: float, hour_bucket: int) -> Dict[str, Any]:
        lat_center = (lat_min + lat_max) / 2.0
        lon_center = (lon_min + lon_max) / 2.0

        low, mid, high, precip, convection = self._cloud_density_triplet(lat_center, lon_center, hour_bucket)

        lat_r = math.radians(lat_center)
        lon_r = math.radians(lon_center)
        t = hour_bucket / 5.0

        wind_low_u = round(3.5 + 7.5 * math.sin(lat_r + t * 0.15), 3)
        wind_low_v = round(2.0 * math.cos(lon_r - t * 0.12), 3)

        wind_mid_u = round(6.0 + 9.5 * math.sin(lat_r * 0.8 - lon_r * 0.3 + t * 0.14), 3)
        wind_mid_v = round(2.6 * math.cos(lon_r * 0.85 + t * 0.09), 3)

        wind_high_u = round(11.0 + 17.0 * math.sin(lat_r * 0.55 + lon_r * 0.22 - t * 0.16), 3)
        wind_high_v = round(3.8 * math.cos(lon_r * 0.6 - t * 0.11), 3)

        importance = _clamp(
            low * 0.22
            + mid * 0.24
            + high * 0.18
            + precip * 0.18
            + convection * 0.18,
            0.0,
            1.0,
        )

        lat_idx = int((lat_min + 90) // 6)
        lon_idx = int((lon_min + 180) // 6)

        seed = int((abs(lat_center) * 1000 + abs(lon_center) * 100 + hour_bucket) % 10_000_000)
        wind = {
            "low": {"u": wind_low_u, "v": wind_low_v},
            "mid": {"u": wind_mid_u, "v": wind_mid_v},
            "high": {"u": wind_high_u, "v": wind_high_v},
        }
        arch = self._derive_tile_cloud_architecture(
            tile_id=f"gfs-{lat_idx:02d}-{lon_idx:02d}",
            lat_center=lat_center,
            lon_center=lon_center,
            low=low,
            mid=mid,
            high=high,
            precip=precip,
            convection=convection,
            wind_low=wind["low"],
            wind_mid=wind["mid"],
            wind_high=wind["high"],
            seed=seed,
        )

        tile_item = {
            "tile_id": f"gfs-{lat_idx:02d}-{lon_idx:02d}",
            "bounds": {
                "lat_min": round(lat_min, 4),
                "lat_max": round(lat_max, 4),
                "lon_min": round(lon_min, 4),
                "lon_max": round(lon_max, 4),
                "lat_center": round(lat_center, 4),
                "lon_center": round(lon_center, 4),
            },
            "low_density": round(low, 4),
            "mid_density": round(mid, 4),
            "high_density": round(high, 4),
            "precipitation_factor": round(precip, 4),
            "convection_factor": round(convection, 4),
            "altitude_low": 1200,
            "altitude_mid": 4200,
            "altitude_high": 9000,
            "wind": wind,
            "seed": seed,
            "importance": round(importance, 4),
            "updated_at": self._now_ms(),
            **arch,
            "subcells": self._build_cloud_subcells(seed, arch["regime"], arch["coverage"], convection, precip),
        }
        return enrich_cloud_tile_geometry(tile_item)

    def extract_precip_rate_mm_hr(self, datasets: dict[str, Any]) -> Any:
        """Extract precip rate (mm/hr) from available GFS variables."""
        if np is None:
            return None
        surf = datasets.get("surface")
        if surf is None:
            return None
        prate = self.safe_data_var(surf, ["prate", "PRATE", "tp", "unknown"])
        if prate is not None:
            arr = np.asarray(self.squeeze_forecast_array(prate).values, dtype=float) * 3600.0
            return np.clip(arr, 0.0, None)
        apcp = self.safe_data_var(surf, ["apcp", "APCP"])
        if apcp is not None:
            arr = np.asarray(self.squeeze_forecast_array(apcp).values, dtype=float)
            return np.clip(arr, 0.0, None)
        return None

    def classify_precip_rate_bucket(self, mm_hr: float) -> str:
        if mm_hr < PRECIP_BUCKETS_MM_HR[0]:
            return "white"
        if mm_hr < PRECIP_BUCKETS_MM_HR[1]:
            return "blue"
        if mm_hr < PRECIP_BUCKETS_MM_HR[2]:
            return "green"
        if mm_hr < PRECIP_BUCKETS_MM_HR[3]:
            return "yellow"
        if mm_hr < PRECIP_BUCKETS_MM_HR[4]:
            return "orange"
        if mm_hr < PRECIP_BUCKETS_MM_HR[5]:
            return "red"
        return "black"

    def compute_layer_rh(self, isobaric_ds: Any, top_hpa: int, bottom_hpa: int) -> Any:
        if np is None or isobaric_ds is None:
            return None

        rh = self.safe_data_var(isobaric_ds, ["r", "RH"])
        if rh is None or "isobaricInhPa" not in rh.dims:
            return None

        levels = np.asarray(isobaric_ds["isobaricInhPa"].values, dtype=float)
        sel = (levels <= bottom_hpa) & (levels >= top_hpa)
        if not np.any(sel):
            return None

        layer = rh.sel(isobaricInhPa=levels[sel])

        for dim in ["time", "step", "valid_time", "surface", "heightAboveGround"]:
            if hasattr(layer, "dims") and dim in layer.dims and layer.sizes.get(dim, 0) > 0:
                layer = layer.isel({dim: 0})

        vals = np.asarray(layer.values, dtype=float)

        if vals.ndim == 3:
            return np.nanmean(vals, axis=0)

        if vals.ndim == 2:
            return vals

        return None

    def estimate_cloud_base_top(self, isobaric_ds: Any, hgt_ds: Any = None) -> dict[str, Any]:
        if np is None or isobaric_ds is None:
            return {}

        rh = self.safe_data_var(isobaric_ds, ["r", "RH"])
        hgt = self.safe_data_var(isobaric_ds, ["gh", "HGT"])
        if rh is None or hgt is None:
            return {}

        rh_arr = self.squeeze_forecast_array(rh, preserve_dims=("isobaricInhPa",))
        hgt_arr = self.squeeze_forecast_array(hgt, preserve_dims=("isobaricInhPa",))
        if rh_arr is None or hgt_arr is None:
            return {}

        rhv = np.asarray(rh_arr.values, dtype=float)
        hgtv = np.asarray(hgt_arr.values, dtype=float)

        try:
            print(
                "[gfs] cloud base/top shapes:",
                f"rh={None if rhv is None else rhv.shape}",
                f"hgt={None if hgtv is None else hgtv.shape}",
            )
        except Exception:
            pass

        if rhv.ndim != 3 or hgtv.ndim != 3:
            return {}

        sat = rhv >= 80.0
        if not np.any(sat):
            return {}

        base_idx = np.argmax(sat, axis=0)
        top_idx = np.maximum(base_idx, rhv.shape[0] - 1 - np.argmax(np.flip(sat, axis=0), axis=0))

        base_m = np.take_along_axis(hgtv, np.expand_dims(base_idx, axis=0), axis=0)[0]
        top_m = np.take_along_axis(hgtv, np.expand_dims(top_idx, axis=0), axis=0)[0]

        return {
            "base_m": base_m,
            "top_m": top_m,
            "thickness_m": np.maximum(0.0, top_m - base_m),
        }

    def derive_cloud_layers(self, surface_ds: Any, agl_ds: Any, isobaric_ds: Any) -> dict[str, Any]:
        """Derive cloud layer occupancy from real GFS fields only.

        This intentionally does not invent default cloud cover.  If RH/TCDC/height
        fields are unavailable, callers receive an empty dict and the frontend can
        report `source_state=unavailable` instead of drawing mock clouds.
        """
        if np is None:
            return {}
        tcdc = None
        if surface_ds is not None:
            da = self.safe_data_var(surface_ds, ["tcc", "TCDC"])
            if da is not None:
                squeezed = self.squeeze_forecast_array(da)
                if squeezed is not None:
                    tcdc = np.asarray(squeezed.values, dtype=float)
        low = self.compute_layer_rh(isobaric_ds, 850, 1000)
        mid = self.compute_layer_rh(isobaric_ds, 600, 850)
        high = self.compute_layer_rh(isobaric_ds, 300, 600)

        for name, arr in [("low", low), ("mid", mid), ("high", high)]:
            if arr is not None and getattr(arr, "ndim", 0) != 2:
                if name == "low":
                    low = None
                elif name == "mid":
                    mid = None
                elif name == "high":
                    high = None
        if tcdc is not None and getattr(tcdc, "ndim", 0) != 2:
            tcdc = None

        try:
            print(
                "[gfs] layer shapes:",
                f"low={None if low is None else low.shape}",
                f"mid={None if mid is None else mid.shape}",
                f"high={None if high is None else high.shape}",
                f"tcdc={None if tcdc is None else tcdc.shape}",
            )
        except Exception:
            pass

        shape = None
        for arr in (low, mid, high, tcdc):
            if arr is not None:
                shape = tuple(np.asarray(arr).shape)
                break
        if not shape:
            log.warning("[gfs] no real cloud RH/TCDC fields available; cloud layer payload empty")
            return {}

        def occ(arr: Any) -> Any:
            if arr is None:
                return np.zeros(shape, dtype=float)
            return np.clip(np.asarray(arr, dtype=float) / 100.0, 0.0, 1.0)

        low_occ = occ(low)
        mid_occ = occ(mid)
        high_occ = occ(high)
        if tcdc is not None:
            tcdc_n = np.clip(np.asarray(tcdc, dtype=float) / 100.0, 0.0, 1.0)
            if tuple(tcdc_n.shape) == tuple(shape):
                if low is None and mid is None and high is None:
                    # TCDC is real, but it is a total field.  Split it conservatively so
                    # the visual shell exists without fabricating extra cover.
                    low_occ = np.clip(tcdc_n * 0.48, 0.0, 1.0)
                    mid_occ = np.clip(tcdc_n * 0.34, 0.0, 1.0)
                    high_occ = np.clip(tcdc_n * 0.18, 0.0, 1.0)
                else:
                    low_occ = np.clip(low_occ * 0.7 + tcdc_n * 0.3, 0.0, 1.0)
                    mid_occ = np.clip(mid_occ * 0.75 + tcdc_n * 0.25, 0.0, 1.0)
                    high_occ = np.clip(high_occ * 0.78 + tcdc_n * 0.22, 0.0, 1.0)
            else:
                log.warning("[gfs] skipping TCDC blend due to shape mismatch tcdc=%s target=%s", tuple(tcdc_n.shape), tuple(shape))
        alt = self.estimate_cloud_base_top(isobaric_ds)
        source_fields = [name for name, arr in (("rh_low", low), ("rh_mid", mid), ("rh_high", high), ("tcdc", tcdc)) if arr is not None]
        return {"low": low_occ, "mid": mid_occ, "high": high_occ, "alt": alt, "source_fields": source_fields}

    def wind_speed_dir_from_uv(self, u: float, v: float) -> tuple[float, float]:
        speed_mps = math.hypot(u, v)
        heading_deg = (math.degrees(math.atan2(u, v)) + 360.0) % 360.0
        return speed_mps, heading_deg

    def select_balloon_steering_level(self, datasets: dict[str, Any], target_ft: int = 10000) -> dict[str, Any]:
        target_hpa = 700
        return {"type": "isobaricInhPa", "level_hpa": target_hpa, "note": "nearest representative level"}

    def derive_balloon_vectors(self, datasets: dict[str, Any], target_ft: int = 10000) -> list[dict[str, Any]]:
        if np is None:
            return []
        iso = datasets.get("isobaricInhPa")
        if iso is None:
            return []
        u_da = self.safe_data_var(iso, ["u", "UGRD"])
        v_da = self.safe_data_var(iso, ["v", "VGRD"])
        if u_da is None or v_da is None or "isobaricInhPa" not in u_da.dims:
            return []
        levels = np.asarray(iso["isobaricInhPa"].values, dtype=float)
        preferred = [250.0, 300.0]
        level = None
        for cand in preferred:
            if cand in levels:
                level = cand
                break
        if level is None:
            level = float(levels[np.argmin(np.abs(levels - 275.0))])
        if not math.isfinite(level):
            level = 300.0
        u = np.asarray(self.squeeze_forecast_array(u_da.sel(isobaricInhPa=level)).values, dtype=float)
        v = np.asarray(self.squeeze_forecast_array(v_da.sel(isobaricInhPa=level)).values, dtype=float)
        lat2d, lon2d = self.ensure_lat_lon_2d(iso)
        if lat2d is None or lon2d is None:
            return []
        vectors: list[dict[str, Any]] = []
        step_y = max(1, u.shape[0] // 18)
        step_x = max(1, u.shape[1] // 36)
        for iy in range(0, u.shape[0], step_y):
            for ix in range(0, u.shape[1], step_x):
                speed_mps, heading_deg = self.wind_speed_dir_from_uv(float(u[iy, ix]), float(v[iy, ix]))
                altitude_m = 10500.0 if level <= 300.0 else 9800.0
                vectors.append({
                    "lat": float(lat2d[iy, ix]),
                    "lon": float(lon2d[iy, ix]),
                    "u": float(u[iy, ix]),
                    "v": float(v[iy, ix]),
                    "speed_mps": round(speed_mps, 3),
                    "speed_mph": round(speed_mps * 2.23694, 2),
                    "heading_deg": round(heading_deg, 2),
                    "altitude_m": round(altitude_m, 1),
                    "source_level": f"{int(level)} hPa",
                })
        return vectors

    def derive_hail_mask(self, datasets: dict[str, Any], precip_mm_hr: Any, cloud_layers: dict[str, Any], *, target_shape: tuple[int, int] | None = None, warned: set[str] | None = None) -> Any:
        if np is None or precip_mm_hr is None:
            return None
        precip_arr = np.asarray(precip_mm_hr, dtype=float)
        if target_shape is None:
            target_shape = tuple(precip_arr.shape)
        precip_arr = self._coerce_field_to_canonical_grid(precip_arr, target_shape, "precip_mm_hr", warned)

        surf = datasets.get("surface")
        cape = None
        if surf is not None:
            da = self.safe_data_var(surf, ["cape", "CAPE"])
            if da is not None:
                cape = np.asarray(self.squeeze_forecast_array(da).values, dtype=float)
        deep = cloud_layers.get("high") if isinstance(cloud_layers, dict) else None
        if cape is None:
            cape = np.zeros(target_shape, dtype=float)
        else:
            cape = self._coerce_field_to_canonical_grid(cape, target_shape, "cape", warned)
        if deep is None:
            deep = np.zeros(target_shape, dtype=float)
        else:
            deep = self._coerce_field_to_canonical_grid(deep, target_shape, "deep_cloud_mask", warned)

        if tuple(cape.shape) != tuple(precip_arr.shape) or tuple(deep.shape) != tuple(precip_arr.shape):
            raise ValueError(
                f"hail_mask_shape_mismatch cape={tuple(cape.shape)} precip={tuple(precip_arr.shape)} deep={tuple(deep.shape)}"
            )
        return (cape > 900.0) & (precip_arr > 3.0) & (deep > 0.55)

    def derive_lightning_mask(self, datasets: dict[str, Any], precip_mm_hr: Any, cloud_layers: dict[str, Any], *, target_shape: tuple[int, int] | None = None, warned: set[str] | None = None) -> Any:
        if np is None or precip_mm_hr is None:
            return None
        precip_arr = np.asarray(precip_mm_hr, dtype=float)
        if target_shape is None:
            target_shape = tuple(precip_arr.shape)
        precip_arr = self._coerce_field_to_canonical_grid(precip_arr, target_shape, "precip_mm_hr_lightning", warned)

        surf = datasets.get("surface")
        cape = np.zeros(target_shape, dtype=float)
        cin = np.zeros(target_shape, dtype=float)
        if surf is not None:
            d_cape = self.safe_data_var(surf, ["cape", "CAPE"])
            d_cin = self.safe_data_var(surf, ["cin", "CIN"])
            if d_cape is not None:
                cape = self._coerce_field_to_canonical_grid(np.asarray(self.squeeze_forecast_array(d_cape).values, dtype=float), target_shape, "cape_lightning", warned)
            if d_cin is not None:
                cin = self._coerce_field_to_canonical_grid(np.asarray(self.squeeze_forecast_array(d_cin).values, dtype=float), target_shape, "cin_lightning", warned)
        high = cloud_layers.get("high") if isinstance(cloud_layers, dict) else np.zeros(target_shape, dtype=float)
        high = self._coerce_field_to_canonical_grid(high, target_shape, "high_cloud_lightning", warned)
        return (cape > 650.0) & (cin > -160.0) & (precip_arr > 1.4) & (high > 0.5)

    def threshold_to_mask(self, array: Any, threshold: float) -> Any:
        if np is None or array is None:
            return None
        return np.asarray(array) >= threshold

    def connected_components_or_simple_cell_polygons(self, mask: Any, lat2d: Any, lon2d: Any) -> list[dict[str, Any]]:
        if np is None or mask is None or lat2d is None or lon2d is None:
            return []
        polys: list[dict[str, Any]] = []
        ys, xs = np.where(mask)
        for y, x in zip(ys.tolist(), xs.tolist()):
            dlat = 0.12
            dlon = 0.12
            ring = close_ring([
                {"lat": float(lat2d[y, x] - dlat), "lng": float(lon2d[y, x] - dlon)},
                {"lat": float(lat2d[y, x] - dlat), "lng": float(lon2d[y, x] + dlon)},
                {"lat": float(lat2d[y, x] + dlat), "lng": float(lon2d[y, x] + dlon)},
                {"lat": float(lat2d[y, x] + dlat), "lng": float(lon2d[y, x] - dlon)},
            ])
            polys.append({"points": ring})
            if len(polys) >= 3500:
                break
        return polys


    def derive_precip_columns_from_tiles(self, tiles: list[dict[str, Any]], max_items: int = 260) -> list[dict[str, Any]]:
        """Build visualization-oriented precipitation columns from tile proxies.

        These are estimated scene hints (not direct observed column geometry).
        """
        out: list[dict[str, Any]] = []
        ranked = sorted(tiles or [], key=lambda t: float((t or {}).get("precip_rate") or ((t or {}).get("precipitation_factor", 0) * 45.0)), reverse=True)
        for t in ranked:
            precip_rate = float(t.get("precip_rate") or (float(t.get("precipitation_factor", 0.0)) * 45.0))
            if precip_rate < 1.2:
                continue
            bounds = t.get("bounds") or {}
            base_alt = float(t.get("base_altitude_m") or ((t.get("bands") or {}).get("low") or {}).get("base_altitude_m") or 1800.0)
            top_alt = float(t.get("top_altitude_m") or ((t.get("bands") or {}).get("mid") or {}).get("top_altitude_m") or 5200.0)
            virga_stop = 0.0
            if precip_rate < 3.0 and base_alt > 2200.0:
                virga_stop = min(base_alt - 120.0, max(250.0, base_alt * 0.18))
            out.append({
                "tile_id": t.get("tile_id"),
                "lat": float(bounds.get("lat_center") or 0.0),
                "lon": float(bounds.get("lon_center") or 0.0),
                "estimated_source_altitude_m": round(max(300.0, base_alt), 1),
                "estimated_top_altitude_m": round(max(base_alt, top_alt), 1),
                "estimated_surface_altitude_m": round(max(0.0, virga_stop), 1),
                "estimated_precip_rate_mm_hr": round(max(0.0, precip_rate), 3),
                "estimated_intensity": round(max(0.0, min(1.0, precip_rate / 45.0)), 4),
                "type_hint": "convective" if float(t.get("storm_energy") or t.get("convection_factor") or 0.0) > 0.62 else "rain",
                "wind_u": float(t.get("wind_u") or ((t.get("wind") or {}).get("mid") or {}).get("u") or 0.0),
                "wind_v": float(t.get("wind_v") or ((t.get("wind") or {}).get("mid") or {}).get("v") or 0.0),
                "estimated": True,
            })
            if len(out) >= max_items:
                break
        return out

    def derive_lightning_events_from_tiles(self, tiles: list[dict[str, Any]], max_items: int = 140) -> list[dict[str, Any]]:
        """Build estimated lightning events from storm-strength proxies."""
        out: list[dict[str, Any]] = []
        ranked = sorted(tiles or [], key=lambda t: float(t.get("storm_energy") or t.get("convection_factor") or 0.0), reverse=True)
        for t in ranked:
            energy = float(t.get("storm_energy") or t.get("convection_factor") or 0.0)
            precip = float(t.get("precip_rate") or (float(t.get("precipitation_factor") or 0.0) * 45.0))
            if energy < 0.48 or precip < 4.0:
                continue
            bounds = t.get("bounds") or {}
            top_alt = float(t.get("top_altitude_m") or ((t.get("bands") or {}).get("high") or {}).get("top_altitude_m") or 9000.0)
            out.append({
                "tile_id": t.get("tile_id"),
                "lat": float(bounds.get("lat_center") or 0.0),
                "lon": float(bounds.get("lon_center") or 0.0),
                "estimated_flash_top_m": round(max(900.0, top_alt), 1),
                "estimated_flash_bottom_m": round(max(80.0, top_alt * (0.24 if energy > 0.72 else 0.42)), 1),
                "estimated_energy": round(max(0.0, min(1.0, energy)), 4),
                "severity_hint": "severe" if energy > 0.72 else "active",
                "estimated": True,
            })
            if len(out) >= max_items:
                break
        return out
    def serialize_cloud_payload(self, tiles: list[dict[str, Any]], meta: dict[str, Any]) -> dict[str, Any]:
        source = meta.get("source", "gfs_nomads")
        payload_state = meta.get("payload_state") or ("live" if source == "gfs_nomads" else "unavailable")
        bbox = meta.get("bbox") or meta.get("bbox_used") or meta.get("requested_bbox")
        diagnostics = dict(meta.get("diagnostics") or {})
        if bbox is not None:
            diagnostics.setdefault("requested_bbox", bbox)
            diagnostics.setdefault("fetch_bbox", bbox)
        diagnostics.setdefault("schema_contract", "tiles/items are authoritative; polygon_field_v1 is not used for cloud bodies")
        cloud_regions = meta.get("cloud_regions") or []
        if not cloud_regions and tiles:
            cloud_regions = [t.get("cloud_region") for t in tiles if isinstance(t, dict) and isinstance(t.get("cloud_region"), dict)]
        return {
            "ok": True,
            "schema": meta.get("schema") or "gfs_cloud_regions_v1",
            "source": source,
            "source_state": payload_state,
            "payload_state": payload_state,
            "heuristic": bool(meta.get("heuristic", source != "gfs_nomads")),
            "updated_at": self._now_ms(),
            "tiles": tiles,
            "items": tiles,
            "features": tiles,
            "cloud_regions": cloud_regions,
            "cloud_region_count": len(cloud_regions),
            "summary": {"tile_count": len(tiles), "cloud_region_count": len(cloud_regions), "cloud_shell_count": len(tiles), "real_data": source == "gfs_nomads"},
            "cycle": meta.get("cycle"),
            "forecast_hour": meta.get("forecast_hour"),
            "valid_time": meta.get("valid_time"),
            "bbox": bbox,
            "bbox_used": bbox,
            "requested_bbox": meta.get("requested_bbox") or bbox,
            "diagnostics": diagnostics,
            "fields_available": meta.get("fields_available") or [],
            "fields_missing": meta.get("fields_missing") or [],
        }

    def serialize_rain_payload(self, rain_polygons: list[dict[str, Any]]) -> dict[str, Any]:
        return {"items": rain_polygons, "count": len(rain_polygons)}

    def serialize_hail_payload(self, hail_polygons: list[dict[str, Any]]) -> dict[str, Any]:
        return {"items": hail_polygons, "count": len(hail_polygons)}

    def serialize_lightning_payload(self, lightning_polygons: list[dict[str, Any]]) -> dict[str, Any]:
        return {"items": lightning_polygons, "count": len(lightning_polygons)}

    def serialize_balloon_payload(self, vectors: list[dict[str, Any]]) -> dict[str, Any]:
        return {"items": vectors, "count": len(vectors)}

    def bbox_cache_key(self, bbox: dict[str, float]) -> str:
        return f"{bbox.get('west')}:{bbox.get('south')}:{bbox.get('east')}:{bbox.get('north')}"

    def payload_cache_key(self, cycle: str, forecast_hour: int, bbox: dict[str, float], grid_tag: str = "na") -> str:
        return f"gfs_payload:v3:{cycle}:{forecast_hour}:{grid_tag}:{self.bbox_cache_key(bbox)}"

    def read_cached_payload(self, key: str) -> Any:
        if self.disk_cache is None:
            return None
        return self.disk_cache.get(key)

    def write_cached_payload(self, key: str, payload: Any) -> None:
        if self.disk_cache is None:
            return
        self.disk_cache.set(key, payload, expire=DEFAULT_GFS_CACHE_TTL_SECONDS)

    def _tile_from_real_fields(self, lat_min: float, lat_max: float, lon_min: float, lon_max: float, low: float, mid: float, high: float, precip: float, conv: float, u: float, v: float, seed_hint: str) -> dict[str, Any]:
        hour_bucket = int(time.time() // 3600)
        tile = self._cloud_tile_payload(lat_min, lat_max, lon_min, lon_max, hour_bucket)
        tile["low_density"] = round(float(low), 4)
        tile["mid_density"] = round(float(mid), 4)
        tile["high_density"] = round(float(high), 4)
        tile["precipitation_factor"] = round(float(precip), 4)
        tile["convection_factor"] = round(float(conv), 4)
        tile["seed"] = stable_hash_u32(seed_hint)
        for b in ("low", "mid", "high"):
            tile["bands"][b]["wind"]["u"] = round(float(u), 3)
            tile["bands"][b]["wind"]["v"] = round(float(v), 3)
        return enrich_cloud_tile_geometry(tile)

    def _grid_tag_from_shape(self, shape: tuple[int, ...] | None) -> str:
        if not shape or len(shape) < 2:
            return "na"
        return f"{int(shape[0])}x{int(shape[1])}"

    def _shape_of(self, arr: Any) -> tuple[int, ...] | None:
        if arr is None or np is None:
            return None
        try:
            a = np.asarray(arr)
            return tuple(a.shape)
        except Exception:
            return None

    def _coerce_to_shape(self, arr: Any, target_shape: tuple[int, ...], field_name: str) -> Any:
        if arr is None or np is None:
            return None
        try:
            a = np.asarray(arr, dtype=float)
        except Exception:
            log.warning("[gfs] dropping field=%s due to non-numeric data", field_name)
            return None
        if tuple(a.shape) == tuple(target_shape):
            return a
        log.warning("[gfs] dropping field=%s due to shape mismatch arr_shape=%s canonical=%s", field_name, tuple(a.shape), tuple(target_shape))
        return None

    def ensure_same_grid(self, field: Any, target_shape: tuple[int, int], field_name: str) -> Any:
        out = self._coerce_to_shape(field, target_shape, field_name)
        if out is None:
            got = self._shape_of(field)
            raise ValueError(f"live_grid_mismatch field={field_name} got={got} expected={target_shape}")
        return out

    def _resample_2d_to_shape(self, arr2d: Any, target_shape: tuple[int, int]) -> Any:
        src = np.asarray(arr2d, dtype=float)
        if src.ndim != 2:
            raise ValueError(f"expected_2d_field got_ndim={src.ndim}")
        th, tw = int(target_shape[0]), int(target_shape[1])
        if th <= 0 or tw <= 0:
            raise ValueError(f"invalid_target_shape={target_shape}")
        if tuple(src.shape) == (th, tw):
            return src
        y_idx = np.rint(np.linspace(0, src.shape[0] - 1, th)).astype(int)
        x_idx = np.rint(np.linspace(0, src.shape[1] - 1, tw)).astype(int)
        return src[np.ix_(y_idx, x_idx)]

    def _coerce_field_to_canonical_grid(self, field: Any, target_shape: tuple[int, int], field_name: str, warned: set[str] | None = None) -> Any:
        if np is None or field is None:
            return field
        arr = np.asarray(field, dtype=float)
        if arr.ndim != 2:
            raise ValueError(f"{field_name}_expected_2d got_shape={tuple(arr.shape)}")
        if tuple(arr.shape) == tuple(target_shape):
            return arr
        out = self._resample_2d_to_shape(arr, target_shape)
        warn_key = f"{field_name}:{tuple(arr.shape)}->{tuple(target_shape)}"
        if warned is None or warn_key not in warned:
            log.warning("[gfs] realigning field=%s from_shape=%s to canonical_shape=%s", field_name, tuple(arr.shape), tuple(target_shape))
            if warned is not None:
                warned.add(warn_key)
        return out

    def _derive_real_source_fields(self, groups: dict[str, Any]) -> dict[str, Any]:
        precip = self.extract_precip_rate_mm_hr(groups)
        hagl = groups.get("10m")
        if hagl is None:
            hagl = groups.get("2m")
        cloud_layers = self.derive_cloud_layers(groups.get("surface"), hagl, groups.get("isobaricInhPa"))
        vectors = self.derive_balloon_vectors(groups)
        if precip is None or not cloud_layers:
            raise RuntimeError("missing precip/cloud arrays")

        sample_ds = groups.get("surface")
        if sample_ds is None:
            sample_ds = groups.get("isobaricInhPa")
        if sample_ds is None:
            sample_ds = groups.get("10m")
        if sample_ds is None:
            sample_ds = groups.get("2m")
        lat2d, lon2d = self.ensure_lat_lon_2d(sample_ds)
        if lat2d is None or lon2d is None:
            raise RuntimeError("missing lat lon grid")

        canonical_shape = tuple(np.asarray(precip).shape)
        log.info("[gfs] canonical live grid selected shape=%s", canonical_shape)
        source_shapes = {
            "lat2d": tuple(np.asarray(lat2d).shape),
            "lon2d": tuple(np.asarray(lon2d).shape),
            "precip": tuple(np.asarray(precip).shape),
            "cloud_low": self._shape_of(cloud_layers.get("low")),
            "cloud_mid": self._shape_of(cloud_layers.get("mid")),
            "cloud_high": self._shape_of(cloud_layers.get("high")),
        }
        high = self._coerce_to_shape(cloud_layers.get("high"), canonical_shape, "cloud_high")
        low = self._coerce_to_shape(cloud_layers.get("low"), canonical_shape, "cloud_low")
        mid = self._coerce_to_shape(cloud_layers.get("mid"), canonical_shape, "cloud_mid")
        if high is None:
            high = np.zeros(canonical_shape, dtype=float)
        if low is None:
            low = np.zeros(canonical_shape, dtype=float)
        if mid is None:
            mid = np.zeros(canonical_shape, dtype=float)
        lat2d_live = self.ensure_same_grid(lat2d, canonical_shape, "hazard_lat2d")
        lon2d_live = self.ensure_same_grid(lon2d, canonical_shape, "hazard_lon2d")
        precip_live = self.ensure_same_grid(precip, canonical_shape, "hazard_precip_mm_hr")
        low_live = self.ensure_same_grid(low, canonical_shape, "hazard_cloud_low")
        mid_live = self.ensure_same_grid(mid, canonical_shape, "hazard_cloud_mid")
        high_live = self.ensure_same_grid(high, canonical_shape, "hazard_cloud_high")

        realigned_fields = [
            name for name, shape in source_shapes.items()
            if shape and len(shape) >= 2 and (int(shape[0]), int(shape[1])) != canonical_shape
        ]
        if realigned_fields:
            log.warning(
                "[gfs] hazard fields resampled once from source shapes=%s to canonical=%s",
                {k: v for k, v in source_shapes.items() if k in realigned_fields},
                canonical_shape,
            )

        conv = np.clip((precip_live / 30.0) * 0.6 + high_live * 0.4, 0.0, 1.0)
        humidity = self._extract_scalar_field(groups, [("isobaricInhPa", ["r", "RH"]), ("surface", ["r", "RH"])])
        wind_u = self._extract_scalar_field(groups, [("10m", ["u", "UGRD"]), ("isobaricInhPa", ["u", "UGRD"]), ("surface", ["u", "UGRD"])])
        wind_v = self._extract_scalar_field(groups, [("10m", ["v", "VGRD"]), ("isobaricInhPa", ["v", "VGRD"]), ("surface", ["v", "VGRD"])])
        wind_u = self.ensure_same_grid(wind_u, canonical_shape, "wind_u") if wind_u is not None else None
        wind_v = self.ensure_same_grid(wind_v, canonical_shape, "wind_v") if wind_v is not None else None
        wind_speed = np.sqrt(np.square(wind_u) + np.square(wind_v)) if wind_u is not None and wind_v is not None else (np.sqrt(np.square(vectors[0]["u"]) + np.square(vectors[0]["v"])) if vectors else np.zeros_like(precip))
        temp_k = self._extract_scalar_field(groups, [("surface", ["t", "TMP", "tmp"]), ("2m", ["t", "TMP", "tmp"])])
        pressure_pa = self._extract_scalar_field(groups, [("meanSea", ["prmsl", "PRMSL"]), ("surface", ["prmsl", "PRMSL"])])
        temp_k = self.ensure_same_grid(temp_k, canonical_shape, "temperature_k") if temp_k is not None else None
        pressure_pa = self.ensure_same_grid(pressure_pa, canonical_shape, "pressure_pa") if pressure_pa is not None else None

        lat2d = self._downsample_2d(lat2d_live, SCENE_DOWNSAMPLE_STRIDE)
        lon2d = self._downsample_2d(lon2d_live, SCENE_DOWNSAMPLE_STRIDE)
        precip = self._downsample_2d(precip_live, SCENE_DOWNSAMPLE_STRIDE)
        canonical_ds_shape = tuple(np.asarray(precip).shape)
        lat2d = self._coerce_to_shape(lat2d, canonical_ds_shape, "lat2d")
        lon2d = self._coerce_to_shape(lon2d, canonical_ds_shape, "lon2d")
        if lat2d is None or lon2d is None:
            raise RuntimeError(f"live_cloud_latlon_grid_invalid shape={canonical_ds_shape}; refusing synthetic world-grid cloud coordinates")
        low = self._downsample_2d(low_live, SCENE_DOWNSAMPLE_STRIDE)
        mid = self._downsample_2d(mid_live, SCENE_DOWNSAMPLE_STRIDE)
        high = self._downsample_2d(high_live, SCENE_DOWNSAMPLE_STRIDE)
        conv = self._downsample_2d(conv, SCENE_DOWNSAMPLE_STRIDE)
        humidity = self._downsample_2d(humidity, SCENE_DOWNSAMPLE_STRIDE) if humidity is not None else None
        wind_u = self._downsample_2d(wind_u, SCENE_DOWNSAMPLE_STRIDE) if wind_u is not None else None
        wind_v = self._downsample_2d(wind_v, SCENE_DOWNSAMPLE_STRIDE) if wind_v is not None else None
        wind_speed = self._downsample_2d(wind_speed, SCENE_DOWNSAMPLE_STRIDE) if wind_speed is not None else None
        temp_k = self._downsample_2d(temp_k, SCENE_DOWNSAMPLE_STRIDE) if temp_k is not None else None
        pressure_pa = self._downsample_2d(pressure_pa, SCENE_DOWNSAMPLE_STRIDE) if pressure_pa is not None else None

        cloud_layers_ds = {
            "low": low,
            "mid": mid,
            "high": high,
        }

        return {
            "canonical_shape": tuple(canonical_shape),
            "precip": precip,
            "cloud_layers": cloud_layers_ds,
            "vectors": vectors,
            "lat2d": lat2d,
            "lon2d": lon2d,
            "high": high,
            "low": low,
            "mid": mid,
            "conv": conv,
            "cloud_density": np.clip((low + mid + high) / 3.0, 0.0, 1.0),
            "precip_rate": precip,
            "wind_speed": wind_speed,
            "temperature_k": temp_k,
            "pressure_pa": pressure_pa,
            "humidity": humidity,
            "wind_u": wind_u,
            "wind_v": wind_v,
            "hazard_inputs": {
                "lat2d": lat2d_live,
                "lon2d": lon2d_live,
                "precip": precip_live,
                "cloud_layers": {
                    "low": low_live,
                    "mid": mid_live,
                    "high": high_live,
                },
                "source_shapes": source_shapes,
                "canonical_shape": tuple(canonical_shape),
                "resampled": bool(realigned_fields),
                "resampled_fields": list(realigned_fields),
                "created_at_ms": self._now_ms(),
            },
        }

    def _assert_same_shape(self, label: str, *arrays: Any) -> None:
        shapes: list[tuple[int, ...]] = []
        for arr in arrays:
            if arr is None:
                continue
            try:
                shape = tuple(np.asarray(arr).shape)
            except Exception:
                continue
            shapes.append(shape)
        unique = {s for s in shapes}
        if len(unique) > 1:
            raise ValueError(f"{label} shape mismatch: {shapes}")


    def _extract_scalar_field(self, groups: dict[str, Any], candidates: list[tuple[str, list[str]]]) -> Any:
        for group_name, names in candidates:
            ds = groups.get(group_name)
            arr = self.safe_data_var(ds, names)
            arr = self.squeeze_forecast_array(arr)
            if arr is None:
                continue
            if np is None:
                continue
            try:
                vals = np.asarray(arr.values, dtype=float)
                if vals.ndim == 2 and vals.size:
                    return vals
            except Exception:
                continue
        return None

    def _downsample_2d(self, arr: Any, stride: int) -> Any:
        if np is None or arr is None:
            return arr
        try:
            a = np.asarray(arr, dtype=float)
        except Exception:
            return arr
        if a.ndim != 2:
            return arr
        step = max(1, int(stride))
        return a[::step, ::step]

    def _json_grid(self, arr: Any, stride: int = 1, precision: int = 4) -> list[list[float]]:
        """Small JSON grid helper for frontend payload contracts/debug panels."""
        if np is None or arr is None:
            return []
        try:
            a = np.asarray(arr, dtype=float)
        except Exception:
            return []
        if a.ndim != 2 or not a.size:
            return []
        step = max(1, int(stride or 1))
        a = a[::step, ::step]
        a = np.nan_to_num(a, nan=0.0, posinf=0.0, neginf=0.0)
        return np.round(a.astype(float), int(precision)).tolist()

    def _store_scalar_fields(self, fields: dict[str, Any]) -> None:
        if np is None:
            return
        lat2d = fields.get("lat2d")
        lon2d = fields.get("lon2d")
        if lat2d is None or lon2d is None:
            return
        try:
            lat_arr = np.asarray(lat2d, dtype=float)
            lon_arr = np.asarray(lon2d, dtype=float)
        except Exception:
            return
        lat_arr = self._downsample_2d(lat_arr, SCALAR_DOWNSAMPLE_STRIDE)
        lon_arr = self._downsample_2d(lon_arr, SCALAR_DOWNSAMPLE_STRIDE)
        scalar_fields: dict[str, dict[str, Any]] = {}
        for key in ("cloud_density", "precip_rate", "temperature_k", "pressure_pa", "wind_u", "wind_v", "wind_speed", "humidity"):
            val = fields.get(key)
            if val is None:
                continue
            try:
                arr = np.asarray(val, dtype=float)
            except Exception:
                continue
            if arr.ndim != 2:
                continue
            arr = self._downsample_2d(arr, SCALAR_DOWNSAMPLE_STRIDE)
            scalar_fields[key] = {
                "lat": lat_arr.astype(np.float32).tolist(),
                "lon": lon_arr.astype(np.float32).tolist(),
                "values": arr.astype(np.float32).tolist(),
                "updated_at": self._now_ms(),
            }
        self.state.scalar_fields = scalar_fields

    def tile_to_bounds(self, z: int, x: int, y: int) -> dict[str, float]:
        return self._tile_bounds_xyz(z, x, y)

    def bounds_to_tile_range(self, bounds: dict[str, float], z: int) -> dict[str, int]:
        z = max(0, int(z))
        n = 2 ** z
        b = self._normalize_bbox(bounds)
        nw = self._lat_lon_to_tile(b["north"], b["west"], z)
        se = self._lat_lon_to_tile(b["south"], b["east"], z)
        return {
            "x_min": max(0, min(n - 1, int(min(nw["x"], se["x"])))),
            "x_max": max(0, min(n - 1, int(max(nw["x"], se["x"])))),
            "y_min": max(0, min(n - 1, int(min(nw["y"], se["y"])))),
            "y_max": max(0, min(n - 1, int(max(nw["y"], se["y"])))),
        }

    def _lat_lon_to_tile(self, lat: float, lon: float, z: int) -> dict[str, int]:
        lat = max(-85.05112878, min(85.05112878, safe_float(lat, 0.0)))
        lon = max(-180.0, min(180.0, safe_float(lon, 0.0)))
        n = 2 ** max(0, int(z))
        x = int((lon + 180.0) / 360.0 * n)
        lat_rad = math.radians(lat)
        y = int((1.0 - math.log(math.tan(lat_rad) + (1 / math.cos(lat_rad))) / math.pi) / 2.0 * n)
        return {"x": max(0, min(n - 1, x)), "y": max(0, min(n - 1, y))}

    def _cloud_intensity_arrays(self, fields: dict[str, Any]) -> dict[str, Any]:
        """Build normalized cloud intelligence fields from the live weather grid.

        This is the shared "sea of weather data" product for clouds/rain:
        low/mid/high cover, total cloud intensity, rain intensity, and tower
        signal are all kept on the native/canonical lat/lon grid. Rendering
        can simplify later; this function does not intentionally coarsen the
        science grid.
        """
        if np is None:
            return {}
        try:
            low = np.asarray(fields.get("low"), dtype=float)
            mid = np.asarray(fields.get("mid"), dtype=float)
            high = np.asarray(fields.get("high"), dtype=float)
            precip = np.asarray(fields.get("precip"), dtype=float)
            conv = np.asarray(fields.get("conv"), dtype=float)
            lat2d = np.asarray(fields.get("lat2d"), dtype=float)
            lon2d = np.asarray(fields.get("lon2d"), dtype=float)
        except Exception:
            return {}
        if low.ndim != 2 or lat2d.shape != low.shape or lon2d.shape != low.shape:
            return {}
        def norm_cloud(a: Any) -> Any:
            arr = np.nan_to_num(np.asarray(a, dtype=float), nan=0.0, posinf=0.0, neginf=0.0)
            # Some decoders return 0..1, others 0..100.
            if np.nanmax(arr) > 1.5:
                arr = arr / 100.0
            return np.clip(arr, 0.0, 1.0)
        low_n = norm_cloud(low)
        mid_n = norm_cloud(mid)
        high_n = norm_cloud(high)
        total = np.clip(np.maximum.reduce([low_n, mid_n, high_n]) * 0.62 + (low_n + mid_n + high_n) * 0.18, 0.0, 1.0)
        precip_n = np.clip(np.nan_to_num(precip, nan=0.0, posinf=0.0, neginf=0.0) / 45.0, 0.0, 1.0)
        conv_n = np.clip(np.nan_to_num(conv, nan=0.0, posinf=0.0, neginf=0.0), 0.0, 1.0)
        rain = np.clip((precip_n * 0.78) + (total * 0.22), 0.0, 1.0)
        tower = np.clip((high_n * 0.30) + (mid_n * 0.28) + (low_n * 0.18) + (precip_n * 0.34) + (conv_n * 0.45), 0.0, 1.0)
        return {"lat2d": lat2d, "lon2d": lon2d, "low": low_n, "mid": mid_n, "high": high_n, "total": total, "rain": rain, "tower": tower, "precip_norm": precip_n, "conv": conv_n}

    def _classify_cloud_region(self, low_v: float, mid_v: float, high_v: float, rain_v: float, tower_v: float) -> dict[str, Any]:
        """Classify a contour component into one of the visible cloud regimes."""
        if tower_v >= 0.72 and rain_v >= 0.18:
            return {"family": "vertical", "type": "cumulonimbus", "roles": ["base", "tower", "anvil", "rain_core"]}
        if tower_v >= 0.55:
            return {"family": "vertical", "type": "towering_cumulus", "roles": ["base", "tower", "turret"]}
        if rain_v >= 0.28 and (low_v + mid_v) >= 0.55:
            return {"family": "stratiform", "type": "nimbostratus", "roles": ["deep_rain_deck", "rain_core"]}
        if low_v >= 0.42 and mid_v >= 0.25:
            return {"family": "stratiform", "type": "stratocumulus", "roles": ["lumpy_deck", "fringe"]}
        if low_v >= 0.36:
            return {"family": "stratiform", "type": "stratus", "roles": ["low_sheet", "fringe"]}
        if mid_v >= 0.45 and high_v < 0.35:
            return {"family": "cumuliform", "type": "altocumulus", "roles": ["puff_field", "core"]}
        if mid_v >= 0.32:
            return {"family": "stratiform", "type": "altostratus", "roles": ["broad_deck", "fringe"]}
        if high_v >= 0.45 and low_v < 0.22 and mid_v < 0.30:
            return {"family": "cirriform", "type": "cirrus", "roles": ["wispy", "feather"]}
        if high_v >= 0.32:
            return {"family": "cirriform", "type": "cirrostratus", "roles": ["veil", "sheet"]}
        return {"family": "cumuliform", "type": "cumulus", "roles": ["base", "core", "dome"]}

    def _component_ring_from_cells(self, lat2d: Any, lon2d: Any, cells: list[tuple[int, int]], salt: int = 0) -> list[dict[str, float]]:
        """Create a stable organic footprint for a marching-squares component.

        This is a lightweight server-side contour footprint. It avoids drawing
        every grid cell by wrapping the component's point cloud with an organic
        ellipse/rounded hull; the exact field threshold and component cells are
        still derived from marching-square-style masks.
        """
        if not cells:
            return []
        lats = [float(lat2d[y, x]) for y, x in cells if np.isfinite(lat2d[y, x]) and np.isfinite(lon2d[y, x])]
        lons = [float(lon2d[y, x]) for y, x in cells if np.isfinite(lat2d[y, x]) and np.isfinite(lon2d[y, x])]
        if not lats or not lons:
            return []
        lat_min, lat_max = min(lats), max(lats)
        lon_min, lon_max = min(lons), max(lons)
        lat_c = (lat_min + lat_max) * 0.5
        lon_c = (lon_min + lon_max) * 0.5
        lat_r = max(0.025, (lat_max - lat_min) * 0.62)
        lon_r = max(0.025, (lon_max - lon_min) * 0.62)
        # Wider/larger components get more vertices, capped to keep payload fast.
        points = max(10, min(30, int(10 + math.sqrt(len(cells)) * 1.2)))
        ring: list[dict[str, float]] = []
        for i in range(points):
            ang = (2.0 * math.pi * i) / points
            n1 = (stable_unit_float(f"cloud-region:{salt}:{i}:a") - 0.5) * 0.26
            n2 = (stable_unit_float(f"cloud-region:{salt}:{i}:b") - 0.5) * 0.18
            radial = 1.0 + n1 + 0.08 * math.sin(ang * 3.0 + salt * 0.001)
            lat = lat_c + math.sin(ang) * lat_r * radial
            lon = lon_c + math.cos(ang) * lon_r * (1.0 + n2)
            ring.append({"lat": round(lat, 6), "lng": round(((lon + 180.0) % 360.0) - 180.0, 6)})
        if ring and ring[0] != ring[-1]:
            ring.append(dict(ring[0]))
        return ring

    def _component_walk(self, mask: Any, max_components: int = 220, max_cells_per_component: int = 3500) -> list[list[tuple[int, int]]]:
        """8-neighbor connected components without scipy."""
        if np is None:
            return []
        m = np.asarray(mask, dtype=bool)
        if m.ndim != 2 or m.size == 0:
            return []
        h, w = m.shape
        seen = np.zeros(m.shape, dtype=bool)
        comps: list[list[tuple[int, int]]] = []
        for sy in range(h):
            for sx in range(w):
                if not m[sy, sx] or seen[sy, sx]:
                    continue
                stack = [(sy, sx)]
                seen[sy, sx] = True
                cells: list[tuple[int, int]] = []
                while stack:
                    y, x = stack.pop()
                    cells.append((y, x))
                    if len(cells) >= max_cells_per_component:
                        continue
                    for dy in (-1, 0, 1):
                        for dx in (-1, 0, 1):
                            if dy == 0 and dx == 0:
                                continue
                            ny, nx = y + dy, x + dx
                            if ny < 0 or nx < 0 or ny >= h or nx >= w or seen[ny, nx] or not m[ny, nx]:
                                continue
                            seen[ny, nx] = True
                            stack.append((ny, nx))
                if len(cells) >= 3:
                    comps.append(cells)
                    if len(comps) >= max_components:
                        return comps
        return comps

    def _derive_cloud_regions_from_fields(self, fields: dict[str, Any], cycle: str, forecast_hour: int, max_regions: int | None = None, bbox: dict[str, float] | None = None) -> list[dict[str, Any]]:
        """Derive cloud regions from the live cloud-intelligence grid.

        This is the cloud equivalent of bait marching-squares: the graphics are
        based on thresholded/connected cloud fields, not raw grid-cell placement.
        """
        if np is None:
            return []
        arrays = self._cloud_intensity_arrays(fields)
        if not arrays:
            return []
        lat2d = arrays["lat2d"]
        lon2d = arrays["lon2d"]
        total = arrays["total"]
        low = arrays["low"]
        mid = arrays["mid"]
        high = arrays["high"]
        rain = arrays["rain"]
        tower = arrays["tower"]
        vectors = fields.get("vectors") or []
        max_regions = int(max_regions or int(os.getenv("GFS_CLOUD_MAX_REGIONS", "260") or "260"))
        # Region solve must be scene/bbox-aware.  Previously we derived the top
        # global components first, then clipped to the tile/viewport bbox; for
        # many local bboxes that meant all 260 global regions were rejected and
        # clouds stayed stuck in warming.  Build a bbox mask before connected
        # components so the marching-squares candidates are local to the request.
        bbox_mask = None
        if isinstance(bbox, dict):
            try:
                bbox_mask = np.zeros(total.shape, dtype=bool)
                lat_arr = np.asarray(lat2d, dtype=float)
                lon_arr = ((np.asarray(lon2d, dtype=float) + 180.0) % 360.0) - 180.0
                south = min(float(bbox.get("south", -90.0)), float(bbox.get("north", 90.0)))
                north = max(float(bbox.get("south", -90.0)), float(bbox.get("north", 90.0)))
                west = ((float(bbox.get("west", -180.0)) + 180.0) % 360.0) - 180.0
                east = ((float(bbox.get("east", 180.0)) + 180.0) % 360.0) - 180.0
                # Light pad prevents edge-clipping of cloud regions that straddle
                # the visible/fetch boundary.
                lat_pad = max(0.25, (north - south) * 0.08)
                lon_pad = max(0.25, abs(east - west if west <= east else (east + 360.0 - west)) * 0.08)
                south -= lat_pad; north += lat_pad
                west_p = ((west - lon_pad + 180.0) % 360.0) - 180.0
                east_p = ((east + lon_pad + 180.0) % 360.0) - 180.0
                lat_ok = (lat_arr >= south) & (lat_arr <= north)
                if west_p <= east_p:
                    lon_ok = (lon_arr >= west_p) & (lon_arr <= east_p)
                else:
                    lon_ok = (lon_arr >= west_p) | (lon_arr <= east_p)
                bbox_mask = lat_ok & lon_ok
            except Exception:
                bbox_mask = None
        thresholds = [0.82, 0.65, 0.45, 0.28, 0.18]
        regions: list[dict[str, Any]] = []
        occupied = np.zeros(total.shape, dtype=bool)
        for level in thresholds:
            mask = (total >= level) & (~occupied)
            if bbox_mask is not None:
                mask = mask & bbox_mask
            components = self._component_walk(mask, max_components=max_regions * 2, max_cells_per_component=5000)
            # Large/high-confidence components first.
            components.sort(key=len, reverse=True)
            for idx, cells in enumerate(components):
                if len(regions) >= max_regions:
                    return regions
                if len(cells) < 4:
                    continue
                ys = np.asarray([c[0] for c in cells], dtype=int)
                xs = np.asarray([c[1] for c in cells], dtype=int)
                low_v = float(np.nanmean(low[ys, xs]))
                mid_v = float(np.nanmean(mid[ys, xs]))
                high_v = float(np.nanmean(high[ys, xs]))
                total_v = float(np.nanmean(total[ys, xs]))
                rain_v = float(np.nanmean(rain[ys, xs]))
                tower_v = float(np.nanmean(tower[ys, xs]))
                if max(low_v, mid_v, high_v, total_v) < 0.10:
                    continue
                salt = stable_hash_u32(f"{cycle}:{forecast_hour}:{level}:{idx}:{len(cells)}")
                ring = self._component_ring_from_cells(lat2d, lon2d, cells, salt)
                if len(ring) < 4:
                    continue
                lat_vals = [p["lat"] for p in ring[:-1]]
                lon_vals = [p["lng"] for p in ring[:-1]]
                lat_c = sum(lat_vals) / len(lat_vals)
                lon_c = sum(lon_vals) / len(lon_vals)
                classification = self._classify_cloud_region(low_v, mid_v, high_v, rain_v, tower_v)
                u = float(vectors[0].get("u", 0.0)) if vectors else 0.0
                v = float(vectors[0].get("v", 0.0)) if vectors else 0.0
                region = {
                    "id": f"cloud-region-{salt}",
                    "schema": "cloud_region_marching_squares_v1",
                    "method": "live_cloud_intensity_marching_squares_components",
                    "threshold": round(float(level), 3),
                    "cell_count": int(len(cells)),
                    "center": {"lat": round(lat_c, 6), "lon": round(lon_c, 6)},
                    "bbox": {"west": round(min(lon_vals), 6), "south": round(min(lat_vals), 6), "east": round(max(lon_vals), 6), "north": round(max(lat_vals), 6)},
                    "footprint": ring,
                    "cloud_type": classification["type"],
                    "family": classification["family"],
                    "roles": classification["roles"],
                    "intensity": {"low": round(low_v, 4), "mid": round(mid_v, 4), "high": round(high_v, 4), "total": round(total_v, 4), "rain": round(rain_v, 4), "tower": round(tower_v, 4)},
                    "wind": {"u": round(u, 3), "v": round(v, 3)},
                    "cycle": cycle,
                    "forecast_hour": forecast_hour,
                }
                regions.append(region)
                occupied[ys, xs] = True
        return regions

    def _cloud_region_to_tile(self, region: dict[str, Any], cycle: str, forecast_hour: int) -> dict[str, Any] | None:
        bbox = region.get("bbox") or {}
        try:
            lat_min = float(bbox.get("south")); lat_max = float(bbox.get("north")); lon_min = float(bbox.get("west")); lon_max = float(bbox.get("east"))
        except Exception:
            return None
        inten = region.get("intensity") or {}
        wind = region.get("wind") or {}
        tile = self._tile_from_real_fields(
            lat_min,
            lat_max,
            lon_min,
            lon_max,
            float(inten.get("low", 0.0)),
            float(inten.get("mid", 0.0)),
            float(inten.get("high", 0.0)),
            float(inten.get("rain", 0.0)),
            float(inten.get("tower", 0.0)),
            float(wind.get("u", 0.0)),
            float(wind.get("v", 0.0)),
            str(region.get("id") or f"{cycle}:{forecast_hour}:cloud-region"),
        )
        tile["id"] = region.get("id")
        tile["tile_id"] = region.get("id")
        tile["source_method"] = "cloud_region_marching_squares_v1"
        tile["cloud_region_id"] = region.get("id")
        tile["cloud_region"] = region
        tile["region_footprint"] = region.get("footprint") or []
        tile["coverage"] = round(float((region.get("intensity") or {}).get("total", 0.0)) * 100.0, 2)
        tile["cloud_type"] = region.get("cloud_type")
        tile["regime"] = region.get("family") or tile.get("regime")
        # Override server footprints to use the region footprint, so the shell is a region contour instead of a grid rectangle.
        for band_name, band in (tile.get("bands") or {}).items():
            if not isinstance(band, dict):
                continue
            fps = band.get("footprints")
            if isinstance(fps, list) and fps:
                fps[0]["points"] = region.get("footprint") or fps[0].get("points") or []
                fps[0]["source"] = "cloud_region_marching_squares_v1"
        return tile

    def _marching_squares_contours(self, field_name: str, bounds: dict[str, float], z: int) -> list[dict[str, Any]]:
        if np is None:
            return []
        sf = (self.state.scalar_fields or {}).get(field_name)
        if not sf:
            return []
        try:
            lat = np.asarray(sf.get("lat"), dtype=float)
            lon = np.asarray(sf.get("lon"), dtype=float)
            vals = np.asarray(sf.get("values"), dtype=float)
        except Exception:
            return []
        if vals.ndim != 2 or vals.shape[0] < 2 or vals.shape[1] < 2:
            return []
        detail_stride = 4 if z < 3 else 2 if z < 6 else 1
        levels = {
            "precip_rate": [0.1, 1.0, 4.0, 12.0],
            "cloud_density": [0.2, 0.4, 0.65, 0.85],
            "pressure_pa": [99500.0, 100500.0, 101300.0],
            "temperature_k": [273.15, 283.15, 293.15, 303.15],
        }.get(field_name, [0.3, 0.6])
        south, north = bounds.get("south", -90.0), bounds.get("north", 90.0)
        west, east = bounds.get("west", -180.0), bounds.get("east", 180.0)
        out = []
        max_features = 60 if z < 3 else 140 if z < 6 else 260
        for lvl in levels:
            for y in range(0, vals.shape[0] - 1, detail_stride):
                for x in range(0, vals.shape[1] - 1, detail_stride):
                    v00 = safe_float(vals[y, x], 0.0)
                    v10 = safe_float(vals[y, x + 1], 0.0)
                    v01 = safe_float(vals[y + 1, x], 0.0)
                    v11 = safe_float(vals[y + 1, x + 1], 0.0)
                    mask = (1 if v00 >= lvl else 0) | (2 if v10 >= lvl else 0) | (4 if v11 >= lvl else 0) | (8 if v01 >= lvl else 0)
                    if mask in (0, 15):
                        continue
                    lat0 = safe_float(lat[y, x], None); lat1 = safe_float(lat[y + 1, x + 1], None)
                    lon0 = safe_float(lon[y, x], None); lon1 = safe_float(lon[y + 1, x + 1], None)
                    if None in (lat0, lat1, lon0, lon1):
                        continue
                    c_lat = (lat0 + lat1) * 0.5
                    c_lon = (lon0 + lon1) * 0.5
                    if not (south <= c_lat <= north and west <= c_lon <= east):
                        continue
                    poly = [[lon0, lat0], [lon1, lat0], [lon1, lat1], [lon0, lat1], [lon0, lat0]]
                    out.append({
                        "type": "Feature",
                        "properties": {"field": field_name, "level": lvl, "mask": mask, "lod_z": z},
                        "geometry": {"type": "Polygon", "coordinates": [poly]},
                    })
                    if len(out) >= max_features:
                        return out
        return out

    def _derive_real_cloud_tiles(self, fields: dict[str, Any], cycle: str, forecast_hour: int, bbox: dict[str, float] | None = None) -> list[dict[str, Any]]:
        """Create cloud shell tiles from marching-squares cloud regions first.

        Fallback to the legacy block/tile method only if the region solver cannot
        derive valid live regions. The preferred path removes the visible grid by
        producing contour components from the cloud-intelligence field.
        """
        if np is not None:
            try:
                regions = self._derive_cloud_regions_from_fields(fields, cycle, forecast_hour, bbox=bbox)
                tiles = [self._cloud_region_to_tile(r, cycle, forecast_hour) for r in regions]
                tiles = [t for t in tiles if isinstance(t, dict)]
                if tiles:
                    for t in tiles:
                        t["schema"] = "cloud_shell_tile_from_region_v1"
                        t["method"] = "cloud_region_marching_squares_v1"
                    # Attach for serializers without requiring a second solve.
                    fields["cloud_regions"] = regions
                    fields["cloud_region_method"] = "live_cloud_intensity_marching_squares_components"
                    return tiles
            except Exception:
                log.exception("[gfs clouds] cloud region marching-squares solve failed; falling back to legacy cloud tiles")

        precip = fields["precip"]
        lat2d = fields["lat2d"]
        lon2d = fields["lon2d"]
        low = fields["low"]
        mid = fields["mid"]
        high = fields["high"]
        conv = fields["conv"]
        vectors = fields["vectors"]

        tiles: list[dict[str, Any]] = []
        y_step = max(1, precip.shape[0] // 28)
        x_step = max(1, precip.shape[1] // 56)
        for y in range(0, precip.shape[0] - y_step, y_step):
            for x in range(0, precip.shape[1] - x_step, x_step):
                lat_min = float(np.min(lat2d[y:y+y_step, x:x+x_step]))
                lat_max = float(np.max(lat2d[y:y+y_step, x:x+x_step]))
                lon_min = float(np.min(lon2d[y:y+y_step, x:x+x_step]))
                lon_max = float(np.max(lon2d[y:y+y_step, x:x+x_step]))
                low_v = float(np.nanmean(low[y:y+y_step, x:x+x_step]))
                mid_v = float(np.nanmean(mid[y:y+y_step, x:x+x_step]))
                high_v = float(np.nanmean(high[y:y+y_step, x:x+x_step]))
                precip_v = float(np.nanmean(np.clip(precip[y:y+y_step, x:x+x_step] / 45.0, 0.0, 1.0)))
                conv_v = float(np.nanmean(conv[y:y+y_step, x:x+x_step]))
                if max(low_v, mid_v, high_v) < 0.06:
                    continue
                u = vectors[0]["u"] if vectors else 0.0
                v = vectors[0]["v"] if vectors else 0.0
                tile = self._tile_from_real_fields(
                    lat_min,
                    lat_max,
                    lon_min,
                    lon_max,
                    low_v,
                    mid_v,
                    high_v,
                    precip_v,
                    conv_v,
                    u,
                    v,
                    f"{cycle}:{forecast_hour}:{y}:{x}",
                )
                tile["method"] = "legacy_block_tile_cloud_shells"
                tiles.append(tile)
        return tiles

    def _select_hazard_canonical_shape(self, fields: dict[str, Any], cloud_layers: dict[str, Any], precip_shape: tuple[int, int]) -> tuple[int, int]:
        from_fields = fields.get("canonical_shape")
        lat_shape = self._shape_of(fields.get("lat2d"))
        low_shape = self._shape_of(cloud_layers.get("low") if isinstance(cloud_layers, dict) else None)

        preferred = None
        if from_fields and len(from_fields) >= 2:
            preferred = (int(from_fields[0]), int(from_fields[1]))
        elif lat_shape and len(lat_shape) >= 2:
            preferred = (int(lat_shape[0]), int(lat_shape[1]))
        elif low_shape and len(low_shape) >= 2:
            preferred = (int(low_shape[0]), int(low_shape[1]))
        else:
            preferred = tuple(int(x) for x in precip_shape)

        candidate_shapes = [
            tuple(int(x) for x in sh[:2])
            for sh in (from_fields, lat_shape, low_shape, precip_shape)
            if sh is not None and len(sh) >= 2
        ]
        max_shape = max(candidate_shapes, key=lambda x: x[0] * x[1]) if candidate_shapes else preferred
        if preferred[0] * preferred[1] < max_shape[0] * max_shape[1]:
            raise ValueError(
                f"hazard_canonical_shape_regression chosen={preferred} max_available={max_shape}"
            )
        return preferred

    def _derive_real_hazard_payloads(self, groups: dict[str, Any], fields: dict[str, Any]) -> dict[str, Any]:
        warned: set[str] = set()
        hazard_inputs = fields.get("hazard_inputs") if isinstance(fields.get("hazard_inputs"), dict) else {}
        precip = np.asarray(hazard_inputs.get("precip", fields["precip"]), dtype=float)
        cloud_layers = hazard_inputs.get("cloud_layers") if isinstance(hazard_inputs.get("cloud_layers"), dict) else (fields["cloud_layers"] if isinstance(fields.get("cloud_layers"), dict) else {})
        canonical_shape = self._select_hazard_canonical_shape(
            {**fields, "canonical_shape": hazard_inputs.get("canonical_shape", fields.get("canonical_shape")), "lat2d": hazard_inputs.get("lat2d", fields.get("lat2d"))},
            cloud_layers,
            tuple(precip.shape),
        )
        log.info("[gfs] hazard canonical target shape=%s", canonical_shape)
        if hazard_inputs:
            log.info(
                "[gfs] hazard inputs canonicalized cycle_ready shape=%s resampled=%s fields=%s",
                canonical_shape,
                bool(hazard_inputs.get("resampled")),
                ",".join(hazard_inputs.get("resampled_fields") or []) or "none",
            )

        lat2d = self.ensure_same_grid(hazard_inputs.get("lat2d", fields["lat2d"]), canonical_shape, "hazard_lat2d")
        lon2d = self.ensure_same_grid(hazard_inputs.get("lon2d", fields["lon2d"]), canonical_shape, "hazard_lon2d")
        precip = self.ensure_same_grid(precip, canonical_shape, "hazard_precip_mm_hr")
        cloud_layers = {
            "low": self.ensure_same_grid(cloud_layers.get("low", np.zeros(canonical_shape, dtype=float)), canonical_shape, "hazard_cloud_low"),
            "mid": self.ensure_same_grid(cloud_layers.get("mid", np.zeros(canonical_shape, dtype=float)), canonical_shape, "hazard_cloud_mid"),
            "high": self.ensure_same_grid(cloud_layers.get("high", np.zeros(canonical_shape, dtype=float)), canonical_shape, "hazard_cloud_high"),
        }

        self._assert_same_shape(
            "hazard_fields",
            precip,
            cloud_layers.get("low"),
            cloud_layers.get("mid"),
            cloud_layers.get("high"),
            lat2d,
            lon2d,
        )
        rain_mask = self.threshold_to_mask(precip, 0.5)
        hail_mask = self.derive_hail_mask(groups, precip, cloud_layers, target_shape=canonical_shape, warned=warned)
        lightning_mask = self.derive_lightning_mask(groups, precip, cloud_layers, target_shape=canonical_shape, warned=warned)
        hail_mask = self._coerce_field_to_canonical_grid(hail_mask, canonical_shape, "hail_mask", warned)
        lightning_mask = self._coerce_field_to_canonical_grid(lightning_mask, canonical_shape, "lightning_mask", warned)
        rain_mask = self._coerce_field_to_canonical_grid(rain_mask, canonical_shape, "rain_mask", warned)
        rain_polys = self.connected_components_or_simple_cell_polygons(rain_mask, lat2d, lon2d)
        hail_polys = self.connected_components_or_simple_cell_polygons(hail_mask, lat2d, lon2d)
        lightning_polys = self.connected_components_or_simple_cell_polygons(lightning_mask, lat2d, lon2d)
        return {
            "rain": self.serialize_rain_payload(rain_polys),
            "hail": self.serialize_hail_payload(hail_polys),
            "lightning": self.serialize_lightning_payload(lightning_polys),
        }

    def generate_real_gfs_payload(self, bbox: dict[str, float] | None = None) -> dict[str, Any]:
        bbox = self._normalize_bbox(bbox)
        ingest = self.ingest_latest_model_fields(bbox)
        fetch = ingest["fetch"]
        groups = ingest["groups"]
        mode = ingest.get("mode", "live")

        try:
            fields = self._derive_real_source_fields(groups)
            self._store_scalar_fields(fields)
            raw_tiles = self._derive_real_cloud_tiles(fields, fetch.cycle, fetch.forecast_hour, bbox=bbox)
            tiles, cloud_diag = self._clip_cloud_tiles_to_bbox(raw_tiles, bbox)
            if raw_tiles and not tiles:
                log.warning("[gfs clouds] live tiles all rejected by bbox contract bbox=%s diag=%s", bbox, cloud_diag)
            hazards = self._derive_real_hazard_payloads(groups, fields)
            grid_shape = self._shape_of(fields.get("precip"))
            grid_tag = self._grid_tag_from_shape(grid_shape)
            payload = {
                "source": "gfs_nomads",
                "grid_shape": list(grid_shape) if grid_shape else None,
                "grid_tag": grid_tag,
                # /api/gfs/scene and the jetstream layer require these exact
                # field keys as plain 2-D JSON arrays. Keep the same successful
                # NOMADS/cfgrib source, but expose the decoded U/V payload in
                # the frontend contract instead of falling into pseudo wind.
                "fields": {
                    "wind_u": self._json_grid(fields.get("wind_u"), precision=4),
                    "wind_v": self._json_grid(fields.get("wind_v"), precision=4),
                    "wind_speed": self._json_grid(fields.get("wind_speed"), precision=4),
                    "precip_rate": self._json_grid(fields.get("precip_rate"), precision=4),
                    "cloud_density": self._json_grid(fields.get("cloud_density"), precision=4),
                    "temp2m": self._json_grid(fields.get("temperature_k"), precision=3),
                    "mslp": self._json_grid(fields.get("pressure_pa"), precision=2),
                },
                "field_shapes": {
                    k: list(np.asarray(v).shape) for k, v in {
                        "wind_u": fields.get("wind_u"),
                        "wind_v": fields.get("wind_v"),
                        "precip_rate": fields.get("precip_rate"),
                        "cloud_density": fields.get("cloud_density"),
                    }.items() if v is not None
                },
                "cycle": fetch.cycle,
                "forecast_hour": fetch.forecast_hour,
                "valid_time": fetch.valid_time,
                "bbox": bbox,
                "bbox_used": bbox,
                "requested_bbox": bbox,
                "diagnostics": {
                    **cloud_diag,
                    "requested_bbox": bbox,
                    "fetch_bbox": bbox,
                    "grid_shape": list(grid_shape) if grid_shape else None,
                    "source_url": fetch.url,
                    "cloud_region_method": fields.get("cloud_region_method") or "legacy_block_tiles",
                    "cloud_region_count": len(fields.get("cloud_regions") or []),
                },
                "schema": "gfs_cloud_regions_v1",
                "cloud_regions": fields.get("cloud_regions") or [],
                "cloud_region_count": len(fields.get("cloud_regions") or []),
                "tiles": tiles,
                "rain": hazards["rain"],
                "hail": hazards["hail"],
                "lightning": hazards["lightning"],
                "balloons": self.serialize_balloon_payload(fields["vectors"]),
                "heuristic": False,
                "quality_note": "Cloud/precip overlays are derived from real NOMADS GFS GRIB2 fields; geometry remains visualization-oriented.",
                "source_format": "grib2",
                "source_url": fetch.url,
                "cache_path": str(fetch.path) if fetch.path else None,
                "fields_available": list(self.state.fields_available or []),
                "fields_missing": list(self.state.fields_missing or []),
                "using_last_known_good": mode == "last_known_good",
                "degraded_mode": mode != "live",
                "decode_backend": self.state.decode_backend,
                "data_source_mode": self.state.data_source_mode,
            }
            return self._annotate_weather_payload(
                payload,
                bbox=bbox,
                source="gfs_nomads",
                payload_state="live" if mode == "live" else "cached",
                heuristic=False,
                quality_note=payload["quality_note"] if mode == "live" else "Serving last-known-good GRIB2 decode after live fetch/decode failure.",
                confidence="high" if mode == "live" else "medium",
            )
        finally:
            # Decoded GRIB groups may be owned by the process-level snapshot
            # cache.  Do not close those xarray objects after every request;
            # that was the cfgrib reopen storm visible in journalctl.  They are
            # closed only when a newer GRIB file replaces the snapshot.
            if not bool(ingest.get("cache_owned")):
                self._release_groups(groups)
                groups = None
                gc.collect()

    def generate_fallback_payload(self, bbox: dict[str, float] | None = None) -> dict[str, Any]:
        bbox = self._normalize_bbox(bbox)
        cloud = self._cached_cloud_tiles_payload()
        cloud.update({
            "source": "fallback_proxy",
            "payload_state": "synthetic",
            "cycle": cloud.get("cycle"),
            "forecast_hour": cloud.get("forecast_hour"),
            "valid_time": cloud.get("valid_time"),
            "bbox_used": bbox,
            "quality_note": "Synthetic fallback generated from heuristic cloud-state proxies; not direct observational truth.",
            "confidence": "low",
        })
        cloud["rain"] = {"items": [], "count": 0}
        cloud["hail"] = {"items": [], "count": 0}
        cloud["lightning"] = {"items": [], "count": 0}
        cloud["balloons"] = {"items": [], "count": 0}
        cloud["decode_backend"] = "none"
        cloud["data_source_mode"] = "heuristic"
        cloud["fallback_offset_degrees"] = SYNTHETIC_FALLBACK_OFFSET_DEGREES
        cloud["layer_sources"] = {"clouds": "synthetic_fallback", "rain": "synthetic_fallback", "hail": "synthetic_fallback", "lightning": "synthetic_fallback", "wind": "synthetic_fallback"}
        try:
            for item in cloud.get("items") or cloud.get("tiles") or []:
                if isinstance(item, dict):
                    if "lat" in item:
                        item["lat"] = float(item.get("lat", 0.0)) + SYNTHETIC_FALLBACK_OFFSET_DEGREES
                    if "lon" in item:
                        item["lon"] = float(item.get("lon", 0.0)) + SYNTHETIC_FALLBACK_OFFSET_DEGREES
                    b = item.get("bounds")
                    if isinstance(b, dict):
                        for k in ("north", "south", "lat_center"):
                            if k in b:
                                b[k] = float(b[k]) + SYNTHETIC_FALLBACK_OFFSET_DEGREES
                        for k in ("east", "west", "lon_center"):
                            if k in b:
                                b[k] = float(b[k]) + SYNTHETIC_FALLBACK_OFFSET_DEGREES
        except Exception:
            log.exception("[gfs] failed applying synthetic fallback offset")
        return self._annotate_weather_payload(
            cloud,
            bbox=bbox,
            source="fallback_proxy",
            payload_state="synthetic",
            heuristic=True,
            quality_note=cloud["quality_note"],
            confidence="low",
        )


    def read_most_recent_cached_real_payload(self, max_age_seconds: int = 5400) -> Any:
        if self.disk_cache is None:
            return None
        now_ts = time.time()
        newest = None
        newest_ts = 0.0
        try:
            for k in self.disk_cache.iterkeys():
                if not str(k).startswith('gfs_payload:v'):
                    continue
                row = self.disk_cache.get(k)
                if not isinstance(row, dict):
                    continue
                if row.get('source') != 'gfs_nomads':
                    continue
                ts = float(row.get('updated_at', 0)) / 1000.0 if row.get('updated_at') else 0.0
                if ts <= 0:
                    continue
                if now_ts - ts > max_age_seconds:
                    continue
                if ts > newest_ts:
                    newest_ts = ts
                    newest = row
        except Exception:
            return None
        return newest

    def _weather_unavailable_payload(self, bbox: dict[str, float], reason: str) -> dict[str, Any]:
        now = self._utc_now()
        return self._attach_truth_contract({
            "ok": True,
            "status": "warming",
            "payload_state": "provider_unavailable",
            "source": "gfs_nomads_unavailable_cache_warming",
            "bbox": bbox,
            "bbox_used": bbox,
            "requested_bbox": bbox,
            "generated_at": now,
            "resolved_time": now,
            "cycle": "unavailable",
            "forecast_hour": 0,
            "grid_tag": "provider_unavailable",
            "items": [],
            "features": [],
            "cloud_items": 0,
            "clouds": {"status": "warming", "source": "gfs_nomads_unavailable", "features": [], "cloud_items": 0},
            "rain": {"status": "warming", "source": "gfs_nomads_unavailable", "precip_columns": [], "features": []},
            "fields": {},
            "error": str(reason),
            "quality_note": "Live NOMADS/GRIB was unavailable; returning a non-fatal warming shell so visual routes stay alive.",
            "confidence": "none",
        }, bbox=bbox)

    def _generate_weather_payload_uncached(self, bbox: dict[str, float] | None = None) -> dict[str, Any]:
        bbox = self._normalize_bbox(bbox)
        try:
            payload = self.generate_real_gfs_payload(bbox)
            key = self.payload_cache_key(payload.get("cycle", "na"), int(payload.get("forecast_hour", 0)), bbox or {}, str(payload.get("grid_tag") or "na"))
            self.write_cached_payload(key, payload)
            return payload
        except Exception as exc:
            log.warning("[gfs] live real payload generation failed err=%s", exc)
            cached = self.read_most_recent_cached_real_payload(max_age_seconds=5400)
            if isinstance(cached, dict):
                log.warning("[gfs] using cached real payload due to live failure grid_tag=%s", cached.get("grid_tag"))
                cached_payload = self._annotate_weather_payload(
                    dict(cached),
                    bbox=bbox,
                    source="gfs_nomads",
                    payload_state="cached",
                    heuristic=False,
                    quality_note="Serving recent cached NOMADS-derived payload because live fetch failed.",
                    confidence="medium",
                )
                return cached_payload
            return self._weather_unavailable_payload(bbox, f"live_only_mode_failed reason={exc}")

    def generate_weather_payload(self, bbox: dict[str, float] | None = None) -> dict[str, Any]:
        refresh_bbox = self._normalize_bbox(bbox)
        cache_key = self._bbox_key_fragment(refresh_bbox)
        ttl_ms = max(10_000, WEATHER_REFRESH_TTL_SECONDS * 1000)
        now_ms = self._now_ms()
        row = self._weather_payload_cache or {}
        cached_payload = row.get("payload") if isinstance(row.get("payload"), dict) else None
        cached_ts = int(row.get("ts") or 0)
        cached_key = str(row.get("key") or "")
        if cached_payload and cached_key == cache_key and (now_ms - cached_ts) <= ttl_ms:
            return cached_payload

        with self._weather_refresh_lock:
            row = self._weather_payload_cache or {}
            cached_payload = row.get("payload") if isinstance(row.get("payload"), dict) else None
            cached_ts = int(row.get("ts") or 0)
            cached_key = str(row.get("key") or "")
            now_ms = self._now_ms()
            if cached_payload and cached_key == cache_key and (now_ms - cached_ts) <= ttl_ms:
                return cached_payload
            try:
                payload = self._generate_weather_payload_uncached(refresh_bbox)
                payload["bbox"] = refresh_bbox
                payload["bbox_used"] = refresh_bbox
                payload["requested_bbox"] = refresh_bbox
                self._weather_payload_cache = {"ts": self._now_ms(), "key": cache_key, "payload": payload}
                return self._attach_truth_contract(payload, bbox=refresh_bbox)
            except Exception as exc:
                if cached_payload and cached_key == cache_key:
                    return cached_payload
                return self._weather_unavailable_payload(refresh_bbox, str(exc))

    def debug_real_gfs_cycle(self, bbox: dict[str, float] | None = None) -> dict[str, Any]:
        """Manual debug helper for cycle/hour/url/group visibility."""
        bbox = bbox or {"west": -130, "south": 20, "east": -60, "north": 55}
        now = utc_now()
        fetch = self.gfs_client.fetch_latest_available_subset(now, bbox, DEFAULT_REQUIRED_VARIABLES, DEFAULT_REQUIRED_LEVELS)
        groups, decode_backend = self.open_all_valid_groups(fetch.path) if fetch.ok and fetch.path else ({}, "none")
        return {
            "ok": fetch.ok,
            "cycle": fetch.cycle,
            "forecast_hour": fetch.forecast_hour,
            "url": fetch.url,
            "groups": {k: list(v.data_vars.keys())[:20] for k, v in groups.items()},
            "decode_backend": decode_backend,
            "error": fetch.error,
        }

    def validate_bbox_real_fields(self, bbox: dict[str, float] | None = None) -> dict[str, Any]:
        """Manual check that precip/cloud/wind products are non-empty."""
        payload = self.generate_weather_payload(bbox)
        fields = payload.get("fields") or {}
        def shape(x):
            try:
                if isinstance(x, dict) and "values" in x:
                    x = x.get("values")
                return list(np.asarray(x).shape) if np is not None and x is not None else []
            except Exception:
                return []
        return {
            "ok": True,
            "source": payload.get("source"),
            "payload_state": payload.get("payload_state"),
            "source_url": payload.get("source_url"),
            "cycle": payload.get("cycle"),
            "forecast_hour": payload.get("forecast_hour"),
            "valid_time": payload.get("valid_time"),
            "has_precip": bool((payload.get("rain") or {}).get("count", 0) > 0),
            "has_cloud": bool(len(payload.get("tiles") or payload.get("items") or []) > 0),
            "has_balloon_vectors": bool((payload.get("balloons") or {}).get("count", 0) > 0),
            "has_field_wind_u": bool(fields.get("wind_u")),
            "has_field_wind_v": bool(fields.get("wind_v")),
            "field_shapes": {k: shape(fields.get(k)) for k in ["wind_u", "wind_v", "wind_speed", "precip_rate", "cloud_density", "temp2m", "mslp"]},
            "cloud_tiles": len(payload.get("tiles") or payload.get("items") or []),
            "rain_count": (payload.get("rain") or {}).get("count", 0),
            "fields_available": payload.get("fields_available") or self.state.fields_available,
            "fields_missing": payload.get("fields_missing") or self.state.fields_missing,
        }

    def compare_fallback_vs_real(self, bbox: dict[str, float] | None = None) -> dict[str, Any]:
        """Manual comparison helper between fallback and real precipitation/cloud outputs."""
        real = self.generate_weather_payload(bbox)
        fb = self.generate_fallback_payload(bbox)
        return {
            "real_source": real.get("source"),
            "real_tiles": len(real.get("tiles") or real.get("items") or []),
            "real_rain_cells": (real.get("rain") or {}).get("count", 0),
            "fallback_tiles": len(fb.get("items") or []),
            "fallback_rain_cells": (fb.get("rain") or {}).get("count", 0),
        }

    def _cached_cloud_tiles_payload(self) -> Dict[str, Any]:
        now_ms = self._now_ms()
        hour_bucket = now_ms // 3_600_000

        tiles: List[Dict[str, Any]] = []
        for lat in range(-90, 90, 6):
            lat_min = float(lat)
            lat_max = float(lat + 6)
            for lon in range(-180, 180, 6):
                lon_min = float(lon)
                lon_max = float(lon + 6)
                tile = self._cloud_tile_payload(lat_min, lat_max, lon_min, lon_max, hour_bucket)
                if max(tile["low_density"], tile["mid_density"], tile["high_density"]) < 0.08:
                    continue
                tiles.append(tile)

        tiles.sort(key=lambda t: t["importance"], reverse=True)
        summary = {
            "tile_count": len(tiles),
            "strong_tile_count": len([t for t in tiles if t["importance"] >= 0.72]),
            "storm_tile_count": len([t for t in tiles if t["precipitation_factor"] >= 0.55 or t["convection_factor"] >= 0.6]),
        }

        return {
            "ok": True,
            "source": "heuristic_forecast_from_latest_state",
            "heuristic": True,
            "note": "Fallback heuristic payload because real GFS path unavailable.",
            "updated_at": now_ms,
            "items": tiles,
            "summary": summary,
        }


    def _cloud_feature_from_tile(self, tile: dict[str, Any]) -> dict[str, Any]:
        bounds = tile.get("bounds") or {}
        low = (tile.get("bands") or {}).get("low") or {}
        mid = (tile.get("bands") or {}).get("mid") or {}
        high = (tile.get("bands") or {}).get("high") or {}
        return {
            "id": str(tile.get("tile_id") or f"cloud-{stable_hash_u32(str(bounds))}"),
            "center": {"lat": float(bounds.get("lat_center") or 0.0), "lon": float(bounds.get("lon_center") or 0.0)},
            "footprint": (low.get("footprints") or [{"points": []}])[0].get("points", []),
            "estimated_cloud_base_m": float(tile.get("estimated_cloud_base_m") or tile.get("base_altitude_m") or low.get("base_altitude_m") or 1000.0),
            "estimated_cloud_top_m": float(tile.get("estimated_cloud_top_m") or tile.get("top_altitude_m") or high.get("top_altitude_m") or 8000.0),
            "estimated_thickness_m": float(tile.get("estimated_cloud_thickness_m") or tile.get("vertical_depth_m") or 2200.0),
            "estimated_density": float(tile.get("estimated_density") or tile.get("density") or 0.0),
            "opacity_hint": round(_clamp(0.14 + float(tile.get("density") or 0.0) * 0.54, 0.08, 0.8), 4),
            "convective_strength": float(tile.get("storm_energy") or tile.get("convection_factor") or 0.0),
            "cloud_type_hint": str(tile.get("regime") or "cumulus_field"),
            "layer_hints": [
                {
                    "band": "low",
                    "base_m": float(low.get("base_altitude_m") or 0.0),
                    "top_m": float(low.get("top_altitude_m") or 0.0),
                    "density": float(low.get("density") or tile.get("low_density") or 0.0),
                    "spread_km": float(low.get("lateral_scale_km") or 0.0),
                },
                {
                    "band": "mid",
                    "base_m": float(mid.get("base_altitude_m") or 0.0),
                    "top_m": float(mid.get("top_altitude_m") or 0.0),
                    "density": float(mid.get("density") or tile.get("mid_density") or 0.0),
                    "spread_km": float(mid.get("lateral_scale_km") or 0.0),
                },
                {
                    "band": "high",
                    "base_m": float(high.get("base_altitude_m") or 0.0),
                    "top_m": float(high.get("top_altitude_m") or 0.0),
                    "density": float(high.get("density") or tile.get("high_density") or 0.0),
                    "spread_km": float(high.get("lateral_scale_km") or 0.0),
                },
            ],
            "visual_priority": float(tile.get("importance") or 0.0),
            "noise_seed": int(tile.get("seed") or stable_hash_u32(str(tile.get("tile_id") or "cloud"))),
            "heuristic": True,
            "source_confidence": "estimated",
            "source_fields": {
                "proxy_precip_rate": float(tile.get("precip_rate") or 0.0),
                "proxy_convection": float(tile.get("convection_factor") or tile.get("storm_energy") or 0.0),
                "proxy_low_density": float(tile.get("low_density") or 0.0),
                "proxy_mid_density": float(tile.get("mid_density") or 0.0),
                "proxy_high_density": float(tile.get("high_density") or 0.0),
            },
        }

    def _precip_feature_from_column(self, col: dict[str, Any]) -> dict[str, Any]:
        rate = float(col.get("estimated_precip_rate_mm_hr") or 0.0)
        intensity = _clamp(rate / 45.0, 0.0, 1.0)
        if intensity >= 0.9:
            bucket = "black"
            cls = "extreme"
        elif intensity >= 0.75:
            bucket = "red"
            cls = "very_heavy"
        elif intensity >= 0.6:
            bucket = "orange"
            cls = "heavy"
        elif intensity >= 0.45:
            bucket = "yellow"
            cls = "moderate"
        elif intensity >= 0.3:
            bucket = "green"
            cls = "light_moderate"
        elif intensity >= 0.16:
            bucket = "blue"
            cls = "light"
        else:
            bucket = "white"
            cls = "very_light"
        lat = float(col.get("lat") or 0.0)
        lon = float(col.get("lon") or 0.0)
        spread = 0.08 + intensity * 0.18
        footprint = close_ring([
            {"lat": lat - spread, "lng": lon - spread},
            {"lat": lat - spread, "lng": lon + spread},
            {"lat": lat + spread, "lng": lon + spread},
            {"lat": lat + spread, "lng": lon - spread},
        ])
        return {
            "id": f"precip-{col.get('tile_id') or stable_hash_u32(str(col))}",
            "center": {"lat": lat, "lon": lon},
            "footprint": footprint,
            "precip_type_hint": str(col.get("type_hint") or "rain"),
            "intensity_value": round(rate, 3),
            "intensity_class": cls,
            "palette_bucket": bucket,
            "source_altitude_m": float(col.get("estimated_source_altitude_m") or 0.0),
            "target_altitude_m": float(col.get("estimated_surface_altitude_m") or 0.0),
            "linked_cloud_id": str(col.get("tile_id") or ""),
            "storm_strength_hint": round(intensity, 4),
            "visual_priority": round(_clamp(intensity * 0.78 + (1 if cls in {"heavy", "very_heavy", "extreme"} else 0) * 0.18, 0.0, 1.0), 4),
            "heuristic": True,
            "source_fields": {"proxy_precip_rate": rate, "proxy_wind_u": float(col.get("wind_u") or 0.0), "proxy_wind_v": float(col.get("wind_v") or 0.0)},
        }

    def _lightning_feature_from_event(self, ev: dict[str, Any]) -> dict[str, Any]:
        energy = float(ev.get("estimated_energy") or 0.0)
        return {
            "id": f"ltg-{ev.get('tile_id') or stable_hash_u32(str(ev))}",
            "center": {"lat": float(ev.get("lat") or 0.0), "lon": float(ev.get("lon") or 0.0)},
            "path": [],
            "linked_cloud_id": str(ev.get("tile_id") or ""),
            "severity_hint": str(ev.get("severity_hint") or ("strong" if energy > 0.7 else "active")),
            "start_altitude_m": float(ev.get("estimated_flash_top_m") or 0.0),
            "end_altitude_m": float(ev.get("estimated_flash_bottom_m") or 0.0),
            "flash_hint": True,
            "visual_priority": round(_clamp(energy, 0.0, 1.0), 4),
            "heuristic": True,
            "source_fields": {"inferred_lightning_risk": energy},
        }

    def _wind_feature_from_vector(self, v: dict[str, Any]) -> dict[str, Any]:
        return {
            "id": f"wind-{stable_hash_u32(str(v.get('lat'))+':'+str(v.get('lon'))+':'+str(v.get('source_level')))}",
            "center": {"lat": float(v.get("lat") or 0.0), "lon": float(v.get("lon") or 0.0)},
            "vector_u": float(v.get("u") or 0.0),
            "vector_v": float(v.get("v") or 0.0),
            "speed_mps": float(v.get("speed_mps") or 0.0),
            "direction_deg": float(v.get("heading_deg") or 0.0),
            "altitude_band": str(v.get("source_level") or "unknown"),
            "feature_type": "jetstream_hint",
            "visual_priority": round(_clamp(float(v.get("speed_mps") or 0.0) / 45.0, 0.0, 1.0), 4),
            "heuristic": True,
        }

    def derive_swell_features_from_wind(self, wind_features: list[dict[str, Any]], max_items: int = 120) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for w in sorted(wind_features or [], key=lambda x: float(x.get("speed_mps") or 0.0), reverse=True):
            speed = float(w.get("speed_mps") or 0.0)
            if speed < 4.0:
                continue
            out.append({
                "id": f"swell-{w.get('id')}",
                "center": dict(w.get("center") or {"lat": 0.0, "lon": 0.0}),
                "direction_deg": float(w.get("direction_deg") or 0.0),
                "height_m": round(_clamp(0.3 + speed * 0.09, 0.2, 7.0), 3),
                "period_s": round(_clamp(4.0 + speed * 0.35, 4.0, 18.0), 3),
                "sample_area_km": round(_clamp(20 + speed * 3.8, 20, 220), 2),
                "intensity_class": "high" if speed > 17 else "moderate" if speed > 10 else "low",
                "visual_priority": round(_clamp(speed / 35.0, 0.0, 1.0), 4),
                "heuristic": True,
            })
            if len(out) >= max_items:
                break
        return out

    def _fish_scene_feature(self, fish: dict[str, Any]) -> dict[str, Any]:
        return {
            "id": str(fish.get("location_key") or fish.get("id") or "fish"),
            "lat": float(fish.get("lat") or 0.0),
            "lon": float(fish.get("lon") or 0.0),
            "label": str(fish.get("name") or fish.get("location_key") or "Fish"),
            "activity_hint": (fish.get("bait") or {}).get("intensity") or "unknown",
            "source": "fish_csv",
            "meta": fish.get("meta") or {},
        }

    def build_scene_payload(self, weather: dict[str, Any], bbox: dict[str, float]) -> dict[str, Any]:
        warnings: list[str] = []
        errors: list[str] = []
        clouds: list[dict[str, Any]] = []
        precip: list[dict[str, Any]] = []
        lightning: list[dict[str, Any]] = []
        wind: list[dict[str, Any]] = []
        swell: list[dict[str, Any]] = []
        fish_scene: list[dict[str, Any]] = []

        try:
            cloud_tiles = weather.get("tiles") or weather.get("items") or []
            clouds = [self._cloud_feature_from_tile(t) for t in cloud_tiles[:800] if isinstance(t, dict)]
        except Exception as exc:
            warnings.append("cloud_feature_derivation_failed")
            errors.append(str(exc))

        try:
            raw_precip = weather.get("precip_columns") or self.derive_precip_columns_from_tiles(weather.get("tiles") or weather.get("items") or [], max_items=260)
            precip = [self._precip_feature_from_column(c) for c in raw_precip if isinstance(c, dict)]
        except Exception as exc:
            warnings.append("precip_feature_derivation_failed")
            errors.append(str(exc))

        try:
            raw_ltg = weather.get("lightning_events") or self.derive_lightning_events_from_tiles(weather.get("tiles") or weather.get("items") or [], max_items=140)
            lightning = [self._lightning_feature_from_event(e) for e in raw_ltg if isinstance(e, dict)]
        except Exception as exc:
            warnings.append("lightning_feature_derivation_failed")
            errors.append(str(exc))

        try:
            raw_wind = (weather.get("balloons") or {}).get("items") if isinstance(weather.get("balloons"), dict) else []
            wind = [self._wind_feature_from_vector(v) for v in (raw_wind or []) if isinstance(v, dict)]
        except Exception as exc:
            warnings.append("wind_feature_derivation_failed")
            errors.append(str(exc))

        try:
            swell = self.derive_swell_features_from_wind(wind, max_items=120)
        except Exception as exc:
            warnings.append("swell_feature_derivation_failed")
            errors.append(str(exc))

        fish_error = None
        try:
            fish_points, fish_error = self.load_fish()
            fish_scene = [self._fish_scene_feature(f) for f in fish_points[:1500] if isinstance(f, dict)]
        except Exception as exc:
            fish_error = str(exc)
            warnings.append("fish_feature_derivation_failed")
            errors.append(str(exc))

        if fish_error:
            warnings.append("fish_source_unavailable")

        heuristic_flag = bool(weather.get("heuristic", True) or weather.get("payload_state") != "live")
        status = {
            "ok": len(errors) == 0,
            "mode": str(weather.get("payload_state") or "synthetic"),
            "warnings": warnings,
            "errors": errors,
            "upstream_available": weather.get("source") == "gfs_nomads",
            "partial": bool(warnings),
            "generated_at": self._now_ms(),
            "request_bounds": bbox,
            "fallback_active": str(weather.get("payload_state") or "synthetic") != "live",
            "heuristic_dominant": heuristic_flag,
            "decode_backend": weather.get("decode_backend") or self.state.decode_backend,
            "data_source_mode": weather.get("data_source_mode") or self.state.data_source_mode,
        }
        meta = {
            "schema_version": "atmo-scene-v1",
            "source_name": str(weather.get("source") or "fallback_proxy"),
            "source_type": "model" if weather.get("source") == "gfs_nomads" else "heuristic",
            "analysis_time": weather.get("cycle"),
            "valid_time": weather.get("valid_time"),
            "generated_at": self._now_ms(),
            "bounds": bbox,
            "units": {
                "altitude": "m",
                "wind_speed": "mps",
                "direction": "deg",
                "precip_rate": "mm_hr",
                "swell_height": "m",
                "swell_period": "s",
            },
            "heuristic_flags": {
                "scene_features_estimated": True,
                "fallback_payload": str(weather.get("payload_state") or "synthetic") != "live",
                "cloud_geometry_derived": True,
                "precip_columns_derived": True,
                "lightning_events_inferred": True,
            },
            "quality_note": weather.get("quality_note"),
            "confidence": weather.get("confidence"),
            "bbox_used": weather.get("bbox_used") or bbox,
            "source_format": weather.get("source_format") or self.state.model_source_format,
            "source_url": weather.get("source_url") or self.state.model_source_url,
            "cache_path": weather.get("cache_path") or self.state.model_cache_path,
            "fields_available": list(weather.get("fields_available") or self.state.fields_available or []),
            "fields_missing": list(weather.get("fields_missing") or self.state.fields_missing or []),
            "using_last_known_good": bool(weather.get("using_last_known_good", self.state.using_last_known_good)),
            "degraded_mode": bool(weather.get("degraded_mode", self.state.degraded_mode)),
            "decode_backend": weather.get("decode_backend") or self.state.decode_backend,
            "data_source_mode": weather.get("data_source_mode") or self.state.data_source_mode,
        }
        summary = {
            "cloud_count": len(clouds),
            "precip_count": len(precip),
            "lightning_count": len(lightning),
            "wind_count": len(wind),
            "swell_count": len(swell),
            "fish_count": len(fish_scene),
            "dominant_weather_mode": "convective" if any(float(c.get("convective_strength") or 0) > 0.65 for c in clouds[:120]) else "layered",
            "strongest_storm_class": "severe" if any(float(c.get("convective_strength") or 0) > 0.78 for c in clouds[:120]) else "moderate",
            "notes": warnings,
        }
        return {
            "status": status,
            "meta": meta,
            "scene": {
                "clouds": clouds,
                "precip": precip,
                "lightning": lightning,
                "wind": wind,
                "swell": swell,
                "fish": fish_scene,
            },
            "summary": summary,
        }
    def _degraded_scene_payload(self, bbox: dict[str, float], reason: str) -> dict[str, Any]:
        now = self._now_ms()
        return {
            "ok": False,
            "status": {
                "ok": False,
                "mode": "degraded",
                "degraded": True,
                "warnings": ["scene_generation_degraded"],
                "errors": [str(reason)],
                "partial": True,
                "generated_at": now,
                "request_bounds": bbox,
            },
            "meta": {
                "schema_version": "atmo-scene-v1",
                "generated_at": now,
                "bounds": bbox,
                "degraded": True,
                "decode_backend": self.state.decode_backend,
                "data_source_mode": self.state.data_source_mode,
            },
            "scene": {"clouds": [], "precip": [], "lightning": [], "wind": [], "swell": [], "fish": []},
            "summary": {"cloud_count": 0, "precip_count": 0, "lightning_count": 0, "wind_count": 0, "swell_count": 0, "fish_count": 0, "notes": ["degraded_response"]},
            "items": [],
            "precip_columns": [],
            "lightning_events": [],
            "source": "unavailable",
            "source_state": "unavailable",
            "payload_state": "unavailable",
            "heuristic": False,
            "quality_note": "No real cloud source data is currently available; no synthetic cloud geometry is drawn.",
            "confidence": "none",
            "bbox_used": bbox,
        }

    def cloud_tiles_payload(self, bbox: dict[str, float] | None = None, visible_bbox: dict[str, float] | None = None) -> Dict[str, Any]:
        bbox_norm = self._normalize_bbox(bbox)
        scene = self.build_scene_plan(bbox_norm, visible_bbox, layer="clouds")
        key = self._bbox_cache_key(f"clouds-{scene.get('tier')}", bbox_norm)
        def _shell():
            return {
                "ok": True,
                "source": "deferred_tile_cache",
                "source_state": "warming",
                "payload_state": "warming",
                "bbox": [bbox_norm["west"], bbox_norm["south"], bbox_norm["east"], bbox_norm["north"]],
                "bbox_object": bbox_norm,
                "scene_plan": scene,
                "visible_bbox": scene.get("visible_bbox"),
                "fetch_bbox": scene.get("fetch_bbox"),
                "render_budget": scene.get("render_budget"),
                "items": [],
                "features": [],
                "precip_columns": [],
                "polygon_field_v1": [],
                "summary": {"cloudItems": 0, "precipColumns": 0, "cacheFirst": True},
                "quality_note": "Cache-first cloud payload queued; existing visible clouds should be held until cache warms.",
            }
        return self._cache_first_split_payload(
            key=key,
            label="clouds",
            ttl_seconds=int(os.getenv("GFS_CLOUD_CACHE_TTL_SECONDS", "180") or "120"),
            stale_seconds=int(os.getenv("GFS_CLOUD_STALE_SECONDS", "1800") or "1800"),
            builder=lambda: self._cloud_tiles_payload_heavy(bbox_norm, scene.get("visible_bbox")),
            shell_factory=_shell,
        )

    def _cloud_tiles_payload_heavy(self, bbox: dict[str, float] | None = None, visible_bbox: dict[str, float] | None = None) -> Dict[str, Any]:
        bbox_norm = self._normalize_bbox(bbox)
        scene = self.build_scene_plan(bbox_norm, visible_bbox, layer="clouds")
        try:
            weather = self.generate_weather_payload(bbox_norm)
        except Exception as exc:
            log.exception("[gfs] scene weather generation failed")
            return self._attach_scene_plan(self._degraded_scene_payload(bbox_norm, str(exc)), scene)

        try:
            if weather.get("source") == "gfs_nomads":
                payload = self.serialize_cloud_payload(weather.get("tiles", []), weather)
                payload["payload_state"] = weather.get("payload_state", "live")
                payload["heuristic"] = bool(weather.get("heuristic", False))
                payload["quality_note"] = weather.get("quality_note") or "Real NOMADS field ingestion with visualization-derived geometry."
                payload["confidence"] = weather.get("confidence") or "high"
                payload["rain"] = weather.get("rain", {"items": [], "count": 0})
                payload["hail"] = weather.get("hail", {"items": [], "count": 0})
                payload["lightning"] = weather.get("lightning", {"items": [], "count": 0})
                payload["balloons"] = weather.get("balloons", {"items": [], "count": 0})
                payload["precip_columns"] = self.derive_precip_columns_from_tiles(payload.get("items", []), max_items=260)
                payload["lightning_events"] = self.derive_lightning_events_from_tiles(payload.get("items", []), max_items=140)
                payload["note"] = "Primary source is NOAA NOMADS GFS 0.25 via GRIB subset decode."
                payload["cycle"] = weather.get("cycle")
                payload["forecast_hour"] = weather.get("forecast_hour")
                payload["valid_time"] = weather.get("valid_time")
                payload["time_selection"] = "present_or_nearest_latest_available"
                payload["cloud_shell_refresh_seconds"] = int(os.getenv("GFS_CLOUD_CACHE_TTL_SECONDS", "180") or "120")
                payload["bbox_used"] = weather.get("bbox_used")
            else:
                payload = self._annotate_weather_payload(
                    weather,
                    bbox=bbox_norm,
                    source=str(weather.get("source") or "unavailable"),
                    payload_state=str(weather.get("payload_state") or "unavailable"),
                    heuristic=bool(weather.get("heuristic", False)),
                    quality_note=str(weather.get("quality_note") or "No real cloud source data is currently available."),
                    confidence=str(weather.get("confidence") or "none"),
                )
                payload.setdefault("precip_columns", self.derive_precip_columns_from_tiles(payload.get("items", []), max_items=260))
                payload.setdefault("lightning_events", self.derive_lightning_events_from_tiles(payload.get("items", []), max_items=140))

            payload["schema"] = "gfs_cloud_regions_v1"
            payload.setdefault("time_selection", "present_or_nearest_latest_available")
            payload.setdefault("cloud_shell_refresh_seconds", int(os.getenv("GFS_CLOUD_CACHE_TTL_SECONDS", "180") or "120"))
            payload["bbox"] = bbox_norm
            payload["bbox_used"] = bbox_norm
            payload["requested_bbox"] = bbox_norm
            payload.setdefault("tiles", payload.get("items") or [])
            if not payload.get("cloud_regions"):
                payload["cloud_regions"] = [t.get("cloud_region") for t in (payload.get("tiles") or []) if isinstance(t, dict) and isinstance(t.get("cloud_region"), dict)]
            payload["cloud_region_count"] = len(payload.get("cloud_regions") or [])
            payload.setdefault("diagnostics", {})
            if isinstance(payload.get("diagnostics"), dict):
                payload["diagnostics"].setdefault("requested_bbox", bbox_norm)
                payload["diagnostics"].setdefault("fetch_bbox", bbox_norm)
                payload["diagnostics"].setdefault("cloud_region_method", "live_cloud_intensity_marching_squares_components")
                payload["diagnostics"].setdefault("cloud_region_count", payload.get("cloud_region_count", 0))
            scene_payload = self.build_scene_payload(payload, bbox_norm)
            payload["status"] = scene_payload.get("status", {})
            payload["meta"] = scene_payload.get("meta", {})
            payload["scene"] = scene_payload.get("scene", {})
            payload["summary"] = scene_payload.get("summary", payload.get("summary") or {})
            payload["ok"] = bool(payload.get("ok", True) and payload["status"].get("ok", True))
            return self._attach_truth_contract(payload, bbox=bbox_norm, stride=(weather.get("scene_plan") or {}).get("provider_stride") if isinstance(weather.get("scene_plan"), dict) else weather.get("stride"), source_resolution_deg=weather.get("source_resolution_deg") or 0.25, derived_resolution_deg=0.03125, extra={"cloud_shells_smoothed": True, "neon_polygon_edges": True})
        except Exception as exc:
            log.exception("[gfs] scene payload assembly failed")
            return self._attach_truth_contract(self._degraded_scene_payload(bbox_norm, str(exc)), bbox=bbox_norm)


    def _tile_bounds_xyz(self, z: int, x: int, y: int) -> dict[str, float]:
        z = max(0, int(z))
        n = 2 ** z
        x = max(0, min(n - 1, int(x)))
        y = max(0, min(n - 1, int(y)))

        def tile2lon(tx: int, tz: int) -> float:
            return tx / (2 ** tz) * 360.0 - 180.0

        def tile2lat(ty: int, tz: int) -> float:
            val = math.pi * (1 - 2 * ty / (2 ** tz))
            return math.degrees(math.atan(math.sinh(val)))

        west = tile2lon(x, z)
        east = tile2lon(x + 1, z)
        north = tile2lat(y, z)
        south = tile2lat(y + 1, z)
        return {"west": west, "south": south, "east": east, "north": north}

    def _expand_bounds(self, bounds: dict[str, float], pad_deg: float = 0.18) -> dict[str, float]:
        return {
            "west": float(bounds.get("west", -180.0)) - pad_deg,
            "south": float(bounds.get("south", -80.0)) - pad_deg,
            "east": float(bounds.get("east", 180.0)) + pad_deg,
            "north": float(bounds.get("north", 80.0)) + pad_deg,
        }

    def _point_in_bounds(self, lat: float, lon: float, bounds: dict[str, float]) -> bool:
        return (
            float(bounds.get("south", -90.0)) <= float(lat) <= float(bounds.get("north", 90.0)
            ) and float(bounds.get("west", -180.0)) <= float(lon) <= float(bounds.get("east", 180.0))
        )

    def _feature_intersects_bounds(self, feat: dict[str, Any], bounds: dict[str, float]) -> bool:
        center = feat.get("center") or {}
        lat = center.get("lat")
        lon = center.get("lon")
        if lat is not None and lon is not None and self._point_in_bounds(safe_float(lat), safe_float(lon), bounds):
            return True
        # Try bounds center.
        bounds = feat.get("bounds") or {}
        if bounds:
            lat = bounds.get("lat_center")
            lon = bounds.get("lon_center")
            if lat is not None and lon is not None and self._point_in_bounds(safe_float(lat), safe_float(lon), bounds):
                return True
        # Try first footprint/path point if present.
        fp = feat.get("footprint")
        if isinstance(fp, list) and fp:
            p0 = fp[0] or {}
            lat = p0.get("lat")
            lon = p0.get("lng", p0.get("lon"))
            if lat is not None and lon is not None and self._point_in_bounds(safe_float(lat), safe_float(lon), bounds):
                return True
        return False

    def _feature_center(self, feat: dict[str, Any]) -> tuple[float | None, float | None]:
        center = feat.get("center") or {}
        lat = center.get("lat")
        lon = center.get("lon")
        if lat is None or lon is None:
            b = feat.get("bounds") or {}
            lat = b.get("lat_center", lat)
            lon = b.get("lon_center", lon)
        if lat is None or lon is None:
            fp = feat.get("footprint")
            if isinstance(fp, list) and fp:
                p0 = fp[0] or {}
                lat = p0.get("lat", lat)
                lon = p0.get("lng", p0.get("lon", lon))
        lat_f = safe_float(lat, None)
        lon_f = safe_float(lon, None)
        if lat_f is None or lon_f is None:
            return None, None
        return lat_f, lon_f

    def _feature_bbox(self, feat: dict[str, Any]) -> dict[str, float]:
        b = feat.get("bbox")
        if isinstance(b, dict):
            try:
                return {"west": float(b.get("west")), "south": float(b.get("south")), "east": float(b.get("east")), "north": float(b.get("north"))}
            except Exception:
                pass
        lat, lon = self._feature_center(feat)
        if lat is None or lon is None:
            return {"west": -181.0, "south": -91.0, "east": -181.0, "north": -91.0}
        return {"west": lon, "south": lat, "east": lon, "north": lat}

    def _grid_cells_for_bbox(self, bbox: dict[str, float], cell_deg: float = SPATIAL_GRID_DEG) -> list[str]:
        west = float(bbox.get("west", -180.0))
        east = float(bbox.get("east", 180.0))
        south = float(bbox.get("south", -90.0))
        north = float(bbox.get("north", 90.0))
        gx0 = int(math.floor((west + 180.0) / cell_deg))
        gx1 = int(math.floor((east + 180.0) / cell_deg))
        gy0 = int(math.floor((south + 90.0) / cell_deg))
        gy1 = int(math.floor((north + 90.0) / cell_deg))
        cells = []
        for gx in range(gx0, gx1 + 1):
            for gy in range(gy0, gy1 + 1):
                cells.append(f"{gx}:{gy}")
        return cells

    def _dedup_key(self, layer: str, feat: dict[str, Any], meta: dict[str, Any]) -> str:
        if layer == "lightning":
            c = meta.get("centroid") or {}
            lat = round(safe_float(c.get("lat"), 0.0), 2)
            lon = round(safe_float(c.get("lon"), 0.0), 2)
            t = str(meta.get("time_bucket") or "na")
            intensity = round(safe_float(feat.get("estimated_energy") or feat.get("intensity") or feat.get("severity"), 0.0), 2)
            kind = str(feat.get("type") or feat.get("kind") or "strike")
            return f"ltg:{lat}:{lon}:{t}:{intensity}:{kind}"
        return str(meta.get("feature_id") or feat.get("id") or stable_hash_u32(json.dumps(feat, sort_keys=True, default=str)))

    def _feature_meta(self, layer: str, feat: dict[str, Any]) -> dict[str, Any]:
        lat, lon = self._feature_center(feat)
        bbox = self._feature_bbox(feat)
        fid = str(feat.get("id") or f"{layer}-{stable_hash_u32(json.dumps(feat, sort_keys=True, default=str))}")
        time_bucket = str(feat.get("time_bucket") or feat.get("ts_bucket") or feat.get("valid_time") or "na")
        altitude_band = str(feat.get("altitude_band") or feat.get("band") or "surface")
        meta = {
            "feature_id": fid,
            "layer": layer,
            "bbox": bbox,
            "centroid": {"lat": lat, "lon": lon},
            "time_bucket": time_bucket,
            "altitude_band": altitude_band,
        }
        meta["dedup_key"] = self._dedup_key(layer, feat, meta)
        return meta

    def _intersects_bbox(self, a: dict[str, float], b: dict[str, float]) -> bool:
        return not (a.get("east", -999) < b.get("west", 999) or a.get("west", 999) > b.get("east", -999) or a.get("north", -999) < b.get("south", 999) or a.get("south", 999) > b.get("north", -999))

    def _build_layer_feature_indexes(self, scene_payload: dict[str, Any]) -> None:
        scene = scene_payload.get("scene") if isinstance(scene_payload.get("scene"), dict) else {}
        layer_sources = {
            "clouds": scene_payload.get("items") or [],
            "precip": scene_payload.get("precip_columns") or scene.get("precip") or [],
            "lightning": scene_payload.get("lightning_events") or scene.get("lightning") or [],
            "wind": scene.get("wind") or ((scene_payload.get("balloons") or {}).get("items") if isinstance(scene_payload.get("balloons"), dict) else []) or [],
            "swell": scene.get("swell") or [],
            "sst": scene.get("sst") or [],
            "fish": (self.state.fish_points or self.load_fish()[0]) or [],
        }
        self.state.layer_feature_index = {}
        self.state.layer_feature_meta = {}
        self.state.layer_feature_store = {}
        for layer, feats in layer_sources.items():
            idx = {}
            metas = {}
            store = {}
            for feat in feats:
                if not isinstance(feat, dict):
                    continue
                meta = self._feature_meta(layer, feat)
                fid = meta["feature_id"]
                metas[fid] = meta
                store[fid] = feat
                for cell in self._grid_cells_for_bbox(meta["bbox"]):
                    idx.setdefault(cell, set()).add(fid)
            self.state.layer_feature_index[layer] = idx
            self.state.layer_feature_meta[layer] = metas
            self.state.layer_feature_store[layer] = store

    def _spatial_candidates(self, layer: str, bounds: dict[str, float]) -> tuple[list[dict[str, Any]], int]:
        idx = self.state.layer_feature_index.get(layer) or {}
        metas = self.state.layer_feature_meta.get(layer) or {}
        store = self.state.layer_feature_store.get(layer) or {}
        if not idx:
            return [], 0
        candidate_ids = set()
        for cell in self._grid_cells_for_bbox(bounds):
            candidate_ids.update(idx.get(cell) or set())
        out = []
        for fid in candidate_ids:
            meta = metas.get(fid) or {}
            if not self._intersects_bbox(meta.get("bbox") or {}, bounds):
                continue
            feat = store.get(fid)
            if feat is None:
                continue
            f = dict(feat)
            f.setdefault("feature_id", fid)
            f.setdefault("layer", layer)
            f.setdefault("bbox", meta.get("bbox"))
            f.setdefault("centroid", meta.get("centroid"))
            f.setdefault("time_bucket", meta.get("time_bucket"))
            f.setdefault("altitude_band", meta.get("altitude_band"))
            f.setdefault("dedup_key", meta.get("dedup_key"))
            c = f.get("centroid") or {}
            lat = safe_float(c.get("lat"), None)
            lon = safe_float(c.get("lon"), None)
            if lat is None or lon is None:
                log.debug("[gfs] skip malformed feature without finite centroid layer=%s fid=%s", layer, fid)
                continue
            out.append(f)
        return out, len(candidate_ids)

    def _record_tile_diag(self, key: str, diag: dict[str, Any]) -> None:
        self.state.tile_diagnostics[key] = diag
        if len(self.state.tile_diagnostics) > MAX_TILE_DIAGNOSTICS:
            for old_key in sorted(self.state.tile_diagnostics.keys())[: len(self.state.tile_diagnostics) - MAX_TILE_DIAGNOSTICS]:
                self.state.tile_diagnostics.pop(old_key, None)

    def _scene_cache_key(self, bbox: dict[str, float]) -> str:
        return f"scene:{round(safe_float(bbox.get('west'),-180.0),3)}:{round(safe_float(bbox.get('south'),-80.0),3)}:{round(safe_float(bbox.get('east'),180.0),3)}:{round(safe_float(bbox.get('north'),80.0),3)}"

    def _get_cached_scene_payload(self, bbox: dict[str, float]) -> tuple[dict[str, Any], dict[str, Any]]:
        now_ms = self._now_ms()
        ttl_ms = max(10_000, SCENE_REFRESH_TTL_SECONDS * 1000)
        key = self._scene_cache_key(bbox)
        row = self.state.tile_cache.get(key) or {}
        diag = {"scene_cache_key": key, "cache_hit": False, "cache_age_ms": None, "build_duration_ms": 0}
        if row and (now_ms - int(row.get("ts") or 0)) <= ttl_ms and isinstance(row.get("payload"), dict):
            diag["cache_hit"] = True
            diag["cache_age_ms"] = now_ms - int(row.get("ts") or 0)
            return row["payload"], diag

        if not self._scene_refresh_lock.acquire(blocking=False):
            if isinstance(row.get("payload"), dict):
                diag["cache_hit"] = True
                diag["cache_age_ms"] = now_ms - int(row.get("ts") or 0)
                return row["payload"], diag
            with self._scene_refresh_lock:
                pass
            row = self.state.tile_cache.get(key) or {}
            if isinstance(row.get("payload"), dict):
                diag["cache_hit"] = True
                diag["cache_age_ms"] = now_ms - int(row.get("ts") or 0)
                return row["payload"], diag

        started = time.perf_counter()
        try:
            payload = self.cloud_tiles_payload(bbox)
        except Exception as exc:
            log.exception("[gfs] cached scene generation failed")
            payload = self._degraded_scene_payload(bbox, str(exc))
        finally:
            self._scene_refresh_lock.release()

        diag["build_duration_ms"] = int((time.perf_counter() - started) * 1000)
        self.state.tile_cache[key] = {"ts": now_ms, "payload": payload}
        self.state.scene_cache = payload
        self.state.scene_cache_ts = now_ms
        try:
            self._build_layer_feature_indexes(payload)
        except Exception:
            log.exception("[gfs] layer feature index build failed")
        return payload, diag

    def get_scene_payload(self, bbox: dict[str, float] | None = None) -> dict[str, Any]:
        payload, _ = self._get_cached_scene_payload(self._normalize_bbox(bbox))
        return payload

    def layer_tile_payload(self, layer: str, z: int, x: int, y: int, pad_deg: float = 0.18, debug: bool = False) -> dict[str, Any]:
        layer_name = (layer or "").strip().lower()
        tile_bounds = self._tile_bounds_xyz(z, x, y)
        filter_bounds = self._expand_bounds(tile_bounds, pad_deg=pad_deg)
        tile_key = f"{layer_name}:{z}/{x}/{y}"
        scene_payload, cache_diag = self._get_cached_scene_payload(filter_bounds)
        if not self.state.layer_feature_index.get(layer_name):
            self._build_layer_feature_indexes(scene_payload)
        scene = scene_payload.get("scene") if isinstance(scene_payload.get("scene"), dict) else {}

        caps = {"clouds": 220, "precip": 240, "lightning": 160, "wind": 220, "swell": 160, "sst": 180, "fish": 260}
        if layer_name not in caps:
            return {
                "status": {"ok": False, "mode": "invalid", "errors": ["unknown_layer"], "warnings": [], "partial": False},
                "meta": {"layer": layer_name, "z": z, "x": x, "y": y, "bounds": tile_bounds, "schema_version": "atmo-tile-v1", "generated_at": self._now_ms()},
                "features": [],
                "summary": {"count": 0},
            }

        try:
            candidates, candidate_count = self._spatial_candidates(layer_name, filter_bounds)
            precise = [f for f in candidates if self._feature_intersects_bounds(f, filter_bounds)]
        except Exception as exc:
            log.exception("[gfs] tile derivation failed layer=%s tile=%s/%s/%s", layer_name, z, x, y)
            candidates, candidate_count, precise = [], 0, []
        precise = sorted(precise, key=lambda f: safe_float(f.get("visual_priority", f.get("importance", 0.0)), 0.0), reverse=True)

        dedup = []
        dedup_seen = set()
        dedup_suppressed = 0
        for feat in precise:
            dkey = str(feat.get("dedup_key") or feat.get("feature_id") or feat.get("id") or stable_hash_u32(json.dumps(feat, sort_keys=True, default=str)))
            if dkey in dedup_seen:
                dedup_suppressed += 1
                continue
            dedup_seen.add(dkey)
            dedup.append(feat)
        features = dedup[: caps[layer_name]]

        if layer_name in {"precip", "clouds", "sst"}:
            field_map = {"precip": "precip_rate", "clouds": "cloud_density", "sst": "temperature_k"}
            contour_geo = self._marching_squares_contours(field_map[layer_name], filter_bounds, z)
            for feat in contour_geo:
                features.append({
                    "id": f"contour-{stable_hash_u32(json.dumps(feat, sort_keys=True, default=str))}",
                    "type": "contour",
                    "geojson": feat,
                    "visual_priority": 0.4,
                })

        src_status = scene_payload.get("status") if isinstance(scene_payload.get("status"), dict) else {}
        src_meta = scene_payload.get("meta") if isinstance(scene_payload.get("meta"), dict) else {}
        diagnostics = {
            "tile_key": tile_key,
            "layer": layer_name,
            "request_bounds": tile_bounds,
            "filter_bounds": filter_bounds,
            "cache_hit": cache_diag.get("cache_hit", False),
            "cache_age_ms": cache_diag.get("cache_age_ms"),
            "build_duration_ms": cache_diag.get("build_duration_ms", 0),
            "candidate_count": candidate_count,
            "precise_count": len(precise),
            "emitted_count": len(features),
            "dedup_suppressed_count": dedup_suppressed,
            "decode_backend": self.state.decode_backend,
            "data_source_mode": self.state.data_source_mode,
            "cycle": self.state.model_cycle,
            "forecast_hour": self.state.model_forecast_hour,
            "valid_time": self.state.model_valid_time,
        }
        self._record_tile_diag(tile_key, diagnostics)

        out = {
            "status": {
                "ok": bool(src_status.get("ok", True)),
                "mode": str(src_status.get("mode") or scene_payload.get("payload_state") or "live"),
                "warnings": list(src_status.get("warnings") or []),
                "errors": list(src_status.get("errors") or []),
                "partial": bool(src_status.get("partial", False)),
                "generated_at": self._now_ms(),
                "request_bounds": tile_bounds,
                "data_source_mode": self.state.data_source_mode,
                "decode_backend": self.state.decode_backend,
            },
            "meta": {
                "layer": layer_name,
                "z": int(z),
                "x": int(x),
                "y": int(y),
                "bounds": tile_bounds,
                "filter_bounds": filter_bounds,
                "schema_version": "atmo-tile-v1",
                "generated_at": self._now_ms(),
                "analysis_time": src_meta.get("analysis_time") or scene_payload.get("cycle"),
                "valid_time": src_meta.get("valid_time") or scene_payload.get("valid_time"),
                "heuristic": bool(src_meta.get("heuristic_flags", {}).get("scene_features_estimated", scene_payload.get("heuristic", True))),
                "decode_backend": self.state.decode_backend,
                "data_source_mode": self.state.data_source_mode,
            },
            "features": features,
            "summary": {
                "count": len(features),
                "layer": layer_name,
                "tile": f"{z}/{x}/{y}",
                "candidate_count": candidate_count,
                "dedup_suppressed": dedup_suppressed,
            },
        }
        if debug:
            out["diagnostics"] = diagnostics
        return out

    def tile_diagnostics_payload(self, layer: str | None = None, tile: str | None = None) -> dict[str, Any]:
        layer_name = (layer or "").strip().lower()
        rows = []
        for key, diag in sorted(self.state.tile_diagnostics.items(), key=lambda kv: kv[0]):
            if layer_name and diag.get("layer") != layer_name:
                continue
            if tile and tile not in key:
                continue
            rows.append(diag)
        return {
            "status": {"ok": True, "generated_at": self._now_ms()},
            "meta": {
                "schema_version": "tile-diagnostics-v1",
                "decode_backend": self.state.decode_backend,
                "data_source_mode": self.state.data_source_mode,
                "cycle": self.state.model_cycle,
                "forecast_hour": self.state.model_forecast_hour,
            },
            "items": rows[-250:],
            "summary": {"count": len(rows[-250:])},
        }

    def _load_store(self) -> Dict[str, Any]:
        if not self.store_path.exists():
            return {"locations": {}}
        try:
            return json.loads(self.store_path.read_text(encoding="utf-8"))
        except Exception:
            return {"locations": {}}

    def _save_store(self, data: Dict[str, Any]) -> None:
        self.store_path.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")

    def _ensure_location_record(self, store: Dict[str, Any], location_key: str) -> Dict[str, Any]:
        locations = store.setdefault("locations", {})
        rec = locations.setdefault(
            location_key,
            {
                "location_key": location_key,
                "report_text": "",
                "report_updated_at": None,
                "live": {"active": False, "stream_url": "", "updated_at": None},
                "uploads": [],
            },
        )
        return rec

    def _location_media_payload(self, location_key: str) -> Dict[str, Any]:
        store = self._load_store()
        key_in = str(location_key or "").strip()
        if not key_in:
            return {"ok": False, "error": "missing location_key", "location_key": "", "uploads": [], "live": {}, "report_text": ""}

        fish_match = self._find_fish_point(key_in)
        key = str((fish_match or {}).get("location_key") or self._normalize_location_key(key_in))
        rec = self._ensure_location_record(store, key)
        now_ms = self._now_ms()
        if fish_match:
            intel = self._build_bait_intel(fish_match, now_ms)
        else:
            intel = self._heuristic_context(None, None, now_ms)
        csv_reports = list((fish_match or {}).get("all_reports") or (fish_match or {}).get("reports") or [])
        user_report = (rec.get("report_text") or "").strip()
        reports = [*csv_reports, *([user_report] if user_report else [])]
        return {
            "ok": True,
            "id": key,
            "location_id": key,
            "location_key": key,
            "csv_id": (fish_match or {}).get("csv_id"),
            "name": (fish_match or {}).get("name") or key,
            "label": (fish_match or {}).get("name") or key,
            "lat": (fish_match or {}).get("lat"),
            "lon": (fish_match or {}).get("lon"),
            "reports": reports,
            "all_reports": reports,
            "csv_reports": csv_reports,
            "last_report": reports[-1] if reports else "",
            "report_count": len(reports),
            "report_text": user_report,
            "report_updated_at": rec.get("report_updated_at"),
            "uploads": rec.get("uploads") or [],
            "live": rec.get("live") or {"active": False, "stream_url": "", "updated_at": None},
            **intel,
            "ts": self._now_ms(),
        }

    def location_payload(self, location_key: str) -> Dict[str, Any]:
        """Detailed marker payload for HUD opening."""
        return self._location_media_payload(location_key)

    def location_environment_payload(self, location_key: str) -> Dict[str, Any]:
        """Weather/environment-only payload for a marker HUD."""
        loc = self._find_fish_point(location_key)
        if not loc:
            return {"ok": False, "error": "location not found", "id": location_key, "marker_environment": None}
        media = self._location_media_payload(str(loc.get("location_key") or loc.get("id")))
        marker_env = media.get("marker_environment") or media.get("weather_environment") or (media.get("weather") or {}).get("marker_environment")
        return {
            "ok": bool(marker_env),
            "id": loc.get("id"),
            "location_id": loc.get("location_key"),
            "location_key": loc.get("location_key"),
            "name": loc.get("name"),
            "lat": loc.get("lat"),
            "lon": loc.get("lon"),
            "marker_environment": marker_env,
            "weather_environment": marker_env,
            "environment": media.get("environment"),
            "environment_meta": media.get("environment_meta"),
            "weather": media.get("weather"),
            "ts": self._now_ms(),
        }

    def node_intelligence_payload(self, node_id: str) -> Dict[str, Any]:
        """Return a stable /intelligence/node/<id> contract for fish markers."""
        loc = self._find_fish_point(node_id)
        if not loc:
            return {"ok": False, "error": "location not found", "id": node_id, "profile": None}
        media = self._location_media_payload(str(loc.get("location_key") or loc.get("id")))
        extra_reports = list(media.get("reports") or [])
        profile = build_location_profile(loc, extra_reports)
        return {
            "ok": True,
            "id": loc.get("id"),
            "location_id": loc.get("location_key"),
            "location_key": loc.get("location_key"),
            "name": loc.get("name"),
            "lat": loc.get("lat"),
            "lon": loc.get("lon"),
            "reports": extra_reports,
            "last_report": extra_reports[-1] if extra_reports else "",
            "profile": profile,
            "bait": media.get("bait"),
            "environment": media.get("environment"),
            "environment_meta": media.get("environment_meta"),
            "history": media.get("history"),
            "marker_environment": media.get("marker_environment") or media.get("weather_environment") or (media.get("weather") or {}).get("marker_environment"),
            "weather_environment": media.get("marker_environment") or media.get("weather_environment") or (media.get("weather") or {}).get("marker_environment"),
            "weather": media.get("weather"),
            "live": media.get("live"),
            "uploads": media.get("uploads"),
            "ts": self._now_ms(),
        }

    def health(self) -> Dict[str, Any]:
        points, _ = self.load_fish()
        return {
            "ok": True,
            "enabled": self.state.enabled,
            "source": self.state.source_name,
            "fish_count": len(points),
            "last_refresh_ts": self.state.last_refresh_ts,
            "last_error": self.state.last_error,
            "fish_csv": str(self._fish_csv_path()),
            "fish_csv_exists": self._fish_csv_path().exists(),
            "fish_csv_candidates": [str(p) for p in self._fish_csv_candidates()],
            "ingest": {
                "status": self.state.ingest_status,
                "last_attempt_ts": self.state.ingest_last_attempt_ts,
                "last_success_ts": self.state.ingest_last_success_ts,
                "error": self.state.ingest_error,
                "degraded_mode": self.state.degraded_mode,
                "using_last_known_good": self.state.using_last_known_good,
                "cycle": self.state.model_cycle,
                "forecast_hour": self.state.model_forecast_hour,
                "valid_time": self.state.model_valid_time,
                "analysis_time": self.state.model_analysis_time,
                "source_url": self.state.model_source_url,
                "cache_path": self.state.model_cache_path,
                "source_format": self.state.model_source_format,
                "fields_available": list(self.state.fields_available or []),
                "fields_missing": list(self.state.fields_missing or []),
                "decode_backend": self.state.decode_backend,
                "data_source_mode": self.state.data_source_mode,
            },
            "ts": self._now_ms(),
        }

    def config(self) -> Dict[str, Any]:
        return {
            "enabled": self.state.enabled,
            "api_base": "/gfs/api",
            "ws_base": "/gfs/ws",
            "cache_ttl_seconds": self.state.cache_ttl_seconds,
            "google_maps_api_key": os.getenv("GOOGLE_MAPS_API_KEY", "").strip() or os.getenv("MAPS_API_KEY", "").strip(),
            "ingest": {
                "fallback_cycle_depth": INGEST_FALLBACK_CYCLE_DEPTH,
                "preferred_forecast_hour": INGEST_PREFERRED_FORECAST_HOUR,
                "cache_min_bytes": INGEST_CACHE_MIN_BYTES,
                "source_format": "grib2",
            },
            "ts": self._now_ms(),
        }

    # Backward-compatible route/service contract helpers.
    def health_payload(self) -> Dict[str, Any]:
        payload = self.health()
        try:
            payload["gfs_cache"] = self.cache_status_payload().get("cache", {})
        except Exception as exc:
            payload["gfs_cache"] = {"enabled": True, "error": str(exc)}
        return payload


    # ------------------------------------------------------------------
    # Managed globe tile cache / center-first tile planning
    # ------------------------------------------------------------------
    def _tile_cache_root(self) -> Path:
        root = BASE_DIR / ".cache" / "gfs_tiles"
        root.mkdir(parents=True, exist_ok=True)
        return root

    def _wrap_lon(self, lon: float) -> float:
        try:
            x = float(lon)
        except Exception:
            return 0.0
        while x < -180.0:
            x += 360.0
        while x >= 180.0:
            x -= 360.0
        return x

    def _base_tile_grid(self) -> tuple[int, int]:
        cols = int(os.getenv("GFS_BASE_TILE_COLS", "32") or "32")
        rows = int(os.getenv("GFS_BASE_TILE_ROWS", "16") or "16")
        return max(1, cols), max(1, rows)

    def _tile_id_for_point(self, lat: float, lon: float, cols: int | None = None, rows: int | None = None) -> str:
        if cols is None or rows is None:
            cols, rows = self._base_tile_grid()
        lat_c = max(-89.999, min(89.999, float(lat)))
        lon_c = self._wrap_lon(float(lon))
        col = int(math.floor(((lon_c + 180.0) / 360.0) * cols))
        row = int(math.floor(((90.0 - lat_c) / 180.0) * rows))
        col = max(0, min(cols - 1, col))
        row = max(0, min(rows - 1, row))
        return f"z0_r{row}_c{col}"

    def _parse_tile_id(self, tile_id: str) -> tuple[int, int, int]:
        m = re.match(r"z(\d+)_r(\d+)_c(\d+)$", str(tile_id or ""))
        if not m:
            return 0, 0, 0
        return int(m.group(1)), int(m.group(2)), int(m.group(3))

    def _tile_bounds_by_id(self, tile_id: str) -> dict[str, float]:
        z, row, col = self._parse_tile_id(tile_id)
        base_cols, base_rows = self._base_tile_grid()
        scale = 2 ** max(0, z)
        cols = base_cols * scale
        rows = base_rows * scale
        col = max(0, min(cols - 1, int(col)))
        row = max(0, min(rows - 1, int(row)))
        lon_w = -180.0 + (360.0 / cols) * col
        lon_e = -180.0 + (360.0 / cols) * (col + 1)
        lat_n = 90.0 - (180.0 / rows) * row
        lat_s = 90.0 - (180.0 / rows) * (row + 1)
        return {"west": lon_w, "south": lat_s, "east": lon_e, "north": lat_n}

    def _bbox_center(self, bbox: dict[str, float]) -> tuple[float, float]:
        b = self._normalize_bbox(bbox)
        return ((b["south"] + b["north"]) / 2.0, self._wrap_lon((b["west"] + b["east"]) / 2.0))

    def _bbox_intersects(self, a: dict[str, float], b: dict[str, float]) -> bool:
        return not (a["east"] <= b["west"] or a["west"] >= b["east"] or a["north"] <= b["south"] or a["south"] >= b["north"])

    def _expand_bbox_factor(self, bbox: dict[str, float], factor: float | None = None, max_lon_span: float | None = None, max_lat_span: float | None = None) -> dict[str, float]:
        """Return a padded anti-clipping bbox around the viewport center."""
        b = self._normalize_bbox(bbox)
        clat, clon = self._bbox_center(b)
        factor_f = float(factor if factor is not None else os.getenv("GFS_VIEWPORT_PAD_FACTOR", "1.25"))
        max_lon = float(max_lon_span if max_lon_span is not None else os.getenv("GFS_MAX_WORK_LON_SPAN", "10.0"))
        max_lat = float(max_lat_span if max_lat_span is not None else os.getenv("GFS_MAX_WORK_LAT_SPAN", "10.0"))
        base_lon_span = max(0.25, abs(float(b["east"]) - float(b["west"])))
        base_lat_span = max(0.25, abs(float(b["north"]) - float(b["south"])))
        lon_span = min(max_lon, max(0.25, base_lon_span * factor_f))
        lat_span = min(max_lat, max(0.25, base_lat_span * factor_f))
        west = max(-180.0, clon - lon_span / 2.0)
        east = min(180.0, clon + lon_span / 2.0)
        south = max(-80.0, clat - lat_span / 2.0)
        north = min(80.0, clat + lat_span / 2.0)
        return {"west": west, "south": south, "east": east, "north": north}

    def _bounded_work_bbox(self, bbox: dict[str, float], max_lon_span: float = 10.0, max_lat_span: float = 10.0) -> dict[str, float]:
        """Padded/limited work bbox for cache/provider/polygon generation."""
        return self._expand_bbox_factor(bbox, factor=None, max_lon_span=max_lon_span, max_lat_span=max_lat_span)


    def _bbox_span_area(self, bbox: dict[str, float]) -> tuple[float, float, float]:
        b = self._normalize_bbox(bbox)
        width = abs(float(b["east"]) - float(b["west"]))
        if width > 180.0:
            width = 360.0 - width
        height = abs(float(b["north"]) - float(b["south"]))
        return width, height, max(0.0, width * height)

    def _scene_tier_for_bbox(self, bbox: dict[str, float]) -> str:
        width, height, area = self._bbox_span_area(bbox)
        span = max(width, height)
        if span <= 1.6 and area <= 2.6:
            return "harbor"
        if span <= 4.0 and area <= 14.0:
            return "coastal"
        if span <= 12.0 and area <= 90.0:
            return "regional"
        return "world"

    def _scene_budget(self, tier: str) -> dict[str, Any]:
        tier_key = str(tier or "regional").lower()
        table = {
            "harbor": {
                "target_cells": 18000, "provider_target_cells": 24000,
                "max_cloud_shells": 180, "max_cloud_particles": 5200,
                "max_boats": 24, "max_bait_polygons": 220,
                "fetch_padding": 1.4, "solve_dx_deg": 0.015, "render_dx_deg": 0.03,
            },
            "coastal": {
                "target_cells": 14000, "provider_target_cells": 19000,
                "max_cloud_shells": 240, "max_cloud_particles": 4800,
                "max_boats": 36, "max_bait_polygons": 180,
                "fetch_padding": 1.6, "solve_dx_deg": 0.03, "render_dx_deg": 0.06,
            },
            "regional": {
                "target_cells": 10000, "provider_target_cells": 14000,
                "max_cloud_shells": 320, "max_cloud_particles": 4200,
                "max_boats": 48, "max_bait_polygons": 150,
                "fetch_padding": 1.8, "solve_dx_deg": 0.06, "render_dx_deg": 0.10,
            },
            "world": {
                "target_cells": 6000, "provider_target_cells": 8000,
                "max_cloud_shells": 400, "max_cloud_particles": 3200,
                "max_boats": 12, "max_bait_polygons": 80,
                "fetch_padding": 2.0, "solve_dx_deg": 0.25, "render_dx_deg": 0.50,
            },
        }
        out = dict(table.get(tier_key) or table["regional"])
        out["tier"] = tier_key if tier_key in table else "regional"
        return out

    def _choose_decimation_for_shape(self, rows: int, cols: int, target_cells: int) -> int:
        try:
            total = max(1, int(rows) * int(cols))
            target = max(1, int(target_cells or 1))
            if total <= target:
                return 1
            return max(1, int(math.ceil(math.sqrt(total / float(target)))))
        except Exception:
            return 1

    def _estimate_provider_stride_for_bbox(self, bbox: dict[str, float], target_cells: int | None = None) -> int:
        # HYCOM/GFS provider spacing varies by product. Use a conservative 0.04°
        # estimate so large/tilted fetch bboxes are protected by target cell budgets
        # instead of fixed magic stride buckets. Small harbor bboxes stay native.
        b = self._normalize_bbox(bbox)
        width, height, area = self._bbox_span_area(b)
        if max(width, height) <= 1.6 and area <= 2.8:
            return 1
        native_dx = float(os.getenv("GFS_SCENE_PROVIDER_DX_DEG", "0.04") or "0.04")
        est_rows = max(1, int(math.ceil(height / native_dx)) + 1)
        est_cols = max(1, int(math.ceil(width / native_dx)) + 1)
        return min(12, self._choose_decimation_for_shape(est_rows, est_cols, int(target_cells or 12000)))

    def build_scene_plan(self, bbox: dict[str, float] | None = None, visible_bbox: dict[str, float] | None = None, layer: str = "frame") -> dict[str, Any]:
        fetch_bbox = self._normalize_bbox(bbox)
        visible = self._normalize_bbox(visible_bbox or bbox)
        tier = self._scene_tier_for_bbox(visible)
        budget = self._scene_budget(tier)
        provider_stride = self._estimate_provider_stride_for_bbox(fetch_bbox, budget.get("provider_target_cells"))
        scene = {
            "schema": "lftr_scene_plan_v1",
            "layer": str(layer or "frame"),
            "tier": budget["tier"],
            "visible_bbox": visible,
            "fetch_bbox": fetch_bbox,
            "bbox_policy": "visible_bbox_draws__fetch_bbox_padded_for_tilt_cache_ncss",
            "provider_stride": provider_stride,
            "target_cells": budget["target_cells"],
            "provider_target_cells": budget["provider_target_cells"],
            "solve_dx_deg": budget["solve_dx_deg"],
            "render_dx_deg": budget["render_dx_deg"],
            "render_budget": {
                "max_cloud_shells": budget["max_cloud_shells"],
                "max_cloud_particles": budget["max_cloud_particles"],
                "max_boats": budget["max_boats"],
                "max_bait_polygons": budget["max_bait_polygons"],
            },
            "compat": {"legacy_lod_quality_stride_supported": True, "stride_is_budget_derived": True},
        }
        return scene

    def _attach_scene_plan(self, payload: dict[str, Any], scene: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(payload, dict):
            return payload
        payload["scene_plan"] = scene
        payload.setdefault("scene_tier", scene.get("tier"))
        payload.setdefault("visible_bbox", scene.get("visible_bbox"))
        payload.setdefault("fetch_bbox", scene.get("fetch_bbox"))
        payload.setdefault("render_budget", scene.get("render_budget"))
        return payload

    def tile_plan_payload(self, bbox: dict[str, float] | None = None, max_tiles: int = 512) -> dict[str, Any]:
        requested = self._normalize_bbox(bbox)
        center_lat, center_lon = self._bbox_center(requested)
        cols, rows = self._base_tile_grid()
        center_id = self._tile_id_for_point(center_lat, center_lon, cols, rows)
        _, center_row, center_col = self._parse_tile_id(center_id)
        tiles: list[dict[str, Any]] = []
        for row in range(rows):
            for col in range(cols):
                tid = f"z0_r{row}_c{col}"
                tb = self._tile_bounds_by_id(tid)
                tc_lat = (tb["south"] + tb["north"]) / 2.0
                tc_lon = (tb["west"] + tb["east"]) / 2.0
                ring = max(abs(row - center_row), abs(col - center_col))
                intersects = self._bbox_intersects(tb, requested)
                dist = math.hypot(tc_lat - center_lat, (tc_lon - center_lon) * math.cos(math.radians(center_lat)))
                priority = 0 if tid == center_id else (1 if intersects else 2 + ring)
                tiles.append({
                    "tile_id": tid,
                    "z": 0,
                    "row": row,
                    "col": col,
                    "bbox": tb,
                    "center": {"lat": round(tc_lat, 6), "lon": round(tc_lon, 6)},
                    "priority": int(priority),
                    "ring": int(ring),
                    "distance_deg": round(dist, 4),
                    "intersects_viewport": bool(intersects),
                })
        tiles.sort(key=lambda t: (t["priority"], t["ring"], t["distance_deg"]))
        max_tiles = max(1, min(int(max_tiles or 512), len(tiles)))
        return {
            "ok": True,
            "schema": "lftr_globe_tile_plan_v1",
            "strategy": "center_first_then_visible_then_rings",
            "grid": {"cols": cols, "rows": rows, "count": cols * rows, "tile_degrees": {"lon": 360 / cols, "lat": 180 / rows}},
            "requested_bbox": requested,
            "viewport_bbox": requested,
            "work_bbox": self._bounded_work_bbox(requested),
            "cache_bbox": self._bounded_work_bbox(requested),
            "bounds_policy": {"mode": "padded_viewport", "factor": float(os.getenv("GFS_VIEWPORT_PAD_FACTOR", "1.25") or "1.25")},
            "center": {"lat": round(center_lat, 6), "lon": round(center_lon, 6), "tile_id": center_id},
            "tiles": tiles[:max_tiles],
            "total_tiles": len(tiles),
            "returned_tiles": max_tiles,
            "ts": self._now_ms(),
        }

    def _tile_cache_path(self, tile_id: str, product: str = "intel") -> Path:
        safe = re.sub(r"[^a-zA-Z0-9_.-]+", "_", str(tile_id or "tile"))
        return self._tile_cache_root() / f"{safe}.{product}.json"

    def _read_tile_disk_cache(self, tile_id: str, product: str = "intel", ttl_seconds: int = 300) -> dict[str, Any] | None:
        path = self._tile_cache_path(tile_id, product)
        try:
            if not path.exists() or (time.time() - path.stat().st_mtime) > ttl_seconds:
                return None
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return None

    def _write_tile_disk_cache(self, tile_id: str, payload: dict[str, Any], product: str = "intel") -> dict[str, Any]:
        path = self._tile_cache_path(tile_id, product)
        tmp = path.with_suffix(path.suffix + ".tmp")
        try:
            tmp.write_text(json.dumps(payload, separators=(",", ":"), ensure_ascii=False), encoding="utf-8")
            tmp.replace(path)
        except Exception as exc:
            log.debug("tile cache write skipped tile=%s err=%s", tile_id, exc)
        return payload

    def _json_safe_for_tile_cache(self, obj: Any) -> Any:
        """Make rich layer payloads safe for gzip JSON tile cache without dropping contracts."""
        if obj is None or isinstance(obj, (str, int, float, bool)):
            return obj
        if isinstance(obj, Path):
            return str(obj)
        if np is not None:
            try:
                if isinstance(obj, np.generic):
                    return obj.item()
                if isinstance(obj, np.ndarray):
                    # Tile caches must stay app-native and browser-loadable; never persist raw global arrays.
                    if obj.size > 4096:
                        return {"array_omitted": True, "shape": list(obj.shape), "dtype": str(obj.dtype)}
                    return obj.tolist()
            except Exception:
                pass
        if isinstance(obj, dict):
            out = {}
            for k, v in obj.items():
                if str(k).startswith("_"):
                    continue
                out[str(k)] = self._json_safe_for_tile_cache(v)
            return out
        if isinstance(obj, (list, tuple)):
            return [self._json_safe_for_tile_cache(v) for v in obj]
        try:
            return json.loads(json.dumps(obj, default=str))
        except Exception:
            return str(obj)

    def _scene_tile_cache_path(self, tile_id: str, product: str = "scene") -> Path:
        safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(tile_id or "tile"))[:96]
        prod = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(product or "scene"))[:48]
        return self.scene_tile_cache_dir / f"{prod}_{safe}.json.gz"

    def _read_scene_tile_cache(self, tile_id: str, product: str = "scene", ttl_seconds: int = 300) -> dict[str, Any] | None:
        path = self._scene_tile_cache_path(tile_id, product)
        if not path.exists():
            return None
        try:
            age = time.time() - path.stat().st_mtime
            if ttl_seconds >= 0 and age > ttl_seconds:
                return None
            import gzip
            with gzip.open(path, "rt", encoding="utf-8") as fh:
                payload = json.load(fh)
            if isinstance(payload, dict):
                payload.setdefault("cache", {})
                payload["cache"].update({"hit": True, "age_seconds": round(age, 3), "path": str(path), "product": product})
                return payload
        except Exception as exc:
            log.debug("scene tile gzip cache read skipped tile=%s err=%s", tile_id, exc)
        return None

    def _write_scene_tile_cache(self, tile_id: str, payload: dict[str, Any], product: str = "scene") -> dict[str, Any]:
        path = self._scene_tile_cache_path(tile_id, product)
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        tmp = path.with_name(path.name + ".tmp")
        try:
            import gzip
            safe_payload = self._json_safe_for_tile_cache(payload)
            with gzip.open(tmp, "wt", encoding="utf-8", compresslevel=5) as fh:
                json.dump(safe_payload, fh, separators=(",", ":"), ensure_ascii=False)
            os.replace(tmp, path)
        except Exception as exc:
            log.debug("scene tile gzip cache write skipped tile=%s err=%s", tile_id, exc)
        return payload

    def _source_quality_summary(self, payload: Any) -> dict[str, Any]:
        if not isinstance(payload, dict):
            return {"available": False}
        source = str(payload.get("source") or payload.get("provider_source") or payload.get("live_source") or "")
        state = str(payload.get("payload_state") or payload.get("status") or payload.get("source_state") or "")
        txt = f"{source} {state} {payload.get('mode','')}".lower()
        return {
            "available": bool(payload),
            "source": source or None,
            "payload_state": state or None,
            "live_ncss_or_erddap": any(x in txt for x in ("ncss", "erddap", "gfs_nomads", "hycom", "coastwatch")),
            "mock": "mock" in txt or "synthetic" in txt,
            "proxy": "proxy" in txt or "fallback" in txt,
            "fallback_used": bool(payload.get("fallback_used") or ((payload.get("fallback") or {}).get("used") if isinstance(payload.get("fallback"), dict) else False)),
        }

    def _clip_markers_to_bbox(self, bbox: dict[str, float], limit: int = 260) -> list[dict[str, Any]]:
        try:
            points, _ = self.load_fish()
        except Exception:
            return []
        out = []
        for p in points or []:
            lat = safe_float(p.get("lat"), 9999)
            lon = safe_float(p.get("lon"), 9999)
            if bbox["south"] <= lat <= bbox["north"] and bbox["west"] <= lon <= bbox["east"]:
                out.append(p)
                if len(out) >= limit:
                    break
        return out

    def _inland_water_payload_for_bbox(self, bbox: dict[str, float] | None = None, *, source: str = "auto", geometry: str = "vector", lod: str = "auto", scene_tier: str | None = None, max_tiles: int = 12) -> dict[str, Any]:
        """Small local NHD/NHDPlus HR-style inland-water payload for a bbox/tile.

        This intentionally stays fast and local: it reads installed high-definition
        NHDPlus/3DHP/OSM-grade GeoJSON or json.gz tiles, then returns accepted
        polygons and flowlines. Coarse seed geometry is rejected.
        """
        if build_inland_water_payload is None:
            b = self._normalize_bbox(bbox)
            return {
                "ok": True,
                "status": "warming",
                "source": "inland_water_module_unavailable",
                "bbox": [b["west"], b["south"], b["east"], b["north"]],
                "polygons": [],
                "lines": [],
                "temperature_points": [],
                "count": 0,
                "payload_state": "module_unavailable",
            }
        return build_inland_water_payload(self.static_dir, self._normalize_bbox(bbox), source=source, geometry=geometry, lod=lod, scene_tier=scene_tier, max_tiles=max_tiles)

    def _empty_inland_water_shell(self, bbox: dict[str, float], reason: str = "cache_miss") -> dict[str, Any]:
        return {
            "ok": True,
            "status": "warming",
            "source": "inland_water_scene_tile_cache_warming",
            "payload_state": "warming",
            "bbox": [bbox["west"], bbox["south"], bbox["east"], bbox["north"]],
            "polygons": [],
            "lines": [],
            "temperature_points": [],
            "temperature_point_count": 0,
            "count": 0,
            "cache": {"hit": False, "product": "scene", "reason": reason},
            "contract": "lftr_inland_water_v1_tile_cache_shell",
        }

    def _merge_inland_water_payloads(self, payloads: list[dict[str, Any]], bbox: dict[str, float] | None = None) -> dict[str, Any]:
        norm = self._normalize_bbox(bbox)
        polys: list[dict[str, Any]] = []
        lines: list[dict[str, Any]] = []
        temps: list[dict[str, Any]] = []
        seen_poly: set[str] = set()
        seen_line: set[str] = set()
        seen_temp: set[str] = set()

        def _is_high_def_inland_item(item: dict[str, Any], *, is_line: bool = False) -> bool:
            path = item.get("path") or []
            min_points = 40 if is_line else 80
            if not isinstance(path, list) or len(path) < min_points:
                return False
            src = " ".join(str(item.get(k, "")) for k in ("source", "source_class", "source_path", "shoreline_truth", "geometry_quality")).lower()
            if any(bad in src for bad in ("bootstrap", "seed", "demo", "coarse", "approx")):
                return False
            return any(ok in src for ok in ("nhdplus", "3dhp", "nhdwaterbody", "nhdarea", "nhdflowline", "osm", "hydrolakes", "waterbody"))

        def _path_key(item: dict[str, Any], kind: str) -> str:
            path = item.get("path") or []
            first = path[0] if isinstance(path, list) and path else {}
            return f"{kind}:{item.get('name','')}:{item.get('fcode','')}:{first.get('lat')},{first.get('lng', first.get('lon'))}:{len(path)}"

        for payload in payloads:
            if not isinstance(payload, dict):
                continue
            for item in payload.get("polygons") or []:
                if not isinstance(item, dict) or not _is_high_def_inland_item(item, is_line=False):
                    continue
                k = _path_key(item, "poly")
                if k in seen_poly:
                    continue
                seen_poly.add(k)
                polys.append(item)
            for item in payload.get("lines") or []:
                if not isinstance(item, dict) or not _is_high_def_inland_item(item, is_line=True):
                    continue
                k = _path_key(item, "line")
                if k in seen_line:
                    continue
                seen_line.add(k)
                lines.append(item)
            for item in payload.get("temperature_points") or []:
                if not isinstance(item, dict):
                    continue
                lat = safe_float(item.get("lat"), 9999)
                lon = safe_float(item.get("lng", item.get("lon")), 9999)
                temp = safe_float(item.get("water_temp_f", item.get("water_temp_est_f", item.get("surface_temp_f"))), -9999)
                k = f"{lat:.4f}:{lon:.4f}:{round(temp)}"
                if k in seen_temp:
                    continue
                seen_temp.add(k)
                temps.append(item)
        return {
            "ok": True,
            "status": "ok" if (polys or lines) else "no_high_def_source",
            "source": "scene_tile_cache_inland_water_aggregate_high_def_only" if (polys or lines) else "no_high_def_nhdplus_hr_source_installed",
            "bbox": [norm["west"], norm["south"], norm["east"], norm["north"]],
            "polygons": polys,
            "lines": lines,
            "temperature_points": temps,
            "temperature_point_count": len(temps),
            "count": len(polys) + len(lines),
            "cache": {"hit": bool(payloads), "mode": "scene_tile_cache_aggregate", "tiles_with_inland_water": len(payloads)},
            "tile_cache_contract": "read /gfs/api/tiles scene cache first; /gfs/api/cache-warm writes inlandWater per tile in parallel",
            "contract": "lftr_inland_water_v1_tiled_cache_aggregate",
        }

    def inland_water_tiles_payload(self, bbox: dict[str, float] | None = None, max_tiles: int = 96, visible_bbox: dict[str, float] | None = None, *, source: str = "auto", geometry: str = "vector", lod: str = "auto", scene_tier: str | None = None) -> dict[str, Any]:
        """Read local NHDPlus HR shoreline tile squares for the active viewport.

        Inland Waters is now independent from the generic scene-tile cache. The
        visible bbox selects installed NHDPlus HR json.gz tile squares; the route
        returns the union/full contents of those selected tiles. Missing manifests
        return immediately instead of waiting on cache-warm or GFS providers.
        """
        norm = self._normalize_bbox(bbox)
        try:
            limit = max(1, min(int(max_tiles or 12), 128))
        except Exception:
            limit = 12
        direct = self._inland_water_payload_for_bbox(norm, source=source, geometry=geometry, lod=lod, scene_tier=scene_tier, max_tiles=limit)
        if isinstance(direct, dict):
            direct.setdefault("plan", {})
            direct["plan"].update({"requested_tile_squares": limit, "selection_bbox": [norm["west"], norm["south"], norm["east"], norm["north"]], "visible_bbox": visible_bbox})
            direct["cache"] = {**(direct.get("cache") if isinstance(direct.get("cache"), dict) else {}), "mode": "local_nhdplus_full_tile_square_read", "selected_tiles": len(direct.get("selected_tiles") or [])}
            direct["tile_cache_contract"] = "visible bbox -> full NHDPlus HR tile squares -> display full selected tiles; no scene-cache/stale coarse merge"
        return direct


    def _bbox_has_probable_ocean_overlap(self, bbox: dict[str, float]) -> bool:
        b = self._normalize_bbox(bbox)
        west, east, south, north = b["west"], b["east"], b["south"], b["north"]
        # Coarse guardrail: skip HYCOM/boats for obvious inland southwest/desert/continental tiles.
        if east < -66 and west > -125 and south > 24 and north < 50:
            return False
        return True

    def _build_scene_tile_point_product(self, tile_id: str, bbox: dict[str, float], visible_bbox: dict[str, float] | None = None, allowed_layers: set[str] | None = None) -> dict[str, Any]:
        """Build the app-native per-tile point/cache product.

        This is the speed layer: NCSS/ERDDAP remain the source of truth, but the site
        can load this gzip JSON first. The product deliberately keeps the diverse
        payload contracts used by graphics layers: clouds, rain/precip columns,
        oceanPoints, baitAdvanced, boats, and fish markers.
        """
        started = time.time()
        bbox_norm = self._normalize_bbox(bbox)
        visible = self._normalize_bbox(visible_bbox or bbox_norm)
        scene = self.build_scene_plan(bbox_norm, visible, layer="scene-tile-cache")
        contracts: dict[str, Any] = {}
        errors: dict[str, str] = {}

        def _try(name: str, fn, *args):
            try:
                contracts[name] = fn(*args)
            except Exception as exc:
                level = log.info if isinstance(exc, FileNotFoundError) else log.warning
                level("[gfs tile cache] contract build failed tile=%s name=%s err=%s", tile_id, name, exc)
                contracts[name] = {"ok": False, "payload_state": "provider_failed", "source": f"{name}_unavailable", "error": str(exc), "bbox": bbox_norm}
                errors[name] = str(exc)

        requested_layers = {str(x).strip().lower() for x in (allowed_layers or set()) if str(x).strip()}
        all_layers = not requested_layers
        wants_clouds = all_layers or bool(requested_layers & {"clouds", "rain"})
        wants_ocean_points = all_layers or bool(requested_layers & {"currents", "current", "boats", "boater", "bait", "ocean", "oceanpoints"})
        wants_boats = all_layers or bool(requested_layers & {"boats", "boater"})
        wants_ocean_bait = all_layers or bool(requested_layers & {"bait", "ocean-bait", "baitadvanced"})
        wants_lightning = all_layers or "lightning" in requested_layers
        wants_inland = all_layers or bool(requested_layers & {"inland-water", "inlandwater", "inland"})

        if wants_clouds:
            _try("clouds", self._cloud_tiles_payload_heavy, bbox_norm, visible)
        else:
            contracts["clouds"] = {"ok": True, "payload_state": "not_requested", "source": "route_layer_policy", "items": [], "tiles": [], "cloud_regions": [], "precip_columns": [], "bbox": bbox_norm}

        if self._bbox_has_probable_ocean_overlap(bbox_norm) and (wants_ocean_points or wants_boats or wants_ocean_bait):
            if wants_ocean_points:
                _try("oceanPoints", self._ocean_points_payload_heavy, bbox_norm, "auto", visible)
            else:
                contracts["oceanPoints"] = {"ok": True, "payload_state": "not_requested", "source": "route_layer_policy", "points": [], "bbox": bbox_norm}
            if wants_boats:
                _try("boats", self._ocean_payload_heavy, bbox_norm, visible)
            else:
                contracts["boats"] = {"ok": True, "payload_state": "not_requested", "source": "route_layer_policy", "boats": [], "items": [], "bbox": bbox_norm}
            if wants_ocean_bait:
                _try("baitAdvanced", self._bait_advanced_payload_heavy, bbox_norm, visible)
            else:
                contracts["baitAdvanced"] = {"ok": True, "payload_state": "not_requested", "source": "route_layer_policy", "bait": {"polygons": [], "bait_score": []}, "bbox": bbox_norm}
        else:
            skip_reason = "no_ocean_overlap" if not self._bbox_has_probable_ocean_overlap(bbox_norm) else "not_requested"
            contracts["oceanPoints"] = {"ok": True, "payload_state": skip_reason, "source": f"hycom_skipped_{skip_reason}", "points": [], "bbox": bbox_norm}
            contracts["boats"] = {"ok": True, "payload_state": skip_reason, "source": f"boats_skipped_{skip_reason}", "boats": [], "items": [], "bbox": bbox_norm}
            contracts["baitAdvanced"] = {"ok": True, "payload_state": skip_reason, "source": f"ocean_bait_skipped_{skip_reason}", "bait": {"polygons": [], "bait_score": []}, "bbox": bbox_norm}
        if wants_lightning:
            _try("lightning", self.lightning_payload, bbox_norm, visible, 20)
        else:
            contracts["lightning"] = {"ok": True, "payload_state": "not_requested", "source": "route_layer_policy", "flashes": [], "regions": [], "bbox": bbox_norm}
        if wants_inland:
            _try("inlandWater", self._inland_water_payload_for_bbox, bbox_norm)
        else:
            contracts["inlandWater"] = self._empty_inland_water_shell(bbox_norm, "not_requested")
        markers = self._clip_markers_to_bbox(visible, limit=260)
        contracts["markers"] = markers

        clouds = contracts.get("clouds") if isinstance(contracts.get("clouds"), dict) else {}
        ocean_points = contracts.get("oceanPoints") if isinstance(contracts.get("oceanPoints"), dict) else {}
        bait = contracts.get("baitAdvanced") if isinstance(contracts.get("baitAdvanced"), dict) else {}
        boats = contracts.get("boats") if isinstance(contracts.get("boats"), dict) else {}
        lightning = contracts.get("lightning") if isinstance(contracts.get("lightning"), dict) else {}
        inland_water = contracts.get("inlandWater") if isinstance(contracts.get("inlandWater"), dict) else {}
        boat_items = boats.get("boats") or boats.get("items") or []
        bait_obj = bait.get("bait") if isinstance(bait.get("bait"), dict) else bait
        bait_polys = []
        if isinstance(bait_obj, dict):
            bait_polys = (bait_obj.get("polygons") or []) + (bait_obj.get("outer_polygons") or []) + (bait_obj.get("inner_polygons") or []) + (bait_obj.get("core_polygons") or [])

        quality = {name: self._source_quality_summary(val) for name, val in contracts.items() if isinstance(val, dict)}
        payload = {
            "ok": True,
            "schema": "lftr_scene_tile_point_cache_v1",
            "tile_id": tile_id,
            "bbox": bbox_norm,
            "visible_bbox": visible,
            "scene_plan": scene,
            "source": "app_native_scene_tile_cache",
            "cache_policy": "gzip_json_cache_first_large_diverse_contracts_live_refresh_second",
            "quality_policy": "live_ncss_erddap_or_explicit_empty_no_silent_mock_proxy",
            "contracts": contracts,
            # Compatibility mirrors for older frontend/debug tools.
            "clouds": clouds,
            "oceanPoints": ocean_points,
            "boats": boats,
            "baitAdvanced": bait,
            "lightning": lightning,
            "inlandWater": inland_water,
            "markers": markers,
            "quality": quality,
            "errors": errors,
            "summary": {
                "cloud_items": len(clouds.get("items") or clouds.get("tiles") or []),
                "cloud_regions": len(clouds.get("cloud_regions") or []),
                "precip_columns": len(clouds.get("precip_columns") or []),
                "ocean_points": len(ocean_points.get("points") or ocean_points.get("items") or []),
                "boat_count": len(boat_items),
                "bait_polygon_count": len(bait_polys),
                "inland_water_polygons": len(inland_water.get("polygons") or []),
                "inland_water_lines": len(inland_water.get("lines") or []),
                "inland_water_temp_points": len(inland_water.get("temperature_points") or []),
                "marker_count": len(markers),
            },
            "latency_ms": int((time.time() - started) * 1000),
            "updated_at": self._now_ms(),
        }
        return payload

    def _compact_tile_intel(self, tile_id: str, bbox: dict[str, float]) -> dict[str, Any]:
        # Compatibility wrapper: now returns the rich app-native scene tile product.
        return self._build_scene_tile_point_product(tile_id, bbox, bbox)

    def _scene_tile_cache_placeholder(self, tile_id: str, bbox: dict[str, float], ttl_seconds: int = 300, reason: str = "cache_miss") -> dict[str, Any]:
        """Return a small JSON-safe tile shell without building live NCSS contracts.

        /gfs/api/tiles must be a fast cache read endpoint.  Missing tiles should not
        synchronously fetch/decode GFS/HYCOM/ERDDAP or the browser can hit nginx/
        worker timeouts.  The live build is handled by /gfs/api/cache-warm.
        """
        return {
            "ok": True,
            "schema": "lftr_scene_tile_point_cache_v1_placeholder",
            "tile_id": tile_id,
            "bbox": bbox,
            "source": "scene_tile_cache_placeholder",
            "payload_state": "cache_miss",
            "mode": "cache_first_no_direct_provider_block",
            "cache": {"hit": False, "ttl_seconds": ttl_seconds, "product": "scene", "reason": reason},
            "contracts": {
                "clouds": {"ok": True, "source": "deferred_tile_cache", "payload_state": "warming", "items": [], "tiles": [], "cloud_regions": [], "precip_columns": []},
                "oceanPoints": {"ok": True, "source": "hycom_ocean_points_cache_warming", "payload_state": "warming", "points": []},
                "boats": {"ok": True, "source": "deferred_tile_cache", "payload_state": "warming", "boats": [], "items": []},
                "baitAdvanced": {"ok": True, "source": "cache_first", "mode": "cache_first_bait_warming", "payload_state": "warming", "bait": {"polygons": [], "bait_score": []}},
                "inlandWater": self._empty_inland_water_shell(bbox, reason),
                "markers": [],
            },
            "clouds": {"ok": True, "source": "deferred_tile_cache", "payload_state": "warming", "items": [], "tiles": [], "cloud_regions": [], "precip_columns": []},
            "oceanPoints": {"ok": True, "source": "hycom_ocean_points_cache_warming", "payload_state": "warming", "points": []},
            "boats": {"ok": True, "source": "deferred_tile_cache", "payload_state": "warming", "boats": [], "items": []},
            "baitAdvanced": {"ok": True, "source": "cache_first", "mode": "cache_first_bait_warming", "payload_state": "warming", "bait": {"polygons": [], "bait_score": []}},
            "inlandWater": self._empty_inland_water_shell(bbox, reason),
            "markers": [],
            "summary": {"cloud_items": 0, "cloud_regions": 0, "precip_columns": 0, "ocean_points": 0, "boat_count": 0, "bait_polygon_count": 0, "inland_water_polygons": 0, "inland_water_lines": 0, "inland_water_temp_points": 0, "marker_count": 0},
            "updated_at": self._now_ms(),
        }

    def tile_intel_payload(self, tile_id: str, ttl_seconds: int = 300, visible_bbox: dict[str, float] | None = None, allow_build: bool = True, allowed_layers: set[str] | None = None) -> dict[str, Any]:
        cached = self._read_scene_tile_cache(tile_id, "scene", ttl_seconds=ttl_seconds)
        if cached:
            return cached
        bbox = self._tile_bounds_by_id(tile_id)
        if not allow_build:
            return self._scene_tile_cache_placeholder(tile_id, bbox, ttl_seconds=ttl_seconds, reason="cache_miss_read_only")
        payload = self._build_scene_tile_point_product(tile_id, bbox, visible_bbox or bbox, allowed_layers=allowed_layers)
        payload["cache"] = {"hit": False, "ttl_seconds": ttl_seconds, "product": "scene"}
        return self._write_scene_tile_cache(tile_id, payload, "scene")

    def tiles_intel_payload(self, bbox: dict[str, float] | None = None, max_tiles: int = 512, visible_bbox: dict[str, float] | None = None) -> dict[str, Any]:
        """Return app-native scene-tile products cache-first for the current viewport.

        This keeps rich graphics contracts in the cache while still letting live NCSS/
        ERDDAP refresh happen behind the scenes via /cache-warm.
        """
        try:
            limit = max(1, min(int(max_tiles or 512), 512))
        except Exception:
            limit = 512
        plan = self.tile_plan_payload(bbox, max_tiles=limit)
        selected = list(plan.get("tiles") or [])[:limit]
        tiles: list[dict[str, Any]] = []
        workers = max(1, min(int(os.getenv("GFS_TILE_READ_WORKERS", "6") or "16"), 24))

        def _read_one(item: dict[str, Any]) -> dict[str, Any]:
            try:
                # Read-only: never build live NCSS/ERDDAP contracts in the browser
                # tile request.  Missing tiles return a tiny warming shell while
                # /cache-warm refreshes the gzip scene tile cache in the background.
                return self.tile_intel_payload(str(item.get("tile_id")), ttl_seconds=600, visible_bbox=visible_bbox, allow_build=False)
            except Exception as exc:
                return {"ok": False, "tile_id": item.get("tile_id"), "bbox": item.get("bbox"), "error": str(exc), "payload_state": "read_failed"}

        with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="gfs-tile-read") as pool:
            futures = [pool.submit(_read_one, item) for item in selected]
            for fut in as_completed(futures):
                tiles.append(fut.result())
        tiles_by_id = {str(t.get("tile_id")): t for t in tiles if isinstance(t, dict)}
        ordered = [tiles_by_id.get(str(item.get("tile_id"))) for item in selected]
        ordered = [t for t in ordered if isinstance(t, dict)]
        return {
            "ok": True,
            "schema": "lftr_scene_tiles_point_cache_v1_cache_first_512",
            "cache_policy": "read_gzip_scene_tile_cache_only_no_direct_provider_block__live_refresh_via_cache_warm",
            "product_contract": "large_diverse_payload_contracts_preserved_per_tile",
            "plan": plan,
            "tiles": ordered,
            "count": len(ordered),
            "tile_read_workers": workers,
            "cache_hits": sum(1 for t in ordered if bool(((t.get("cache") or {}).get("hit")))),
            "cache_misses": sum(1 for t in ordered if str(t.get("payload_state") or "") == "cache_miss"),
            "ts": self._now_ms(),
        }

    def location_live_intel_payload(self, location_key: str) -> dict[str, Any]:
        """Small auto-refresh payload for the selected glass pane."""
        loc = self._find_fish_point(location_key)
        if not loc:
            return {"ok": False, "error": "location not found", "location_id": location_key, "ts": self._now_ms()}
        lat = safe_float(loc.get("lat"), 0.0)
        lon = safe_float(loc.get("lon"), 0.0)
        tile_id = self._tile_id_for_point(lat, lon)
        box = {"west": lon - 1.8, "south": lat - 1.8, "east": lon + 1.8, "north": lat + 1.8}
        tile = self.tile_intel_payload(tile_id, ttl_seconds=240)
        env = self.location_environment_payload(location_key)
        node = self.node_intelligence_payload(location_key)
        return {
            "ok": True,
            "schema": "lftr_selected_location_live_intel_v1",
            "location": loc,
            "tile_id": tile_id,
            "bbox": box,
            "tile_summary": tile.get("summary") or {},
            "environment": env,
            "node": node,
            "source_status": {
                "tile_cache_hit": bool((tile.get("cache") or {}).get("hit")),
                "tile_updated_at": tile.get("updated_at"),
                "environment_source": (env.get("marker_environment") or {}).get("source_tier") if isinstance(env, dict) else None,
                "auto_refresh": True,
            },
            "updated_at": self._now_ms(),
        }

    def config_payload(self) -> Dict[str, Any]:
        return self.config()

    def status_payload(self) -> Dict[str, Any]:
        return self.health()

    def diagnostics_payload(self) -> Dict[str, Any]:
        return self.tile_diagnostics_payload()

    def hazards_payload(self) -> Dict[str, Any]:
        scene_payload = self.get_scene_payload()
        scene = scene_payload.get("scene") if isinstance(scene_payload.get("scene"), dict) else {}
        return {
            "ok": True,
            "source": scene_payload.get("source", "unknown"),
            "payload_state": scene_payload.get("payload_state", "unknown"),
            "rain": scene_payload.get("precip_columns") or scene.get("precip") or [],
            "hail": scene_payload.get("hail_events") or scene.get("hail") or [],
            "lightning": scene_payload.get("lightning_events") or scene.get("lightning") or [],
            "ts": self._now_ms(),
        }

    def tile_layer_payload(self, layer: str, z: int, x: int, y: int, pad_deg: float = 0.18, debug: bool = False) -> Dict[str, Any]:
        return self.layer_tile_payload(layer=layer, z=z, x=x, y=y, pad_deg=pad_deg, debug=debug)

    def tile_aggregate_payload(self, z: int, x: int, y: int, debug: bool = False) -> Dict[str, Any]:
        layer_map = {
            "clouds": "clouds",
            "rain": "precip",
            "hail": "hail",
            "lightning": "lightning",
        }
        out: Dict[str, Any] = {
            "z": int(z),
            "x": int(x),
            "y": int(y),
            "clouds": [],
            "rain": [],
            "hail": [],
            "lightning": [],
            "status": {"ok": True},
            "meta": {"generated_at": self._now_ms()},
        }
        errors = []
        for public_name, service_layer in layer_map.items():
            try:
                payload = self.layer_tile_payload(layer=service_layer, z=z, x=x, y=y, debug=debug)
                out[public_name] = payload.get("features") if isinstance(payload, dict) else []
            except Exception as exc:  # noqa: BLE001
                errors.append(f"{public_name}:{exc}")
                out[public_name] = []
        if errors:
            out["status"] = {"ok": False, "errors": errors}
        return out

    def _extract_csv_reports(self, row: Dict[str, Any]) -> List[str]:
        """Return non-empty report_ columns in natural numeric order."""
        def sort_key(item: tuple[str, Any]) -> tuple[int, str]:
            key, _ = item
            m = re.search(r"report_(\d+)$", str(key or ""), re.I)
            return (int(m.group(1)) if m else 9999, str(key or ""))

        reports: List[str] = []
        for key, value in sorted(row.items(), key=sort_key):
            if not str(key or "").lower().startswith("report_"):
                continue
            text = str(value or "").strip()
            if text:
                reports.append(text)
        return reports

    def _find_fish_point(self, identifier: str) -> Dict[str, Any] | None:
        """Resolve a marker by canonical id, location_key, CSV id, or slug."""
        raw = str(identifier or "").strip()
        if not raw:
            return None
        norm = self._normalize_location_key(raw)
        points = list(self.state.fish_points or [])
        if not points:
            points, _ = self.load_fish()
        for point in points:
            candidates = {
                str(point.get("id") or ""),
                str(point.get("location_key") or ""),
                str(point.get("csv_id") or ""),
                self._normalize_location_key(str(point.get("name") or "")),
            }
            if raw in candidates or norm in {self._normalize_location_key(c) for c in candidates if c}:
                return point
        return None

    def load_fish(self) -> Tuple[List[Dict[str, Any]], str | None]:
        csv_path = self._fish_csv_path()
        if not csv_path.exists():
            candidates = ", ".join(str(p) for p in self._fish_csv_candidates())
            self.state.last_error = f"missing fish CSV: {csv_path}; searched: {candidates}"
            return [], self.state.last_error

        points: List[Dict[str, Any]] = []
        try:
            with csv_path.open("r", encoding="utf-8-sig", newline="") as f:
                reader = csv.DictReader(f)
                for i, row in enumerate(reader):
                    if not row:
                        continue

                    lat_raw = row.get("lat") or row.get("latitude") or row.get("Lat") or row.get("Latitude")
                    lon_raw = row.get("lon") or row.get("lng") or row.get("longitude") or row.get("Lon") or row.get("Longitude")
                    if lat_raw is None or lon_raw is None:
                        continue

                    try:
                        lat = float(str(lat_raw).strip())
                        lon = float(str(lon_raw).strip())
                    except Exception:
                        continue
                    if lat < -90 or lat > 90 or lon < -180 or lon > 180:
                        continue

                    name = (row.get("name") or row.get("location") or row.get("label") or f"Location {i + 1}").strip()
                    raw_key = (row.get("location_key") or row.get("id") or row.get("locationId") or name or str(i + 1)).strip()
                    location_key = self._normalize_location_key(raw_key) or f"loc-{i + 1}"
                    csv_id = (row.get("id") or row.get("locationId") or str(i + 1)).strip()
                    reports = self._extract_csv_reports(row)
                    latest_report = reports[-1] if reports else ""
                    excluded = {
                        "lat", "latitude", "Lat", "Latitude",
                        "lon", "lng", "longitude", "Lon", "Longitude",
                        "name", "location", "label", "id", "locationId", "location_key",
                    }
                    point = {
                        # Canonical marker/API identifier.  The frontend calls
                        # /gfs/api/intelligence/node/<id> with this value.
                        "id": location_key,
                        "location_id": location_key,
                        "location_key": location_key,
                        "csv_id": csv_id,
                        "name": name,
                        "lat": lat,
                        "lon": lon,
                        "reports": reports,
                        "all_reports": reports,
                        "last_report": latest_report,
                        "report_count": len(reports),
                        "meta": {
                            k: v
                            for k, v in row.items()
                            if k and k not in excluded and not str(k).lower().startswith("report_")
                        },
                    }
                    point.update(self._build_bait_intel(point, self._now_ms()))
                    points.append(point)

            self.state.fish_points = points
            self.state.last_refresh_ts = self._now_ms()
            self.state.last_error = None
            return points, None
        except Exception as exc:  # noqa: BLE001
            self.state.last_error = f"failed to parse fish CSV: {exc}"
            return [], self.state.last_error

    def fish_payload(self) -> Dict[str, Any]:
        points, err = self.load_fish()
        return {"ok": err is None, "error": err, "count": len(points), "items": points, "ts": self._now_ms()}

    def _point_in_request_bbox(self, point: Dict[str, Any], bbox: dict[str, float]) -> bool:
        try:
            lat = float(point.get("lat"))
            lon = float(point.get("lon"))
            return float(bbox.get("south", -90)) <= lat <= float(bbox.get("north", 90)) and float(bbox.get("west", -180)) <= lon <= float(bbox.get("east", 180))
        except Exception:
            return False

    def _regional_marker_frame_payload(self, bbox: dict[str, float], points: list[Dict[str, Any]], now_ms: int) -> Dict[str, Any]:
        selected = [p for p in points if self._point_in_request_bbox(p, bbox)] or points[:43]
        boats = []
        bait_score = []
        for pnt in selected[:80]:
            try:
                lat = float(pnt.get("lat")); lon = float(pnt.get("lon"))
            except Exception:
                continue
            intel = pnt if pnt.get("marker_environment") else {**pnt, **self._build_bait_intel(pnt, now_ms)}
            marker_env = intel.get("marker_environment") or {}
            ocean = marker_env.get("ocean") or {}
            boat = ocean.get("boat") or marker_env.get("boating")
            if isinstance(boat, dict):
                boats.append(boat)
            bait = intel.get("bait") or {}
            try:
                profile = build_location_profile(pnt, [])
            except Exception:
                profile = {}
            habitat_key = str(profile.get("habitat_key") or "").lower()
            ocean_like = habitat_key not in {"freshwater", "inland", "lake", "river"}
            bait_score.append({
                "lat": lat,
                "lon": lon,
                "probability": round(float(bait.get("presence_probability") or 0.35), 3),
                "preferred_depth_m": round(float((bait.get("school_depth_band_ft") or [25, 65])[0]) * 0.3048, 1),
                "depth_min_m": round(float((bait.get("school_depth_band_ft") or [25, 65])[0]) * 0.3048, 1),
                "depth_max_m": round(float((bait.get("school_depth_band_ft") or [25, 65])[-1]) * 0.3048, 1),
                "driver": "marker_history_ocean_proxy",
                "source": "fish_csv_marker_intelligence",
                "habitat_key": habitat_key or None,
                "waterbody": profile.get("waterbody"),
                "ocean_like": ocean_like,
                "water_mask_source": "marker_waterbody_profile_until_hycom_bait_grid",
            })
        avg_prob = sum(float(b.get("probability") or 0.0) for b in bait_score) / max(1, len(bait_score))
        return {
            "boats": {"ok": True, "boats": boats, "count": len(boats), "source": "marker_ocean_solve", "sparse_fallback": False},
            "baitAdvanced": {
                "ok": True,
                "schema": "bait_ocean_field_v1",
                "bait": {"status": "ok", "source": "marker_history_ocean_proxy", "meta": {"valid_cells": len(bait_score), "source": "fish_csv_marker_intelligence"}},
                "bait_score": bait_score,
                "front_lines": [],
                "convergence_polygons": [],
                "boil_probability_polygons": [],
                "confidence": {"overall": round(avg_prob, 3)},
                "valid_time": datetime.fromtimestamp(now_ms / 1000, tz=timezone.utc).isoformat(),
            },
        }


    def _split_cache_get(self, key: str, ttl_seconds: int) -> Any:
        if not hasattr(self, "_split_payload_cache"):
            self._split_payload_cache = {}
        row = self._split_payload_cache.get(key)
        if not row:
            return None
        if (time.time() - float(row.get("time", 0))) > ttl_seconds:
            return None
        return row.get("payload")

    def _split_cache_set(self, key: str, payload: Any) -> Any:
        if not hasattr(self, "_split_payload_cache"):
            self._split_payload_cache = {}
        self._split_payload_cache[key] = {"time": time.time(), "payload": payload}
        return payload

    def _bbox_cache_key(self, prefix: str, bbox: dict[str, float]) -> str:
        b = self._normalize_bbox(bbox)
        rounded = [round(float(b[k]), 2) for k in ("west", "south", "east", "north")]
        return f"{prefix}:{rounded[0]},{rounded[1]},{rounded[2]},{rounded[3]}"

    def _bbox_center(self, bbox: dict[str, float]) -> tuple[float, float]:
        b = self._normalize_bbox(bbox)
        return ((float(b["south"]) + float(b["north"])) / 2.0, (float(b["west"]) + float(b["east"])) / 2.0)

    def _source_row(self, role: str, provider: str, function: str, url: str | None, *, engine: str = "", ttl_seconds: int = 0, status: str = "configured", details: str = "", variables: list[str] | None = None) -> Dict[str, Any]:
        return {
            "role": role,
            "provider": provider,
            "function": function,
            "engine": engine,
            "ttl_seconds": ttl_seconds,
            "status": status,
            "url": url,
            "variables": variables or [],
            "details": details,
        }


    def _resolution_truth_contract(self, bbox: dict[str, Any] | None = None, stride: int | None = None, source_resolution_deg: float | None = None, derived_resolution_deg: float | None = None, extra: dict[str, Any] | None = None) -> dict[str, Any]:
        source_res = float(source_resolution_deg if source_resolution_deg is not None else 0.25)
        stride_val = max(1, int(stride or 1))
        contract = {
            "source_truth_first": True,
            "cache_first": True,
            "source_resolution_deg": source_res,
            "stride": stride_val,
            "viewport_fetch_bbox": bbox,
            "derived_render_geometry": True,
            "derived_resolution_deg": float(derived_resolution_deg if derived_resolution_deg is not None else max(source_res / stride_val, source_res / 8.0)),
            "policy": "use live source-resolution viewport fetches as truth, cache them, then derive smooth render geometry from that truth",
        }
        if isinstance(extra, dict):
            contract.update(extra)
        return contract

    def _attach_truth_contract(self, payload: dict[str, Any], *, bbox: dict[str, Any] | None = None, stride: int | None = None, source_resolution_deg: float | None = None, derived_resolution_deg: float | None = None, extra: dict[str, Any] | None = None) -> dict[str, Any]:
        if not isinstance(payload, dict):
            return payload
        payload.setdefault("source_resolution_deg", float(source_resolution_deg if source_resolution_deg is not None else payload.get("source_resolution_deg") or 0.25))
        payload.setdefault("stride", max(1, int(stride or payload.get("stride") or payload.get("provider_stride") or ((payload.get("scene_plan") or {}).get("provider_stride") if isinstance(payload.get("scene_plan"), dict) else 1) or 1)))
        if derived_resolution_deg is not None and payload.get("derived_resolution_deg") is None:
            payload["derived_resolution_deg"] = float(derived_resolution_deg)
        payload["truth_contract"] = self._resolution_truth_contract(
            bbox=bbox or payload.get("bbox") or payload.get("bbox_object") or payload.get("requested_bbox"),
            stride=payload.get("stride"),
            source_resolution_deg=payload.get("source_resolution_deg"),
            derived_resolution_deg=payload.get("derived_resolution_deg"),
            extra=extra,
        )
        return payload

    def payload_debug_payload(self, bbox: dict[str, float] | None = None) -> Dict[str, Any]:
        """Full layer/source contract status for the browser debug panel.

        This endpoint does not hide failures. It reports which payloads arrived,
        which variables were requested/selected, shapes, timings, drawable counts,
        and exact failure diagnostics so the next error can be followed from the UI.
        """
        b = self._normalize_bbox(bbox)
        started = time.time()
        out: dict[str, Any] = {"ok": True, "bbox": b, "ts": self._now_ms(), "layers": {}, "providers": {}, "latency_ms": 0}
        out["truth_contract"] = self._resolution_truth_contract(bbox=b, stride=1, source_resolution_deg=0.25, derived_resolution_deg=0.03125)
        try:
            w = self.generate_weather_payload(b)
            fields = w.get("fields") or {}
            gfs_stride = max(1, int(w.get("stride") or (((w.get("scene_plan") or {}).get("provider_stride")) if isinstance(w.get("scene_plan"), dict) else 1) or 1))
            out["providers"]["gfs_nomads"] = {
                "ok": w.get("source") == "gfs_nomads",
                "source": w.get("source"),
                "payload_state": w.get("payload_state"),
                "cycle": w.get("cycle"),
                "forecast_hour": w.get("forecast_hour"),
                "valid_time": w.get("valid_time"),
                "source_url": w.get("source_url"),
                "cache_path": w.get("cache_path"),
                "source_resolution_deg": float(w.get("source_resolution_deg") or 0.25),
                "stride": gfs_stride,
                "derived_resolution_deg": round(float(w.get("source_resolution_deg") or 0.25) / 8.0, 6),
                "fields_available": w.get("fields_available") or self.state.fields_available,
                "fields_missing": w.get("fields_missing") or self.state.fields_missing,
                "field_shapes": {k: (list(np.asarray(v).shape) if np is not None and v is not None else []) for k, v in fields.items() if k in {"wind_u", "wind_v", "wind_speed", "precip_rate", "cloud_density", "temp2m", "mslp"}},
            }
            out["layers"]["clouds"] = {
                "data_came": bool(w.get("tiles") or w.get("items")),
                "drawable_count": len(w.get("tiles") or w.get("items") or []),
                "rain_count": (w.get("rain") or {}).get("count", 0),
                "balloon_vectors": (w.get("balloons") or {}).get("count", 0),
                "has_uv_fields_for_jetstream": bool(fields.get("wind_u") and fields.get("wind_v")),
                "source_resolution_deg": float(w.get("source_resolution_deg") or 0.25),
                "stride": gfs_stride,
                "derived_resolution_deg": round(float(w.get("source_resolution_deg") or 0.25) / 8.0, 6),
            }
        except Exception as exc:
            out["providers"]["gfs_nomads"] = {"ok": False, "error": str(exc)}
        try:
            ocean = self.ocean_points_payload(b, "auto")
            meta = ocean.get("source_meta") or {}
            out["providers"]["hycom"] = {
                "ok": bool(ocean.get("ok")),
                "source": ocean.get("source"),
                "count": ocean.get("count"),
                "stride": ocean.get("stride"),
                "source_resolution_deg": 0.0,
                "derived_resolution_deg": None,
                "selected_attempt": meta.get("selected_attempt"),
                "selected_dataset": meta.get("selected_dataset"),
                "selected_vars": meta.get("selected_vars"),
                "selected_u_var": meta.get("selected_u_var"),
                "selected_v_var": meta.get("selected_v_var"),
                "hycom_slices": meta.get("hycom_slices"),
                "hycom_lon_diagnostics": meta.get("hycom_lon_diagnostics"),
                "grid_shape": meta.get("grid_shape") or (ocean.get("grid") or {}).get("grid_shape"),
                "real_subset": meta.get("real_subset"),
                "diagnostics": meta.get("diagnostics"),
                "debug_previews": meta.get("debug_previews"),
                "error": ocean.get("error"),
            }
            out["layers"]["ocean_points"] = {"data_came": bool(ocean.get("points")), "drawable_count": len(ocean.get("points") or []), "mask": ocean.get("mask"), "stride": ocean.get("stride")}
        except Exception as exc:
            out["providers"]["hycom"] = {"ok": False, "error": str(exc)}
        try:
            bait = self.bait_advanced_payload(b)
            bait_obj = bait.get("bait") or {}
            out["layers"]["bait"] = {
                "data_came": True,
                "status": bait_obj.get("status"),
                "source": bait_obj.get("source") or bait.get("source"),
                "polygon_count": len(bait_obj.get("polygons") or []),
                "outer_count": len(bait_obj.get("outer_polygons") or []),
                "inner_count": len(bait_obj.get("inner_polygons") or []),
                "stride": bait.get("stride") or ((bait.get("scene_plan") or {}).get("provider_stride") if isinstance(bait.get("scene_plan"), dict) else None),
                "source_resolution_deg": bait.get("source_resolution_deg") or 0.25,
                "derived_resolution_deg": bait.get("derived_resolution_deg"),
                "core_count": len(bait_obj.get("core_polygons") or []),
                "bait_score_rows": len(bait.get("bait_score") or []),
                "ocean_point_rows": len(bait.get("ocean_points") or []),
                "mode": bait.get("mode"),
            }
        except Exception as exc:
            out["layers"]["bait"] = {"data_came": False, "error": str(exc)}
        try:
            boats = self.boats_payload(b)
            out["layers"]["boats"] = {
                "data_came": True,
                "raw": boats.get("count"),
                "renderable_hint": boats.get("renderable_count_hint"),
                "fallback_rejected": boats.get("fallback_rejected_count_hint"),
                "source": boats.get("source"),
                "mode": boats.get("mode"),
                "contract": boats.get("render_contract"),
            }
        except Exception as exc:
            out["layers"]["boats"] = {"data_came": False, "error": str(exc)}
        try:
            cloud_truth = out.get("layers", {}).get("clouds", {})
            out["resolution_truth"] = self._resolution_truth_contract(
                bbox=b,
                stride=cloud_truth.get("stride") or 1,
                source_resolution_deg=cloud_truth.get("source_resolution_deg") or 0.25,
                derived_resolution_deg=cloud_truth.get("derived_resolution_deg") or 0.03125,
                extra={
                    "debug_payload": True,
                    "source_grid_shape": out.get("providers", {}).get("gfs_nomads", {}).get("field_shapes", {}).get("wind_u"),
                },
            )
        except Exception:
            out["resolution_truth"] = out.get("truth_contract")
        out["latency_ms"] = int((time.time() - started) * 1000)
        return out

    def source_diagnostics_payload(self, bbox: dict[str, float] | None = None) -> Dict[str, Any]:
        b = self._normalize_bbox(bbox)
        lat, lon = self._bbox_center(b)
        gfs_vars = [
            "u-component_of_wind_height_above_ground", "v-component_of_wind_height_above_ground",
            "Temperature_height_above_ground", "Relative_humidity_height_above_ground",
            "Precipitation_rate_surface", "Total_cloud_cover_entire_atmosphere",
            "Low_cloud_cover_low_cloud", "Medium_cloud_cover_middle_cloud", "High_cloud_cover_high_cloud",
            "Pressure_reduced_to_MSL_msl",
        ]
        from urllib.parse import urlencode
        gfs_query = urlencode({
            "north": round(b["north"], 4), "south": round(b["south"], 4),
            "west": round(b["west"], 4), "east": round(b["east"], 4),
            "time": "present", "accept": "netCDF4", "addLatLon": "true", "horizStride": 1,
        }) + "&" + "&".join(f"var={v}" for v in gfs_vars)
        gfs_ncss = f"https://thredds.ucar.edu/thredds/ncss/grid/grib/NCEP/GFS/Global_0p25deg/TwoD?{gfs_query}"
        rows = [
            self._source_row("weather", "GFS THREDDS NCSS", "weather/clouds/rain/wind", gfs_ncss, engine="netcdf4/h5netcdf target", ttl_seconds=30, status="target_next", details="Preferred fast path: one NetCDF4 subset shared by weather, clouds, and rain.", variables=gfs_vars),
            self._source_row("weather_cached_fallback", "NOAA NOMADS GFS", "weather/clouds/rain cached fallback", NOMADS_FILTER_BASE, engine="grib2+cfgrib current", ttl_seconds=WEATHER_REFRESH_TTL_SECONDS, status="current", details="Current working path. Reliable, but heavier than NCSS NetCDF stream."),
            self._source_row("ocean", "HYCOM ESPC-D-V02 all_best NCSS", "surface SST + salinity + U/V currents", "https://ncss.hycom.org/thredds/ncss/grid/FMRC_ESPC-D-V02_all/FMRC_ESPC-D-V02_all_best.ncd", engine="netcdf4/h5netcdf live", ttl_seconds=180, status="current_live_if_bbox_small", details="Primary live NCSS NetCDF4 subset uses compact all_best with sst, sss, ssu, ssv and lowercase accept=netcdf4. The default quality policy is strict: no marker/proxy/mock ocean is drawn when HYCOM NCSS fails; payloads return explicit provider_empty/provider_failed diagnostics instead. HYCOM downloader uses curl-style no-sudo timeouts and NetCDF validation.", variables=["sst", "sss", "ssu", "ssv"]),
            self._source_row("swells", "NOAA WaveWatch III", "3 swell components", "https://nomads.ncep.noaa.gov/cgi-bin/filter_wave.pl", engine="netcdf4/grib2 target", ttl_seconds=180, status="target_next", details="Use multi-swell height/period/direction where fields are available. In strict mode, unavailable WW3 data remains diagnostic only and must not be presented as live measured swell."),
            self._source_row("sst", "NOAA OISST / ERDDAP", "bait temperature band", "https://coastwatch.pfeg.noaa.gov/erddap/griddap/ncdcOisst21Agg_LonPM180.csv", engine="csv/netcdf target", ttl_seconds=300, status="target_next", details="Observed SST for bait species likelihood and water/land validity."),
            self._source_row("chlorophyll", "NOAA CoastWatch ERDDAP", "bait productivity", "https://coastwatch.pfeg.noaa.gov/erddap/griddap/erdMH1chlamday.csv", engine="csv/netcdf target", ttl_seconds=300, status="target_next", details="Chlorophyll/productivity multiplier for bait polygons."),
            self._source_row("markers", "local CSV", "fish locations/intelligence", str(self._fish_csv_path()), engine="csv", ttl_seconds=0, status="current", details="Fish marker locations and fishing history reports."),
        ]
        api_calls = [
            {"endpoint": "/gfs/api/weather", "function": "weather fields", "source_role": "weather", "target_ttl_seconds": 30},
            {"endpoint": "/gfs/api/clouds", "function": "cloud/rain scene", "source_role": "weather", "target_ttl_seconds": 30},
            {"endpoint": "/gfs/api/ocean", "function": "currents/ocean solve", "source_role": "ocean", "target_ttl_seconds": 180},
            {"endpoint": "/gfs/api/boats", "function": "boating solve + 3 swells", "source_role": "ocean/swells", "target_ttl_seconds": 180},
            {"endpoint": "/gfs/api/bait-advanced", "function": "bait polygons/scores", "source_role": "sst/chl/ocean live grid; markers sample grid only", "target_ttl_seconds": 300},
            {"endpoint": "/gfs/api/frame", "function": "fast composite assembler", "source_role": "cached split payloads", "target_ttl_seconds": 15},
        ]
        return {"ok": True, "bbox": b, "center": {"lat": round(lat, 4), "lon": round(lon, 4)}, "api_calls": api_calls, "sources": rows, "ts": self._now_ms()}

    def _ocean_stride_for_bbox(self, bbox: dict[str, float], target_cells: int | None = None) -> int:
        """Budget-derived HYCOM NCSS stride.

        The old fixed harbor/regional/world buckets made stride and LOD hard to
        reason about.  This keeps tiny harbor views native, then derives stride
        from a scene target-cell budget so provider fetch coarseness is explicit.
        Final visual density is still controlled later by render budgets.
        """
        return self._estimate_provider_stride_for_bbox(bbox, target_cells or int(os.getenv("GFS_SCENE_PROVIDER_TARGET_CELLS", "14000") or "14000"))

    @staticmethod
    def _current_dir_deg(u_ms: float, v_ms: float) -> float | None:
        if not (math.isfinite(u_ms) and math.isfinite(v_ms)):
            return None
        if abs(u_ms) < 1e-9 and abs(v_ms) < 1e-9:
            return None
        return (math.degrees(math.atan2(u_ms, v_ms)) + 360.0) % 360.0

    @staticmethod
    def _safety_from_current(speed_kt: float, sst_c: float | None = None) -> dict[str, Any]:
        speed = max(0.0, float(speed_kt or 0.0))
        if speed >= 2.5:
            color, label, score = "red", "Strong current / rough drift caution", 0.82
        elif speed >= 1.5:
            color, label, score = "orange", "Active current / plan drift", 0.62
        elif speed >= 0.75:
            color, label, score = "yellow", "Moderate current", 0.42
        else:
            color, label, score = "green", "Light current", 0.22
        if sst_c is not None and math.isfinite(float(sst_c)) and (sst_c < 8 or sst_c > 31):
            score = min(1.0, score + 0.08)
        return {"color": color, "label": label, "score": round(score, 3), "risk": round(score, 3)}

    def _proxy_swells_for_point(self, lat: float, lon: float, regional_boats: list[dict[str, Any]]) -> list[dict[str, Any]]:
        best = None
        best_d = 1e9
        for boat in regional_boats or []:
            try:
                d = (float(boat.get("lat")) - lat) ** 2 + (float(boat.get("lon")) - lon) ** 2
            except Exception:
                continue
            if d < best_d:
                best, best_d = boat, d
        if best:
            sw = best.get("swells") or best.get("swell_components") or []
            if sw:
                return sw[:3]
            waves = best.get("waves") or {}
            cand = []
            for k in ("primary", "secondary", "tertiary"):
                if isinstance(waves.get(k), dict):
                    cand.append(waves[k])
            if cand:
                return cand[:3]
        return []

    @staticmethod
    def _lon_pm180(value: float) -> float:
        lon = float(value)
        while lon > 180.0:
            lon -= 360.0
        while lon <= -180.0:
            lon += 360.0
        return lon

    @staticmethod
    def _grid_spacing(values: list[float], index: int, fallback: float) -> float:
        vals = [float(v) for v in values if isinstance(v, (int, float)) and math.isfinite(float(v))]
        if len(vals) >= 2 and 0 <= index < len(vals):
            if index == 0:
                return abs(vals[1] - vals[0])
            if index >= len(vals) - 1:
                return abs(vals[-1] - vals[-2])
            return max(abs(vals[index] - vals[index - 1]), abs(vals[index + 1] - vals[index]))
        return abs(float(fallback or 0.08))


    def _ocean_points_from_grid(self, *, bbox: dict[str, float], ocean: dict[str, Any], lod: str = "auto") -> tuple[list[dict[str, Any]], dict[str, Any]]:
        """Build a true lat/lon HYCOM sea-of-points payload.

        HYCOM valid SST/current cells are treated as the implicit water mask.
        Output longitude is always normalized back to -180..180 for Google Maps.
        """
        u_grid = ocean.get("current_u") or []
        v_grid = ocean.get("current_v") or []
        sst_grid = ocean.get("sst") or []
        sal_grid = ocean.get("salinity") or []
        lat_values = [float(x) for x in (ocean.get("lat_values") or []) if isinstance(x, (int, float)) and math.isfinite(float(x))]
        lon_values_raw = [float(x) for x in (ocean.get("lon_values") or []) if isinstance(x, (int, float)) and math.isfinite(float(x))]
        lon_values = [self._lon_pm180(x) for x in lon_values_raw]
        # Prefer full SST+U/V current grids, but do not collapse the ocean
        # point payload to zero when HYCOM returns SST while U/V is unavailable.
        # Bait can still draw SST-backed school cells without current vectors.
        has_uv_grid = bool(u_grid and v_grid)
        if has_uv_grid:
            ny = min(len(u_grid), len(v_grid), len(sst_grid) if sst_grid else 10**9)
            nx = min(
                len(u_grid[0]) if u_grid and u_grid[0] else 0,
                len(v_grid[0]) if v_grid and v_grid[0] else 0,
                len(sst_grid[0]) if sst_grid and sst_grid[0] else 10**9,
            )
        else:
            ny = len(sst_grid)
            nx = len(sst_grid[0]) if sst_grid and sst_grid[0] else 0
        if ny < 1 or nx < 1:
            return [], {"real_grid": False, "reason": "missing_sst_and_u_v_grid", "grid_shape": [ny, nx], "has_uv_grid": has_uv_grid}

        b = self._normalize_bbox(bbox)
        west, east = float(b["west"]), float(b["east"])
        east_i = east + 360.0 if east < west else east
        south, north = float(b["south"]), float(b["north"])
        fallback_dlat = abs(north - south) / max(1, ny - 1)
        fallback_dlon = abs(east_i - west) / max(1, nx - 1)

        span = max(abs(east_i - west), abs(north - south))
        lod_key = str(lod or "auto").lower()
        if lod_key in {"harbor", "dense", "high"} or span < 1.5:
            max_points = max(220, OCEAN_POINTS_MAX)
        elif lod_key in {"world", "coarse", "low"} or span > 8:
            max_points = max(80, min(OCEAN_POINTS_MAX, 180))
        else:
            max_points = max(140, min(OCEAN_POINTS_MAX, 320))
        step_y = max(1, int(math.ceil(ny / math.sqrt(max_points))))
        step_x = max(1, int(math.ceil(nx / math.sqrt(max_points))))

        def valid_at(y: int, x: int) -> bool:
            if y < 0 or x < 0 or y >= ny or x >= nx:
                return False
            if has_uv_grid:
                try:
                    u = float(u_grid[y][x]); v = float(v_grid[y][x])
                except Exception:
                    return False
                if not (math.isfinite(u) and math.isfinite(v)):
                    return False
            if sst_grid:
                try:
                    sst = float(sst_grid[y][x])
                except Exception:
                    return False
                if not math.isfinite(sst):
                    return False
            return True

        points: list[dict[str, Any]] = []
        speeds: list[float] = []
        skipped_land = 0
        skipped_nan = 0
        edge_points = 0
        for iy in range(0, ny, step_y):
            for ix in range(0, nx, step_x):
                if not valid_at(iy, ix):
                    if sst_grid:
                        skipped_land += 1
                    else:
                        skipped_nan += 1
                    continue
                u = float(u_grid[iy][ix]) if has_uv_grid else 0.0
                v = float(v_grid[iy][ix]) if has_uv_grid else 0.0
                if lat_values and iy < len(lat_values):
                    lat = lat_values[iy]
                else:
                    frac_y = 0.5 if ny == 1 else iy / max(1, ny - 1)
                    lat = south + (north - south) * frac_y
                if lon_values and ix < len(lon_values):
                    lon = lon_values[ix]
                else:
                    frac_x = 0.5 if nx == 1 else ix / max(1, nx - 1)
                    lon = self._lon_pm180(west + (east_i - west) * frac_x)
                if not (math.isfinite(lat) and math.isfinite(lon)):
                    skipped_nan += 1
                    continue

                sst_c = None
                sal_psu = None
                if sst_grid:
                    try: sst_c = float(sst_grid[iy][ix])
                    except Exception: sst_c = None
                if sal_grid:
                    try: sal_psu = float(sal_grid[iy][ix])
                    except Exception: sal_psu = None
                speed_ms = math.hypot(u, v)
                speed_kt = speed_ms * 1.9438444924
                dir_deg = self._current_dir_deg(u, v)
                dlat = max(0.003, min(1.2, abs(self._grid_spacing(lat_values, iy, fallback_dlat))))
                dlon = max(0.003, min(1.2, abs(self._grid_spacing(lon_values_raw, ix, fallback_dlon))))

                neighbor_checks = [(iy-1,ix),(iy+1,ix),(iy,ix-1),(iy,ix+1)]
                valid_neighbors = sum(1 for y,x in neighbor_checks if valid_at(y,x))
                if valid_neighbors < 4:
                    edge_points += 1
                confidence = 0.55 + 0.1 * min(valid_neighbors, 4)
                if sst_grid and sst_c is not None and math.isfinite(sst_c):
                    confidence += 0.05
                if valid_neighbors < 2:
                    confidence -= 0.28
                confidence = max(0.12, min(0.98, confidence))

                safety = self._safety_from_current(speed_kt, sst_c)
                bait_temp = 0.5
                if sst_c is not None and math.isfinite(sst_c):
                    # Broad SoCal-ish marine bait comfort window: ~13C-22C.
                    bait_temp = max(0.0, min(1.0, 1.0 - abs(float(sst_c) - 17.5) / 8.5))
                current_edge = 1.0 - min(1.0, valid_neighbors / 4.0)
                bait_score = max(0.0, min(1.0, (bait_temp * 0.58) + (min(speed_kt, 2.0) / 2.0 * 0.24) + (current_edge * 0.18)))

                point = {
                    "id": f"hycom-point-{iy}-{ix}",
                    "lat": round(float(lat), 6),
                    "lon": round(float(lon), 6),
                    "u": round(u, 5),
                    "v": round(v, 5),
                    "speedMs": round(speed_ms, 5),
                    "speedKt": round(speed_kt, 4),
                    "heading": round(dir_deg, 2) if dir_deg is not None else None,
                    "sst": round(sst_c, 4) if sst_c is not None and math.isfinite(sst_c) else None,
                    "salinity": round(sal_psu, 4) if sal_psu is not None and math.isfinite(sal_psu) else None,
                    "baitScore": round(bait_score, 4),
                    "boatingRisk": safety.get("risk"),
                    "confidence": round(confidence, 4),
                    "valid": True,
                    "water": True,
                    "mask": "hycom_valid_sst_current" if (sst_grid and has_uv_grid) else ("hycom_valid_sst_only" if sst_grid else "hycom_valid_current"),
                    "hasCurrentUv": bool(has_uv_grid),
                    "edgeConfidence": round(valid_neighbors / 4.0, 3),
                    "cell": {"dLat": round(dlat, 6), "dLon": round(dlon, 6), "validNeighbors": valid_neighbors},
                    "current": {"u": round(u, 5), "v": round(v, 5), "speedMs": round(speed_ms, 5), "speedKt": round(speed_kt, 4), "dirDeg": round(dir_deg, 2) if dir_deg is not None else None},
                    "safety": safety,
                }
                speeds.append(speed_kt)
                points.append(point)
                if len(points) >= max_points:
                    break
            if len(points) >= max_points:
                break

        return points, {
            "real_grid": bool(points),
            "grid_shape": [ny, nx],
            "point_count": len(points),
            "max_points": max_points,
            "lod": lod_key,
            "lod_step": {"y": step_y, "x": step_x},
            "mask_method": "hycom_valid_sst_current" if (sst_grid and has_uv_grid) else ("hycom_valid_sst_only" if sst_grid else "hycom_valid_current"),
            "has_uv_grid": bool(has_uv_grid),
            "sst_only_points_allowed": bool(sst_grid and not has_uv_grid),
            "skipped_land_or_invalid_sst": skipped_land,
            "coastline_guard": "valid_sst_neighbor_count_min_5_of_9",
            "skipped_nan_current": skipped_nan,
            "edge_points": edge_points,
            "lat_values": len(lat_values),
            "lon_values": len(lon_values),
            "avg_current_kt": round(sum(speeds) / max(1, len(speeds)), 4),
            "max_current_kt": round(max(speeds) if speeds else 0.0, 4),
        }

    def _advected_point(self, lat: float, lon: float, u_ms: float, v_ms: float, seconds: float = 900.0) -> dict[str, float]:
        lat_rad = math.radians(float(lat))
        meters_north = float(v_ms) * float(seconds)
        meters_east = float(u_ms) * float(seconds)
        dlat = meters_north / 111320.0
        denom = max(15000.0, 111320.0 * max(0.08, math.cos(lat_rad)))
        dlon = meters_east / denom
        return {"lat": round(float(lat) + dlat, 6), "lon": round(self._lon_pm180(float(lon) + dlon), 6)}

    def _boats_from_ocean_grid(self, *, bbox: dict[str, float], ocean: dict[str, Any], regional_boats: list[dict[str, Any]], scene: dict[str, Any] | None = None) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        """Build renderable GLB boats from live HYCOM water cells without grid/row lines.

        Older builds walked the HYCOM grid with step_y/step_x and stopped as soon
        as render_limit boats were found. On a tilted globe that made boats line
        up on a row, often near the lower padded fetch bbox. This version scans a
        deterministic pool of live water/current/SST candidates, ranks them by a
        stable pseudo-random seed, then accepts candidates only if they are spaced
        apart geographically. The result is stable between refreshes, but visually
        scattered instead of equidistant.
        """
        u_grid = ocean.get("current_u") or []
        v_grid = ocean.get("current_v") or []
        sst_grid = ocean.get("sst") or []
        sal_grid = ocean.get("salinity") or []
        lat_values = [float(x) for x in (ocean.get("lat_values") or []) if isinstance(x, (int, float)) and math.isfinite(float(x))]
        lon_values_raw = [float(x) for x in (ocean.get("lon_values") or []) if isinstance(x, (int, float)) and math.isfinite(float(x))]
        lon_values = [self._lon_pm180(x) for x in lon_values_raw]
        ny = min(len(u_grid), len(v_grid), len(sst_grid) if sst_grid else 10**9)
        nx = min(
            len(u_grid[0]) if ny and u_grid and u_grid[0] else 0,
            len(v_grid[0]) if ny and v_grid and v_grid[0] else 0,
            len(sst_grid[0]) if sst_grid and sst_grid[0] else 10**9,
        )
        if ny < 1 or nx < 1:
            return [], {"real_grid": False, "reason": "missing_u_v_or_sst_grid", "grid_shape": [ny, nx], "rejection_counts": {"missing_grid": 1}}

        west, east = float(bbox["west"]), float(bbox["east"])
        south, north = float(bbox["south"]), float(bbox["north"])
        east_i = east + 360.0 if east < west else east
        scene_budget = ((scene or {}).get("render_budget") or {}) if isinstance(scene, dict) else {}
        render_limit = max(1, min(96, int(scene_budget.get("max_boats") or OCEAN_NCSS_RENDER_BOATS)))
        # Keep a larger live candidate pool so the frontend can also scatter/filter
        # by the true screen viewport while the backend remains cache/fetch-bbox based.
        candidate_limit = max(render_limit * 10, min(240, int(OCEAN_NCSS_MAX_BOATS) * 4))
        fallback_dlat = abs(north - south) / max(1, ny - 1)
        fallback_dlon = abs(east_i - west) / max(1, nx - 1)

        def finite_grid_value(grid, y: int, x: int) -> float | None:
            try:
                value = float(grid[y][x])
                return value if math.isfinite(value) else None
            except Exception:
                return None

        def valid_sst_at(y: int, x: int) -> bool:
            if not sst_grid or y < 0 or x < 0 or y >= ny or x >= nx:
                return False
            return finite_grid_value(sst_grid, y, x) is not None

        def marine_neighbor_count(y: int, x: int) -> tuple[int, int]:
            valid = 0
            possible = 0
            for jy in range(max(0, y - 1), min(ny, y + 2)):
                for jx in range(max(0, x - 1), min(nx, x + 2)):
                    possible += 1
                    if valid_sst_at(jy, jx):
                        valid += 1
            return valid, possible

        def rand01(seed: str) -> float:
            h = hashlib.blake2b(seed.encode("utf-8", "ignore"), digest_size=8).digest()
            return int.from_bytes(h, "big") / float(2**64 - 1)

        def geo_dist2(a: dict[str, Any], b: dict[str, Any]) -> float:
            alat = float(a.get("lat") or 0.0); blat = float(b.get("lat") or 0.0)
            alon = float(a.get("lon") or 0.0); blon = float(b.get("lon") or 0.0)
            mean_lat = math.radians((alat + blat) * 0.5)
            dx = (alon - blon) * max(0.25, math.cos(mean_lat))
            dy = alat - blat
            return dx * dx + dy * dy

        def make_boat(iy: int, ix: int) -> tuple[dict[str, Any] | None, str | None]:
            try:
                u = float(u_grid[iy][ix]); v = float(v_grid[iy][ix])
            except Exception:
                return None, "nan_current"
            if not (math.isfinite(u) and math.isfinite(v)):
                return None, "nan_current"

            sst_c = finite_grid_value(sst_grid, iy, ix) if sst_grid else None
            if sst_grid and sst_c is None:
                return None, "land_or_nan_sst"

            # Stricter coastline/island guard for GLB boats. Bait/ocean points may
            # use softer edge cells, but boats should only spawn in established water.
            valid_neighbors, possible_neighbors = marine_neighbor_count(iy, ix) if sst_grid else (9, 9)
            if sst_grid and possible_neighbors >= 6 and valid_neighbors < 8:
                return None, "coastline_guard"

            sal_psu = finite_grid_value(sal_grid, iy, ix) if sal_grid else None
            if lat_values and iy < len(lat_values):
                lat = lat_values[iy]
            else:
                frac_y = 0.5 if ny == 1 else iy / max(1, ny - 1)
                lat = south + (north - south) * frac_y
            if lon_values and ix < len(lon_values):
                lon = lon_values[ix]
            else:
                frac_x = 0.5 if nx == 1 else ix / max(1, nx - 1)
                lon = self._lon_pm180(west + (east_i - west) * frac_x)

            if not (math.isfinite(lat) and math.isfinite(lon)):
                return None, "nan_lat_lon"
            if not (south <= lat <= north and min(west, east) <= lon <= max(west, east)):
                return None, "outside_bbox"

            speed_ms = math.hypot(u, v)
            speed_kt = speed_ms * 1.9438444924
            if not math.isfinite(speed_kt) or speed_kt < 0.03:
                return None, "low_current"

            dir_deg = self._current_dir_deg(u, v)
            swells = self._proxy_swells_for_point(lat, lon, regional_boats)
            dlat = max(0.004, min(1.2, abs(self._grid_spacing(lat_values, iy, fallback_dlat))))
            dlon = max(0.004, min(1.2, abs(self._grid_spacing(lon_values_raw, ix, fallback_dlon))))
            safety = self._safety_from_current(speed_kt, sst_c)
            seed = f"boat:{round(west,3)}:{round(south,3)}:{round(east,3)}:{round(north,3)}:{iy}:{ix}:{round(speed_kt,3)}"
            # Put the rendered boat inside the live water cell, not exactly on the
            # HYCOM node. The jitter is deterministic and bounded by cell spacing.
            jitter_lat = (rand01(seed + ':lat') - 0.5) * dlat * 0.66
            jitter_lon = (rand01(seed + ':lon') - 0.5) * dlon * 0.66
            boat = {
                "id": f"hycom-current-{iy}-{ix}",
                "lat": round(float(lat + jitter_lat), 5),
                "lon": round(float(lon + jitter_lon), 5),
                "source": "hycom_espc_d_v02_ncss",
                "derivedFrom": "HYCOM ESPC-D-V02 NCSS selected surface/current variables",
                "gridIndex": {"iy": iy, "ix": ix},
                "cell": {
                    "dLat": round(dlat, 6),
                    "dLon": round(dlon, 6),
                    "water": True,
                    "mask": "hycom_valid_sst_current",
                    "validNeighbors": valid_neighbors,
                    "possibleNeighbors": possible_neighbors,
                    "placement": "deterministic_random_inside_cell",
                },
                "current": {
                    "u": round(u, 4),
                    "v": round(v, 4),
                    "speedMs": round(speed_ms, 4),
                    "speedKt": round(speed_kt, 3),
                    "dirDeg": round(dir_deg, 1) if dir_deg is not None else None,
                },
                "water": {
                    "sst_c": round(sst_c, 3) if sst_c is not None else None,
                    "sst_f": round(sst_c * 9 / 5 + 32, 1) if sst_c is not None else None,
                    "salinity_psu": round(sal_psu, 3) if sal_psu is not None else None,
                },
                "waves": {"source": "proxy_swells_until_ww3_live", "components": swells, "sigHeightFt": (swells[0].get("heightFt") if swells and isinstance(swells[0], dict) else None)},
                "swells": swells,
                "swell_components": swells,
                "safety": safety,
                "hazard": safety["score"],
                "placement": {
                    "mode": "backend_scattered_water_cell",
                    "seed_rank": round(rand01(seed + ':rank'), 6),
                    "jitter_lat": round(jitter_lat, 6),
                    "jitter_lon": round(jitter_lon, 6),
                },
            }
            return boat, None

        rejection_counts: dict[str, int] = {
            "nan_current": 0,
            "nan_lat_lon": 0,
            "land_or_nan_sst": 0,
            "coastline_guard": 0,
            "outside_bbox": 0,
            "low_current": 0,
            "candidate_cap": 0,
            "spacing_rejected": 0,
        }
        considered = 0
        candidates: list[dict[str, Any]] = []
        speeds: list[float] = []

        # Adaptive pre-step keeps enormous bboxes safe, but we no longer stop after
        # the first row of valid water. The rank/spacing pass below decides the set.
        target_scan = 1800
        scan_step = max(1, int(math.sqrt(max(1, (ny * nx) / target_scan))))
        # Phase offsets prevent every cache refresh from sampling the same north/south
        # and west/east stripes while staying deterministic for the bbox.
        phase_seed = f"{round(west,3)}:{round(south,3)}:{round(east,3)}:{round(north,3)}:{ny}x{nx}"
        off_y = int(rand01(phase_seed + ':y') * scan_step) if scan_step > 1 else 0
        off_x = int(rand01(phase_seed + ':x') * scan_step) if scan_step > 1 else 0

        for iy in range(off_y, ny, scan_step):
            for ix in range(off_x, nx, scan_step):
                considered += 1
                boat, reason = make_boat(iy, ix)
                if boat is None:
                    if reason in rejection_counts:
                        rejection_counts[reason] += 1
                    continue
                candidates.append(boat)
                try:
                    speeds.append(float(boat.get("current", {}).get("speedKt") or 0.0))
                except Exception:
                    pass

        # If the offset/stride pass missed too much water, do a sparse second pass
        # at cell centers. This helps narrow harbor bboxes without creating lines.
        if len(candidates) < render_limit and scan_step > 1:
            for iy in range(0, ny, max(1, scan_step // 2)):
                for ix in range(0, nx, max(1, scan_step // 2)):
                    if any((c.get("gridIndex") or {}) == {"iy": iy, "ix": ix} for c in candidates):
                        continue
                    considered += 1
                    boat, reason = make_boat(iy, ix)
                    if boat is None:
                        if reason in rejection_counts:
                            rejection_counts[reason] += 1
                        continue
                    candidates.append(boat)
                    try:
                        speeds.append(float(boat.get("current", {}).get("speedKt") or 0.0))
                    except Exception:
                        pass
                    if len(candidates) >= candidate_limit:
                        break
                if len(candidates) >= candidate_limit:
                    break

        # Stable random order, then greedy geo-spacing. The min distance is tied to
        # the fetch bbox size so a wide view does not create clumps and a harbor view
        # does not reject everything.
        span = max(abs(north - south), abs(east_i - west), 0.05)
        min_sep_deg = max(0.012, min(0.65, span / max(3.0, math.sqrt(render_limit) * 3.2)))
        min_sep2 = min_sep_deg * min_sep_deg
        candidates.sort(key=lambda b: (float(((b.get("placement") or {}).get("seed_rank") or 0.5)), -float((b.get("current") or {}).get("speedKt") or 0.0)))
        selected: list[dict[str, Any]] = []
        for boat in candidates:
            if all(geo_dist2(boat, prev) >= min_sep2 for prev in selected):
                selected.append(boat)
                if len(selected) >= render_limit:
                    break
            else:
                rejection_counts["spacing_rejected"] += 1
        if len(selected) < render_limit:
            seen = {b.get("id") for b in selected}
            for boat in candidates:
                if boat.get("id") in seen:
                    continue
                selected.append(boat)
                if len(selected) >= render_limit:
                    break

        if len(candidates) > candidate_limit:
            rejection_counts["candidate_cap"] = len(candidates) - candidate_limit
        avg_speed = sum(speeds) / max(1, len(speeds))
        return selected, {
            "real_grid": bool(selected),
            "grid_shape": [ny, nx],
            "sampled_count": len(selected),
            "render_limit": render_limit,
            "candidate_limit": candidate_limit,
            "candidate_pool_count": len(candidates),
            "considered_cells": considered,
            "rejection_counts": rejection_counts,
            "skipped_land_or_invalid_sst": rejection_counts["land_or_nan_sst"] + rejection_counts["coastline_guard"],
            "coastline_guard": "boat_glb_requires_8_of_9_valid_sst_neighbors",
            "skipped_nan_current": rejection_counts["nan_current"],
            "lat_values": len(lat_values),
            "lon_values": len(lon_values),
            "lod_step": {"scan_step": scan_step, "phase_y": off_y, "phase_x": off_x},
            "placement_policy": "deterministic_random_scatter_with_geo_spacing_not_grid_rows",
            "min_spacing_deg": round(min_sep_deg, 5),
            "avg_current_kt": round(avg_speed, 3),
            "max_current_kt": round(max(speeds) if speeds else 0.0, 3),
        }

    def _fetch_live_ocean_ncss(self, bbox: dict[str, float], regional_boats: list[dict[str, Any]], scene: dict[str, Any] | None = None) -> dict[str, Any]:
        if not ENABLE_LIVE_OCEAN_NCSS:
            return {"ok": False, "reason": "disabled_by_GFS_ENABLE_LIVE_OCEAN_NCSS"}
        started = time.time()
        b = self._normalize_bbox(bbox)
        scene = scene or self.build_scene_plan(b, None, layer="ocean")
        stride = int(scene.get("provider_stride") or self._ocean_stride_for_bbox(b, scene.get("provider_target_cells")))
        try:
            raw, valid_time = self.ocean_provider._fetch_subset_sync(
                bbox=BBox(west=b["west"], south=b["south"], east=b["east"], north=b["north"]),
                stride=stride,
                valid_time=None,
            )
        except Exception as exc:
            return {"ok": False, "reason": "hycom_fetch_exception", "error": str(exc), "latency_ms": int((time.time() - started) * 1000)}
        meta = raw.get("source_meta") or {}
        boats, grid_meta = self._boats_from_ocean_grid(bbox=b, ocean=raw, regional_boats=regional_boats, scene=scene)
        quality_gate = meta.get("quality_gate") or {}
        live_ncss_ok = bool(quality_gate.get("live_ncss_ok") if isinstance(quality_gate, dict) else meta.get("real_subset"))
        ok = bool(live_ncss_ok)
        return {
            "ok": ok,
            "source": "hycom_espc_d_v02_ncss" if ok else "hycom_espc_d_v02_ncss_empty",
            "mode": "live_hycom_ncss_surface_currents" if ok else "live_hycom_attempt_no_quality_grid",
            "engine": "xarray->netcdf4/h5netcdf/scipy",
            "valid_time": valid_time.isoformat() if hasattr(valid_time, "isoformat") and valid_time else None,
            "latency_ms": int((time.time() - started) * 1000),
            "bbox": b,
            "scene_plan": scene,
            "visible_bbox": scene.get("visible_bbox"),
            "fetch_bbox": scene.get("fetch_bbox"),
            "render_budget": scene.get("render_budget"),
            "stride": stride,
            "hycom_resolution_mode": ("native_no_horizStride" if stride <= 1 else "adaptive_horizStride"),
            "bbox_area_deg2": round(abs((b["east"] - b["west"]) * (b["north"] - b["south"])), 4),
            "boats": boats,
            "boat_count": len(boats),
            "current_points": [{"lat": x.get("lat"), "lon": x.get("lon"), "current": x.get("current"), "safety": x.get("safety")} for x in boats],
            "grid": grid_meta,
            "source_meta": meta,
            "diagnostics": {
                "provider": "HYCOM ESPC-D-V02 all_best NCSS strict-live",
                "dataset_url": meta.get("current_dataset_url") or meta.get("sst_dataset_url"),
                "real_subset": bool(meta.get("real_subset")),
                "quality_gate": meta.get("quality_gate"),
                "fallback_used": bool(meta.get("fallback_used")),
                "fallback_sources": meta.get("fallback_sources") or [],
                "grid_shape": meta.get("grid_shape") or grid_meta.get("grid_shape"),
                "current_source": meta.get("current_source"),
                "selected_attempt": meta.get("selected_attempt"),
                "selected_dataset": meta.get("selected_dataset"),
                "selected_vars": meta.get("selected_vars"),
                "selected_u_var": meta.get("selected_u_var"),
                "selected_v_var": meta.get("selected_v_var"),
                "attempt_order": meta.get("attempt_order"),
                "hycom_slices": meta.get("hycom_slices"),
                "hycom_lon_diagnostics": meta.get("hycom_lon_diagnostics"),
                "diagnostics": meta.get("diagnostics", [])[:4],
                "debug_previews": meta.get("debug_previews", [])[:2],
            },
            "cache": {"hit": False, "ttl_seconds": 180},
            "ts": self._now_ms(),
        }


    def ocean_points_payload(self, bbox: dict[str, float] | None = None, lod: str = "auto", visible_bbox: dict[str, float] | None = None) -> Dict[str, Any]:
        b = self._normalize_bbox(bbox)
        scene = self.build_scene_plan(b, visible_bbox, layer="ocean-points")
        lod_key = str(lod or scene.get("tier") or "auto").lower()
        if lod_key == "auto":
            lod_key = str(scene.get("tier") or "regional")
        key = self._bbox_cache_key(f"ocean-points-{lod_key}", b)
        def _shell():
            return {
                "ok": True,
                "source": "hycom_ocean_points_cache_warming",
                "schema": "hycom_ocean_points_v1",
                "bbox": [b["west"], b["south"], b["east"], b["north"]],
                "bbox_object": b,
                "scene_plan": scene,
                "visible_bbox": scene.get("visible_bbox"),
                "fetch_bbox": scene.get("fetch_bbox"),
                "render_budget": scene.get("render_budget"),
                "lod": lod_key,
                "points": [],
                "count": 0,
                "mask": {"method": "cache_first_hold", "valid_count": 0, "rejected_count": 0},
                "grid": {"grid_shape": [0, 0], "real_grid": False, "reason": "cache_warming_no_direct_provider_block"},
                "source_meta": {"cache_first": True, "note": "HYCOM provider request queued; use stale cache or wait for warm pull."},
            }
        return self._cache_first_split_payload(
            key=key,
            label="ocean-points",
            ttl_seconds=int(os.getenv("GFS_OCEAN_POINTS_CACHE_TTL_SECONDS", "600") or "300"),
            stale_seconds=int(os.getenv("GFS_OCEAN_POINTS_STALE_SECONDS", "1800") or "1800"),
            builder=lambda: self._ocean_points_payload_heavy(b, lod_key, scene.get("visible_bbox")),
            shell_factory=_shell,
        )

    def _ocean_points_payload_heavy(self, bbox: dict[str, float] | None = None, lod: str = "auto", visible_bbox: dict[str, float] | None = None) -> Dict[str, Any]:
        """HYCOM sea-of-points foundation for ocean/bait/current LOD rendering."""
        b = self._normalize_bbox(bbox)
        scene = self.build_scene_plan(b, visible_bbox, layer="ocean-points")
        lod_key = str(lod or scene.get("tier") or "auto").lower()
        if lod_key == "auto":
            lod_key = str(scene.get("tier") or "regional")
        key = self._bbox_cache_key(f"ocean-points-{lod_key}", b)
        cached = self._split_cache_get(key, 180)
        if cached:
            out = dict(cached)
            out["cache"] = {"hit": True, "ttl_seconds": 180}
            return out
        started = time.time()
        stride = int(scene.get("provider_stride") or self._ocean_stride_for_bbox(b, scene.get("provider_target_cells")))
        try:
            raw, valid_time = self.ocean_provider._fetch_subset_sync(
                bbox=BBox(west=b["west"], south=b["south"], east=b["east"], north=b["north"]),
                stride=stride,
                valid_time=None,
            )
        except Exception as exc:
            return {"ok": False, "source": "hycom_ocean_points_error", "bbox": b, "error": str(exc), "points": [], "count": 0, "ts": self._now_ms()}
        points, grid_meta = self._ocean_points_from_grid(bbox=b, ocean=raw, lod=lod_key)
        for p in points:
            try:
                adv = self._advected_point(float(p["lat"]), float(p["lon"]), float(p.get("u") or 0.0), float(p.get("v") or 0.0), seconds=900.0)
                p["advected15m"] = adv
            except Exception:
                pass
        meta = raw.get("source_meta") or {}
        payload = {
            "ok": bool(points),
            "source": "hycom_all_best_ocean_points" if points and bool((raw.get("source_meta") or {}).get("real_subset")) else "hycom_ocean_points_empty_or_quality_gate_failed",
            "schema": "hycom_ocean_points_v1",
            "bbox": [b["west"], b["south"], b["east"], b["north"]],
            "bbox_object": b,
            "lon_mode": "0_360_internal__minus180_180_output",
            "lod": lod_key,
            "scene_plan": scene,
            "visible_bbox": scene.get("visible_bbox"),
            "fetch_bbox": scene.get("fetch_bbox"),
            "render_budget": scene.get("render_budget"),
            "stride": stride,
            "hycom_resolution_mode": ("native_no_horizStride" if stride <= 1 else "adaptive_horizStride"),
            "bbox_area_deg2": round(abs((b["east"] - b["west"]) * (b["north"] - b["south"])), 4),
            "valid_time": valid_time.isoformat() if hasattr(valid_time, "isoformat") and valid_time else None,
            "points": points,
            "count": len(points),
            "mask": {
                "method": grid_meta.get("mask_method"),
                "valid_count": len(points),
                "rejected_count": int(grid_meta.get("skipped_land_or_invalid_sst") or 0) + int(grid_meta.get("skipped_nan_current") or 0),
                "shoreline_edge_points": grid_meta.get("edge_points"),
            },
            "grid": grid_meta,
            "source_meta": {
                "quality_gate": meta.get("quality_gate"),
                "fallback_used": bool(meta.get("fallback_used")),
                "fallback_sources": meta.get("fallback_sources") or [],
                "selected_attempt": meta.get("selected_attempt"),
                "selected_dataset": meta.get("selected_dataset"),
                "selected_vars": meta.get("selected_vars"),
                "selected_u_var": meta.get("selected_u_var"),
                "selected_v_var": meta.get("selected_v_var"),
                "hycom_slices": meta.get("hycom_slices"),
                "hycom_lon_diagnostics": meta.get("hycom_lon_diagnostics"),
                "real_subset": bool(meta.get("real_subset")),
                "grid_shape": meta.get("grid_shape"),
                "diagnostics": (meta.get("diagnostics") or [])[:3],
                "debug_previews": (meta.get("debug_previews") or [])[:2],
            },
            "cache": {"hit": False, "ttl_seconds": 180},
            "latency_ms": int((time.time() - started) * 1000),
            "ts": self._now_ms(),
        }
        return self._split_cache_set(key, self._attach_truth_contract(self._attach_scene_plan(payload, scene), bbox=b, stride=stride, source_resolution_deg=0.25, derived_resolution_deg=0.03125, extra={"input_truth": "live_source_resolution_viewport_fetch"}))

    def ocean_payload(self, bbox: dict[str, float] | None = None, visible_bbox: dict[str, float] | None = None) -> Dict[str, Any]:
        b = self._normalize_bbox(bbox)
        scene = self.build_scene_plan(b, visible_bbox, layer="ocean")
        key = self._bbox_cache_key(f"ocean-live-{scene.get('tier')}", b)
        def _shell():
            return {
                "ok": True,
                "bbox": b,
                "scene_plan": scene,
                "visible_bbox": scene.get("visible_bbox"),
                "fetch_bbox": scene.get("fetch_bbox"),
                "render_budget": scene.get("render_budget"),
                "source": "deferred_tile_cache",
                "mode": "cache_first_ocean_warming",
                "engine": "cache-first; HYCOM provider warm queued",
                "boats": [],
                "boat_count": 0,
                "swell_components": [],
                "grid": {"grid_shape": [0, 0], "real_grid": False, "reason": "cache_warming_no_direct_provider_block"},
                "fallback": {"used": False, "reason": "cache_warming"},
            }
        return self._cache_first_split_payload(
            key=key,
            label="ocean-live",
            ttl_seconds=int(os.getenv("GFS_OCEAN_CACHE_TTL_SECONDS", "600") or "300"),
            stale_seconds=int(os.getenv("GFS_OCEAN_STALE_SECONDS", "1800") or "1800"),
            builder=lambda: self._ocean_payload_heavy(b, scene.get("visible_bbox")),
            shell_factory=_shell,
        )

    def _live_payload_policy(self) -> dict[str, Any]:
        return {
            "strict_live_payloads": bool(GFS_STRICT_LIVE_PAYLOADS),
            "allow_proxy_fallback": bool(GFS_ALLOW_PROXY_FALLBACK),
            "allow_synthetic_fallback": bool(ALLOW_SYNTHETIC_FALLBACK),
            "rule": "live_ncss_erddap_or_empty_no_mock_draw",
        }

    def _empty_live_required_payload(self, *, label: str, bbox: dict[str, float], reason: str, error: str | None = None, live_attempt: dict[str, Any] | None = None) -> Dict[str, Any]:
        now = self._now_ms()
        payload: Dict[str, Any] = {
            "ok": False,
            "bbox": bbox,
            "source": f"{label}_live_required_unavailable",
            "mode": "live_required_no_proxy_or_mock",
            "payload_state": "provider_failed" if error else "provider_empty",
            "status": "unavailable",
            "reason": reason,
            "error": error,
            "quality_policy": self._live_payload_policy(),
            "fallback": {"used": False, "allowed": bool(GFS_ALLOW_PROXY_FALLBACK), "reason": "proxy_fallback_disabled_by_quality_policy"},
            "live_attempt": live_attempt or {},
            "diagnostics": {
                "quality_gate": "failed_live_required",
                "label": label,
                "reason": reason,
                "error": error,
            },
            "cache": {"hit": False, "ttl_seconds": 45, "mode": "explicit_unavailable_not_fallback"},
            "ts": now,
        }
        if label in {"ocean", "boats"}:
            payload.update({
                "boats": [],
                "boat_count": 0,
                "current_points": [],
                "points": [],
                "grid": {"real_grid": False, "reason": reason, "quality_gate": "failed_live_required"},
                "swell_components": [],
            })
        if label == "bait":
            payload.update({
                "schema": "bait_live_required_unavailable_v1",
                "bait": {"status": "unavailable", "source": payload["source"], "polygons": [], "outer_polygons": [], "inner_polygons": [], "core_polygons": []},
                "bait_score": [],
                "oceanPoints": [],
                "ocean_points": [],
                "confidence": {"overall": 0.0, "reason": reason},
            })
        return payload

    def _ocean_payload_heavy(self, bbox: dict[str, float] | None = None, visible_bbox: dict[str, float] | None = None) -> Dict[str, Any]:
        b = self._normalize_bbox(bbox)
        scene = self.build_scene_plan(b, visible_bbox, layer="ocean")
        key = self._bbox_cache_key(f"ocean-live-{scene.get('tier')}", b)
        cached = self._split_cache_get(key, 180)
        if cached:
            out = dict(cached)
            out["cache"] = {"hit": True, "ttl_seconds": 180}
            return out
        started = time.time()
        points, _ = self.load_fish()
        regional = self._regional_marker_frame_payload(b, points, self._now_ms())
        regional_boats = (regional.get("boats") or {}).get("boats", [])
        swell_components = []
        for boat in regional_boats[:20]:
            sw = boat.get("swells") or boat.get("swell_components") or []
            if sw:
                swell_components.append({"lat": boat.get("lat"), "lon": boat.get("lon"), "swells": sw[:3], "source": "proxy_swells_until_ww3_live"})

        live = self._fetch_live_ocean_ncss(b, regional_boats, scene=scene)
        if live.get("ok"):
            # Preserve proxy swell anchors until the WaveWatch pass lands, but currents/boats are now live HYCOM.
            live["swell_components"] = live.get("swell_components") or swell_components
            live["fallback"] = {"used": False, "proxy_boats_available": len(regional_boats), "allowed": bool(GFS_ALLOW_PROXY_FALLBACK)}
            live["quality_policy"] = self._live_payload_policy()
            live["payload_state"] = "live"
            live["latency_ms"] = int((time.time() - started) * 1000)
            return self._split_cache_set(key, self._attach_scene_plan(live, scene))

        if not GFS_ALLOW_PROXY_FALLBACK:
            payload = self._empty_live_required_payload(
                label="ocean",
                bbox=b,
                reason=str(live.get("reason") or live.get("mode") or "hycom_ncss_unavailable_or_empty"),
                error=live.get("error"),
                live_attempt=live,
            )
            payload["latency_ms"] = int((time.time() - started) * 1000)
            payload["diagnostics"].update({"source_diagnostics": self.source_diagnostics_payload(b)})
            return self._split_cache_set(key, self._attach_scene_plan(payload, scene))

        boats = {"ok": True, "boats": regional_boats, "count": len(regional_boats), "source": "marker_ocean_solve", "sparse_fallback": False}
        payload = {
            "ok": True,
            "bbox": b,
            "source": "marker_ocean_solve_fallback",
            "mode": "fallback_proxy_after_hycom_ncss_attempt",
            "engine": "proxy_current; live_attempt=netcdf4/h5netcdf",
            "latency_ms": int((time.time() - started) * 1000),
            "boats": boats.get("boats", []),
            "boat_count": boats.get("count", len(boats.get("boats", []))),
            "swell_components": swell_components,
            "live_attempt": live,
            "diagnostics": self.source_diagnostics_payload(b),
            "cache": {"hit": False, "ttl_seconds": 180},
            "quality_policy": self._live_payload_policy(),
            "fallback": {"used": True, "allowed": True, "reason": live.get("reason") or live.get("mode") or "hycom_unavailable"},
            "ts": self._now_ms(),
        }
        return self._split_cache_set(key, self._attach_scene_plan(payload, scene))

    def boats_payload(self, bbox: dict[str, float] | None = None, visible_bbox: dict[str, float] | None = None) -> Dict[str, Any]:
        scene = self.build_scene_plan(bbox, visible_bbox, layer="boats")
        ocean = self.ocean_payload(bbox, visible_bbox=scene.get("visible_bbox"))
        boats = ocean.get("boats", []) or []
        source = str(ocean.get("source") or "")
        mode = str(ocean.get("mode") or "")
        is_fallback = ("fallback" in source.lower()) or ("marker_ocean_solve" in source.lower()) or ("fallback" in mode.lower()) or ("proxy" in mode.lower())
        # Keep fallback/proxy boats visible in diagnostics, but separate them from
        # renderable GLB boats. The frontend only draws GLB boats from live
        # SST/current-backed water samples; this avoids saying “34 boats” when
        # all 34 were intentionally rejected as marker/proxy fallback.
        return {
            "ok": bool(ocean.get("ok")),
            "source": ocean.get("source"),
            "mode": ocean.get("mode"),
            "engine": ocean.get("engine"),
            "bbox": ocean.get("bbox"),
            "scene_plan": scene,
            "visible_bbox": scene.get("visible_bbox"),
            "fetch_bbox": scene.get("fetch_bbox"),
            "render_budget": scene.get("render_budget"),
            "boats": boats,
            "count": len(boats),
            "renderable_count_hint": 0 if is_fallback else len(boats),
            "fallback_rejected_count_hint": len(boats) if is_fallback else 0,
            "render_contract": "glb_boats_require_live_sst_current_samples",
            "rejection_counts": ((ocean.get("grid") or {}).get("rejection_counts") or {}),
            "grid": ocean.get("grid"),
            "swell_components": ocean.get("swell_components", []),
            "diagnostics": ocean.get("diagnostics"),
            "cache": ocean.get("cache"),
            "quality_policy": ocean.get("quality_policy") or self._live_payload_policy(),
            "payload_state": ocean.get("payload_state") or ("live" if not is_fallback and boats else "provider_empty"),
            "fallback": ocean.get("fallback") or {"used": bool(is_fallback)},
            "ts": self._now_ms(),
        }

    def bait_advanced_payload(self, bbox: dict[str, float] | None = None, visible_bbox: dict[str, float] | None = None) -> Dict[str, Any]:
        b = self._normalize_bbox(bbox)
        scene = self.build_scene_plan(b, visible_bbox, layer="bait")
        key = self._bbox_cache_key(f"bait-{scene.get('tier')}", b)
        def _shell():
            return {
                "ok": True,
                "bbox": b,
                "scene_plan": scene,
                "visible_bbox": scene.get("visible_bbox"),
                "fetch_bbox": scene.get("fetch_bbox"),
                "render_budget": scene.get("render_budget"),
                "source": "deferred_tile_cache",
                "mode": "cache_first_bait_warming",
                "bait": {"status": "warming", "source": "cache_first", "polygons": []},
                "bait_score": [],
                "oceanPoints": [],
                "ocean_points": [],
                "confidence": {"overall": 0.0, "reason": "cache_warming"},
            }
        return self._cache_first_split_payload(
            key=key,
            label="bait",
            ttl_seconds=int(os.getenv("GFS_BAIT_CACHE_TTL_SECONDS", "600") or "300"),
            stale_seconds=int(os.getenv("GFS_BAIT_STALE_SECONDS", "1800") or "1800"),
            builder=lambda: self._bait_advanced_payload_heavy(b, scene.get("visible_bbox")),
            shell_factory=_shell,
        )


    def _bait_advanced_payload_heavy(self, bbox: dict[str, float] | None = None, visible_bbox: dict[str, float] | None = None) -> Dict[str, Any]:
        """Live bait solve: HYCOM/RTOFS SST+current + CoastWatch chlorophyll + weather.

        This replaces the old marker-history proxy bait polygons. Fish CSV locations
        still exist as selectable nodes, but their glass-pane bait score should now
        be sampled from this live grid/bait_score contract instead of driving the
        polygon solve.
        """
        b = self._normalize_bbox(bbox)
        scene = self.build_scene_plan(b, visible_bbox, layer="bait")
        key = self._bbox_cache_key(f"bait-{scene.get('tier')}", b)
        cached = self._split_cache_get(key, 300)
        if cached:
            out = dict(cached)
            out.setdefault("cache", {})["hit"] = True
            out["cache"]["mode"] = "fresh_live_bait_grid_cache"
            return out

        started = time.time()
        diagnostics: dict[str, Any] = {
            "solve": "live_grid_bait_probability",
            "states": [],
            "cache_warm_state": "builder_running",
        }

        # Safe proxy fallback is kept for hard provider failures only, and is
        # explicitly marked fallback so the debug panel can distinguish it from
        # live marching-square bait.
        def _proxy_fallback(reason: str, error: str | None = None) -> Dict[str, Any]:
            if not GFS_ALLOW_PROXY_FALLBACK:
                payload = self._empty_live_required_payload(label="bait", bbox=b, reason=reason, error=error)
                payload["latency_ms"] = int((time.time() - started) * 1000)
                payload["diagnostics"].update(diagnostics)
                return self._split_cache_set(key, self._attach_scene_plan(payload, scene))
            points, _ = self.load_fish()
            regional = self._regional_marker_frame_payload(b, points, self._now_ms())
            payload = dict(regional.get("baitAdvanced", {}) or {})
            payload.update({
                "ok": True,
                "bbox": b,
                "source": "marker_history_ocean_proxy_fallback",
                "mode": "fallback_proxy_after_live_bait_grid_failure",
                "engine": "proxy fallback; live HYCOM/CoastWatch bait solve failed or empty",
                "latency_ms": int((time.time() - started) * 1000),
                "diagnostics": {**diagnostics, "fallback_reason": reason, "error": error},
                "cache": {"hit": False, "ttl_seconds": 120, "mode": "fallback_cached_short"},
                "payload_state": "provider_failed" if error else "provider_empty",
                "ts": self._now_ms(),
            })
            payload.setdefault("bait", {}).setdefault("status", "fallback")
            payload.setdefault("bait", {}).setdefault("source", "marker_history_ocean_proxy_fallback")
            return self._split_cache_set(key, self._attach_scene_plan(payload, scene))

        stride = int(scene.get("provider_stride") or self._ocean_stride_for_bbox(b, scene.get("provider_target_cells")))
        try:
            ocean_raw, ocean_time = self.ocean_provider._fetch_subset_sync(
                bbox=BBox(west=b["west"], south=b["south"], east=b["east"], north=b["north"]),
                stride=stride,
                valid_time=None,
            )
            diagnostics["states"].append({"provider": "ocean", "state": "ok", "stride": stride, "grid_shape": (ocean_raw.get("source_meta") or {}).get("grid_shape")})
        except Exception as exc:
            return _proxy_fallback("ocean_provider_exception", str(exc))

        bio_raw: dict[str, Any] = {}
        if getattr(self, "bio_provider", None) is not None:
            try:
                bio_raw, bio_time = self.bio_provider._fetch_subset_sync(
                    bbox=BBox(west=b["west"], south=b["south"], east=b["east"], north=b["north"]),
                    stride=max(1, min(stride, 2)),
                    valid_time=None,
                )
                diagnostics["states"].append({"provider": "coastwatch_chlorophyll", "state": "ok" if bio_raw.get("chlorophyll") else "empty", "grid_shape": [len(bio_raw.get("chlorophyll") or []), len((bio_raw.get("chlorophyll") or [[]])[0] if bio_raw.get("chlorophyll") else [])]})
            except Exception as exc:
                diagnostics["states"].append({"provider": "coastwatch_chlorophyll", "state": "failed_optional", "error": str(exc)})
        else:
            diagnostics["states"].append({"provider": "coastwatch_chlorophyll", "state": "unavailable_optional"})

        weather_fields: dict[str, Any] = {}
        try:
            weather_payload = self.generate_weather_payload(b)
            weather_fields = dict(weather_payload.get("fields") or {})
            diagnostics["states"].append({"provider": "gfs_weather_fields", "state": "ok" if weather_fields else "empty", "field_keys": list(weather_fields.keys())[:12]})
        except Exception as exc:
            diagnostics["states"].append({"provider": "gfs_weather_fields", "state": "failed_optional", "error": str(exc)})

        if derive_bait_payload is None:
            return _proxy_fallback("derive_bait_payload_import_missing")

        try:
            solved = derive_bait_payload(
                weather_fields,
                ocean_raw or {},
                bio_raw or {},
                bbox=[b["west"], b["south"], b["east"], b["north"]],
            )
        except Exception as exc:
            log.exception("live bait grid solve failed")
            return _proxy_fallback("derive_bait_payload_exception", str(exc))

        bait = dict(solved.get("bait") or {})
        score_rows = list(solved.get("bait_score") or [])
        if not score_rows:
            return _proxy_fallback("live_bait_grid_empty")

        # Keep bait.source as "full_stack" for the frontend renderer readiness contract.
        # Put the live provider name in live_source/provider_source instead of replacing it;
        # older JS checks bait.source === "full_stack" before trusting server polygons.
        bait["source"] = "full_stack"
        bait["live_source"] = "live_hycom_coastwatch_weather_grid"
        bait["provider_source"] = "live_hycom_coastwatch_weather_grid"
        bait["status"] = "ready"
        bait["bait_score"] = score_rows
        bait.setdefault("meta", {})
        bait["meta"].update({
            "solve_method": "server_live_marching_squares_grid",
            "input_ocean": "HYCOM/RTOFS SST/current grid",
            "input_bio": "CoastWatch chlorophyll when available",
            "input_weather": "GFS wind/cloud/precip when available",
            "marker_locations_drive_polygons": False,
            "location_intel_should_sample_grid": True,
        })

        payload: Dict[str, Any] = {
            **solved,
            "ok": True,
            "bbox": b,
            "bbox_object": b,
            "source": "live_hycom_coastwatch_bait_grid",
            "mode": "live_full_stack_marching_squares_bait_solve",
            "schema": "bait_live_marching_squares_v2",
            "engine": "HYCOM/RTOFS SST/current + CoastWatch chlorophyll + GFS weather -> bait_score grid -> marching-square contours",
            "quality_policy": self._live_payload_policy(),
            "bait": bait,
            "bait_score": score_rows,
            "ocean_points": score_rows,
            "oceanPoints": score_rows,
            "valid_time": ocean_time.isoformat() if hasattr(ocean_time, "isoformat") and ocean_time else None,
            "latency_ms": int((time.time() - started) * 1000),
            "diagnostics": diagnostics,
            "cache": {"hit": False, "ttl_seconds": 300, "mode": "live_grid_bait_solve"},
            "payload_state": "live",
            "data_quality": {"live_ncss_erddap": True, "mock": False, "proxy": False, "fallback_used": False},
            "ts": self._now_ms(),
        }
        payload["stride"] = stride
        payload["source_resolution_deg"] = 0.25
        payload["derived_resolution_deg"] = round(0.25 / 8.0, 6)
        return self._split_cache_set(key, self._attach_truth_contract(self._attach_scene_plan(payload, scene), bbox=b, stride=stride, source_resolution_deg=0.25, derived_resolution_deg=round(0.25 / 8.0, 6), extra={"input_truth": "live_source_resolution_viewport_fetch", "layer": "bait"}))

    def _frame_cache_key(self, bbox: dict[str, float]) -> str:
        # Round loosely so camera jitter reuses the same fast frame cache.
        b = self._normalize_bbox(bbox)
        rounded = [round(float(b[k]), 1) for k in ("west", "south", "east", "north")]
        return f"frame:v2:{rounded[0]},{rounded[1]},{rounded[2]},{rounded[3]}"

    def _split_cache_peek(self, key: str) -> Any:
        if not hasattr(self, "_split_payload_cache"):
            return None
        row = self._split_payload_cache.get(key)
        if not row:
            return None
        return row.get("payload")

    def _split_cache_row(self, key: str) -> dict[str, Any] | None:
        if not hasattr(self, "_split_payload_cache"):
            return None
        row = self._split_payload_cache.get(key)
        return row if isinstance(row, dict) else None

    def _split_cache_age_seconds(self, key: str) -> int | None:
        row = self._split_cache_row(key)
        if not row:
            return None
        try:
            return max(0, int(time.time() - float(row.get("time", 0))))
        except Exception:
            return None

    def _split_cache_inflight(self) -> set[str]:
        if not hasattr(self, "_split_warm_inflight"):
            self._split_warm_inflight = set()
        return self._split_warm_inflight

    def _schedule_split_warm(self, key: str, label: str, builder) -> bool:
        """Run a split payload builder in the background.

        This is the core cache-first rule for viewport changes: API callers get
        memory/stale/queued cache immediately while the slow provider work happens
        off the request path.  Errors stay visible in provider/payload debug and
        are not swallowed as fake data.
        """
        inflight = self._split_cache_inflight()
        if key in inflight:
            return False
        inflight.add(key)

        def _run() -> None:
            try:
                payload = builder()
                if isinstance(payload, dict):
                    payload.setdefault("cache", {})["warmed_by"] = label
                    payload["cache"]["warmed_at"] = self._now_ms()
                    payload["cache"]["key"] = key
                    self._split_cache_set(key, payload)
            except Exception as exc:
                level = log.info if isinstance(exc, FileNotFoundError) else log.warning
                level("[gfs/cache] split warm failed label=%s key=%s err=%s", label, key, exc)
            finally:
                try:
                    inflight.discard(key)
                except Exception:
                    pass

        threading.Thread(target=_run, name=f"gfs-{label}-warm", daemon=True).start()
        return True

    def _cache_first_split_payload(self, *, key: str, label: str, ttl_seconds: int, stale_seconds: int, builder, shell_factory):
        cached = self._split_cache_get(key, ttl_seconds)
        if isinstance(cached, dict):
            out = dict(cached)
            out.setdefault("cache", {})["hit"] = True
            out["cache"]["mode"] = "fresh_memory_cache"
            out["cache"]["age_sec"] = self._split_cache_age_seconds(key)
            return out
        stale = self._split_cache_peek(key)
        scheduled = self._schedule_split_warm(key, label, builder)
        if isinstance(stale, dict):
            out = dict(stale)
            out.setdefault("cache", {})["hit"] = True
            out["cache"]["mode"] = "stale_while_revalidate"
            out["cache"]["age_sec"] = self._split_cache_age_seconds(key)
            out["cache"]["refresh_scheduled"] = scheduled
            out["payload_state"] = "stale_while_revalidate"
            return out
        shell = shell_factory() if callable(shell_factory) else {}
        if not isinstance(shell, dict):
            shell = {}
        shell.setdefault("ok", True)
        shell.setdefault("status", "warming")
        shell.setdefault("source", "cache_first_queued")
        shell.setdefault("cache", {})["hit"] = False
        shell["cache"].update({"mode": "queued_background_warm", "refresh_scheduled": scheduled, "key": key, "ttl_seconds": ttl_seconds, "stale_seconds": stale_seconds})
        shell["payload_state"] = "warming"
        shell["ts"] = self._now_ms()
        return shell

    def _frame_quick_shell(self, bbox_norm: dict[str, float], tile_plan: dict[str, Any], reason: str = "quick_return", visible_bbox: dict[str, float] | None = None) -> Dict[str, Any]:
        """Return a browser-safe frame without live NCSS/HYCOM/ERDDAP work.

        This prevents the frontend's 30s AbortController from killing /gfs/api/frame.
        Heavy source work is warmed separately and then appears on later calls.
        """
        now_ms = self._now_ms()
        scene = self.build_scene_plan(bbox_norm, visible_bbox, layer="frame")
        work_bbox = tile_plan.get("work_bbox") or self._bounded_work_bbox(bbox_norm)
        points, _ = self.load_fish()
        markers = []
        for p in points:
            lat = safe_float(p.get("lat"), 999)
            lon = safe_float(p.get("lon"), 999)
            if work_bbox["south"] <= lat <= work_bbox["north"] and work_bbox["west"] <= lon <= work_bbox["east"]:
                markers.append(p)
        empty_bait = {
            "ok": True,
            "schema": "bait_ocean_field_v1",
            "source": "fast_frame_waiting_for_tile_cache",
            "mode": "deferred_tile_refresh",
            "bait": {"status": "warming", "source": "tile_cache", "polygons": []},
            "bait_score": [],
            "front_lines": [],
            "convergence_polygons": [],
            "boil_probability_polygons": [],
            "confidence": {"overall": 0.0, "reason": "warming"},
            "valid_time": datetime.fromtimestamp(now_ms / 1000, tz=timezone.utc).isoformat(),
        }
        empty_ocean = {
            "ok": True,
            "source": "fast_frame_waiting_for_tile_cache",
            "mode": "deferred_tile_refresh",
            "points": [],
            "boats": [],
            "boat_count": 0,
            "currentZones": {"ok": True, "polygons": [], "status": "warming"},
            "diagnostics": {"reason": reason},
            "ts": now_ms,
        }
        return {
            "ok": True,
            "model": "GFS",
            "payload_state": "fast_partial",
            "valid_time": None,
            "weather": {"ok": True, "source": "deferred_tile_cache", "fields": {}, "summary": {}, "status": "warming"},
            "clouds": {"ok": True, "source": "deferred_tile_cache", "source_state": "warming", "payload_state": "warming", "scene": {}, "features": [], "items": [], "status": "warming", "quality_note": "Waiting for real GFS cloud tile data; no synthetic clouds drawn."},
            "boats": {"ok": True, "source": "deferred_tile_cache", "mode": "warming", "boats": [], "count": 0, "ts": now_ms},
            "baitAdvanced": empty_bait,
            "baitBase": empty_bait,
            "ocean": empty_ocean,
            "sourceDiagnostics": {"ok": True, "status": "deferred", "reason": reason, "bbox": work_bbox, "ts": now_ms},
            "scene_plan": scene,
            "scene_tier": scene.get("tier"),
            "visible_bbox": scene.get("visible_bbox"),
            "fetch_bbox": scene.get("fetch_bbox"),
            "render_budget": scene.get("render_budget"),
            "tilePlan": tile_plan,
            "markers": markers[:200],
            "bbox_requested": bbox_norm,
            "viewport_bbox": bbox_norm,
            "cache_bbox": work_bbox,
            "bounds_policy": {"mode": "padded_viewport", "factor": float(os.getenv("GFS_VIEWPORT_PAD_FACTOR", "1.25") or "1.25")},
            "bbox": work_bbox,
            "cache": {"hit": False, "mode": "quick_shell", "heavy_refresh_deferred": True},
            "frame": {
                "wind_knots": None,
                "wave_feet": None,
                "cloud_pct": None,
                "current_knots": None,
                "sst_f": None,
                "updated_at": now_ms,
            },
        }

    def _frame_payload_heavy(self, bbox_norm: dict[str, float], visible_bbox: dict[str, float] | None = None) -> Dict[str, Any]:
        """Original composite solve, but only for bounded work boxes/background warmers."""
        scene = self.build_scene_plan(bbox_norm, visible_bbox, layer="frame")
        points, _ = self.load_fish()
        now_ms = self._now_ms()
        tile_plan = self.tile_plan_payload(bbox_norm, max_tiles=9)
        work_bbox = scene.get("fetch_bbox") or tile_plan.get("work_bbox") or self._bounded_work_bbox(bbox_norm)
        ocean = self.ocean_payload(work_bbox, visible_bbox=scene.get("visible_bbox"))
        boats_payload = self.boats_payload(work_bbox, visible_bbox=scene.get("visible_bbox"))
        bait_payload = self.bait_advanced_payload(work_bbox, visible_bbox=scene.get("visible_bbox"))
        try:
            clouds = self.cloud_tiles_payload(work_bbox, visible_bbox=scene.get("visible_bbox"))
            weather = {
                "ok": clouds.get("ok", True),
                "valid_time": clouds.get("valid_time") or (clouds.get("meta") or {}).get("valid_time"),
                "source": clouds.get("source") or (clouds.get("meta") or {}).get("source_name"),
                "fields": clouds.get("fields") or {},
                "summary": clouds.get("summary") or {},
            }
        except Exception as exc:
            log.warning("[gfs] frame background weather/cloud solve sparse bbox=%s err=%s", bbox_norm, exc)
            clouds = {"ok": False, "error": str(exc), "scene": {}}
            weather = {"ok": False, "error": str(exc), "fields": {}}
        payload = {
            "ok": True,
            "model": "GFS",
            "payload_state": "cached_fullish",
            "valid_time": weather.get("valid_time") if isinstance(weather, dict) else None,
            "weather": weather,
            "clouds": clouds,
            "boats": boats_payload,
            "baitAdvanced": bait_payload,
            "baitBase": bait_payload,
            "ocean": ocean,
            "sourceDiagnostics": self.source_diagnostics_payload(work_bbox),
            "scene_plan": scene,
            "scene_tier": scene.get("tier"),
            "visible_bbox": scene.get("visible_bbox"),
            "fetch_bbox": scene.get("fetch_bbox"),
            "render_budget": scene.get("render_budget"),
            "tilePlan": tile_plan,
            "bbox_requested": bbox_norm,
            "viewport_bbox": bbox_norm,
            "cache_bbox": work_bbox,
            "bounds_policy": {"mode": "padded_viewport", "factor": float(os.getenv("GFS_VIEWPORT_PAD_FACTOR", "1.25") or "1.25")},
            "bbox": work_bbox,
            "cache": {"hit": False, "mode": "background_refreshed"},
            "frame": {
                "wind_knots": None,
                "wave_feet": None,
                "cloud_pct": None,
                "current_knots": None,
                "sst_f": None,
                "updated_at": now_ms,
            },
        }
        return self._attach_scene_plan(payload, scene)

    def _schedule_frame_warm(self, bbox_norm: dict[str, float], key: str, visible_bbox: dict[str, float] | None = None) -> None:
        if not hasattr(self, "_frame_warm_inflight"):
            self._frame_warm_inflight = set()
        if key in self._frame_warm_inflight:
            return
        self._frame_warm_inflight.add(key)

        def _run() -> None:
            try:
                payload = self._frame_payload_heavy(bbox_norm, visible_bbox)
                payload.setdefault("cache", {})["warmed_at"] = self._now_ms()
                self._split_cache_set(key, payload)
            except Exception as exc:
                level = log.info if isinstance(exc, FileNotFoundError) else log.warning
                level("[gfs] deferred frame warm failed key=%s err=%s", key, exc)
            finally:
                try:
                    self._frame_warm_inflight.discard(key)
                except Exception:
                    pass

        threading.Thread(target=_run, name="gfs-frame-warm", daemon=True).start()

    def frame_payload(self, bbox: dict[str, float] | None = None, visible_bbox: dict[str, float] | None = None) -> Dict[str, Any]:
        bbox_norm = self._normalize_bbox(bbox)
        scene = self.build_scene_plan(bbox_norm, visible_bbox, layer="frame")
        self.note_viewport_priority(scene.get("visible_bbox") or bbox_norm, reason="api_frame")
        key = self._frame_cache_key(bbox_norm) + f":{scene.get('tier')}"
        tile_plan = self.tile_plan_payload(bbox_norm, max_tiles=9)

        # /gfs/api/frame is now a controller/status payload by default.  The
        # frontend already gets real render geometry from /gfs/api/sea,
        # /gfs/api/clouds, /gfs/api/boats, and /gfs/api/bait-advanced.  Returning
        # a huge composite frame here caused 10-14s requests, AbortController
        # kills, and cfgrib/cache stampedes during boot.  Keep the legacy heavy
        # composite available only when explicitly requested by environment.
        lightweight_only = str(os.getenv("GFS_FRAME_LIGHTWEIGHT_ONLY", "true")).strip().lower() not in {"0", "false", "no", "off"}
        if lightweight_only:
            shell = self._frame_quick_shell(bbox_norm, tile_plan, reason="frame_lightweight_controller_no_heavy_composite", visible_bbox=scene.get("visible_bbox"))
            shell["payload_state"] = "frame_controller_shell"
            shell.setdefault("cache", {}).update({
                "hit": False,
                "mode": "frame_lightweight_controller",
                "heavy_composite_disabled": True,
                "key": key,
            })
            shell["frame_sources"] = {
                "render_geometry": ["/gfs/api/sea", "/gfs/api/clouds"],
                "ocean_boats": ["/gfs/api/boats"],
                "bait": ["/gfs/api/bait-advanced"],
                "cache": ["/gfs/api/tiles", "/gfs/api/cache-warm/status"],
                "policy": "frame stays fast; layer endpoints carry the heavy payloads",
            }
            return shell

        cached = self._split_cache_get(key, int(os.getenv("GFS_FRAME_CACHE_TTL_SECONDS", "120")))
        if cached:
            out = dict(cached)
            out.setdefault("cache", {})["hit"] = True
            out["cache"]["mode"] = "memory_frame_cache"
            return out

        stale = self._split_cache_peek(key)
        warm_enabled = str(os.getenv("GFS_FRAME_HEAVY_WARM", "false")).strip().lower() in {"1", "true", "yes", "on"}
        scheduled = False
        if warm_enabled:
            self._schedule_frame_warm(bbox_norm, key, scene.get("visible_bbox"))
            scheduled = True
        if stale:
            out = dict(stale)
            out.setdefault("cache", {})["hit"] = True
            out["cache"]["mode"] = "stale_while_revalidate" if scheduled else "stale_frame_cache_no_refresh"
            out["payload_state"] = "stale_while_revalidate" if scheduled else "stale_frame_cache"
            return out
        return self._frame_quick_shell(bbox_norm, tile_plan, reason="first_request_deferred_background_warm" if scheduled else "first_request_frame_shell_no_heavy_warm", visible_bbox=scene.get("visible_bbox"))


    def _cache_warm_status_payload(self) -> dict[str, Any]:
        state = getattr(self, "_globe_cache_warm_state", None)
        if not isinstance(state, dict):
            return {"running": False, "started": False, "message": "no warm has been scheduled", "ts": self._now_ms()}
        out = dict(state)
        out["ts"] = self._now_ms()
        return out

    def cache_warm_status_payload(self) -> dict[str, Any]:
        return {"ok": True, "schema": "lftr_globe_cache_warm_status_v1", "warm": self._cache_warm_status_payload()}

    def schedule_globe_cache_warm(self, bbox: dict[str, float] | None = None, max_tiles: int = 512, reason: str = "website_load", visible_bbox: dict[str, float] | None = None, layers: list[str] | None = None) -> dict[str, Any]:
        """Kick a center-first global cache warm without blocking the web request.

        The browser should load from whatever disk/memory cache exists immediately.
        This warmer then refreshes the selected center tile, visible tiles, and rings
        outward. It writes compact tile products to disk and releases memory per tile.
        This build is tuned for the LFTR e2 2-vCPU / 16GB RAM VM profile: bounded
        I/O parallelism, larger live build batches, and conservative CPU decode.
        """
        requested = self._normalize_bbox(bbox)
        scene = self.build_scene_plan(requested, visible_bbox, layer="cache-warm")
        try:
            max_tiles_i = max(1, min(int(max_tiles or 512), 512))
        except Exception:
            max_tiles_i = 512
        plan = self.tile_plan_payload(requested, max_tiles=max_tiles_i)
        requested_layers = {str(x).strip().lower() for x in (layers or []) if str(x).strip()}
        if not hasattr(self, "_globe_cache_warm_lock"):
            self._globe_cache_warm_lock = threading.Lock()
        with self._globe_cache_warm_lock:
            state = getattr(self, "_globe_cache_warm_state", {}) or {}
            if state.get("running"):
                return {"ok": True, "schema": "lftr_globe_cache_warm_v1", "scheduled": False, "reason": "already_running", "plan": plan, "warm": self._cache_warm_status_payload()}
            run_id = f"warm-{self._now_ms()}"
            self._globe_cache_warm_state = {
                "running": True,
                "started": True,
                "run_id": run_id,
                "reason": reason,
                "requested_bbox": requested,
                "scene_plan": scene,
                "visible_bbox": scene.get("visible_bbox"),
                "fetch_bbox": scene.get("fetch_bbox"),
                "center": plan.get("center"),
                "total_tiles_requested": len(plan.get("tiles") or []),
                "concurrency": int(os.getenv("GFS_TILE_WARM_WORKERS", "3") or "3"),
                "tile_count_policy": "plan_up_to_512_tiles_but_build_live_only_center_first_limit_env_GFS_TILE_WARM_BUILD_LIMIT_default_32",
                "download_policy": "bounded_parallel_live_tile_refresh_cache_first_read_only_browser_tiles",
                "scene_tile_product": "gzip_json_large_diverse_payload_contracts",
                "completed_tiles": 0,
                "failed_tiles": 0,
                "last_tile_id": None,
                "started_at": self._now_ms(),
                "finished_at": None,
                "message": "warming bounded center-first gzip scene-tile point cache",
                "requested_layers": sorted(requested_layers) if requested_layers else ["all"],
                "route_policy": "only requested layer contracts are live-built; omitted pills return not_requested shells",
            }

        def _run() -> None:
            try:
                # Do not build the full frame inside the cache warmer.  The frame
                # endpoint is independently cache-first; doing a full frame plus 512
                # tile contract builds in one background run can starve /ws/gfs and
                # cause nginx 502s on small VMs.
                tiles = list(plan.get("tiles") or [])
                try:
                    live_build_limit = max(1, min(int(os.getenv("GFS_TILE_WARM_BUILD_LIMIT", "32") or "32"), len(tiles), 160))
                except Exception:
                    live_build_limit = min(32, len(tiles), 160)
                tiles_to_build = tiles[:live_build_limit]
                with self._globe_cache_warm_lock:
                    st = self._globe_cache_warm_state
                    st["live_build_limit"] = live_build_limit
                    st["message"] = "warming bounded live scene-tile point cache; uncached tiles stay cache-miss placeholders"
                # Warm many small tiles in parallel. Each worker is synchronous for a
                # single tile, but the thread pool lets NCSS/cache exchanges overlap.
                # Existing disk cache is read first by tile_intel_payload(); ttl=0 then
                # refreshes the compact tile product while provider-level caches keep
                # network use bounded.
                workers = max(1, min(int(os.getenv("GFS_TILE_WARM_WORKERS", "3") or "3"), 12))

                def _warm_one(item: dict[str, Any]) -> dict[str, Any]:
                    tid = str(item.get("tile_id") or "")
                    if not tid:
                        return {"ok": False, "tile_id": None, "error": "missing_tile_id"}
                    payload = self.tile_intel_payload(tid, ttl_seconds=0, visible_bbox=scene.get("visible_bbox"), allowed_layers=requested_layers)
                    return {"ok": True, "tile_id": tid, "latency_ms": payload.get("latency_ms"), "cache_hit": bool((payload.get("cache") or {}).get("hit"))}

                with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="gfs-tile-warm") as pool:
                    futures = [pool.submit(_warm_one, item) for item in tiles_to_build if item.get("tile_id")]
                    for fut in as_completed(futures):
                        try:
                            result = fut.result()
                            tid = str(result.get("tile_id") or "")
                            with self._globe_cache_warm_lock:
                                st = self._globe_cache_warm_state
                                if result.get("ok"):
                                    st["completed_tiles"] = int(st.get("completed_tiles") or 0) + 1
                                else:
                                    st["failed_tiles"] = int(st.get("failed_tiles") or 0) + 1
                                    st["last_error"] = str(result.get("error") or "tile warm failed")
                                st["last_tile_id"] = tid
                                st["message"] = "warming parallel small scene-tile point cache"
                        except Exception as exc:
                            log.warning("[gfs] tile warm failed err=%s", exc)
                            with self._globe_cache_warm_lock:
                                st = self._globe_cache_warm_state
                                st["failed_tiles"] = int(st.get("failed_tiles") or 0) + 1
                                st["last_error"] = str(exc)
                with self._globe_cache_warm_lock:
                    st = self._globe_cache_warm_state
                    st["running"] = False
                    st["finished_at"] = self._now_ms()
                    st["message"] = "scene-tile point cache warm complete"
            except Exception as exc:
                log.warning("[gfs] globe cache warm crashed err=%s", exc)
                try:
                    with self._globe_cache_warm_lock:
                        st = self._globe_cache_warm_state
                        st["running"] = False
                        st["finished_at"] = self._now_ms()
                        st["message"] = "cache warm failed"
                        st["last_error"] = str(exc)
                except Exception:
                    pass

        threading.Thread(target=_run, name="gfs-globe-cache-warm", daemon=True).start()
        return {"ok": True, "schema": "lftr_globe_cache_warm_v1", "scheduled": True, "reason": reason, "requested_layers": sorted(requested_layers) if requested_layers else ["all"], "route_policy": "cache-warm builds only requested visual contracts", "scene_plan": scene, "plan": plan, "warm": self._cache_warm_status_payload()}


    def _lightning_cache_path(self, bbox: dict[str, float] | None = None, product: str = "goes_glm") -> Path:
        b = self._normalize_bbox(bbox)
        sig = f"{b.get('west',0):.2f}_{b.get('south',0):.2f}_{b.get('east',0):.2f}_{b.get('north',0):.2f}"
        safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", sig)[:96]
        path = DEFAULT_GFS_CACHE_DIR / "lightning"
        path.mkdir(parents=True, exist_ok=True)
        return path / f"{product}_{safe}.json.gz"

    def _read_lightning_cache(self, bbox: dict[str, float] | None = None, ttl_seconds: int = 90) -> dict[str, Any] | None:
        path = self._lightning_cache_path(bbox)
        if not path.exists():
            return None
        try:
            age = time.time() - path.stat().st_mtime
            if ttl_seconds >= 0 and age > ttl_seconds:
                return None
            import gzip
            with gzip.open(path, "rt", encoding="utf-8") as fh:
                payload = json.load(fh)
            if isinstance(payload, dict):
                payload.setdefault("cache", {})
                payload["cache"].update({"hit": True, "age_seconds": round(age, 3), "path": str(path)})
                payload.setdefault("payload_state", "cache_hit")
                return payload
        except Exception as exc:
            log.debug("lightning cache read skipped err=%s", exc)
        return None

    def _write_lightning_cache(self, bbox: dict[str, float] | None, payload: dict[str, Any]) -> dict[str, Any]:
        path = self._lightning_cache_path(bbox)
        tmp = path.with_suffix(path.suffix + ".tmp")
        try:
            import gzip
            safe_payload = self._json_safe_for_tile_cache(payload)
            with gzip.open(tmp, "wt", encoding="utf-8", compresslevel=5) as fh:
                json.dump(safe_payload, fh, separators=(",", ":"), ensure_ascii=False)
            tmp.replace(path)
        except Exception as exc:
            log.debug("lightning cache write skipped err=%s", exc)
        return payload

    def _goes_glm_s3_bases(self) -> list[tuple[str, str]]:
        # GOES-19 is current GOES-East; GOES-18 is current GOES-West.  These
        # buckets are public NOAA Open Data buckets.  Override with
        # GFS_GLM_SATELLITES="19,18" if needed.
        sats = os.getenv("GFS_GLM_SATELLITES", "19,18").replace("GOES", "").replace("goes", "")
        out: list[tuple[str, str]] = []
        for raw in re.split(r"[,;\s]+", sats):
            sat = raw.strip().lstrip("0")
            if not sat:
                continue
            if sat not in {"16", "17", "18", "19"}:
                continue
            out.append((f"GOES-{sat}", f"https://noaa-goes{sat}.s3.amazonaws.com"))
        return out or [("GOES-19", "https://noaa-goes19.s3.amazonaws.com"), ("GOES-18", "https://noaa-goes18.s3.amazonaws.com")]

    def _list_goes_glm_keys(self, base: str, when: datetime, limit: int = 12) -> list[str]:
        # NOAA S3 prefix example: GLM-L2-LCFA/2026/152/05/
        prefix = f"GLM-L2-LCFA/{when:%Y}/{when.timetuple().tm_yday:03d}/{when:%H}/"
        url = f"{base}/?list-type=2&prefix={prefix}"
        try:
            r = requests.get(url, timeout=(4, 12), headers={"User-Agent": DEFAULT_UA})
            if r.status_code != 200:
                return []
            import xml.etree.ElementTree as ET
            ns = {"s3": "http://s3.amazonaws.com/doc/2006-03-01/"}
            root = ET.fromstring(r.text)
            keys = []
            for node in root.findall(".//s3:Key", ns):
                txt = (node.text or "").strip()
                if txt.endswith(".nc") and "GLM-L2-LCFA" in txt:
                    keys.append(txt)
            return sorted(keys)[-max(1, int(limit)):]
        except Exception as exc:
            log.debug("GOES GLM list skipped url=%s err=%s", url, exc)
            return []

    def _download_goes_glm_nc(self, base: str, key: str) -> Path | None:
        cache_dir = DEFAULT_GFS_CACHE_DIR / "lightning" / "glm_nc"
        cache_dir.mkdir(parents=True, exist_ok=True)
        name = re.sub(r"[^A-Za-z0-9_.-]+", "_", key)[-160:]
        path = cache_dir / name
        if path.exists() and path.stat().st_size > 0:
            return path
        try:
            url = f"{base}/{key}"
            r = requests.get(url, timeout=(5, 30), headers={"User-Agent": DEFAULT_UA})
            if r.status_code != 200 or not r.content:
                return None
            tmp = path.with_suffix(path.suffix + ".tmp")
            tmp.write_bytes(r.content)
            tmp.replace(path)
            return path
        except Exception as exc:
            log.debug("GOES GLM download skipped key=%s err=%s", key, exc)
            return None

    def _read_goes_glm_flashes(self, path: Path, platform: str, bbox: dict[str, float], now: datetime) -> list[dict[str, Any]]:
        if xr is None:
            return []
        try:
            ds = xr.open_dataset(path, engine="netcdf4")
        except Exception:
            try:
                ds = xr.open_dataset(path)
            except Exception as exc:
                log.debug("GOES GLM nc open skipped path=%s err=%s", path, exc)
                return []
        try:
            lat_name = "flash_lat" if "flash_lat" in ds.variables else None
            lon_name = "flash_lon" if "flash_lon" in ds.variables else None
            if not lat_name or not lon_name:
                return []
            lats = ds[lat_name].values
            lons = ds[lon_name].values
            energies = ds["flash_energy"].values if "flash_energy" in ds.variables else [None] * len(lats)
            areas = ds["flash_area"].values if "flash_area" in ds.variables else [None] * len(lats)
            times = None
            for tname in ("flash_time_offset_of_first_event", "flash_time_offset_of_last_event", "flash_time_offset_of_first_event"):
                if tname in ds.variables:
                    times = ds[tname].values
                    break
            out = []
            west, south, east, north = [float(bbox[k]) for k in ("west", "south", "east", "north")]
            for i in range(min(len(lats), int(os.getenv("GFS_GLM_MAX_FLASHES_PER_FILE", "1200")))):
                try:
                    lat = float(lats[i]); lon = float(lons[i])
                    if not (south <= lat <= north and west <= lon <= east):
                        continue
                    energy = float(energies[i]) if energies is not None and energies[i] is not None else None
                    area = float(areas[i]) if areas is not None and areas[i] is not None else None
                    # GLM time variable is seconds relative to dataset epoch; xarray
                    # often decodes it to timedelta64. Keep a safe string if possible.
                    tstr = None; age = None
                    try:
                        tv = times[i] if times is not None else None
                        if tv is not None:
                            tstr = str(tv)
                    except Exception:
                        pass
                    out.append({
                        "lat": round(lat, 5), "lon": round(lon, 5),
                        "energy_j": energy, "area_m2": area,
                        "time": tstr, "valid_time": tstr,
                        "age_seconds": age if age is not None else 0,
                        "satellite": platform, "platform": platform,
                        "source": "goes_glm_l2_lcfa", "product": "GLM-L2-LCFA",
                    })
                except Exception:
                    continue
            return out
        finally:
            try: ds.close()
            except Exception: pass

    def _cluster_lightning_regions(self, flashes: list[dict[str, Any]]) -> list[dict[str, Any]]:
        buckets: dict[tuple[int, int], list[dict[str, Any]]] = {}
        for f in flashes:
            try:
                key = (int(float(f.get("lat")) * 2), int(float(f.get("lon")) * 2))  # ~0.5 degree cells
                buckets.setdefault(key, []).append(f)
            except Exception:
                continue
        regions = []
        for _key, items in buckets.items():
            if not items:
                continue
            lat = sum(float(x.get("lat")) for x in items) / len(items)
            lon = sum(float(x.get("lon")) for x in items) / len(items)
            energy = sum(float(x.get("energy_j") or 0.0) for x in items)
            regions.append({
                "center": {"lat": round(lat, 5), "lon": round(lon, 5)},
                "flash_count": len(items),
                "energy_j_sum": energy,
                "age_seconds": min(float(x.get("age_seconds") or 0.0) for x in items),
                "source": "goes_glm_l2_lcfa",
            })
        return sorted(regions, key=lambda r: int(r.get("flash_count") or 0), reverse=True)[:80]

    def _lightning_cache_shell(self, visible: dict[str, float], scene: dict[str, Any], minutes: int, reason: str = "queued_background_warm") -> dict[str, Any]:
        now = datetime.now(timezone.utc)
        return self._attach_scene_plan({
            "ok": True,
            "schema": "lftr_lightning_v1",
            "source": "goes_glm_l2_lcfa_cache_first",
            "payload_state": "warming",
            "mode": "stale_while_revalidate_no_direct_provider_block",
            "valid_window_minutes": minutes,
            "bbox": [visible["west"], visible["south"], visible["east"], visible["north"]],
            "bbox_used": [visible["west"], visible["south"], visible["east"], visible["north"]],
            "flashes": [],
            "items": [],
            "regions": [],
            "count": 0,
            "fallback_used": False,
            "mock": False,
            "proxy": False,
            "quality": {"live_goes_glm": False, "fallback_used": False, "mock": False, "proxy": False},
            "cache": {"hit": False, "mode": "queued_background_warm", "ttl_seconds": int(os.getenv("GFS_GLM_CACHE_TTL_SECONDS", "180") or "180"), "reason": reason},
            "diagnostics": {"note": "Lightning is cache-first; slow GOES/GLM provider work is running off the browser request path."},
            "generated_at": now.isoformat(),
        }, scene)

    def _schedule_lightning_warm(self, requested: dict[str, float], visible: dict[str, float], minutes: int, scene: dict[str, Any]) -> None:
        if os.getenv("GFS_DISABLE_GLM", "false").strip().lower() in {"1", "true", "yes", "on"}:
            return
        if not hasattr(self, "_lightning_warm_inflight"):
            self._lightning_warm_inflight = set()
        key = self._bbox_cache_key("lightning", visible) + f":{int(minutes or 20)}"
        if key in self._lightning_warm_inflight:
            return
        self._lightning_warm_inflight.add(key)

        def _run() -> None:
            try:
                self._lightning_payload_live(requested, visible, minutes)
            except Exception as exc:
                log.warning("[gfs lightning] deferred warm failed key=%s err=%s", key, exc)
            finally:
                try:
                    self._lightning_warm_inflight.discard(key)
                except Exception:
                    pass

        threading.Thread(target=_run, name="gfs-lightning-warm", daemon=True).start()

    def lightning_payload(self, bbox: dict[str, float] | None = None, visible_bbox: dict[str, float] | None = None, minutes: int = 20) -> dict[str, Any]:
        requested = self._normalize_bbox(bbox)
        visible = self._normalize_bbox(visible_bbox or requested)
        scene = self.build_scene_plan(requested, visible, layer="lightning")
        ttl = int(os.getenv("GFS_GLM_CACHE_TTL_SECONDS", "180") or "180")
        cached = self._read_lightning_cache(visible, ttl_seconds=ttl)
        if cached:
            cached["payload_state"] = "cache_hit_live_recent"
            cached["cache"] = {"hit": True, "mode": "fresh_lightning_cache", "ttl_seconds": ttl}
            cached["scene_plan"] = scene
            return cached
        stale = self._read_lightning_cache(visible, ttl_seconds=-1)
        self._schedule_lightning_warm(requested, visible, minutes, scene)
        if stale:
            stale["payload_state"] = "stale_while_revalidate"
            stale["cache"] = {"hit": True, "mode": "stale_while_revalidate", "ttl_seconds": ttl}
            stale["scene_plan"] = scene
            return stale
        return self._lightning_cache_shell(visible, scene, minutes)

    def _lightning_payload_live(self, bbox: dict[str, float] | None = None, visible_bbox: dict[str, float] | None = None, minutes: int = 20) -> dict[str, Any]:
        requested = self._normalize_bbox(bbox)
        visible = self._normalize_bbox(visible_bbox or requested)
        scene = self.build_scene_plan(requested, visible, layer="lightning")
        ttl = int(os.getenv("GFS_GLM_CACHE_TTL_SECONDS", "60"))
        cached = self._read_lightning_cache(visible, ttl_seconds=ttl)
        if cached:
            cached["payload_state"] = "cache_hit_live_recent"
            cached["scene_plan"] = scene
            return cached
        if os.getenv("GFS_DISABLE_GLM", "false").strip().lower() in {"1", "true", "yes", "on"}:
            return self._attach_scene_plan({
                "ok": False, "schema": "lftr_lightning_v1", "source": "goes_glm_disabled",
                "payload_state": "disabled", "flashes": [], "items": [], "regions": [],
                "fallback_used": False, "mock": False, "proxy": False,
            }, scene)
        now = datetime.now(timezone.utc)
        flashes: list[dict[str, Any]] = []
        diagnostics: list[dict[str, Any]] = []
        hours = [now - timedelta(hours=h) for h in range(0, max(1, int(math.ceil(max(1, minutes) / 60)) + 2))]
        per_hour_keys = int(os.getenv("GFS_GLM_KEYS_PER_HOUR", "8"))
        for platform, base in self._goes_glm_s3_bases():
            before = len(flashes)
            for wh in hours:
                keys = self._list_goes_glm_keys(base, wh, limit=per_hour_keys)
                diagnostics.append({"platform": platform, "hour": wh.strftime("%Y-%j-%H"), "keys": len(keys)})
                for key in keys:
                    path = self._download_goes_glm_nc(base, key)
                    if not path:
                        continue
                    flashes.extend(self._read_goes_glm_flashes(path, platform, visible, now))
                    if len(flashes) >= int(os.getenv("GFS_GLM_MAX_FLASHES", "1500")):
                        break
                if len(flashes) >= int(os.getenv("GFS_GLM_MAX_FLASHES", "1500")):
                    break
            diagnostics[-1:]
            diagnostics.append({"platform": platform, "flashes_added": len(flashes) - before})
        # De-duplicate near-identical flashes.
        seen = set(); unique = []
        for f in flashes:
            key = (round(float(f.get("lat") or 0), 3), round(float(f.get("lon") or 0), 3), str(f.get("satellite")))
            if key in seen:
                continue
            seen.add(key); unique.append(f)
        unique = unique[: int(os.getenv("GFS_GLM_MAX_FLASHES", "1500"))]
        payload = {
            "ok": True,
            "schema": "lftr_lightning_v1",
            "source": "goes_glm_l2_lcfa",
            "payload_state": "live" if unique else "provider_empty",
            "valid_window_minutes": minutes,
            "bbox": [visible["west"], visible["south"], visible["east"], visible["north"]],
            "bbox_used": [visible["west"], visible["south"], visible["east"], visible["north"]],
            "flashes": unique,
            "items": unique,
            "regions": self._cluster_lightning_regions(unique),
            "count": len(unique),
            "fallback_used": False, "mock": False, "proxy": False,
            "quality": {"live_goes_glm": bool(unique), "fallback_used": False, "mock": False, "proxy": False},
            "diagnostics": {"providers": diagnostics, "satellites": [p for p, _ in self._goes_glm_s3_bases()], "note": "GOES GLM Level 2 LCFA flash_lat/flash_lon filtered to visible bbox"},
            "generated_at": now.isoformat(),
        }
        payload = self._attach_scene_plan(payload, scene)
        # Cache both positive and provider-empty GLM results.  Empty-but-fresh is
        # still valuable; without this, every browser refresh can re-trigger a
        # slow GOES/GLM scan that returns no flashes after tens of seconds.
        self._write_lightning_cache(visible, payload)
        return payload

    def note_viewport_priority(self, bbox: dict[str, float] | None = None, reason: str = "viewport") -> dict[str, Any]:
        """Remember a browser viewport as high priority without blocking."""
        b = self._normalize_bbox(bbox)
        b["noted_at"] = self._now_ms()
        b["reason"] = reason
        recent = [x for x in getattr(self, "_recent_viewports", []) if isinstance(x, dict)]
        sig = tuple(round(float(b[k]), 2) for k in ("west", "south", "east", "north"))
        filtered = []
        for old in recent:
            try:
                old_sig = tuple(round(float(old[k]), 2) for k in ("west", "south", "east", "north"))
                if old_sig == sig:
                    continue
            except Exception:
                pass
            filtered.append(old)
        self._recent_viewports = [b] + filtered[:11]
        return {"ok": True, "viewport_bbox": self._normalize_bbox(b), "cache_bbox": self._bounded_work_bbox(b), "reason": reason}

    def _default_boot_bboxes(self) -> list[dict[str, float]]:
        """Priority bboxes for no-browser always-on warming."""
        env = os.getenv("GFS_ALWAYS_ON_BOOT_BBOXES", "").strip()
        out: list[dict[str, float]] = []
        if env:
            for chunk in env.split(";"):
                try:
                    w, s, e, n = [float(x.strip()) for x in chunk.split(",")[:4]]
                    out.append({"west": w, "south": s, "east": e, "north": n})
                except Exception:
                    continue
        if out:
            return out[:12]
        try:
            points, _ = self.load_fish()
            pts = []
            for p in points[:80]:
                lat = safe_float(p.get("lat"), 999)
                lon = safe_float(p.get("lon"), 999)
                if -80 <= lat <= 80 and -180 <= lon <= 180:
                    pts.append((lat, lon))
            if pts:
                lats = [p[0] for p in pts]
                lons = [p[1] for p in pts]
                out.append({"west": max(-180, min(lons) - 1.0), "south": max(-80, min(lats) - 1.0), "east": min(180, max(lons) + 1.0), "north": min(80, max(lats) + 1.0)})
        except Exception:
            pass
        out.append({"west": -121.0, "south": 31.5, "east": -116.0, "north": 35.5})
        return out[:6]

    def start_always_on_cache(self) -> dict[str, Any]:
        """Start the server-resident 5-minute cache warmer daemon."""
        state = getattr(self, "_always_on_cache_state", {})
        if not state.get("enabled", True):
            return {"ok": True, "started": False, "reason": "disabled", "cache": state}
        if self._always_on_cache_started:
            return {"ok": True, "started": False, "reason": "already_started", "cache": state}
        self._always_on_cache_started = True
        state["running"] = True
        state["started_at"] = self._now_ms()
        def _loop() -> None:
            interval = max(60, int(state.get("interval_sec") or 300))
            max_tiles = max(1, min(int(os.getenv("GFS_ALWAYS_ON_MAX_TILES", "384") or "384"), 512))
            while True:
                try:
                    state["last_tick"] = self._now_ms()
                    candidates = list(getattr(self, "_recent_viewports", []) or [])[:4] + self._default_boot_bboxes()
                    scheduled = []
                    for i, bbox in enumerate(candidates[:6]):
                        # Always-on warming should keep the map responsive, not hammer every remote provider.
                        # Ocean/bait/boats warm only when the browser explicitly asks for those layers.
                        base_layers = ["clouds", "rain", "inland-water", "lightning"]
                        result = self.schedule_globe_cache_warm(bbox, max_tiles=max_tiles, reason="always_on_5min" if i == 0 else "always_on_background", layers=base_layers)
                        scheduled.append({"bbox": self._normalize_bbox(bbox), "scheduled": bool(result.get("scheduled")), "reason": result.get("reason")})
                        if result.get("scheduled"):
                            break
                    state["last_scheduled"] = scheduled
                    state["last_error"] = None
                except Exception as exc:
                    state["last_error"] = str(exc)
                    log.warning("[gfs/cache] always-on loop error: %s", exc)
                time.sleep(interval)
        t = threading.Thread(target=_loop, name="gfs-always-on-cache", daemon=True)
        self._always_on_cache_thread = t
        t.start()
        log.info("[gfs/cache] always-on cache daemon started interval=%ss pad_factor=%s", state.get("interval_sec"), state.get("pad_factor"))
        return {"ok": True, "started": True, "cache": state}

    def cache_status_payload(self) -> dict[str, Any]:
        root = self._tile_cache_root()
        files = list(root.glob("*.intel.json")) if root.exists() else []
        ages = []
        now = time.time()
        for p in files[:5000]:
            try:
                ages.append(max(0, int(now - p.stat().st_mtime)))
            except Exception:
                pass
        warm = self._cache_warm_status_payload()
        return {
            "ok": True,
            "schema": "lftr_cache_first_status_v1",
            "server_time": datetime.now(timezone.utc).isoformat(),
            "cache": {
                "enabled": True,
                "running": bool((getattr(self, "_always_on_cache_state", {}) or {}).get("running")),
                "cache_path": str(root),
                "tiles_total": len(files),
                "fresh_target_sec": int(os.getenv("GFS_CACHE_FRESH_TARGET_SEC", "240") or "240"),
                "newest_age_sec": min(ages) if ages else None,
                "oldest_age_sec_sample": max(ages) if ages else None,
                "clients_connected": "tracked_by_ws",
                "warm": warm,
                "always_on": getattr(self, "_always_on_cache_state", {}),
                "recent_viewports": list(getattr(self, "_recent_viewports", []) or [])[:6],
                "bounds_policy": {"mode": "padded_viewport", "factor": float(os.getenv("GFS_VIEWPORT_PAD_FACTOR", "1.25") or "1.25")},
            },
        }

    def contours_payload(self) -> Dict[str, Any]:
        return {"ok": True, "features": [], "ts": self._now_ms()}

    def overlay_payload(self) -> Dict[str, Any]:
        return {"ok": True, "layers": [], "ts": self._now_ms()}

    def legend_payload(self) -> Dict[str, Any]:
        return {
            "ok": True,
            "legend": [
                {"name": "Low", "color": "#1f77b4"},
                {"name": "Medium", "color": "#ff7f0e"},
                {"name": "High", "color": "#d62728"},
            ],
            "ts": self._now_ms(),
        }

    def tile_png_bytes(self, z: int, x: int, y: int) -> bytes:
        _ = (z, x, y)
        return base64.b64decode(_TRANSPARENT_PNG_BASE64)

    def location_media(self, location_key: str) -> Dict[str, Any]:
        return self._location_media_payload(location_key)

    def upsert_report(self, location_key: str, report_text: str) -> Dict[str, Any]:
        key = self._normalize_location_key(location_key)
        if not key:
            return {"ok": False, "error": "missing location_key"}
        store = self._load_store()
        rec = self._ensure_location_record(store, key)
        rec["report_text"] = (report_text or "").strip()
        rec["report_updated_at"] = self._now_ms()
        self._save_store(store)
        return {"ok": True, **self._location_media_payload(key)}

    def upsert_live(self, location_key: str, active: bool, stream_url: str) -> Dict[str, Any]:
        key = self._normalize_location_key(location_key)
        if not key:
            return {"ok": False, "error": "missing location_key"}
        store = self._load_store()
        rec = self._ensure_location_record(store, key)
        rec["live"] = {
            "active": bool(active),
            "stream_url": (stream_url or "").strip(),
            "updated_at": self._now_ms(),
        }
        self._save_store(store)
        return {"ok": True, **self._location_media_payload(key)}

    def save_upload_video(self, location_key: str, filename: str, raw: bytes) -> Dict[str, Any]:
        key = self._normalize_location_key(location_key)
        if not key:
            return {"ok": False, "error": "missing location_key"}
        if not raw:
            return {"ok": False, "error": "empty upload"}

        safe_name = secure_filename(filename or "upload.mp4")
        ext = Path(safe_name).suffix.lower()
        if ext not in _ALLOWED_VIDEO_EXTS:
            return {"ok": False, "error": f"unsupported file type: {ext or 'none'}"}

        saved_name = f"{key}-{self._now_ms()}{ext}"
        out_path = self.fishvid_dir / saved_name
        out_path.write_bytes(raw)
        media_url = f"/static/fishvid/{saved_name}"

        store = self._load_store()
        rec = self._ensure_location_record(store, key)
        uploads = rec.setdefault("uploads", [])
        uploads.insert(
            0,
            {
                "url": media_url,
                "filename": saved_name,
                "mime": f"video/{ext.lstrip('.') if ext != '.mov' else 'quicktime'}",
                "uploaded_at": self._now_ms(),
            },
        )
        rec["uploads"] = uploads[:20]
        self._save_store(store)
        return {"ok": True, "location_key": key, "media_url": media_url, **self._location_media_payload(key)}

    async def ws_snapshot(self) -> Dict[str, Any]:
        cloud_payload = self.cloud_tiles_payload()
        return {
            "type": "gfs_update",
            "health": self.health(),
            "frame": self.frame_payload().get("frame", {}),
            "clouds": {
                "updated_at": cloud_payload.get("updated_at"),
                "summary": cloud_payload.get("summary", {}),
                "source": cloud_payload.get("source"),
            },
            "ts": self._now_ms(),
        }
