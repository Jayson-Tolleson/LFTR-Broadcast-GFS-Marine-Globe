"""FastAPI sidecar for LFTR /gfs high-speed derivation endpoints."""
