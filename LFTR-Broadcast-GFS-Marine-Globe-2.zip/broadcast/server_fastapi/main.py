from __future__ import annotations

import os
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from .sea_engine import SeaOfIntelligenceEngine, parse_bbox

APP_TITLE = 'LFTR FastAPI Sea of Intelligence Engine'
ENGINE = SeaOfIntelligenceEngine(grid_size=int(os.environ.get('LFTR_SEA_GRID_SIZE', '48')))

app = FastAPI(title=APP_TITLE, version='0.1.0')
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.environ.get('LFTR_FASTAPI_CORS_ORIGINS', '').split(',') if os.environ.get('LFTR_FASTAPI_CORS_ORIGINS') else [],
    allow_credentials=True,
    allow_methods=['GET', 'POST'],
    allow_headers=['*'],
)


class SeaRequest(BaseModel):
    bbox: List[float] = Field(..., min_length=4, max_length=4)
    grid_size: Optional[int] = Field(default=None, ge=16, le=256)
    layers: Optional[List[str]] = None


@app.get('/health')
async def health() -> Dict[str, Any]:
    return {
        'ok': True,
        'service': 'lftr-fastapi-sea-engine',
        'grid_size': ENGINE.grid_size,
        'time': datetime.now(timezone.utc).isoformat(),
    }


@app.get('/gfs/api/sea')
async def sea_get(
    bbox: str = Query(..., description='west,south,east,north'),
    grid_size: Optional[int] = Query(None, ge=16, le=256),
    layers: Optional[str] = Query(None, description='comma list: clouds,rain,bait,boats,jetstream,day_night'),
) -> Dict[str, Any]:
    started = time.perf_counter()
    try:
        parsed = parse_bbox(bbox)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    layer_list = [x.strip() for x in layers.split(',') if x.strip()] if layers else None
    payload = await ENGINE.derive_all(parsed, grid_size=grid_size, layers=layer_list)
    payload['latency_ms'] = round((time.perf_counter() - started) * 1000.0, 2)
    return payload


@app.post('/gfs/api/sea')
async def sea_post(req: SeaRequest) -> Dict[str, Any]:
    started = time.perf_counter()
    try:
        parsed = parse_bbox(req.bbox)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    payload = await ENGINE.derive_all(parsed, grid_size=req.grid_size, layers=req.layers)
    payload['latency_ms'] = round((time.perf_counter() - started) * 1000.0, 2)
    return payload


@app.get('/gfs/api/derive/{layer}')
async def derive_layer(
    layer: str,
    bbox: str = Query(...),
    grid_size: Optional[int] = Query(None, ge=16, le=256),
) -> Dict[str, Any]:
    allowed = {'clouds', 'rain', 'bait', 'boats', 'jetstream', 'day_night'}
    if layer not in allowed:
        raise HTTPException(status_code=404, detail=f'unknown layer {layer}; allowed={sorted(allowed)}')
    started = time.perf_counter()
    try:
        parsed = parse_bbox(bbox)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    payload = await ENGINE.derive_all(parsed, grid_size=grid_size, layers=[layer])
    payload['latency_ms'] = round((time.perf_counter() - started) * 1000.0, 2)
    return payload
