from __future__ import annotations

import asyncio
import math
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Mapping, MutableMapping, Optional, Sequence, Tuple

import numpy as np

try:  # scikit-image is the intended fast path; tests/dev can still import without it.
    from skimage import measure  # type: ignore
except Exception:  # pragma: no cover - deployment installs scikit-image
    measure = None  # type: ignore

BBox = Tuple[float, float, float, float]


def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def parse_bbox(value: Any) -> BBox:
    if isinstance(value, str):
        parts = [float(p.strip()) for p in value.split(',') if p.strip()]
    elif isinstance(value, Sequence):
        parts = [float(p) for p in value]
    else:
        raise ValueError('bbox must be a comma string or four-number array')
    if len(parts) != 4:
        raise ValueError('bbox must contain west,south,east,north')
    west, south, east, north = parts
    west = _clamp(west, -179.9, 179.9)
    east = _clamp(east, -179.9, 179.9)
    south = _clamp(south, -89.9, 89.9)
    north = _clamp(north, -89.9, 89.9)
    if north <= south:
        raise ValueError('bbox north must be greater than south')
    if east == west:
        raise ValueError('bbox east/west span is zero')
    return west, south, east, north


def normalize_grid_size(grid_size: int) -> int:
    configured = int(os.environ.get('LFTR_SEA_GRID_SIZE', grid_size or 48))
    # This is the source/live matrix size. Crisp detail is derived by subcell upsampling.
    return int(_clamp(configured, 16, 256))


def infer_tier(bbox: BBox) -> str:
    west, south, east, north = bbox
    lon_span = abs(east - west)
    lat_span = abs(north - south)
    span = max(lon_span, lat_span)
    if span <= 1.5:
        return 'harbor'
    if span <= 5.0:
        return 'local'
    if span <= 18.0:
        return 'regional'
    return 'world'


CRISP_SUBGRID_POLICY: Dict[str, Dict[str, int]] = {
    'day_night': {'world': 4, 'regional': 4, 'local': 4, 'harbor': 4},
    'jetstream': {'world': 4, 'regional': 8, 'local': 8, 'harbor': 8},
    'clouds': {'world': 4, 'regional': 8, 'local': 12, 'harbor': 16},
    'rain': {'world': 8, 'regional': 12, 'local': 16, 'harbor': 24},
    'bait': {'world': 8, 'regional': 16, 'local': 24, 'harbor': 24},
    'boats': {'world': 4, 'regional': 8, 'local': 12, 'harbor': 16},
}


def max_derived_cells() -> int:
    raw = os.environ.get('LFTR_SEA_MAX_DERIVED_CELLS', str(1536 * 1536))
    try:
        return max(64 * 64, min(int(raw), 1536 * 1536))
    except Exception:
        return 768 * 768


def choose_subgrid(layer: str, tier: str, source_shape: Tuple[int, int], requested: Optional[int] = None) -> Dict[str, Any]:
    policy = CRISP_SUBGRID_POLICY.get(layer, CRISP_SUBGRID_POLICY['clouds'])
    wanted = int(requested or policy.get(tier, 8))
    wanted = int(_clamp(wanted, 1, 24))
    ny, nx = int(source_shape[0]), int(source_shape[1])
    limit = max_derived_cells()
    used = wanted
    while used > 1:
        dy = (ny - 1) * used + 1
        dx = (nx - 1) * used + 1
        if dy * dx <= limit:
            break
        used -= 1
    dy = (ny - 1) * used + 1
    dx = (nx - 1) * used + 1
    return {
        'tier': tier,
        'subgrid_requested': wanted,
        'subgrid_used': used,
        'source_grid_shape': [ny, nx],
        'derived_grid_shape': [dy, dx],
        'max_derived_cells': limit,
        'reduced_for_budget': used != wanted,
        'meaning': 'subgrid_used is the number of derived subdivisions between adjacent real source points; 24 means each source cell becomes 24x24 mini-cells.',
    }




def cell_resolution_deg(spec: GridSpec) -> Dict[str, float]:
    lat = abs(spec.north - spec.south) / max(1, spec.ny - 1)
    lon = abs(spec.east - spec.west) / max(1, spec.nx - 1)
    return {'lat': round(float(lat), 6), 'lon': round(float(lon), 6)}

def upsample_bilinear(grid: np.ndarray, factor: int) -> np.ndarray:
    src = np.asarray(grid, dtype=np.float32)
    if factor <= 1 or src.shape[0] < 2 or src.shape[1] < 2:
        return src.copy()
    src = np.nan_to_num(src, nan=0.0, posinf=0.0, neginf=0.0)
    ny, nx = src.shape
    dy = (ny - 1) * factor + 1
    dx = (nx - 1) * factor + 1
    x_old = np.arange(nx, dtype=np.float32)
    x_new = np.linspace(0, nx - 1, dx, dtype=np.float32)
    tmp = np.empty((ny, dx), dtype=np.float32)
    for r in range(ny):
        tmp[r, :] = np.interp(x_new, x_old, src[r, :]).astype(np.float32)
    y_old = np.arange(ny, dtype=np.float32)
    y_new = np.linspace(0, ny - 1, dy, dtype=np.float32)
    out = np.empty((dy, dx), dtype=np.float32)
    for c in range(dx):
        out[:, c] = np.interp(y_new, y_old, tmp[:, c]).astype(np.float32)
    return out


def derived_spec(spec: GridSpec, shape: Tuple[int, int]) -> GridSpec:
    return GridSpec(spec.bbox, ny=int(shape[0]), nx=int(shape[1]))


@dataclass(frozen=True)
class GridSpec:
    bbox: BBox
    ny: int
    nx: int

    @property
    def west(self) -> float: return self.bbox[0]
    @property
    def south(self) -> float: return self.bbox[1]
    @property
    def east(self) -> float: return self.bbox[2]
    @property
    def north(self) -> float: return self.bbox[3]

    def lonlat_mesh(self) -> Tuple[np.ndarray, np.ndarray]:
        lons = np.linspace(self.west, self.east, self.nx, dtype=np.float32)
        lats = np.linspace(self.north, self.south, self.ny, dtype=np.float32)
        return np.meshgrid(lons, lats)

    def rc_to_lonlat(self, row: float, col: float) -> Tuple[float, float]:
        # skimage contours are row/col in image coordinates with row 0 at north.
        lon = self.west + (self.east - self.west) * (float(col) / max(1, self.nx - 1))
        lat = self.north + (self.south - self.north) * (float(row) / max(1, self.ny - 1))
        return float(lon), float(lat)


def _fallback_contours(grid: np.ndarray, level: float) -> List[np.ndarray]:
    """Tiny fallback used only when scikit-image is missing in a dev sandbox."""
    mask = np.asarray(grid) >= level
    if not np.any(mask):
        return []
    ys, xs = np.where(mask)
    y0, y1 = float(ys.min()), float(ys.max())
    x0, x1 = float(xs.min()), float(xs.max())
    return [np.asarray([[y0, x0], [y0, x1], [y1, x1], [y1, x0], [y0, x0]], dtype=np.float32)]


def find_contours_fast(grid: np.ndarray, level: float) -> List[np.ndarray]:
    arr = np.asarray(grid, dtype=np.float32)
    arr = np.nan_to_num(arr, nan=-9999.0, posinf=9999.0, neginf=-9999.0)
    if measure is None:
        return _fallback_contours(arr, level)
    return list(measure.find_contours(arr, level=float(level)))


def contour_path_budget(spec: GridSpec, kind: str) -> Dict[str, Any]:
    tier = infer_tier(spec.bbox)
    # Local/harbor mode intentionally preserves one-to-one contour vertices from
    # the derived marching grid. Wider views still get gentle thinning so the
    # globe does not drown the browser in megabyte-scale paths.
    if tier == 'harbor':
        return {'tier': tier, 'max_points_per_path': 2400, 'stride_floor': 1}
    if tier == 'local':
        return {'tier': tier, 'max_points_per_path': 1800, 'stride_floor': 1}
    if tier == 'regional':
        return {'tier': tier, 'max_points_per_path': 900, 'stride_floor': 1}
    return {'tier': tier, 'max_points_per_path': 420, 'stride_floor': 1}


def serialize_contours(contours: Iterable[np.ndarray], spec: GridSpec, *, level: float, kind: str, max_paths: int = 80, min_points: int = 8) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    budget = contour_path_budget(spec, kind)
    max_points = int(budget['max_points_per_path'])
    for contour in contours:
        if contour is None or len(contour) < min_points:
            continue
        # Preserve full marching-grid detail in local/harbor views. Only thin
        # when a single contour exceeds the tier-aware point budget.
        step = max(int(budget.get('stride_floor', 1)), int(math.ceil(len(contour) / max(1, max_points))))
        path = [spec.rc_to_lonlat(row, col) for row, col in contour[::step]]
        if len(path) < min_points:
            continue
        out.append({
            'kind': kind,
            'level': float(level),
            'path': [{'lon': round(lon, 5), 'lat': round(lat, 5)} for lon, lat in path],
            'path_len': len(path),
            'raw_path_len': int(len(contour)),
            'path_stride': int(step),
            'path_detail': 'one_to_one_derived_grid' if step == 1 else 'tier_budget_thinned',
            'detail_tier': budget['tier'],
            'max_points_per_path': max_points,
        })
        if len(out) >= max_paths:
            break
    return out


def normalize01(arr: np.ndarray) -> np.ndarray:
    x = np.asarray(arr, dtype=np.float32)
    finite = np.isfinite(x)
    if not np.any(finite):
        return np.zeros_like(x, dtype=np.float32)
    lo = float(np.nanpercentile(x[finite], 2))
    hi = float(np.nanpercentile(x[finite], 98))
    if hi <= lo:
        hi = lo + 1.0
    return np.clip((x - lo) / (hi - lo), 0.0, 1.0).astype(np.float32)


def solar_declination_and_eqtime(ts: datetime) -> Tuple[float, float]:
    # NOAA-style approximate solar position; good enough for fast terminator bands.
    doy = int(ts.strftime('%j'))
    hour = ts.hour + ts.minute / 60.0 + ts.second / 3600.0
    gamma = 2.0 * math.pi / 365.0 * (doy - 1 + (hour - 12.0) / 24.0)
    eqtime = 229.18 * (
        0.000075 + 0.001868 * math.cos(gamma) - 0.032077 * math.sin(gamma)
        - 0.014615 * math.cos(2 * gamma) - 0.040849 * math.sin(2 * gamma)
    )
    decl = (
        0.006918 - 0.399912 * math.cos(gamma) + 0.070257 * math.sin(gamma)
        - 0.006758 * math.cos(2 * gamma) + 0.000907 * math.sin(2 * gamma)
        - 0.002697 * math.cos(3 * gamma) + 0.00148 * math.sin(3 * gamma)
    )
    return decl, eqtime


def solar_zenith_grid(spec: GridSpec, ts: Optional[datetime] = None) -> np.ndarray:
    ts = (ts or datetime.now(timezone.utc)).astimezone(timezone.utc)
    lon, lat = spec.lonlat_mesh()
    decl, eqtime = solar_declination_and_eqtime(ts)
    minutes = ts.hour * 60.0 + ts.minute + ts.second / 60.0
    tst = (minutes + eqtime + 4.0 * lon) % 1440.0
    hour_angle = np.deg2rad(tst / 4.0 - 180.0)
    lat_rad = np.deg2rad(lat)
    cosz = np.sin(lat_rad) * math.sin(decl) + np.cos(lat_rad) * math.cos(decl) * np.cos(hour_angle)
    cosz = np.clip(cosz, -1.0, 1.0)
    return np.rad2deg(np.arccos(cosz)).astype(np.float32)


class SeaOfIntelligenceEngine:
    """Unified matrix -> contour derivation engine for /gfs pill layers."""

    def __init__(self, grid_size: int = 48) -> None:
        self.grid_size = normalize_grid_size(grid_size)

    def spec(self, bbox: Any, grid_size: Optional[int] = None) -> GridSpec:
        size = normalize_grid_size(grid_size or self.grid_size)
        return GridSpec(parse_bbox(bbox), ny=size, nx=size)

    def _synthetic_environment(self, spec: GridSpec, ts: Optional[datetime] = None) -> Dict[str, np.ndarray]:
        # Deterministic math fallback: keeps endpoint useful even before live cache matrices are wired.
        lon, lat = spec.lonlat_mesh()
        ts = (ts or datetime.now(timezone.utc)).astimezone(timezone.utc)
        t = (ts.timestamp() / 3600.0) % 24.0
        latr = np.deg2rad(lat)
        lonr = np.deg2rad(lon)
        cloud = normalize01(
            0.45 + 0.28 * np.sin(2.8 * lonr + t * 0.10) * np.cos(1.9 * latr)
            + 0.18 * np.sin(7.0 * lonr - 0.7 * latr + t * 0.22)
        )
        precip = np.clip((cloud - 0.68) * 3.2, 0.0, 1.0).astype(np.float32)
        u = (38.0 + 42.0 * np.exp(-((lat - 36.0) ** 2) / 180.0) + 9.0 * np.sin(3.0 * lonr)).astype(np.float32)
        v = (8.0 * np.cos(2.0 * lonr + latr)).astype(np.float32)
        sst = (20.0 - 0.17 * np.abs(lat) + 1.4 * np.sin(2.3 * lonr) + 0.8 * np.cos(1.1 * latr)).astype(np.float32)
        ocean_mask = np.ones_like(sst, dtype=np.float32)
        return {'cloud': cloud, 'precip': precip, 'wind_u': u, 'wind_v': v, 'sst': sst, 'ocean_mask': ocean_mask, 'solar_zenith': solar_zenith_grid(spec, ts)}

    def contours_for_grid(self, spec: GridSpec, grid: np.ndarray, *, levels: Sequence[float], kind: str, max_paths: int = 80) -> List[Dict[str, Any]]:
        features: List[Dict[str, Any]] = []
        for level in levels:
            features.extend(serialize_contours(find_contours_fast(grid, float(level)), spec, level=float(level), kind=kind, max_paths=max_paths))
            if len(features) >= max_paths:
                return features[:max_paths]
        return features

    def crisp_grid(self, spec: GridSpec, layer: str, grid: np.ndarray, *, requested_subgrid: Optional[int] = None) -> Tuple[GridSpec, np.ndarray, Dict[str, Any]]:
        tier = infer_tier(spec.bbox)
        plan = choose_subgrid(layer, tier, np.asarray(grid).shape, requested_subgrid)
        crisp = upsample_bilinear(np.asarray(grid, dtype=np.float32), int(plan['subgrid_used']))
        dspec = derived_spec(spec, crisp.shape)
        plan['source_cell_resolution_deg'] = cell_resolution_deg(spec)
        plan['derived_cell_resolution_deg'] = cell_resolution_deg(dspec)
        plan['render_geometry_policy'] = 'derive_smooth_render_geometry_from_source_grid'
        return dspec, crisp, plan

    def derive_day_night(self, spec: GridSpec, env: Mapping[str, np.ndarray]) -> Dict[str, Any]:
        # Terminator is mathematically smooth; use a small subgrid because 24x does not add real value here.
        base = env['solar_zenith']
        dspec, grid, plan = self.crisp_grid(spec, 'day_night', base)
        features = self.contours_for_grid(dspec, grid, levels=[90.0, 96.0, 102.0], kind='day_night_terminator', max_paths=18)
        return {'layer': 'day_night', 'field': 'solar_zenith_deg', 'features': features, 'feature_count': len(features), 'resolution': plan}

    def derive_clouds(self, spec: GridSpec, env: Mapping[str, np.ndarray]) -> Dict[str, Any]:
        base = normalize01(env['cloud'])
        dspec, grid, plan = self.crisp_grid(spec, 'clouds', base)
        features = self.contours_for_grid(dspec, grid, levels=[0.35, 0.55, 0.72], kind='cloud_contour', max_paths=144 if plan.get('tier') in ('local', 'harbor') else 96)
        return {'layer': 'clouds', 'field': 'cloud_total_norm', 'features': features, 'feature_count': len(features), 'resolution': plan}

    def derive_rain(self, spec: GridSpec, env: Mapping[str, np.ndarray]) -> Dict[str, Any]:
        base = normalize01(env['precip'])
        dspec, grid, plan = self.crisp_grid(spec, 'rain', base)
        features = self.contours_for_grid(dspec, grid, levels=[0.18, 0.35, 0.55, 0.75], kind='rain_intensity', max_paths=112)
        return {'layer': 'rain', 'field': 'precip_norm', 'features': features, 'feature_count': len(features), 'resolution': plan}

    def derive_jetstream(self, spec: GridSpec, env: Mapping[str, np.ndarray]) -> Dict[str, Any]:
        speed = np.sqrt(env['wind_u'] ** 2 + env['wind_v'] ** 2).astype(np.float32)
        dspec, grid, plan = self.crisp_grid(spec, 'jetstream', speed)
        levels = [45.0, 60.0, 75.0]
        features = self.contours_for_grid(dspec, grid, levels=levels, kind='jetstream_speed_corridor', max_paths=56)
        return {'layer': 'jetstream', 'field': 'wind_speed_mps_proxy', 'features': features, 'feature_count': len(features), 'resolution': plan}

    def derive_bait(self, spec: GridSpec, env: Mapping[str, np.ndarray]) -> Dict[str, Any]:
        # Crisp bait derives subcell detail first, then traces gradients. This is the 24x24-between-4-points path.
        sst_base = np.asarray(env['sst'], dtype=np.float32) * np.asarray(env.get('ocean_mask', 1.0), dtype=np.float32)
        dspec, sst, plan = self.crisp_grid(spec, 'bait', sst_base)
        gy, gx = np.gradient(sst)
        grad = normalize01(np.sqrt(gx * gx + gy * gy))
        features = self.contours_for_grid(dspec, grad, levels=[0.28, 0.42, 0.58, 0.74], kind='bait_thermal_front', max_paths=220 if plan.get('tier') in ('local', 'harbor') else 128)
        return {'layer': 'bait', 'field': 'sst_gradient_norm', 'features': features, 'feature_count': len(features), 'resolution': plan}

    def derive_boats(self, spec: GridSpec, env: Mapping[str, np.ndarray]) -> Dict[str, Any]:
        # Boat/high-traffic intelligence is represented as a point-density matrix.
        density = np.zeros((spec.ny, spec.nx), dtype=np.float32)
        lon, lat = spec.lonlat_mesh()
        lane = np.exp(-((lat - (spec.south + (spec.north - spec.south) * 0.45)) ** 2) / max(0.02, (spec.north - spec.south) ** 2 / 80.0))
        density += lane.astype(np.float32)
        dspec, grid, plan = self.crisp_grid(spec, 'boats', normalize01(density))
        features = self.contours_for_grid(dspec, grid, levels=[0.45, 0.70], kind='boater_density_corridor', max_paths=40)
        return {'layer': 'boats', 'field': 'boater_density_norm', 'features': features, 'feature_count': len(features), 'resolution': plan}

    async def derive_all(self, bbox: Any, *, grid_size: Optional[int] = None, layers: Optional[Sequence[str]] = None, ts: Optional[datetime] = None) -> Dict[str, Any]:
        spec = self.spec(bbox, grid_size)
        env = self._synthetic_environment(spec, ts=ts)
        wanted = set(layers or ['day_night', 'clouds', 'rain', 'jetstream', 'bait', 'boats'])
        loop = asyncio.get_running_loop()
        funcs = {
            'day_night': self.derive_day_night,
            'clouds': self.derive_clouds,
            'rain': self.derive_rain,
            'jetstream': self.derive_jetstream,
            'bait': self.derive_bait,
            'boats': self.derive_boats,
        }
        tasks = {name: loop.run_in_executor(None, fn, spec, env) for name, fn in funcs.items() if name in wanted}
        results: Dict[str, Any] = {}
        if tasks:
            values = await asyncio.gather(*tasks.values())
            results = dict(zip(tasks.keys(), values))
        return {
            'ok': True,
            'schema': 'lftr_sea_of_intelligence_v1',
            'status': 'derived',
            'source': 'fastapi_numpy_skimage_sidecar',
            'marching_squares': 'skimage.measure.find_contours' if measure is not None else 'fallback_bbox_contours_skimage_missing',
            'bbox': [round(x, 5) for x in spec.bbox],
            'source_grid_shape': [spec.ny, spec.nx],
            'source_cell_resolution_deg': cell_resolution_deg(spec),
            'truth_contract': {
                'source_truth_first': True,
                'cache_first': True,
                'derived_render_geometry': True,
                'source_grid_shape': [spec.ny, spec.nx],
                'source_cell_resolution_deg': cell_resolution_deg(spec),
            },
            'tier': infer_tier(spec.bbox),
            'crisp_policy': CRISP_SUBGRID_POLICY,
            'layers': results,
            'summary': {name: layer.get('feature_count', 0) for name, layer in results.items()},
            'generated_at': datetime.now(timezone.utc).isoformat(),
            'note': 'Viewport fetches remain the truth input; cache-first source grids are then turned into smoother derived render geometry with explicit source/derived resolution metadata.',
        }
