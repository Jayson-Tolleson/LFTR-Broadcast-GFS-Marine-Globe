import { normalizePolygonFieldPayload } from './polygon_math.js';
import { clamp01 } from './greek_math.js';
import { createPolygon3D } from './polygon3d.js';
import { contourPolygonsFromPoints } from './marching_squares.js';

const MAX_POLYGONS_PER_FRAME = 120; // local/harbor FastAPI contours are already budgeted; draw more per frame for crisp bait
const BAIT_DRIFT_DEFAULT_TIME_SCALE = 420; // simulated seconds per real second; keeps schools visibly alive without teleporting.
const BAIT_DRIFT_MAX_STEP_DEG = 0.018;
// Keep false by default: Google Maps 3D beta can stringify post-append polygon.path
// mutations into a `path` attribute, causing huge LatLngAltitude parse errors.
// Bait still gets score-based opacity and U/V vectors in debug; live drift can be
// re-enabled from the console only after the path setter is verified safe.
const BAIT_MUTATE_PATHS_DEFAULT = false;
const EARTH_METERS_PER_DEG_LAT = 111320;

function polygonApiPath() {
  return window.google?.maps?.maps3d?.Polygon3DElement ? 'Polygon3DElement.path' : 'gmp-polygon-3d.path';
}

function toNumber(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function wrapLongitude(lon) {
  const n = Number(lon);
  if (!Number.isFinite(n)) return n;
  return ((((n + 180) % 360) + 360) % 360) - 180;
}

function normalizeBbox(bbox) {
  if (Array.isArray(bbox) && bbox.length >= 4) {
    const [west, south, east, north] = bbox.map(Number);
    if ([west, south, east, north].every(Number.isFinite)) return { west, south, east, north };
  }
  if (bbox && typeof bbox === 'object') {
    const west = Number(bbox.west); const south = Number(bbox.south); const east = Number(bbox.east); const north = Number(bbox.north);
    if ([west, south, east, north].every(Number.isFinite)) return { west, south, east, north };
  }
  return null;
}

function pointNearBbox(lat, lng, bbox, pad = 0.75) {
  const b = normalizeBbox(bbox);
  if (!b) return true;
  if (lat < Math.min(b.south, b.north) - pad || lat > Math.max(b.south, b.north) + pad) return false;
  const x = wrapLongitude(lng);
  const west = wrapLongitude(b.west - pad);
  const east = wrapLongitude(b.east + pad);
  return west <= east ? (x >= west && x <= east) : (x >= west || x <= east);
}

function pathBbox(path) {
  let minLat = Infinity; let maxLat = -Infinity; let minLng = Infinity; let maxLng = -Infinity;
  for (const p of Array.isArray(path) ? path : []) {
    const lat = Number(p?.lat);
    const lng = Number(p?.lng);
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) continue;
    minLat = Math.min(minLat, lat); maxLat = Math.max(maxLat, lat);
    minLng = Math.min(minLng, lng); maxLng = Math.max(maxLng, lng);
  }
  return [minLat, maxLat, minLng, maxLng].every(Number.isFinite) ? { minLat, maxLat, minLng, maxLng } : null;
}

function pathLooksLikeViewportBait(path, bbox = null) {
  if (!Array.isArray(path) || path.length < 3) return false;
  const b = normalizeBbox(bbox);
  const pb = pathBbox(path);
  if (!pb) return false;
  if (!b) return true;
  const spanLat = Math.max(0.0001, Math.abs(b.north - b.south));
  const spanLng = Math.max(0.0001, Math.abs(b.east - b.west));
  // Reject detached chlorophyll/parabola artifacts. True bait polygons should
  // stay inside/near the requested payload bbox; points/axis errors often create
  // long curved shapes that extend far outside the viewport or have huge jumps.
  const padLat = Math.max(0.15, spanLat * 0.22);
  const padLng = Math.max(0.15, spanLng * 0.22);
  if (pb.minLat < Math.min(b.south, b.north) - padLat || pb.maxLat > Math.max(b.south, b.north) + padLat) return false;
  const west = Math.min(b.west, b.east) - padLng;
  const east = Math.max(b.west, b.east) + padLng;
  if (pb.minLng < west || pb.maxLng > east) return false;
  const maxJumpLat = Math.max(0.35, spanLat * 0.55);
  const maxJumpLng = Math.max(0.35, spanLng * 0.55);
  for (let i = 1; i < path.length; i += 1) {
    if (Math.abs(path[i].lat - path[i - 1].lat) > maxJumpLat || Math.abs(path[i].lng - path[i - 1].lng) > maxJumpLng) return false;
  }
  return true;
}

function clampProbability(value) {
  return clamp01(toNumber(value, 0));
}

function toHexByte(value) {
  const clamped = Math.max(0, Math.min(255, Math.round(value)));
  return clamped.toString(16).padStart(2, '0');
}

function rgbHex(r, g, b) {
  return `#${toHexByte(r)}${toHexByte(g)}${toHexByte(b)}`;
}

function interpolateColor(a, b, t) {
  const p = clampProbability(t);
  return {
    r: a.r + ((b.r - a.r) * p),
    g: a.g + ((b.g - a.g) * p),
    b: a.b + ((b.b - a.b) * p),
  };
}

function probabilityBaseColor(probability) {
  const p = clampProbability(probability);
  // Water-first bait palette: weak = aqua/green, medium = yellow/orange, hot = magenta/red.
  const aqua = { r: 64, g: 231, b: 255 };
  const green = { r: 64, g: 214, b: 92 };
  const yellow = { r: 255, g: 232, b: 64 };
  const orange = { r: 255, g: 147, b: 43 };
  const magenta = { r: 255, g: 45, b: 171 };
  if (p < 0.30) return interpolateColor(aqua, green, p / 0.30);
  if (p < 0.58) return interpolateColor(green, yellow, (p - 0.30) / 0.28);
  if (p < 0.78) return interpolateColor(yellow, orange, (p - 0.58) / 0.20);
  return interpolateColor(orange, magenta, (p - 0.78) / 0.22);
}

function probabilityColorRamp(probability) {
  const base = probabilityBaseColor(probability);
  const toLayerHex = (mix) => rgbHex(
    base.r + ((255 - base.r) * mix),
    base.g + ((255 - base.g) * mix),
    base.b + ((255 - base.b) * mix),
  );
  return {
    coreColor: toLayerHex(0),
    innerColor: toLayerHex(0.16),
    outerColor: toLayerHex(0.38),
  };
}

function baitOpacity(probability, band) {
  const p = clampProbability(probability);
  const p2 = p * p;
  if (band === 'outer') return clampProbability(0.035 + (0.26 * p2));
  if (band === 'inner') return clampProbability(0.055 + (0.42 * p2));
  return clampProbability(0.09 + (0.68 * p2));
}

function baitStrokeOpacity(probability, band) {
  const p = clampProbability(probability);
  const base = band === 'outer' ? 0.12 : band === 'inner' ? 0.22 : 0.36;
  return clampProbability(base + (0.48 * p));
}


function schoolScore(row) {
  return clampProbability(
    row?.schoolScore
    ?? row?.school_score
    ?? row?.baitSchoolScore
    ?? row?.school
    ?? row?.probability
    ?? row?.baitScore
    ?? row?.bait_score
    ?? row?.score
    ?? row?.confidence
    ?? 0.0,
  );
}

function vectorComponent(row, names) {
  for (const name of names) {
    const n = Number(row?.[name]);
    if (Number.isFinite(n)) return n;
  }
  return NaN;
}

function currentVectorFromRow(row) {
  if (!row || typeof row !== 'object') return null;
  const u = vectorComponent(row, ['u', 'u_ms', 'uMps', 'u_mps', 'current_u', 'currentU', 'eastward_current', 'water_u', 'ucur', 'ugos']);
  const v = vectorComponent(row, ['v', 'v_ms', 'vMps', 'v_mps', 'current_v', 'currentV', 'northward_current', 'water_v', 'vcur', 'vgos']);
  if (Number.isFinite(u) && Number.isFinite(v) && Math.hypot(u, v) > 0.001) return { u, v, source: row.source || 'row_uv' };

  const speed = vectorComponent(row, ['speed', 'speed_ms', 'current_speed', 'currentSpeed', 'current_speed_ms']);
  const dir = vectorComponent(row, ['dir', 'direction', 'dirDeg', 'direction_deg', 'current_dir', 'currentDirectionDeg']);
  if (Number.isFinite(speed) && Number.isFinite(dir) && speed > 0.001) {
    const rad = (dir * Math.PI) / 180;
    return { u: Math.sin(rad) * speed, v: Math.cos(rad) * speed, source: row.source || 'row_speed_dir' };
  }
  return null;
}

function averageCurrentVector(rows) {
  let uSum = 0;
  let vSum = 0;
  let wSum = 0;
  for (const row of Array.isArray(rows) ? rows : []) {
    const vec = currentVectorFromRow(row);
    if (!vec) continue;
    const w = Math.max(0.08, schoolScore(row));
    uSum += vec.u * w;
    vSum += vec.v * w;
    wSum += w;
  }
  if (wSum <= 0) return { u: 0, v: 0, source: 'no_uv_available' };
  return { u: uSum / wSum, v: vSum / wSum, source: 'weighted_payload_uv' };
}

function motionVectorForPolygon(poly, fallbackVector) {
  return currentVectorFromRow(poly) || fallbackVector || { u: 0, v: 0, source: 'no_uv_available' };
}

function centroidOfPath(path) {
  let lat = 0;
  let lng = 0;
  let count = 0;
  for (const p of path || []) {
    const la = Number(p?.lat);
    const ln = Number(p?.lng);
    if (!Number.isFinite(la) || !Number.isFinite(ln)) continue;
    lat += la;
    lng += ln;
    count += 1;
  }
  return count ? { lat: lat / count, lng: lng / count } : { lat: 0, lng: 0 };
}

function metersToLatLngDelta({ eastMeters, northMeters, lat }) {
  const safeLat = Number.isFinite(lat) ? lat : 0;
  const cosLat = Math.max(0.12, Math.cos((safeLat * Math.PI) / 180));
  return {
    dLat: northMeters / EARTH_METERS_PER_DEG_LAT,
    dLng: eastMeters / (EARTH_METERS_PER_DEG_LAT * cosLat),
  };
}

function clampStep(value) {
  return Math.max(-BAIT_DRIFT_MAX_STEP_DEG, Math.min(BAIT_DRIFT_MAX_STEP_DEG, value));
}

function animatedBaitPath(basePath, state, elapsedSeconds) {
  const center = state.center || centroidOfPath(basePath);
  const timeScale = Number(window.GFS_BAIT_DRIFT_TIME_SCALE ?? BAIT_DRIFT_DEFAULT_TIME_SCALE);
  const driftScale = Number.isFinite(timeScale) ? Math.max(0, Math.min(3600, timeScale)) : BAIT_DRIFT_DEFAULT_TIME_SCALE;
  const scoreScale = 0.35 + (0.75 * clampProbability(state.schoolScore));
  const bandScale = state.band === 'outer' ? 0.62 : state.band === 'inner' ? 0.82 : 1.0;
  const eastMeters = state.vector.u * elapsedSeconds * driftScale * scoreScale * bandScale;
  const northMeters = state.vector.v * elapsedSeconds * driftScale * scoreScale * bandScale;
  const { dLat, dLng } = metersToLatLngDelta({ eastMeters, northMeters, lat: center.lat });

  // Subtle cross-current shimmer makes the school “roll” with the water while
  // preserving the overall polygon shape. It is intentionally tiny in degrees.
  const speed = Math.min(1.8, Math.hypot(state.vector.u, state.vector.v));
  const phase = (elapsedSeconds * (0.18 + speed * 0.18)) + state.phase;
  const rollMeters = Math.sin(phase) * (18 + (52 * clampProbability(state.schoolScore))) * bandScale;
  const mag = Math.max(0.001, Math.hypot(state.vector.u, state.vector.v));
  const normalEast = -state.vector.v / mag;
  const normalNorth = state.vector.u / mag;
  const roll = metersToLatLngDelta({ eastMeters: normalEast * rollMeters, northMeters: normalNorth * rollMeters, lat: center.lat });

  return basePath.map((p, idx) => {
    const ripple = Math.sin(phase + idx * 0.77) * 0.45;
    return {
      lat: p.lat + clampStep(dLat + (roll.dLat * ripple)),
      lng: p.lng + clampStep(dLng + (roll.dLng * ripple)),
      altitude: p.altitude,
    };
  });
}

function applyPolygonPath(el, path) {
  if (!el || !Array.isArray(path) || path.length < 3) return;
  // Google Maps 3D Polygon3DElement expects `path` as a JS array/property.
  // Do NOT set the `path` attribute to JSON text: Maps 3D tries to parse the
  // entire string as one LatLngAltitude and logs huge "lat is not a number"
  // errors, which stalls rendering when bait advection updates every frame.
  const clean = sanitizePath(path);
  if (clean.length < 3) return;
  try { el.removeAttribute?.('path'); } catch (_) {}
  try { el.path = clean; }
  catch (err) { console.warn('[gfs bait] polygon path update skipped', { message: err?.message || String(err), points: clean.length }); }
}

function startBaitAdvectionLoop(states) {
  const mutatePaths = false; // hard-off: Maps 3D beta stringifies bait path mutations
  if (!mutatePaths) {
    console.info('[gfs bait] live path drift held', {
      reason: 'maps3d_path_mutation_stringifies_arrays',
      states: Array.isArray(states) ? states.length : 0,
      enableForTest: 'window.GFS_BAIT_MUTATE_PATHS = true',
    });
    return () => {};
  }
  let rafId = null;
  let disposed = false;
  const start = performance.now();
  let lastUpdate = 0;
  const tick = (now) => {
    if (disposed) return;
    if ((now - lastUpdate) >= 180) {
      const elapsedSeconds = (now - start) / 1000;
      const enabled = window.GFS_BAIT_DRIFT_ENABLED !== false && (window.GFS_BAIT_MUTATE_PATHS === true || window.GFS_BAIT_DRIFT_MUTATE_PATHS === true);
      if (enabled) {
        for (const state of states) {
          applyPolygonPath(state.el, animatedBaitPath(state.basePath, state, elapsedSeconds));
        }
      }
      lastUpdate = now;
    }
    rafId = requestAnimationFrame(tick);
  };
  rafId = requestAnimationFrame(tick);
  return () => {
    disposed = true;
    if (rafId) cancelAnimationFrame(rafId);
  };
}

function baitExtrudeHeight(probability, band) {
  const p = clampProbability(probability);
  if (band === 'outer') return 8 + (18 * p);
  if (band === 'inner') return 16 + (34 * p);
  return 28 + (58 * p);
}

function sanitizePath(path) {
  const cleaned = [];
  for (const point of path || []) {
    const lat = Number(point?.lat);
    const lng = Number(point?.lng);
    const altitude = Number(point?.altitude ?? 20);
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) continue;
    const prev = cleaned[cleaned.length - 1];
    if (prev && Math.abs(prev.lat - lat) < 1e-6 && Math.abs(prev.lng - lng) < 1e-6) continue;
    cleaned.push({ lat, lng, altitude: Number.isFinite(altitude) ? altitude : 20 });
  }
  if (cleaned.length >= 2) {
    const first = cleaned[0];
    const last = cleaned[cleaned.length - 1];
    if (Math.abs(first.lat - last.lat) < 1e-6 && Math.abs(first.lng - last.lng) < 1e-6) {
      cleaned.pop();
    }
  }
  return cleaned;
}

function toPath(coords, altitude = 20, bbox = null) {
  if (!Array.isArray(coords)) return [];
  const mapped = coords.map((p) => {
    if (Array.isArray(p) && p.length >= 2) {
      const a = Number(p[0]);
      const b = Number(p[1]);
      if (!Number.isFinite(a) || !Number.isFinite(b)) return null;
      // GeoJSON is [lon, lat], but some chlorophyll-derived payloads arrive as [lat, lon]
      // or 0..360 longitude. Pick the interpretation that lands inside the payload bbox.
      const lonLat = { lat: b, lng: wrapLongitude(a), altitude };
      const latLon = { lat: a, lng: wrapLongitude(b), altitude };
      const lonLatOk = lonLat.lat >= -90 && lonLat.lat <= 90 && pointNearBbox(lonLat.lat, lonLat.lng, bbox);
      const latLonOk = latLon.lat >= -90 && latLon.lat <= 90 && pointNearBbox(latLon.lat, latLon.lng, bbox);
      if (lonLatOk && !latLonOk) return lonLat;
      if (latLonOk && !lonLatOk) return latLon;
      if (lonLatOk) return lonLat;
      if (latLonOk) return latLon;
      return lonLat.lat >= -90 && lonLat.lat <= 90 ? lonLat : (latLon.lat >= -90 && latLon.lat <= 90 ? latLon : null);
    }
    if (p && typeof p === 'object') {
      let lat = Number(p.lat ?? p.latitude);
      let lng = Number(p.lng ?? p.lon ?? p.longitude);
      if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
      if ((lat < -90 || lat > 90) && lng >= -90 && lng <= 90) { const tmp = lat; lat = lng; lng = tmp; }
      lng = wrapLongitude(lng);
      if (lat < -90 || lat > 90 || !pointNearBbox(lat, lng, bbox)) return null;
      return { lat, lng, altitude: toNumber(p.altitude, altitude) };
    }
    return null;
  }).filter(Boolean);
  return sanitizePath(mapped);
}

function ringAreaScore(ring) {
  if (!Array.isArray(ring) || ring.length < 3) return -1;
  let area = 0;
  let valid = 0;
  for (let i = 0; i < ring.length; i += 1) {
    const a = ring[i];
    const b = ring[(i + 1) % ring.length];
    const ax = Array.isArray(a) ? Number(a[0]) : Number(a?.lng ?? a?.lon ?? a?.longitude);
    const ay = Array.isArray(a) ? Number(a[1]) : Number(a?.lat ?? a?.latitude);
    const bx = Array.isArray(b) ? Number(b[0]) : Number(b?.lng ?? b?.lon ?? b?.longitude);
    const by = Array.isArray(b) ? Number(b[1]) : Number(b?.lat ?? b?.latitude);
    if (![ax, ay, bx, by].every(Number.isFinite)) continue;
    area += ax * by - bx * ay;
    valid += 1;
  }
  return valid >= 3 ? Math.abs(area) : -1;
}

function flattenPolygonCoordinates(coords) {
  if (!Array.isArray(coords) || !coords.length) return [];
  // Already a simple ring: [[lon,lat], ...] or [{lat,lng}, ...]
  const first = coords[0];
  if ((Array.isArray(first) && typeof first[0] === 'number' && typeof first[1] === 'number') || (first && typeof first === 'object' && !Array.isArray(first) && ('lat' in first || 'latitude' in first))) {
    return coords;
  }
  // GeoJSON Polygon: [outerRing, hole1, ...]. MultiPolygon: [[outerRing...], ...].
  const rings = [];
  const collect = (node, depth = 0) => {
    if (!Array.isArray(node) || depth > 4) return;
    const f = node[0];
    if ((Array.isArray(f) && typeof f[0] === 'number' && typeof f[1] === 'number') || (f && typeof f === 'object' && !Array.isArray(f) && ('lat' in f || 'latitude' in f))) {
      rings.push(node);
      return;
    }
    for (const child of node) collect(child, depth + 1);
  };
  collect(coords);
  if (!rings.length) return [];
  // Draw the largest exterior ring; holes are ignored because gmp-polygon-3d
  // does not consistently support inner rings in the beta element.
  return rings.sort((a, b) => ringAreaScore(b) - ringAreaScore(a))[0];
}

function polygonCoordinates(poly) {
  const raw = Array.isArray(poly?.geometry?.coordinates) ? poly.geometry.coordinates
    : Array.isArray(poly?.coordinates) ? poly.coordinates
    : Array.isArray(poly?.path) ? poly.path
    : Array.isArray(poly?.points) ? poly.points
    : Array.isArray(poly?.ring) ? poly.ring
    : Array.isArray(poly) ? poly
    : [];
  return flattenPolygonCoordinates(raw);
}

function makePolygonLayer(path, fillColor, fillOpacity, extrudedHeight, strokeOpacity = null, hover = null) {
  return tagBaitLayer(createPolygon3D({
    path,
    altitude: 20,
    altitudeMode: 'relative',
    fillColor,
    fillOpacity,
    strokeColor: fillColor,
    strokeOpacity: strokeOpacity == null ? Math.min(fillOpacity + 0.08, 0.92) : strokeOpacity,
    strokeWidth: 0.8,
    extrudedHeight,
    hover,
    preferAttributePath: true,
  }));
}


function tagBaitLayer(el) {
  try { el?.setAttribute?.('data-gfs-layer', 'bait'); } catch (_) {}
  return el;
}

function baitProbability(row) {
  return clampProbability(row?.probability ?? row?.baitScore ?? row?.bait_score ?? row?.score ?? row?.confidence ?? 0.0);
}

function isWaterRow(row) {
  if (!row) return false;
  if (row.valid === false || row.water === false) return false;
  const mask = String(row.mask || row.water_mask_source || '').toLowerCase();
  if (mask.includes('land') || mask.includes('invalid')) return false;
  return true;
}

function normalizedBaitRowsFromOceanPoints(points) {
  return (Array.isArray(points) ? points : [])
    .filter(isWaterRow)
    .map((row, index) => ({
      row: { ...row, source: row.source || 'hycom_ocean_points_bait_probability' },
      index,
      lat: Number(row?.lat),
      lon: Number(row?.lon),
      probability: baitProbability(row),
      cell: row?.cell || null,
      waterMask: row?.mask || 'hycom_valid_water',
    }))
    .filter((x) => Number.isFinite(x.lat) && Number.isFinite(x.lon) && x.probability >= 0.10)
    .sort((a, b) => b.probability - a.probability)
    .slice(0, 96);
}

function normalizedBaitRowsFromScores(scoreRows) {
  return (Array.isArray(scoreRows) ? scoreRows : [])
    .filter(isWaterRow)
    .map((row, index) => ({
      row,
      index,
      lat: Number(row?.lat),
      lon: Number(row?.lon),
      probability: baitProbability(row),
      cell: row?.cell || null,
      waterMask: row?.water_mask_source || row?.mask || 'marker_or_bait_score',
    }))
    .filter((x) => Number.isFinite(x.lat) && Number.isFinite(x.lon) && x.probability >= 0.08)
    .sort((a, b) => b.probability - a.probability)
    .slice(0, 42);
}

function bboxSpan(bbox) {
  let west; let south; let east; let north;
  if (Array.isArray(bbox) && bbox.length >= 4) {
    [west, south, east, north] = bbox.map(Number);
  } else if (bbox && typeof bbox === 'object') {
    west = Number(bbox.west); south = Number(bbox.south); east = Number(bbox.east); north = Number(bbox.north);
  } else {
    return 6;
  }
  if (![west, south, east, north].every(Number.isFinite)) return 6;
  return Math.max(Math.abs(east - west), Math.abs(north - south));
}

function polygonFieldFromBaitRows({ oceanPoints = [], scoreRows = [], bbox = null } = {}) {
  // Preferred solve: SST/current-backed water samples. Fallback solve: the same
  // bait_score rows that feed the glass intel pane. The fallback is still
  // contoured into schools; it is not rendered as random point blobs.
  let rows = normalizedBaitRowsFromOceanPoints(oceanPoints);
  let source = 'hycom_ocean_points_bait_probability';
  let thresholds = [
    { name: 'outer', value: 0.12 },
    { name: 'inner', value: 0.27 },
    { name: 'core', value: 0.49 },
  ];

  if (rows.length < 4) {
    rows = normalizedBaitRowsFromScores(scoreRows);
    source = 'csv_marker_nearby_bait_score_school_solve';
    thresholds = [
      // Lower thresholds make low-viewport / sparse-marker bait cells show up
      // as broad schools instead of only appearing as HUD intel rows.
      { name: 'outer', value: 0.07 },
      { name: 'inner', value: 0.16 },
      { name: 'core', value: 0.32 },
    ];
  }

  const points = rows.map((x) => ({
    ...x.row,
    lat: x.lat,
    lon: x.lon,
    probability: x.probability,
    baitScore: x.probability,
    cell: x.cell,
    source,
    water_mask_source: x.waterMask,
  }));

  if (points.length < 4) {
    return { outer: [], inner: [], core: [], rows, source: 'waiting_for_bait_field_solve', grid: null };
  }

  const span = bboxSpan(bbox);
  const maxGrid = span > 18 ? 42 : span > 8 ? 58 : span > 3 ? 72 : 88;
  const contour = contourPolygonsFromPoints({
    points,
    bbox,
    valueAccessor: (row) => row?.probability ?? row?.baitScore ?? row?.bait_score ?? row?.score,
    thresholds,
    maxGrid,
    capPerBand: span > 12 ? 52 : 72,
  });

  return {
    outer: contour.bands?.outer || [],
    inner: contour.bands?.inner || [],
    core: contour.bands?.core || [],
    rows,
    source: `${source}+${contour.source}`,
    grid: contour.grid,
  };
}

function makeLineOverlay(line) {
  const el = tagBaitLayer(document.createElement('gmp-polyline-3d'));
  const pts = Array.isArray(line?.coordinates) ? line.coordinates : [];
  const path = sanitizePath(pts
    .filter((p) => Array.isArray(p) && p.length >= 2)
    .map((p) => ({ lat: toNumber(p[1]), lng: toNumber(p[0]), altitude: 15 })));
  if (path.length < 2) return null;
  el.path = path;
  el.setAttribute('altitude-mode', 'relative-to-ground');
  el.setAttribute('stroke-color', '#ffe38d');
  el.setAttribute('stroke-width', '2');
  el.setAttribute('stroke-opacity', '0.85');
  return el;
}

function enqueuePolygonBand(queue, polygons, band, payloadBbox = null) {
  (Array.isArray(polygons) ? polygons : []).forEach((poly) => {
    const pathBboxHint = poly?.bbox || poly?.bbox_used || payloadBbox || window.__gfsLastBaitBbox || null;
    const path = toPath(polygonCoordinates(poly), 20, pathBboxHint);
    if (path.length < 3) return;
    if (!pathLooksLikeViewportBait(path, pathBboxHint)) {
      try { console.info('[gfs bait] rejected detached chlorophyll/bait polygon', { band, source: poly?.source, pathPoints: path.length, bbox: pathBboxHint }); } catch (_) {}
      return;
    }
    const probability = poly?.probability ?? poly?.score ?? poly?.value ?? poly?.confidence ?? 0.35;
    queue.push({
      ...poly,
      path,
      probability,
      schoolScore: schoolScore({ ...poly, probability }),
      band: poly?.band || band,
    });
  });
}

function startFrameBatch({ queue, map3DElement, created, motionStates, payloadVector }) {
  let rafId = null;
  let disposed = false;

  const pump = () => {
    if (disposed) return;
    let injected = 0;
    const frag = document.createDocumentFragment();
    while (queue.length && injected < MAX_POLYGONS_PER_FRAME) {
      const poly = queue.shift();
      const p = clampProbability(poly?.schoolScore ?? poly?.probability);
      const { coreColor, innerColor, outerColor } = probabilityColorRamp(p);
      let el = null;
      const pct = Math.round(p * 100);
      const hover = {
        title: `Bait ${poly.band} marching-square zone`,
        lines: [
          `Grid bait score: ${pct}%`,
          Number.isFinite(Number(poly?.preferred_depth_m)) ? `Preferred depth: ${Number(poly.preferred_depth_m).toFixed(0)} m` : null,
          Number.isFinite(Number(poly?.depth_min_m)) && Number.isFinite(Number(poly?.depth_max_m)) ? `Depth band: ${Number(poly.depth_min_m).toFixed(0)}–${Number(poly.depth_max_m).toFixed(0)} m` : null,
          poly?.driver ? `Driver: ${String(poly.driver).replace(/_/g, ' ')}` : null,
          `Band: ${poly.band}`,
          `Motion: U/V current advection`,
        ].filter(Boolean),
        metrics: { layer: 'bait', band: poly.band, path_points: poly.path?.length || 0, source: poly.source || 'bait_advanced' },
        payload: {
          score: Number(p.toFixed(3)),
          probability_pct: pct,
          band: poly.band,
          preferred_depth_m: poly?.preferred_depth_m,
          depth_min_m: poly?.depth_min_m,
          depth_max_m: poly?.depth_max_m,
          driver: poly?.driver,
          sst_c: poly?.sst_c ?? poly?.sst,
          chlorophyll: poly?.chlorophyll ?? poly?.chl_mg_m3,
          current_mps: poly?.current_mps ?? poly?.current_speed_mps,
          path_points: poly.path?.length || 0,
        },
      };
      if (poly.band === 'outer') {
        el = makePolygonLayer(poly.path, outerColor, baitOpacity(p, 'outer'), baitExtrudeHeight(p, 'outer'), baitStrokeOpacity(p, 'outer'), hover);
      } else if (poly.band === 'inner') {
        el = makePolygonLayer(poly.path, innerColor, baitOpacity(p, 'inner'), baitExtrudeHeight(p, 'inner'), baitStrokeOpacity(p, 'inner'), hover);
      } else {
        el = makePolygonLayer(poly.path, coreColor, baitOpacity(p, 'core'), baitExtrudeHeight(p, 'core'), baitStrokeOpacity(p, 'core'), hover);
      }
      try {
        el?.setAttribute?.('data-bait-probability', String(Math.round(p * 100)));
        if (!el?.getAttribute?.('title')) el?.setAttribute?.('title', `Bait probability ${Math.round(p * 100)}%`);
      } catch (_) {}
      if (!el) continue;
      frag.append(el);
      created.push(el);
      motionStates.push({
        el,
        basePath: poly.path.map((pnt) => ({ ...pnt })),
        vector: motionVectorForPolygon(poly, payloadVector),
        schoolScore: p,
        band: poly.band,
        center: centroidOfPath(poly.path),
        phase: ((poly.path?.[0]?.lat || 0) * 7.13) + ((poly.path?.[0]?.lng || 0) * 3.17),
      });
      injected += 1;
    }
    if (injected) {
      map3DElement.append(frag);
    }
    if (queue.length) {
      rafId = requestAnimationFrame(pump);
    }
  };

  rafId = requestAnimationFrame(pump);

  return () => {
    disposed = true;
    if (rafId) cancelAnimationFrame(rafId);
  };
}


function isDrawableViewportReason(reason) {
  const r = String(reason || 'steady').toLowerCase();
  return r === 'boot' || r === 'steady' || r === 'settled' || r === 'manual' || r === 'refresh' || r.includes('steady') || r.includes('settled') || r.includes('update') || r.includes('deferred');
}

export function renderBaitZones({ payload, map3DElement, viewportReason = 'steady' }) {
  const created = [];
  if (!map3DElement || !payload) return () => {};
  console.info('[gfs bait] polygon api', { api: polygonApiPath() });
  if (!isDrawableViewportReason(viewportReason)) {
    console.info('[gfs bait] hold visible layer during non-draw reason', { reason: viewportReason });
    return () => {};
  }

  const bait = payload?.bait || {};
  const rootBait = payload || {};
  const polygonFieldV1 = payload?.polygon_field_v1;
  if (polygonFieldV1) {
    normalizePolygonFieldPayload(polygonFieldV1);
  }
  const scoreRows = Array.isArray(payload?.bait_score) ? payload.bait_score : (Array.isArray(payload?.bait?.bait_score) ? payload.bait.bait_score : []);
  const oceanPoints = Array.isArray(payload?.oceanPoints?.points) ? payload.oceanPoints.points : (Array.isArray(payload?.points) ? payload.points : []);
  const bbox = payload?.bbox || payload?.bbox_used || payload?.oceanPoints?.bbox || payload?.oceanPoints?.bbox_used || null;
  try { window.__gfsLastBaitBbox = bbox; } catch (_) {}
  const allowClientBaitFallback = window.__GFS_DEBUG_CLIENT_BAIT_FALLBACK === true;
  const solvePolygons = allowClientBaitFallback ? polygonFieldFromBaitRows({ oceanPoints, scoreRows, bbox }) : { outer: [], inner: [], core: [], rows: [], source: 'disabled_strict_payload_only', grid: null };
  const hasServerPolygons = Boolean(
    (Array.isArray(bait.outer_polygons) && bait.outer_polygons.length)
    || (Array.isArray(bait.inner_polygons) && bait.inner_polygons.length)
    || (Array.isArray(bait.core_polygons) && bait.core_polygons.length)
    || (Array.isArray(bait.polygons) && bait.polygons.length)
    || (Array.isArray(rootBait.outer_polygons) && rootBait.outer_polygons.length)
    || (Array.isArray(rootBait.inner_polygons) && rootBait.inner_polygons.length)
    || (Array.isArray(rootBait.core_polygons) && rootBait.core_polygons.length)
    || (Array.isArray(rootBait.polygons) && rootBait.polygons.length)
  );
  const baitSource = String(bait?.source || payload?.source || '').toLowerCase();
  const baitMode = String(payload?.mode || '').toLowerCase();
  const hasFullStack = bait.status === 'ready' && hasServerPolygons && (baitSource === 'full_stack' || baitSource.includes('live_hycom') || baitSource.includes('coastwatch') || baitMode.includes('marching_squares'));

  const outerPolygons = Array.isArray(bait.outer_polygons) && bait.outer_polygons.length ? bait.outer_polygons : (Array.isArray(rootBait.outer_polygons) && rootBait.outer_polygons.length ? rootBait.outer_polygons : solvePolygons.outer);
  const innerPolygons = Array.isArray(bait.inner_polygons) && bait.inner_polygons.length ? bait.inner_polygons : (Array.isArray(rootBait.inner_polygons) && rootBait.inner_polygons.length ? rootBait.inner_polygons : (Array.isArray(bait.polygons) && bait.polygons.length ? bait.polygons : (Array.isArray(rootBait.polygons) && rootBait.polygons.length ? rootBait.polygons : solvePolygons.inner)));
  const corePolygons = Array.isArray(bait.core_polygons) && bait.core_polygons.length ? bait.core_polygons : (Array.isArray(rootBait.core_polygons) && rootBait.core_polygons.length ? rootBait.core_polygons : solvePolygons.core);

  if (!outerPolygons.length && !innerPolygons.length && !corePolygons.length) {
    console.info('[gfs bait] waiting for field solve', {
      status: bait.status,
      source: bait.source || payload?.source,
      baitScoreRows: scoreRows.length,
      oceanPointRows: oceanPoints.length,
      payloadKeys: Object.keys(payload || {}),
      baitKeys: Object.keys(bait || {}),
      reason: allowClientBaitFallback ? 'debug_client_bait_fallback_no_visible_school_solve_yet' : 'strict_payload_has_no_server_polygons_yet',
    });
    return () => {};
  }

  const payloadVector = averageCurrentVector([...(oceanPoints || []), ...(scoreRows || [])]);
  const motionStates = [];
  const polygonQueue = [];
  enqueuePolygonBand(polygonQueue, outerPolygons, 'outer', bbox);
  enqueuePolygonBand(polygonQueue, innerPolygons, 'inner', bbox);
  enqueuePolygonBand(polygonQueue, corePolygons, 'core', bbox);

  const frag = document.createDocumentFragment();
  const lines = Array.isArray(payload?.front_lines) ? payload.front_lines : [];
  lines.forEach((line) => {
    const el = makeLineOverlay(line);
    if (!el) return;
    frag.append(el);
    created.push(el);
  });
  if (created.length) {
    map3DElement.append(frag);
  }

  const stopBatch = startFrameBatch({ queue: polygonQueue, map3DElement, created, motionStates, payloadVector });
  const stopAdvection = startBaitAdvectionLoop(motionStates);
  console.info('[gfs bait] queued polygons', {
    totalPolygons: polygonQueue.length,
    outer: outerPolygons.length,
    inner: innerPolygons.length,
    core: corePolygons.length,
    lines: lines.length,
    batchSize: MAX_POLYGONS_PER_FRAME,
    source: hasFullStack ? 'full_stack' : solvePolygons.source,
    baitScoreRows: scoreRows.length,
    oceanPointRows: oceanPoints.length,
    opacityModel: 'fillAlpha = base + scale * schoolScore^2',
    advection: { enabled: window.GFS_BAIT_DRIFT_ENABLED !== false, pathMutationEnabled: window.GFS_BAIT_MUTATE_PATHS === true || window.GFS_BAIT_DRIFT_MUTATE_PATHS === true, vector: payloadVector, timeScale: Number(window.GFS_BAIT_DRIFT_TIME_SCALE ?? BAIT_DRIFT_DEFAULT_TIME_SCALE) },
    solveGrid: solvePolygons.grid || null,
    solveMethod: allowClientBaitFallback ? 'debug client contour solve from ocean/bait rows' : 'strict server polygons only: sea contours plus advanced bait marching-squares',
    seaResolution: payload?.sea_resolution || null,
  });

  return () => {
    stopBatch();
    stopAdvection();
    created.forEach((el) => {
      try { el.remove(); } catch (_) {}
    });
    try { map3DElement.querySelectorAll?.('[data-gfs-layer="bait"]')?.forEach((el) => el.remove()); } catch (_) {}
    console.info('[gfs bait] layer cleared', { removed: created.length });
  };
}
