// Tunable bait scoring formulas used by tests and future frontend HUD tuning.
export function clamp01(v) { return Math.max(0, Math.min(1, Number(v) || 0)); }

export function computeBaseBaitScore({ sstScore = 0.5, chlScore = 0.5, currentScore = 0.5, windScore = 0.5 } = {}) {
  return clamp01(0.34 * sstScore + 0.24 * chlScore + 0.20 * currentScore + 0.22 * windScore);
}

export function computeFinalBaitScore({ baseBait = 0.5, frontsScore = 0.5, tideScore = 0.5, moonScore = 0.5 } = {}) {
  return clamp01(0.40 * baseBait + 0.25 * frontsScore + 0.20 * tideScore + 0.15 * moonScore);
}
