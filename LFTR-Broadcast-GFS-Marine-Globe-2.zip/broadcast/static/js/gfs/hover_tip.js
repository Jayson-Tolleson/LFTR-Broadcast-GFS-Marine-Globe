let tipEl = null;

const DEFAULT_PROMPT = 'Hover drawn bait, boat, current, cloud, rain, lightning, or scene polygons for details.';
const MAX_PAYLOAD_ROWS = 16;

function ensureTip() {
  if (tipEl) return tipEl;
  tipEl = document.createElement('div');
  tipEl.id = 'gfsPolygonHoverTip';
  tipEl.className = 'gfs-polygon-hover-tip hidden';
  document.body.appendChild(tipEl);
  return tipEl;
}

function ensureTitleHoverHud() {
  // Hover intel is now cursor-local only. Keep this helper as a harmless
  // compatibility stub for older callers that imported setTitleHoverHud().
  return null;
}

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function titleCase(value) {
  return String(value || '')
    .replace(/[_\-]+/g, ' ')
    .replace(/\b\w/g, (m) => m.toUpperCase())
    .trim();
}

function fmtValue(value) {
  if (value == null || value === '') return 'n/a';
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) return 'n/a';
    if (Math.abs(value) >= 1000) return value.toFixed(0);
    if (Math.abs(value) >= 10) return value.toFixed(2);
    return value.toFixed(3);
  }
  if (typeof value === 'boolean') return value ? 'true' : 'false';
  if (Array.isArray(value)) {
    if (!value.length) return '[]';
    if (value.length <= 4 && value.every((v) => typeof v !== 'object')) return value.map(fmtValue).join(', ');
    return `[${value.length} items]`;
  }
  if (typeof value === 'object') {
    const keys = Object.keys(value);
    if (!keys.length) return '{}';
    const simple = keys.slice(0, 4).filter((k) => typeof value[k] !== 'object').map((k) => `${k}:${fmtValue(value[k])}`);
    return simple.length ? simple.join(' ') : `{${keys.slice(0, 4).join(', ')}}`;
  }
  const s = String(value);
  return s.length > 80 ? `${s.slice(0, 77)}…` : s;
}

function parseMaybeJson(value) {
  if (!value || typeof value !== 'string') return null;
  try { return JSON.parse(value); } catch (_) { return null; }
}

function attrsPayload(el) {
  const payload = {};
  try {
    for (const attr of Array.from(el?.attributes || [])) {
      const name = attr.name || '';
      if (!name.startsWith('data-')) continue;
      const key = name.replace(/^data-/, '').replace(/-/g, '_');
      if (key === 'gfs_hover_payload') continue;
      payload[key] = attr.value;
    }
  } catch (_) {}
  return payload;
}

function inferHoverFromElement(el) {
  if (!el) return null;
  const ds = el.dataset || {};
  const json = parseMaybeJson(ds.gfsHoverPayload || ds.payload || '');
  const layer = ds.gfsLayer || ds.layer || ds.gfsSubLayer || el.getAttribute?.('data-gfs-layer') || 'drawn graphic';
  const sub = ds.gfsSubLayer || ds.cloudShell || ds.lightningRegion || ds.currentBand || '';
  const title = ds.gfsHoverTitle || el.getAttribute?.('aria-label') || el.getAttribute?.('title') || `${titleCase(layer)}${sub ? ` ${titleCase(sub)}` : ''}`;
  const rawPathMode = el.__gfsPathMode || el.getAttribute?.('data-gfs-path-mode');
  const points = el.__gfsPathPointCount || el.getAttribute?.('data-gfs-path-points');
  const metrics = {
    layer,
    sub_layer: sub || undefined,
    source: ds.source || ds.gfsSource || ds.cloudShellSource || ds.lightningSource || undefined,
    path_mode: rawPathMode || undefined,
    path_points: points || undefined,
    altitude_mode: el.getAttribute?.('altitude-mode') || undefined,
    fill_opacity: el.getAttribute?.('fill-opacity') || undefined,
    extrusion_m: el.getAttribute?.('extruded-height') || undefined,
  };
  const attrPayload = attrsPayload(el);
  return {
    title,
    detail: ds.gfsHoverDetail || '',
    lines: [
      layer ? `Layer: ${titleCase(layer)}` : null,
      sub ? `Graphic: ${titleCase(sub)}` : null,
      points ? `Path points: ${points}` : null,
    ].filter(Boolean),
    metrics,
    payload: json || attrPayload,
  };
}

function normalizeHover(hover, el = null) {
  if (!hover || hover === true || hover.auto) return inferHoverFromElement(el);
  if (typeof hover === 'string') return { title: hover, lines: [] };
  if (hover && typeof hover === 'object') return hover;
  return inferHoverFromElement(el);
}


function countFromPayload(payload, ...keys) {
  if (!payload || typeof payload !== 'object') return null;
  for (const key of keys) {
    const value = payload[key];
    if (Array.isArray(value)) return value.length;
    const n = Number(value);
    if (Number.isFinite(n)) return n;
  }
  return null;
}

function payloadDescription(h) {
  if (!h || typeof h !== 'object') return '';
  const payload = h.payload || h.data || h.raw || {};
  const metrics = h.metrics || {};
  const layer = String(h.layer || payload.layer || metrics.layer || '').toLowerCase();
  const title = String(h.title || '').toLowerCase();
  const source = payload.source || payload.gfs_source || metrics.source || payload.lightning_source || payload.cloud_shell_source || '';
  const parts = [];
  const add = (label, value) => { if (value != null && value !== '') parts.push(`${label}: ${fmtValue(value)}`); };
  if (layer.includes('bait') || title.includes('bait')) {
    add('payload', 'bait polygon');
    add('score', payload.score || payload.bait_score || payload.probability);
    add('sst', payload.sst_c || payload.sst_f || payload.temperature);
    add('chlorophyll', payload.chlorophyll || payload.chl_mg_m3);
    add('current', payload.current_mps || payload.current_speed_mps);
  } else if (layer.includes('cloud') || title.includes('cloud')) {
    add('payload', 'cloud shell');
    add('base', payload.base_m || payload.base_altitude_m || metrics.altitude_m);
    add('top', payload.top_m || payload.top_altitude_m);
    add('cover', payload.cover || payload.cloud_total || payload.density);
  } else if (layer.includes('rain') || title.includes('rain')) {
    add('payload', 'rain/precip polygon');
    add('rate', payload.precip_rate || payload.rain_rate || payload.mm_hr);
    add('intensity', payload.intensity || payload.severity);
  } else if (layer.includes('lightning') || title.includes('lightning')) {
    add('payload', 'lightning region');
    add('flashes', countFromPayload(payload, 'flashes', 'flash_count'));
    add('age', payload.age_seconds || payload.newest_age_seconds);
    add('source', source);
  } else if (layer.includes('current') || title.includes('current')) {
    add('payload', 'ocean current polygon');
    add('speed', payload.speed_mps || payload.current_mps);
    add('direction', payload.direction_deg || payload.direction);
  } else if (layer.includes('boater') || layer.includes('boat') || title.includes('boat')) {
    add('payload', 'boater safety polygon');
    add('swell', payload.swell_ft || payload.wave_height_ft);
    add('wind', payload.wind_mps || payload.wind_mph);
    add('risk', payload.risk || payload.safety);
  } else {
    add('payload', titleCase(layer || 'scene polygon'));
    add('source', source || payload.provider);
  }
  add('path', metrics.path_points || payload.path_points);
  return parts.filter(Boolean).join(' • ');
}

function payloadRows(payload) {
  if (!payload || typeof payload !== 'object') return [];
  return Object.entries(payload)
    .filter(([_, v]) => v != null && v !== '')
    .slice(0, MAX_PAYLOAD_ROWS)
    .map(([k, v]) => `<div class="gfs-hover-kv"><span>${escapeHtml(titleCase(k))}</span><b>${escapeHtml(fmtValue(v))}</b></div>`);
}

function htmlFromHover(hover, el = null) {
  const h = normalizeHover(hover, el);
  if (!h) return '';
  const title = h.title || h.layer || 'GFS graphic';
  const lines = Array.isArray(h.lines) ? h.lines : [];
  const desc = payloadDescription(h);
  const detail = [desc, h.detail].filter(Boolean);
  const metrics = h.metrics && typeof h.metrics === 'object'
    ? Object.entries(h.metrics).filter(([_, v]) => v != null && v !== '').map(([k, v]) => `${titleCase(k)}: ${fmtValue(v)}`)
    : [];
  const payload = payloadRows(h.payload || h.data || h.raw || null);
  return [
    `<div class="gfs-hover-title">${escapeHtml(title)}</div>`,
    ...detail.map((line) => `<div>${escapeHtml(line)}</div>`),
    ...lines.filter(Boolean).map((line) => `<div>${escapeHtml(line)}</div>`),
    ...metrics.filter(Boolean).map((line) => `<div>${escapeHtml(line)}</div>`),
    payload.length ? '<div class="gfs-hover-section">Payload</div>' : '',
    ...payload,
  ].join('');
}

function positionTip(event) {
  const tip = ensureTip();
  const pad = 16;
  const x = Number(event?.clientX ?? 0) + pad;
  const y = Number(event?.clientY ?? 0) + pad;
  const rect = tip.getBoundingClientRect();
  const maxX = Math.max(0, window.innerWidth - rect.width - 10);
  const maxY = Math.max(0, window.innerHeight - rect.height - 10);
  tip.style.left = `${Math.min(x, maxX)}px`;
  tip.style.top = `${Math.min(y, maxY)}px`;
}

function markPolygonHoverActive(ms = 2600) {
  try { window.__gfsPolygonHoverActiveUntil = Date.now() + ms; } catch (_) {}
}

export function isPolygonHoverActive() {
  try { return Date.now() < Number(window.__gfsPolygonHoverActiveUntil || 0); } catch (_) { return false; }
}

function showHoverHtml(html, event) {
  markPolygonHoverActive();
  const tip = ensureTip();
  tip.innerHTML = html || escapeHtml(DEFAULT_PROMPT);
  tip.classList.remove('hidden');
  positionTip(event);
}

export function setTitleHoverHud(hover) {
  // Legacy name retained, but there is no longer a fixed hover-intel pane.
  // Callers with no cursor event should not create a floating tooltip at 0,0.
  markPolygonHoverActive();
  return htmlFromHover(hover);
}

export function describeLayerPayload(el, payload) {
  if (!el || !payload || typeof payload !== 'object') return el;
  try { el.dataset.gfsHoverPayload = JSON.stringify(payload); } catch (_) {}
  return el;
}

export function attachPolygonHover(el, hover = null) {
  if (!el) return el;
  if (el.__gfsHoverAttached) {
    if (hover) el.__gfsHover = hover;
    return el;
  }
  el.__gfsHoverAttached = true;
  el.__gfsHover = hover || true;

  const initial = normalizeHover(hover, el);
  const title = initial?.title || initial?.layer || el.getAttribute?.('title') || 'GFS graphic';
  const desc = payloadDescription(initial || {});
  try {
    el.setAttribute?.('title', desc ? `${title} — ${desc}` : title);
    el.setAttribute?.('aria-label', title);
    el.setAttribute?.('data-gfs-hover-title', title);
    if (el.style) el.style.cursor = 'pointer';
  } catch (_) {}

  const show = (event) => {
    markPolygonHoverActive();
    const html = htmlFromHover(el.__gfsHover || true, el);
    if (html) showHoverHtml(html, event);
  };
  const move = (event) => {
    if (!tipEl || tipEl.classList.contains('hidden')) return;
    positionTip(event);
  };
  const hide = () => {
    markPolygonHoverActive(900);
    if (tipEl) tipEl.classList.add('hidden');
  };

  try {
    el.addEventListener?.('pointerenter', show);
    el.addEventListener?.('pointermove', move);
    el.addEventListener?.('pointerleave', hide);
    el.addEventListener?.('mouseenter', show);
    el.addEventListener?.('mousemove', move);
    el.addEventListener?.('mouseleave', hide);
    el.addEventListener?.('gmp-click', show);
    el.addEventListener?.('click', show);
    el.addEventListener?.('focus', show);
  } catch (_) {}
  return el;
}

export function hidePolygonHoverTip() {
  if (tipEl) tipEl.classList.add('hidden');
}

function hoverableSelector() {
  return 'gmp-polygon-3d,[data-gfs-layer],gmp-marker-3d[data-gfs-layer],gmp-polyline-3d[data-gfs-layer]';
}

function hoverableFromEvent(event) {
  const selector = hoverableSelector();
  try {
    const path = typeof event?.composedPath === 'function' ? event.composedPath() : [];
    for (const node of path || []) {
      if (node?.matches?.(selector)) return node;
    }
  } catch (_) {}
  let node = event?.target || null;
  while (node && node !== document && node !== window) {
    if (node.matches?.(selector)) return node;
    node = node.parentNode || node.host || null;
  }
  return null;
}

function installDocumentHoverBridge(root = document) {
  if (window.__gfsUniversalPolygonHoverBridgeInstalled) return;
  window.__gfsUniversalPolygonHoverBridgeInstalled = true;
  const showFromEvent = (event) => {
    const el = hoverableFromEvent(event);
    if (!el) return;
    attachPolygonHover(el, el.__gfsHover || true);
    const html = htmlFromHover(el.__gfsHover || true, el);
    if (html) showHoverHtml(html, event);
  };
  // Capture phase is important for Google Maps 3D custom elements: normal
  // pointerenter/mouseenter may not bubble out of the upgraded map element, but
  // pointerover/move usually still passes through the composed event path.
  root.addEventListener?.('pointerover', showFromEvent, true);
  root.addEventListener?.('pointermove', showFromEvent, true);
  root.addEventListener?.('mouseover', showFromEvent, true);
  root.addEventListener?.('click', showFromEvent, true);
  root.addEventListener?.('gmp-click', showFromEvent, true);
}

export function installUniversalPolygonHover(root = document) {
  const selector = hoverableSelector();
  const attachExisting = () => {
    try {
      root.querySelectorAll?.(selector)?.forEach((el) => attachPolygonHover(el, el.__gfsHover || true));
    } catch (_) {}
  };
  attachExisting();
  installDocumentHoverBridge(document);
  try {
    const mo = new MutationObserver((records) => {
      for (const rec of records) {
        for (const node of Array.from(rec.addedNodes || [])) {
          if (!node || node.nodeType !== 1) continue;
          if (node.matches?.(selector)) attachPolygonHover(node, node.__gfsHover || true);
          node.querySelectorAll?.(selector)?.forEach((el) => attachPolygonHover(el, el.__gfsHover || true));
        }
      }
    });
    mo.observe(root === document ? document.body : root, { childList: true, subtree: true });
    window.__gfsUniversalPolygonHoverObserver = mo;
  } catch (_) {}
}

try {
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => installUniversalPolygonHover(document));
  else installUniversalPolygonHover(document);
} catch (_) {}
