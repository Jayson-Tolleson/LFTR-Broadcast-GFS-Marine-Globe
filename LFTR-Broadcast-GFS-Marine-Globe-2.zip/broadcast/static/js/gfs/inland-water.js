import { createPolygon3D } from './polygon3d.js';
import { attachPolygonHover } from './hover_tip.js';

const VIRIDIAN = '#40826D';
const VIRIDIAN_FILL = 'rgba(64,130,109,0.045)';
const VIRIDIAN_STROKE = '#6fffd2';
const BAIT_FILL = 'rgba(88,255,126,0.12)';
const BAIT_STROKE = '#9cff75';

function n(v, fallback = 0) {
  const out = Number(v);
  return Number.isFinite(out) ? out : fallback;
}

function normalizePath(path, altitude = 10) {
  const out = [];
  for (const p of Array.isArray(path) ? path : []) {
    const lat = n(p?.lat, NaN);
    const lng = n(p?.lng ?? p?.lon, NaN);
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) continue;
    if (lat < -90 || lat > 90 || lng < -180 || lng > 180) continue;
    const prev = out[out.length - 1];
    if (prev && Math.abs(prev.lat - lat) < 1e-8 && Math.abs(prev.lng - lng) < 1e-8) continue;
    out.push({ lat, lng, altitude });
  }
  if (out.length >= 2) {
    const a = out[0];
    const b = out[out.length - 1];
    if (Math.abs(a.lat - b.lat) < 1e-8 && Math.abs(a.lng - b.lng) < 1e-8) out.pop();
  }
  return out;
}

function linePathAttr(path) {
  return path.map((p) => `${p.lat.toFixed(8)},${p.lng.toFixed(8)},${n(p.altitude, 12).toFixed(2)}`).join(' ');
}

function makePolyline3D({ path, strokeColor = VIRIDIAN_STROKE, strokeWidth = 4, altitude = 18, hover = null }) {
  const coords = normalizePath(path, altitude);
  if (coords.length < 2) return null;
  const el = document.createElement('gmp-polyline-3d');
  try { el.setAttribute('path', linePathAttr(coords)); } catch (_) {}
  try { el.path = coords; } catch (_) {}
  try { el.setAttribute('altitude-mode', 'relative-to-ground'); } catch (_) {}
  try { el.strokeColor = strokeColor; } catch (_) {}
  try { el.strokeWidth = strokeWidth; } catch (_) {}
  try { el.setAttribute('stroke-color', strokeColor); } catch (_) {}
  try { el.setAttribute('stroke-width', String(strokeWidth)); } catch (_) {}
  try { el.setAttribute('draws-when-occluded', 'true'); } catch (_) {}
  try { el.setAttribute('data-gfs-layer', 'inland-water'); } catch (_) {}
  try { el.setAttribute('data-inland-water-kind', 'flowline'); } catch (_) {}
  if (hover) {
    try { attachPolygonHover(el, hover); } catch (_) {}
  }
  return el;
}

function waterHover(item, path, kind = 'water') {
  const temp = item.water_temp_f ?? item.surface_temp_f ?? null;
  const bait = item.bait_score ?? null;
  return {
    title: `${item.name || 'Inland water'} (${item.kind || kind})`,
    lines: [
      `Source: ${item.source_class || 'NHD/NHDPlus HR'}`,
      `FCode: ${item.fcode ?? 'n/a'}`,
      temp != null ? `Surface temp: ${Number(temp).toFixed(1)} °F` : 'Surface temp: unavailable until real t0m/TMP:surface/skt sample',
      bait != null ? `Inland bait score: ${Number(bait).toFixed(1)} / 5` : 'Inland bait: pending',
      item.shoreline_truth ? `Shoreline: ${item.shoreline_truth}` : `Path points: ${path.length}`,
      `Path points: ${path.length}`,
    ],
    metrics: { layer: 'inland-water', kind: item.kind || kind, path_points: path.length, source: item.source_class || 'NHDPlus HR' },
    payload: item,
  };
}

function makeWaterPolygon(item) {
  const path = normalizePath(item.path, 9);
  if (path.length < 3) return null;
  const el = createPolygon3D({
    path,
    altitude: 9,
    altitudeMode: 'relative',
    fillColor: VIRIDIAN_FILL,
    fillOpacity: Number(item?.style?.fillOpacity ?? 0.045),
    strokeColor: item?.style?.strokeColor || VIRIDIAN_STROKE,
    strokeOpacity: Number(item?.style?.strokeOpacity ?? 0.78),
    strokeWidth: Number(item?.style?.strokeWidth ?? 0.72),
    extrudedHeight: Number(item?.style?.extrudedHeight ?? 0),
    neonGlow: false,
    preferAttributePath: true,
    hover: waterHover(item, path, 'waterbody'),
  });
  try { el?.setAttribute?.('data-gfs-layer', 'inland-water'); } catch (_) {}
  try { el?.setAttribute?.('data-inland-water-kind', item.kind || 'waterbody'); } catch (_) {}
  return el;
}


function baitZoneHover(zone = {}, path = []) {
  const safeZone = zone && typeof zone === 'object' ? zone : {};
  const safePath = Array.isArray(path) ? path : [];
  const temp = n(safeZone.water_temp_f ?? safeZone.surface_temp_f, NaN);
  const bait = n(safeZone.bait_score ?? safeZone.score, NaN);
  const source = String(safeZone.source || safeZone.temperature_source || 'freshwater thermal bait heuristic');
  const reason = String(safeZone.reason || safeZone.reasons?.[0] || 'freshwater bait zone');
  return {
    title: `${safeZone.name || 'Inland bait'} (${safeZone.kind || 'bait-zone'})`,
    lines: [
      Number.isFinite(bait) ? `Inland bait score: ${bait.toFixed(1)} / 5` : 'Inland bait score: pending',
      Number.isFinite(temp) ? `Water temp: ${temp.toFixed(1)} °F` : 'Water temp: unavailable',
      `Source: ${source}`,
      `Reason: ${reason}`,
      safeZone.shoreline_truth ? `Shoreline: ${safeZone.shoreline_truth}` : `Path points: ${safePath.length}`,
    ],
    metrics: { layer: 'inland-water', kind: 'bait-zone', path_points: safePath.length, source },
    payload: safeZone,
  };
}

function makeBaitZonePolygon(zone) {
  const path = normalizePath(zone?.path, 14);
  if (path.length < 3) return null;
  const score = n(zone?.bait_score, 2.5);
  const fillOpacity = Math.max(0.12, Math.min(0.28, 0.10 + ((score / 5) * 0.18)));
  const el = createPolygon3D({
    path,
    altitude: 14,
    altitudeMode: 'relative',
    fillColor: BAIT_FILL,
    fillOpacity,
    strokeColor: BAIT_STROKE,
    strokeOpacity: 0.96,
    strokeWidth: 1.5,
    extrudedHeight: Math.max(6, Math.min(14, 4 + score * 1.4)),
    neonGlow: true,
    preferAttributePath: true,
    hover: baitZoneHover(zone, path),
  });
  try { el?.setAttribute?.('data-gfs-layer', 'inland-water'); } catch (_) {}
  try { el?.setAttribute?.('data-inland-water-kind', 'bait-zone'); } catch (_) {}
  return el;
}

function cameraRangeMeters(map3DElement) {
  const raw = Number(map3DElement?.range ?? map3DElement?.camera?.range ?? map3DElement?.getAttribute?.('range'));
  return Number.isFinite(raw) && raw > 0 ? raw : 900000;
}

function tempLabelBudget(range) {
  // Zoomed in: many small labels; zoomed out: a few large labels.
  if (range < 55000) return 120;
  if (range < 140000) return 86;
  if (range < 350000) return 54;
  if (range < 900000) return 24;
  return 10;
}

function tempLabelStride(range) {
  if (range < 55000) return 1;
  if (range < 140000) return 1;
  if (range < 350000) return 1;
  if (range < 900000) return 2;
  return 3;
}

function tempLabelFontSize(range) {
  // User-visible intent: large blue temps when zoomed out; smaller repeated
  // temps when zoomed into the actual inland water surface.
  if (range < 55000) return 20;
  if (range < 140000) return 23;
  if (range < 350000) return 28;
  if (range < 900000) return 38;
  return 52;
}

function tempLabelAltitude(range) {
  if (range < 55000) return 16;
  if (range < 140000) return 20;
  if (range < 350000) return 26;
  if (range < 900000) return 36;
  return 48;
}

function isRealTemperaturePoint(pt) {
  const source = String(pt?.source || pt?.temperature_source || '').toLowerCase();
  const confidence = String(pt?.confidence || '').toLowerCase();
  if (!pt) return false;
  if (pt.real === true || pt.observed === true) return true;
  if (confidence === 'high' || confidence === 'medium') {
    if (source.includes('gfs_ncss_surface_candidate') || source.includes('surface:') || source.includes('2m:') || source.includes('usgs') || source.includes('gauge') || source.includes('observed')) return true;
  }
  return false;
}

function dedupeTemperaturePoints(points) {
  const seen = new Set();
  const out = [];
  for (const pt of Array.isArray(points) ? points : []) {
    if (!isRealTemperaturePoint(pt)) continue;
    const lat = n(pt?.lat, NaN);
    const lng = n(pt?.lng ?? pt?.lon, NaN);
    const temp = n(pt?.water_temp_f ?? pt?.surface_temp_f, NaN);
    if (!Number.isFinite(lat) || !Number.isFinite(lng) || !Number.isFinite(temp)) continue;
    if (lat < -90 || lat > 90 || lng < -180 || lng > 180) continue;
    const key = `${lat.toFixed(4)}:${lng.toFixed(4)}:${Math.round(temp)}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({ ...pt, lat, lng, water_temp_f: temp, real: true });
  }
  return out;
}

function centroidFromPath(path) {
  const pts = normalizePath(path, 14);
  if (!pts.length) return null;
  const lat = pts.reduce((a, p) => a + p.lat, 0) / pts.length;
  const lng = pts.reduce((a, p) => a + p.lng, 0) / pts.length;
  return { lat, lng };
}

function synthesizeTemperaturePointsFromGeometry({ polygons, lines, bait, conditions }) {
  // Real-only policy: do not synthesize labels from geometry or fallback values.
  // We only duplicate already-real sampled points supplied by conditions/bait.
  const out = [];
  const candidates = [
    ...(Array.isArray(conditions?.temperature_points) ? conditions.temperature_points : []),
    ...(Array.isArray(bait?.temperature_points) ? bait.temperature_points : []),
  ];
  for (const pt of candidates) {
    if (isRealTemperaturePoint(pt)) out.push(pt);
  }
  return out;
}

function makeTempLabelMarker(pt, map3DElement) {
  const temp = n(pt?.water_temp_f ?? pt?.surface_temp_f, NaN);
  const lat = n(pt?.lat, NaN);
  const lng = n(pt?.lng ?? pt?.lon, NaN);
  if (!Number.isFinite(temp) || !Number.isFinite(lat) || !Number.isFinite(lng)) return null;
  const range = cameraRangeMeters(map3DElement);
  const fontSize = tempLabelFontSize(range);
  if (!isRealTemperaturePoint(pt)) return null;
  const label = `${Math.round(temp)}°F`;
  const width = Math.max(82, label.length * fontSize * 0.78);
  const height = fontSize + 30;
  const safeTitle = `${pt.name || 'Inland water'} surface temp`;
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">
      <filter id="glow"><feGaussianBlur stdDeviation="2.4" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
      <ellipse cx="${width/2}" cy="${height/2}" rx="${width*0.44}" ry="${height*0.30}" fill="rgba(0,30,60,.18)"/>
      <text x="${width/2}" y="${height/2 + fontSize*0.34}" text-anchor="middle"
        font-family="Inter, Arial, sans-serif" font-size="${fontSize}" font-weight="950"
        stroke="#ff7a00" stroke-width="7" fill="#009dff" paint-order="stroke fill"
        filter="url(#glow)">${label}</text>
    </svg>`;
  const marker = document.createElement('gmp-marker-3d');
  const altitude = tempLabelAltitude(range);
  try { marker.position = { lat, lng, altitude }; } catch (_) {}
  try { marker.setAttribute('position', `${lat},${lng},${altitude}`); } catch (_) {}
  try { marker.setAttribute('altitude-mode', 'relative-to-ground'); } catch (_) {}
  try { marker.setAttribute('draws-when-occluded', 'true'); } catch (_) {}
  try { marker.setAttribute('data-gfs-layer', 'inland-water'); } catch (_) {}
  try { marker.setAttribute('data-inland-water-kind', 'temp-label'); } catch (_) {}
  const template = document.createElement('template');
  template.innerHTML = svg.trim();
  marker.append(template);
  try {
    attachPolygonHover(marker, {
      title: safeTitle,
      lines: [
        `Water temp: ${temp.toFixed(1)} °F`,
        `Source: ${pt.source || pt.temperature_source || 'real_surface_temperature'}`,
        `Confidence: ${pt.confidence || 'medium'}`,
      ],
      metrics: { layer: 'inland-water', kind: 'temp-label', source: pt.source || pt.temperature_source || 'real_surface_temperature' },
      payload: pt,
    });
  } catch (_) {}
  return marker;
}

export function renderInlandWaterLayer({ payload, map3DElement }) {
  const created = [];
  if (!map3DElement || !payload) return () => {};
  const polygons = Array.isArray(payload.polygons) ? payload.polygons : [];
  const lines = Array.isArray(payload.lines) ? payload.lines : [];
  const baitZones = Array.isArray(payload.bait?.zones) ? payload.bait.zones : [];
  const baitByName = new Map((Array.isArray(payload.bait?.targets) ? payload.bait.targets : []).map((x) => [String(x.name || '').toLowerCase(), x]));
  const conditionsByName = new Map((Array.isArray(payload.conditions?.items) ? payload.conditions.items : []).map((x) => [String(x.name || '').toLowerCase(), x]));
  const cameraRange = cameraRangeMeters(map3DElement);
  const tempBudget = tempLabelBudget(cameraRange);
  const tempStride = tempLabelStride(cameraRange);
  const rawTempPoints = [
    ...(Array.isArray(payload.temperature_points) ? payload.temperature_points : []),
    ...(Array.isArray(payload.conditions?.temperature_points) ? payload.conditions.temperature_points : []),
    ...(Array.isArray(payload.bait?.temperature_points) ? payload.bait.temperature_points : []),
    ...synthesizeTemperaturePointsFromGeometry({ polygons, lines, bait: payload.bait, conditions: payload.conditions }),
  ];
  const candidateTempPoints = dedupeTemperaturePoints(rawTempPoints);
  const temperaturePoints = candidateTempPoints.filter((_, idx) => idx % tempStride === 0).slice(0, tempBudget);
  const frag = document.createDocumentFragment();

  for (const p of polygons) {
    const key = String(p.name || '').toLowerCase();
    const merged = { ...p, ...(conditionsByName.get(key) || {}), ...(baitByName.get(key) || {}) };
    const el = makeWaterPolygon(merged);
    if (!el) continue;
    frag.append(el);
    created.push(el);
  }
  for (const l of lines) {
    const path = normalizePath(l.path, 18);
    if (path.length < 2) continue;
    const key = String(l.name || '').toLowerCase();
    const merged = { ...l, ...(conditionsByName.get(key) || {}), ...(baitByName.get(key) || {}) };
    const el = makePolyline3D({ path, altitude: 18, strokeColor: VIRIDIAN_STROKE, strokeWidth: 4, hover: waterHover(merged, path, 'flowline') });
    if (!el) continue;
    frag.append(el);
    created.push(el);
  }
  let baitZoneFailures = 0;
  for (const zone of baitZones) {
    try {
      const el = makeBaitZonePolygon(zone);
      if (!el) continue;
      frag.append(el);
      created.push(el);
    } catch (err) {
      baitZoneFailures += 1;
      if (baitZoneFailures <= 3) console.warn('[gfs inland-water] skipped malformed bait zone', { message: err?.message || String(err), zoneName: zone?.name || null });
    }
  }
  for (const pt of temperaturePoints) {
    const label = makeTempLabelMarker(pt, map3DElement);
    if (!label) continue;
    frag.append(label);
    created.push(label);
  }
  if (created.length) map3DElement.append(frag);
  try { window.__gfsDebugEvent?.('inland-water/render', { polygons: polygons.length, lines: lines.length, unfilteredCount: payload.unfiltered_count || null, prominenceFilter: payload.prominence_filter || null, baitZones: baitZones.length, baitZoneFailures, tempLabels: temperaturePoints.length, rendered: created.length, source: payload.source }); } catch (_) {}
  console.info('[gfs inland-water] rendered', { polygons: polygons.length, lines: lines.length, unfilteredCount: payload.unfiltered_count || null, prominenceFilter: payload.prominence_filter || null, baitZones: baitZones.length, baitZoneFailures, tempLabels: temperaturePoints.length, rawTempPoints: rawTempPoints.length, range: Math.round(cameraRange), rendered: created.length, source: payload.source, baitTargets: payload.bait?.targets?.length || 0, labelMode: cameraRange < 350000 ? 'close_many_small' : 'far_few_large' });
  return () => {
    created.forEach((el) => { try { el.remove(); } catch (_) {} });
  };
}
