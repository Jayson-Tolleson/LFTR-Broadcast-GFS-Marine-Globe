
const DRAWABLE_REASONS = new Set(['boot', 'steady', 'settled', 'refresh', 'manual', 'cache_update', 'tile_update', 'bait-deferred', 'clouds-deferred', 'boats-deferred', 'oceanPoints-deferred']);
const HOLD_REASONS = new Set(['camera_move', 'camera_moving', 'orbit', 'orbit_move', 'pan', 'tilt', 'range', 'heading']);

function normalizeReason(reason) {
  return String(reason || 'steady').toLowerCase();
}

function isDrawableReason(reason) {
  const r = normalizeReason(reason);
  return DRAWABLE_REASONS.has(r) || r.endsWith('_settled') || r.includes('settled') || r.includes('steady') || r.includes('update');
}

function isHoldReason(reason) {
  const r = normalizeReason(reason);
  return HOLD_REASONS.has(r) || r.includes('camera_move') || r.includes('moving');
}

function defaultSignature(frame, payload) {
  const bbox = Array.isArray(payload?.bbox) ? payload.bbox.join(',') : (Array.isArray(frame?.bbox) ? frame.bbox.join(',') : '');
  const valid = payload?.valid_time || frame?.valid_time || '';
  const source = payload?.source_time || frame?.source_time || '';
  const resolved = payload?.resolved_time || frame?.resolved_time || '';
  const hint = [
    Array.isArray(payload?.cloud_layers) ? payload.cloud_layers.length : 0,
    Array.isArray(payload?.items) ? payload.items.length : 0,
    Array.isArray(payload?.features) ? payload.features.length : 0,
    Array.isArray(payload?.polygon_field_v1?.features) ? payload.polygon_field_v1.features.length : 0,
    payload?.sea_feature_count || 0,
    payload?.sea_resolution?.subgrid_used || '',
    Array.isArray(payload?.precip_columns) ? payload.precip_columns.length : 0,
    Array.isArray(payload?.scene?.clouds) ? payload.scene.clouds.length : 0,
    Object.keys(payload?.fields || {}).join(','),
    Array.isArray(payload?.front_lines) ? payload.front_lines.length : 0,
    Array.isArray(payload?.bait?.polygons) ? payload.bait.polygons.length : 0,
    Array.isArray(payload?.bait?.outer_polygons) ? payload.bait.outer_polygons.length : 0,
    Array.isArray(payload?.bait?.inner_polygons) ? payload.bait.inner_polygons.length : 0,
    Array.isArray(payload?.bait?.core_polygons) ? payload.bait.core_polygons.length : 0,
    Array.isArray(payload?.bait_score) ? payload.bait_score.length : 0,
    Array.isArray(payload?.oceanPoints?.points) ? payload.oceanPoints.points.length : 0,
    payload?.oceanPoints?.source_time || payload?.oceanPoints?.valid_time || '',
    Array.isArray(payload?.boats) ? payload.boats.length : 0,
    Array.isArray(payload?.polygons?.boater) ? payload.polygons.boater.length : 0,
    Array.isArray(payload?.current_polygons) ? payload.current_polygons.length : 0,
  ].join(':');
  return `${bbox}|${valid}|${source}|${resolved}|${hint}`;
}

export class RendererLayer {
  constructor(map3DElement, { name, selector, renderer, signature, clearBeforeRender = true }) {
    this.map = map3DElement;
    this.name = name;
    this.selector = selector;
    this.renderer = renderer;
    this.signature = signature || defaultSignature;
    this.visible = false;
    this.currentFrame = null;
    this.currentDisposer = null;
    this.lastSignature = '';
    this.clearBeforeRender = clearBeforeRender !== false;
  }

  show() {
    this.visible = true;
    if (this.currentFrame) this.onData(this.currentFrame);
  }

  hide() {
    this.visible = false;
    this.clear();
  }

  clear() {
    this.lastSignature = '';
    // Belt-and-suspenders cleanup: renderer disposers should remove their own
    // elements, but Google Maps 3D/custom element constructors can leave nodes
    // behind if an async batch is still injecting. Remove any node tagged for
    // this layer so a double-click pill OFF always clears the globe.
    try {
      if (this.map && this.name) {
        this.map.querySelectorAll?.(`[data-gfs-layer="${this.name}"]`)?.forEach((el) => {
          try { el.remove(); } catch (_) {}
        });
      }
    } catch (_) {}
    if (typeof this.currentDisposer === 'function') {
      try { this.currentDisposer(); } catch (err) { console.warn('[gfs renderer layer] disposer failed', this.name, err); }
    }
    this.currentDisposer = null;
  }

  onData(frame) {
    this.currentFrame = frame || null;
    if (!this.visible || !this.map || !frame) return;
    const viewportReason = frame?.render_reason || frame?.meta?.render_reason || 'steady';
    const payload = this.selector?.(frame) || null;
    if (!payload) {
      // During camera movement keep the last known visible layer. A moving camera
      // should prioritize/fetch data, not clear bait/rain/current/clouds before
      // the settled replacement payload exists.
      if (isHoldReason(viewportReason) && this.currentDisposer) return;
      this.clear();
      return;
    }
    if (!isDrawableReason(viewportReason)) {
      if (this.currentDisposer) return;
    }
    const nextSignature = String(this.signature(frame, payload));
    if (nextSignature && nextSignature === this.lastSignature) return;
    if (this.clearBeforeRender) {
      this.clear();
      this.lastSignature = nextSignature;
      try {
        this.currentDisposer = this.renderer?.({
          frame,
          payload,
          map3DElement: this.map,
          viewportReason: isDrawableReason(viewportReason) ? viewportReason : 'steady',
          layerName: this.name,
        }) || null;
      } catch (err) {
        console.error('[gfs renderer layer] render failed', this.name, err);
        this.currentDisposer = null;
      }
      return;
    }

    // Some layers, especially clouds, receive warming/queued frames while the
    // real drawable payload is still being prepared. For those layers, render
    // first and only replace the disposer when the renderer says it actually
    // drew a new scene. This prevents blank/flash cycles during warm loads.
    const previousDisposer = this.currentDisposer;
    let nextDisposer = null;
    try {
      nextDisposer = this.renderer?.({
        frame,
        payload,
        map3DElement: this.map,
        viewportReason: isDrawableReason(viewportReason) ? viewportReason : 'steady',
        layerName: this.name,
      }) || null;
    } catch (err) {
      console.error('[gfs renderer layer] render failed', this.name, err);
      return;
    }
    if (nextDisposer && nextDisposer.__gfsDidRender === true) {
      if (typeof previousDisposer === 'function') {
        try { previousDisposer(); } catch (err) { console.warn('[gfs renderer layer] previous disposer failed', this.name, err); }
      }
      this.currentDisposer = nextDisposer;
      this.lastSignature = nextSignature;
    }
  }

  update() {}
}
