import { getJsonSafe, uploadSafe } from './api.js';
import { ensureMaps3D, libs } from './globe.js';
import { renderMarkers } from './markers.js';
import { createHud } from './hud.js';
import { startLive, stopLive } from './live.js';
import { LayerEngine } from './layer_engine.js';
import { RendererLayer } from './layers/renderer_layer.js';
import { renderCloudZones } from './cloud-zones.js';
import { renderRainZones } from './rain-zones.js';
import { renderLightningLayer } from './lightning-zones.js';
import { startSkySystem } from './sky.js';

const CLOUD_SHELL_REFRESH_MS = 60000;
import { renderBaitZones } from './bait-zones.js';
import { renderCurrentZonesLayer } from './current-zones.js';
import { renderBoatsLayer } from './boats.js';
import { renderInlandWaterLayer } from './inland-water.js';

const statusEl = document.getElementById('status');
const globeEl = document.getElementById('globe');
const fallbackEl = document.getElementById('globeFallback');

let activeLocation = null;
let liveManuallyDismissed = false;
let selectedLocation = null;
let liveStatePollId = null;
const missingLiveLocationIds = new Set();
const GFS_DEBUG = Boolean(window.__GFS_DEBUG);
let skyRuntime = null;

const layerRuntime = {
  engine: null,
  rafId: 0,
};

// One pill = one topic. All topics start active per LFTR operator preference.
// Missing real sources do NOT trigger fallback geometry; the pill stays visibly
// active/marked source-missing while the route returns empty strict payloads.
const DEFAULT_LAYER_ENABLED = Object.freeze({
  clouds: true,
  rain: true,
  lightning: true,
  jetstream: true,
  bait: true,
  boater: true,
  'inland-water': true,
});

const LAYER_CLEAR_SELECTORS = Object.freeze({
  clouds: '[data-gfs-layer="clouds"],[data-cloud-shell],[data-cloud-particle],[data-gfs-layer="ocean-fx"],[data-ocean-fx-kind]',
  rain: '[data-gfs-layer="rain"]',
  lightning: '[data-gfs-layer="lightning"]',
  jetstream: '[data-gfs-layer="jetstream"],[data-jetstream-balloon],gmp-marker-3d[data-jetstream-balloon]',
  bait: '[data-gfs-layer="bait"]',
  boater: '[data-gfs-layer="boater"],[data-gfs-layer="current-zones"]',
  'inland-water': '[data-gfs-layer="inland-water"]',
});

function debugPanelEvent(topic, detail = {}) {
  try {
    window.__gfsDebugEvent?.(topic, detail);
  } catch (_) {}
}

function logMissionControlState(reason = 'manual') {
  try {
    const layers = Object.fromEntries(Object.entries(layerRuntime.engine?.layers || {}).map(([k, v]) => [k, Boolean(v?.enabled)]));
    const frame = dataState.latest.frame || {};
    debugPanelEvent('mission-control/state', {
      reason,
      layers,
      frame: summarizePayloadForDebug(frame),
      cache: frame?.cache || frame?.cache_state || frame?.meta?.cache || null,
      renderReason: frame?.render_reason || frame?.meta?.render_reason || null,
    });
  } catch (_) {}
}

function summarizePayloadForDebug(payload) {
  if (!payload || typeof payload !== 'object') return { type: typeof payload };
  const summary = {
    status: payload.status || payload.payload_state || payload.source_state || payload.mode || undefined,
    source: payload.source || payload.data_source || payload.provider || undefined,
    sceneTier: payload.scene_tier || payload.scene_plan?.tier || undefined,
    cache: payload.cache || payload.cache_state || payload.cache_hit || undefined,
  };
  const addCount = (key, value) => { if (Array.isArray(value)) summary[key] = value.length; };
  addCount('tiles', payload.tiles);
  addCount('features', payload.features);
  addCount('polygons', payload.polygons || payload.bait?.polygons);
  addCount('boats', payload.boats);
  addCount('flashes', payload.flashes);
  addCount('regions', payload.regions);
  addCount('clouds', payload.clouds?.items || payload.clouds?.scene?.clouds || payload.items);
  addCount('rain', payload.rain?.items || payload.precip_columns || payload.weather?.precip_columns);
  addCount('points', payload.points || payload.ocean_points || payload.samples);
  if (payload.bbox) summary.bbox = payload.bbox;
  const resolution = resolutionContractFromPayload(payload);
  if (resolution) summary.resolution = resolution;
  return Object.fromEntries(Object.entries(summary).filter(([, v]) => v !== undefined && v !== null && v !== ''));
}



function resolutionContractFromPayload(payload) {
  if (!payload || typeof payload !== 'object') return null;
  const sourceResolutionDeg = Number(payload.source_resolution_deg ?? payload.sourceResolutionDeg ?? payload?.meta?.source_resolution_deg ?? payload?.resolution?.source_resolution_deg);
  const stride = Number(payload.stride ?? payload.provider_stride ?? payload?.scene_plan?.provider_stride ?? payload?.resolution?.stride ?? 1);
  const derivedResolutionDeg = Number(payload.derived_resolution_deg ?? payload?.meta?.derived_resolution_deg ?? payload?.resolution?.derived_resolution_deg);
  const sourceGridShape = payload.source_grid_shape || payload?.resolution?.source_grid_shape || payload?.meta?.source_grid_shape || undefined;
  const derivedGridShape = payload.derived_grid_shape || payload?.resolution?.derived_grid_shape || payload?.meta?.derived_grid_shape || undefined;
  const subgridUsed = payload.subgrid_used ?? payload?.resolution?.subgrid_used;
  const contract = {
    source_resolution_deg: Number.isFinite(sourceResolutionDeg) ? sourceResolutionDeg : undefined,
    stride: Number.isFinite(stride) ? stride : undefined,
    derived_resolution_deg: Number.isFinite(derivedResolutionDeg) ? derivedResolutionDeg : undefined,
    source_grid_shape: Array.isArray(sourceGridShape) ? sourceGridShape : undefined,
    derived_grid_shape: Array.isArray(derivedGridShape) ? derivedGridShape : undefined,
    subgrid_used: Number.isFinite(Number(subgridUsed)) ? Number(subgridUsed) : undefined,
  };
  return Object.keys(contract).some((k) => contract[k] !== undefined) ? contract : null;
}

function countArray(value) {
  return Array.isArray(value) ? value.length : 0;
}

function countRenderableClouds(frame) {
  const clouds = frame?.clouds || {};
  const weather = frame?.weather || {};
  return {
    sigmaClouds: countArray(frame?.sigmaClouds),
    cloudItems: countArray(clouds?.items) + countArray(clouds?.scene?.clouds),
    cloudBodies: countArray(clouds?.bodies) + countArray(clouds?.cloud_bodies),
    precipColumns: countArray(weather?.precip_columns) + countArray(clouds?.precip_columns) + countArray(clouds?.scene?.precip),
    polygonFeatures: countArray(weather?.polygon_field_v1?.features) + countArray(clouds?.polygon_field_v1?.features),
    fieldKeys: Object.keys(weather?.fields || clouds?.fields || {}).length,
  };
}

function isFallbackBoatPayload(payload) {
  const source = String(payload?.source || payload?.ocean?.source || payload?.oceanPoints?.source || '').toLowerCase();
  const mode = String(payload?.mode || payload?.ocean?.mode || '').toLowerCase();
  return source.includes('fallback') || source.includes('marker_ocean_solve') || mode.includes('fallback') || mode.includes('proxy');
}

function boatCounts(payload) {
  const raw = countArray(payload?.boats);
  const fallbackRejected = isFallbackBoatPayload(payload) ? raw : 0;
  return {
    raw,
    renderableHint: fallbackRejected ? 0 : raw,
    fallbackRejected,
    source: payload?.source || payload?.mode || 'unknown',
  };
}


function seaLayer(frame, layerName) {
  const layers = frame?.seaIntelligence?.layers || dataState.latest?.seaIntelligence?.layers || {};
  const layer = layers?.[layerName] || null;
  if (!layer || !Array.isArray(layer.features) || !layer.features.length) return null;
  return layer;
}

function seaPayloadHasLayer(payload, layerName) {
  const layer = payload?.layers?.[layerName] || null;
  return Boolean(layer && Array.isArray(layer.features) && layer.features.length);
}

function seaFeaturePath(feature, altitude = 0) {
  const raw = Array.isArray(feature?.path) ? feature.path : [];
  const out = [];
  for (const pt of raw) {
    const lat = Number(pt?.lat ?? pt?.latitude);
    const lng = Number(pt?.lng ?? pt?.lon ?? pt?.longitude);
    if (!Number.isFinite(lat) || !Number.isFinite(lng) || lat < -90 || lat > 90) continue;
    out.push({ lat, lng, altitude });
  }
  if (out.length >= 3) {
    const first = out[0];
    const last = out[out.length - 1];
    if (Math.abs(first.lat - last.lat) > 1e-5 || Math.abs(first.lng - last.lng) > 1e-5) {
      out.push({ ...first });
    }
  }
  return out.length >= 4 ? out : [];
}

function seaFeatureCenter(feature) {
  const path = seaFeaturePath(feature, 0);
  if (!path.length) return null;
  let lat = 0;
  let lng = 0;
  for (const p of path) { lat += p.lat; lng += p.lng; }
  return { lat: lat / path.length, lon: lng / path.length };
}

function seaLevel01(feature, fallback = 0.5) {
  const n = Number(feature?.level ?? feature?.properties?.level ?? fallback);
  if (!Number.isFinite(n)) return fallback;
  if (n > 1.25) return Math.max(0, Math.min(1, n / 100));
  return Math.max(0, Math.min(1, n));
}

function seaBaitPayloadFromLayer(layer, basePayload = null, oceanPoints = null, bbox = null) {
  if (!layer) return null;
  const outer = [];
  const inner = [];
  const core = [];
  for (const f of layer.features || []) {
    const score = seaLevel01(f, 0.5);
    const band = score >= 0.58 ? 'core' : (score >= 0.42 ? 'inner' : 'outer');
    const path = seaFeaturePath(f, band === 'core' ? 36 : band === 'inner' ? 20 : 8);
    if (!path.length) continue;
    const poly = {
      id: `sea-bait-${band}-${outer.length + inner.length + core.length}`,
      source: 'fastapi_sea_engine',
      band,
      path,
      score,
      probability: score,
      schoolScore: score,
      driver: f.kind || layer.field || 'fastapi_marching_squares',
      level: f.level,
      current_u: 0,
      current_v: 0,
    };
    if (band === 'core') core.push(poly);
    else if (band === 'inner') inner.push(poly);
    else outer.push(poly);
  }
  if (!outer.length && !inner.length && !core.length) return null;
  return {
    ...(basePayload || {}),
    status: 'derived',
    source: 'fastapi_numpy_skimage_sidecar',
    mode: 'fastapi_marching_squares_same_renderer_payload',
    bbox: bbox || basePayload?.bbox || dataState.latest?.seaIntelligence?.bbox,
    oceanPoints: oceanPoints || basePayload?.oceanPoints || null,
    bait: {
      ...(basePayload?.bait || {}),
      status: 'ready',
      source: 'fastapi_sea_engine',
      outer_polygons: outer,
      inner_polygons: inner,
      core_polygons: core,
      polygons: [...inner, ...core],
    },
    bait_score: basePayload?.bait_score || [],
    sea_resolution: layer.resolution || null,
    sea_feature_count: layer.feature_count || (layer.features || []).length,
  };
}

function seaPolygonFieldPayloadFromLayer(layer, { kind = 'clouds', bbox = null } = {}) {
  if (!layer) return null;
  const lat = [];
  const lon = [];
  const altitude_m = [];
  const wind_u = [];
  const wind_v = [];
  const cloud_total = [];
  const cloud_low = [];
  const cloud_mid = [];
  const cloud_high = [];
  const precip_rate = [];
  const features = [];
  const tier = String(layer?.resolution?.tier || '').toLowerCase();
  const maxFeatures = kind === 'clouds'
    ? (tier === 'harbor' ? 72 : (tier === 'local' ? 54 : 36))
    : (kind === 'rain' ? (tier === 'harbor' ? 72 : 48) : 96);
  const sourceFeatures = (layer.features || [])
    .slice()
    .sort((a, b) => seaLevel01(b, 0.5) - seaLevel01(a, 0.5))
    .slice(0, maxFeatures);
  let idx = 0;
  for (const f of sourceFeatures) {
    const center = seaFeatureCenter(f);
    if (!center) continue;
    const level = seaLevel01(f, 0.5);
    const cellSize = Math.max(0.035, Math.min(0.35, Number(f?.path_len || 20) / 2200));
    const contourPath = seaFeaturePath(f, kind === 'clouds' ? 1800 + level * 7800 : 1200 + level * 6500);
    const common = {
      id: `sea-${kind}-${idx}`,
      lat: center.lat,
      lon: center.lon,
      level,
      source: 'fastapi_sea_engine',
      kind: f.kind || layer.layer || kind,
      cell_size_deg: cellSize,
      wind_u: 0,
      wind_v: 0,
      path: contourPath,
      path_len: f.path_len || contourPath.length,
      raw_path_len: f.raw_path_len || f.path_len || contourPath.length,
      path_stride: f.path_stride || 1,
      path_detail: f.path_detail || 'fastapi_contour_path',
      detail_tier: f.detail_tier || layer?.resolution?.tier || null,
      sea_resolution: layer?.resolution || null,
    };
    if (kind === 'rain') {
      const rate = Math.max(0.08, level * 18);
      features.push({ ...common, precip_rate: rate, cloud_total: Math.max(45, level * 100), cloud_low: level * 65, cloud_mid: level * 45, cloud_high: level * 25 });
      precip_rate.push(rate);
      cloud_total.push(Math.max(45, level * 100)); cloud_low.push(level * 65); cloud_mid.push(level * 45); cloud_high.push(level * 25);
      altitude_m.push(1200 + level * 6500);
    } else {
      features.push({ ...common, cloud_total: Math.max(25, level * 100), cloud_low: level * 45, cloud_mid: level * 58, cloud_high: level * 72, precip_rate: 0 });
      precip_rate.push(0);
      cloud_total.push(Math.max(25, level * 100)); cloud_low.push(level * 45); cloud_mid.push(level * 58); cloud_high.push(level * 72);
      altitude_m.push(1800 + level * 7800);
    }
    lat.push(center.lat); lon.push(center.lon); wind_u.push(0); wind_v.push(0);
    idx += 1;
  }
  if (!features.length) return null;
  return {
    schema: 'gfs_polygon_field_v1',
    source: 'fastapi_sea_engine',
    derived_render_geometry: true,
    prefer_derived_contours: true,
    cell_size_deg: 0.12,
    features,
    fields: { lat, lon, altitude_m, wind_u, wind_v, cloud_total, cloud_low, cloud_mid, cloud_high, precip_rate },
    bbox,
  };
}

function seaCloudPayloadFromLayer(layer, basePayload = null, frame = null) {
  const polygonField = seaPolygonFieldPayloadFromLayer(layer, { kind: 'clouds', bbox: frame?.bbox || frame?.meta?.bbox || dataState.latest?.seaIntelligence?.bbox });
  if (!polygonField) return null;
  return {
    ...(basePayload || {}),
    status: 'derived',
    source_state: 'derived',
    source: 'fastapi_numpy_skimage_sidecar',
    prefer_derived_contours: true,
    derived_render_geometry: true,
    bbox: polygonField.bbox || basePayload?.bbox || basePayload?.bbox_used,
    bbox_used: polygonField.bbox || basePayload?.bbox_used || basePayload?.bbox,
    allow_polygon_cloud_fallback: false,
    prefer_sea_contours: true,
    items: [],
    tiles: [],
    cloud_regions: [],
    scene: { ...(basePayload?.scene || {}), clouds: [], precip: [] },
    polygon_field_v1: polygonField,
    sea_resolution: layer.resolution || null,
    sea_feature_count: layer.feature_count || layer.features.length,
  };
}

function seaRainPayloadFromLayer(layer, baseWeather = null, baseClouds = null, frame = null) {
  const polygonField = seaPolygonFieldPayloadFromLayer(layer, { kind: 'rain', bbox: frame?.bbox || frame?.meta?.bbox || dataState.latest?.seaIntelligence?.bbox });
  if (!polygonField) return null;
  return {
    ...(baseWeather || {}),
    status: 'derived',
    source: 'fastapi_numpy_skimage_sidecar',
    prefer_derived_contours: true,
    derived_render_geometry: true,
    bbox: polygonField.bbox || baseWeather?.bbox || baseClouds?.bbox,
    bbox_used: polygonField.bbox || baseWeather?.bbox_used || baseClouds?.bbox_used,
    polygon_field_v1: polygonField,
    fields: baseWeather?.fields || baseClouds?.fields || {},
    cloud_layers: baseClouds?.cloud_layers || baseWeather?.cloud_layers || [],
    items: [],
    tiles: [],
    precip_columns: [],
    scene: { ...(baseWeather?.scene || {}), precip: [] },
    sea_resolution: layer.resolution || null,
    sea_feature_count: layer.feature_count || layer.features.length,
  };
}

function seaBoaterPayloadFromLayer(layer, basePayload = null, frame = null) {
  if (!layer) return null;
  const polygonField = seaPolygonFieldPayloadFromLayer(layer, { kind: 'boats', bbox: frame?.bbox || frame?.meta?.bbox || dataState.latest?.seaIntelligence?.bbox });
  if (!polygonField) return null;
  const currentPolygons = [];
  for (const f of layer.features || []) {
    const path = seaFeaturePath(f, 12);
    if (!path.length) continue;
    const level = seaLevel01(f, 0.5);
    currentPolygons.push({
      source: 'fastapi_sea_engine',
      band: level > 0.70 ? 'fast' : (level > 0.45 ? 'medium' : 'slow'),
      value: 0.25 + level * 2.2,
      cells: f.path_len || path.length,
      coordinates: path.map((p) => [p.lng, p.lat]),
    });
  }
  return {
    ...(basePayload || {}),
    status: 'derived',
    source: 'fastapi_numpy_skimage_sidecar',
    mode: 'fastapi_boater_density_corridor',
    bbox: polygonField.bbox || basePayload?.bbox,
    bbox_used: polygonField.bbox || basePayload?.bbox_used,
    polygon_field_v1: polygonField,
    current_polygons: currentPolygons,
    sea_resolution: layer.resolution || null,
    sea_feature_count: layer.feature_count || layer.features.length,
  };
}

function syncPillState(name, enabled) {
  const btn = document.querySelector(`.overlay-pill[data-layer="${name}"]`);
  if (!btn) return;
  const unavailable = isLayerUnavailable(name);
  const on = Boolean(enabled);
  btn.classList.toggle('active', on);
  btn.classList.toggle('unavailable', unavailable);
  btn.setAttribute('aria-pressed', on ? 'true' : 'false');
  btn.setAttribute('data-layer-enabled', on ? 'true' : 'false');
  if (unavailable) btn.setAttribute('data-source-status', 'missing');
  else btn.removeAttribute('data-source-status');
}

const PILL_DOUBLE_TAP_MS = 0;
const pillTapState = new Map();

function layerUserPrefs() {
  if (!window.__gfsLayerUserPrefs || typeof window.__gfsLayerUserPrefs !== 'object') {
    window.__gfsLayerUserPrefs = { ...DEFAULT_LAYER_ENABLED };
  } else {
    for (const [name, enabled] of Object.entries(DEFAULT_LAYER_ENABLED)) {
      if (window.__gfsLayerUserPrefs[name] === undefined) window.__gfsLayerUserPrefs[name] = enabled;
    }
  }
  return window.__gfsLayerUserPrefs;
}

function layerDefaultEnabled(name) {
  return DEFAULT_LAYER_ENABLED[name] !== false;
}

function isLayerUnavailable(name) {
  return Boolean(window.__gfsLayerUnavailable?.[name]);
}

function isLayerUserDisabled(name) {
  return layerUserPrefs()[name] === false;
}

function isLayerOn(name) {
  const layer = layerRuntime.engine?.layers?.[name];
  return Boolean(layer && layer.enabled && !isLayerUserDisabled(name));
}

function clearLayerVisuals(name) {
  const selector = LAYER_CLEAR_SELECTORS[name] || `[data-gfs-layer="${name}"]`;
  try { globeEl?.querySelectorAll?.(selector)?.forEach((el) => el.remove()); } catch (_) {}
  if (name === 'clouds') {
    try { window.clearGfsCloudLayer?.(); } catch (_) {}
  }
  if (name === 'jetstream') {
    try { window.pauseJetBalloons?.(); } catch (_) {}
    try { window.clearJetBalloons?.(); } catch (_) {}
  }
  if (name === 'rain') {
    try { window.clearGfsRainLayer?.(); } catch (_) {}
  }
}

function markLayerUnavailable(name, message = '') {
  window.__gfsLayerUnavailable = { ...(window.__gfsLayerUnavailable || {}), [name]: { at: Date.now(), message } };
  // Strict/no-fallback policy: keep the operator pill active if enabled, but
  // annotate it as source-missing and draw nothing until the real source exists.
  clearLayerVisuals(name);
  const enabled = layerUserPrefs()[name] !== false;
  try { layerRuntime.engine?.setEnabled?.(name, enabled); } catch (_) {}
  const btn = document.querySelector(`.overlay-pill[data-layer="${name}"]`);
  if (btn) {
    btn.classList.toggle('active', enabled);
    btn.classList.add('unavailable');
    btn.setAttribute('aria-pressed', enabled ? 'true' : 'false');
    btn.setAttribute('data-layer-enabled', enabled ? 'true' : 'false');
    btn.setAttribute('data-source-status', 'missing');
    if (message) btn.title = message;
  }
  debugPanelEvent('pill/source-unavailable', { layer: name, message, active: enabled });
}

function clearLayerUnavailable(name) {
  if (!window.__gfsLayerUnavailable?.[name]) return;
  const next = { ...(window.__gfsLayerUnavailable || {}) };
  delete next[name];
  window.__gfsLayerUnavailable = next;
  const btn = document.querySelector(`.overlay-pill[data-layer="${name}"]`);
  if (btn) {
    btn.classList.remove('unavailable');
    btn.removeAttribute('data-source-status');
  }
}

function rememberLayerChoice(name, enabled) {
  const prefs = layerUserPrefs();
  prefs[name] = enabled !== false;
  window.__gfsLayerState = { ...(window.__gfsLayerState || {}) };
  if (name === 'jetstream') {
    window.__gfsLayerState.jetstreamBalloons = enabled !== false;
    window.__gfsJetstreamDisabled = enabled === false;
    window.__gfsJetstreamPillOn = enabled !== false;
  }
  if (name === 'clouds') {
    window.__gfsCloudsDisabled = enabled === false;
  }
}

function togglePillLayer(name, btn, engine) {
  const layer = engine.layers[name];
  if (!layer) {
    console.warn('[gfs pills] missing layer', { name });
    debugPanelEvent('pill/missing-layer', { layer: name });
    return;
  }
  const nextEnabled = !isLayerOn(name);
  rememberLayerChoice(name, nextEnabled);
  engine.setEnabled(name, nextEnabled);
  if (nextEnabled === false) clearLayerVisuals(name);
  syncPillState(name, nextEnabled);
  console.info('[gfs pills] toggle', { layer: name, enabled: nextEnabled });
  debugPanelEvent('pill/toggle', { layer: name, enabled: nextEnabled, activeLayers: Object.fromEntries(Object.entries(engine.layers || {}).map(([k, v]) => [k, Boolean(v?.enabled && !isLayerUserDisabled(k))])) });
  window.setTimeout(() => refreshVisualPipeline(getCanonicalViewport(), `pill_${name}_${nextEnabled ? 'on' : 'off'}`).catch(() => {}), 80);
}


function baitAdvancedReady(payload) {
  const bait = payload?.bait || {};
  const source = String(bait?.source || payload?.source || '').toLowerCase();
  const mode = String(payload?.mode || '').toLowerCase();
  const hasPolygons = Boolean(
    (Array.isArray(bait.polygons) && bait.polygons.length > 0)
    || (Array.isArray(bait.outer_polygons) && bait.outer_polygons.length > 0)
    || (Array.isArray(bait.inner_polygons) && bait.inner_polygons.length > 0)
    || (Array.isArray(bait.core_polygons) && bait.core_polygons.length > 0)
  );
  const liveReady = source === 'full_stack' || source.includes('live_hycom') || source.includes('coastwatch') || mode.includes('marching_squares');
  return Boolean(payload && bait && bait.status === 'ready' && liveReady && hasPolygons);
}

function nonEmptyFields(...sets) {
  for (const fields of sets) {
    if (fields && typeof fields === 'object' && Object.keys(fields).length > 0) return fields;
  }
  return {};
}

function preferStableBaitAdvanced(nextPayload, fallbackPayload) {
  if (baitAdvancedReady(nextPayload)) return nextPayload;
  if (baitAdvancedReady(fallbackPayload)) return fallbackPayload;
  return nextPayload || fallbackPayload || null;
}


function hasBaitRenderablePayload(payload) {
  const bait = payload?.bait || {};
  // Bait-score rows are intentionally not renderable by themselves. They feed HUD
  // intel, but the visible bait layer must start from polygons or a solved ocean
  // field so it never flashes point/proxy bait before the marching-school solve.
  return Boolean(
    payload
    && (
      (Array.isArray(bait?.polygons) && bait.polygons.length > 0)
      || (Array.isArray(bait?.outer_polygons) && bait.outer_polygons.length > 0)
      || (Array.isArray(bait?.inner_polygons) && bait.inner_polygons.length > 0)
      || (Array.isArray(bait?.core_polygons) && bait.core_polygons.length > 0)
      || (Array.isArray(payload?.oceanPoints?.points) && payload.oceanPoints.points.length >= 4)
      || (Array.isArray(payload?.points) && payload.points.length >= 4)
      || (Array.isArray(payload?.bait_score) && payload.bait_score.length >= 4)
      || (Array.isArray(bait?.bait_score) && bait.bait_score.length >= 4)
    )
  );
}

function preferRenderableBaitAdvanced(nextPayload, fallbackPayload) {
  if (baitAdvancedReady(nextPayload)) return nextPayload;
  if (hasBaitRenderablePayload(nextPayload)) return nextPayload;
  if (baitAdvancedReady(fallbackPayload)) return fallbackPayload;
  if (hasBaitRenderablePayload(fallbackPayload)) return fallbackPayload;
  return nextPayload || fallbackPayload || null;
}


function serverBaitPolygonCount(payload) {
  const bait = payload?.bait || {};
  const root = payload || {};
  return [
    bait.polygons, bait.outer_polygons, bait.inner_polygons, bait.core_polygons,
    root.polygons, root.outer_polygons, root.inner_polygons, root.core_polygons,
  ].reduce((sum, value) => sum + (Array.isArray(value) ? value.length : 0), 0);
}

function hasStrictBaitPolygons(payload) {
  return Boolean(payload && serverBaitPolygonCount(payload) > 0);
}

function mergeAdvancedBaitIntoSeaPayload(seaPayload, advancedPayload) {
  const sea = seaPayload || null;
  const advanced = advancedPayload || null;
  if (!sea && !advanced) return null;
  if (!hasStrictBaitPolygons(advanced)) return sea;
  const advancedBait = advanced.bait || advanced;
  const seaBait = sea?.bait || {};
  return {
    ...(sea || {}),
    ...advanced,
    source: 'strict_sea_plus_advanced_bait',
    bbox: advanced.bbox || advanced.bbox_used || sea?.bbox || sea?.bbox_used || null,
    bbox_used: advanced.bbox_used || advanced.bbox || sea?.bbox_used || sea?.bbox || null,
    oceanPoints: sea?.oceanPoints || advanced.oceanPoints || null,
    sea_resolution: sea?.sea_resolution || sea?.resolution || advanced.sea_resolution || null,
    sea_feature_count: sea?.sea_feature_count || 0,
    bait: {
      ...seaBait,
      ...advancedBait,
      status: advancedBait.status || 'ready',
      source: advancedBait.source || advanced.source || 'advanced_bait_marching_squares',
      polygons: advancedBait.polygons || advanced.polygons || [],
      outer_polygons: advancedBait.outer_polygons || advanced.outer_polygons || [],
      inner_polygons: advancedBait.inner_polygons || advanced.inner_polygons || [],
      core_polygons: advancedBait.core_polygons || advanced.core_polygons || [],
      sea_polygons: seaBait.polygons || sea?.polygons || [],
      sea_outer_polygons: seaBait.outer_polygons || sea?.outer_polygons || [],
      sea_inner_polygons: seaBait.inner_polygons || sea?.inner_polygons || [],
      sea_core_polygons: seaBait.core_polygons || sea?.core_polygons || [],
    },
    strict_render_contract: 'advanced_bait_polygons_primary_plus_sea_metadata_no_client_fallback',
  };
}

function pushLayerFrameWithBait(reason = 'bait-deferred') {
  const frame = dataState.latest.frame;
  if (!frame) return;
  frame.baitAdvanced = dataState.latest.baitAdvanced || frame.baitAdvanced || null;
  frame.baitBase = dataState.latest.baitBase || frame.baitBase || null;
  frame.render_reason = 'steady';
  frame.meta = { ...(frame.meta || {}), render_reason: 'steady', bait_refresh_reason: reason, bait_refresh_ts: Date.now() };
  try { layerRuntime.engine?.setData?.(frame); } catch (err) { console.warn('[gfs bait] layer push failed', err); }
}

function initLayerSystem() {
  if (layerRuntime.engine) return layerRuntime.engine;
  const engine = new LayerEngine();
  const clouds = new RendererLayer(globeEl, {
    name: 'clouds',
    selector: (frame) => {
      if (window.__gfsCloudsDisabled === true || isLayerUserDisabled('clouds')) return null;
      const clouds = frame?.clouds || null;
      // Strict source policy: draw only live/server cloud payloads. Prefer the
      // older split cloud route when it has drawable live content because its
      // pressure-band items and precip columns carry richer display geometry;
      // otherwise draw the FastAPI sea contours. No synthetic/client fallback.
      if (clouds && cloudPayloadHasDrawableContent(clouds)) {
        return {
          ...clouds,
          source_state: clouds.source_state || clouds.payload_state || clouds.status || 'unknown',
          fields: clouds.fields || frame?.weather?.fields || {},
          bbox: clouds.bbox || clouds.bbox_used || frame?.bbox || frame?.meta?.bbox,
          bbox_used: clouds.bbox_used || clouds.bbox || frame?.bbox || frame?.meta?.bbox_used,
          allow_polygon_cloud_fallback: false,
          strict_render_contract: 'split_cloud_payload_primary_no_client_fallback',
        };
      }
      const seaClouds = seaCloudPayloadFromLayer(seaLayer(frame, 'clouds'), clouds, frame);
      if (seaClouds) return { ...seaClouds, allow_polygon_cloud_fallback: false, strict_render_contract: 'sea_cloud_contours_no_client_fallback' };
      return null;
    },
    renderer: ({ payload, map3DElement }) => renderCloudZones({ payload, map3DElement }),
    clearBeforeRender: false,
  });
  const baseCloudHide = clouds.hide.bind(clouds);
  clouds.hide = () => {
    try { baseCloudHide(); } catch (err) { console.warn('[gfs clouds] base hide failed', err); }
    try { window.clearGfsCloudLayer?.(); } catch (_) {}
    try { globeEl?.querySelectorAll?.('[data-gfs-layer="clouds"],[data-cloud-shell],[data-cloud-particle],[data-gfs-layer="ocean-fx"],[data-ocean-fx-kind]')?.forEach((el) => el.remove()); } catch (_) {}
  };

  const rain = new RendererLayer(globeEl, {
    name: 'rain',
    selector: (frame) => {
      const weather = frame?.weather || null;
      const cloudsPayload = frame?.clouds || null;
      const seaRain = seaRainPayloadFromLayer(seaLayer(frame, 'rain'), weather, cloudsPayload, frame);
      if (seaRain) return seaRain;
      if (!weather && !cloudsPayload) return null;
      return {
        ...(weather || {}),
        bbox: weather?.bbox || weather?.bbox_used || cloudsPayload?.bbox || cloudsPayload?.bbox_used || frame?.bbox || frame?.meta?.bbox,
        bbox_used: weather?.bbox_used || cloudsPayload?.bbox_used || cloudsPayload?.bbox || frame?.bbox || frame?.meta?.bbox_used,
        fields: nonEmptyFields(weather?.fields, cloudsPayload?.fields, frame?.fields),
        cloud_layers: cloudsPayload?.cloud_layers || weather?.cloud_layers || [],
        items: cloudsPayload?.items || cloudsPayload?.tiles || weather?.items || [],
        precip_columns: cloudsPayload?.precip_columns || cloudsPayload?.scene?.precip || weather?.precip_columns || [],
        // Rain should prefer real cloud/rain tiles. Polygon field is only a debug fallback.
        polygon_field_v1: (cloudsPayload?.allow_polygon_cloud_fallback === true || window.__GFS_DEBUG_POLYGON_CLOUDS === true) ? (weather?.polygon_field_v1 || cloudsPayload?.polygon_field_v1 || null) : null,
      };
    },
    renderer: ({ payload, map3DElement, viewportReason }) => renderRainZones({ payload, map3DElement, viewportReason: viewportReason === 'boot' ? 'steady' : viewportReason }),
  });
  const lightning = new RendererLayer(globeEl, {
    name: 'lightning',
    selector: (frame) => {
      if (isLayerUserDisabled('lightning')) return null;
      const payload = frame?.lightning || null;
      if (!payload) return null;
      if (payload?.heuristic === true || payload?.mock === true || payload?.proxy === true || payload?.fallback_used === true) return null;
      return payload;
    },
    renderer: ({ payload, map3DElement }) => renderLightningLayer({ payload, map3DElement }),
    signature: (_frame, payload) => [
      Array.isArray(payload?.bbox) ? payload.bbox.join(',') : '',
      payload?.generated_at || payload?.valid_time || '',
      payload?.payload_state || '',
      Array.isArray(payload?.flashes) ? payload.flashes.length : 0,
      Array.isArray(payload?.regions) ? payload.regions.length : 0,
    ].join('|'),
  });

  const bait = new RendererLayer(globeEl, {
    name: 'bait',
    selector: (frame) => {
      const advanced = frame?.baitAdvanced || null;
      if (hasStrictBaitPolygons(advanced)) {
        const seaBait = seaBaitPayloadFromLayer(seaLayer(frame, 'bait'), advanced, null, frame?.bbox || frame?.meta?.bbox);
        const merged = mergeAdvancedBaitIntoSeaPayload(seaBait, advanced);
        return hasStrictBaitPolygons(merged) ? merged : advanced;
      }
      // Do not draw sea-engine bait-only polygons on boot. Those contours are useful
      // metadata, but chlorophyll/SST sea sidecar paths can arrive before the full
      // advanced bait contract and can look like a detached parabola if axes/bounds
      // are imperfect. Visible bait now waits for /gfs/api/bait-advanced polygons.
      return null;
    },
    renderer: ({ payload, map3DElement, viewportReason }) => renderBaitZones({ payload, map3DElement, viewportReason: viewportReason === 'boot' ? 'steady' : viewportReason }),
  });


  const boater = new RendererLayer(globeEl, {
    name: 'boater',
    selector: (frame) => {
      const boatsPayload = frame?.boats || null;
      const oceanPayload = frame?.ocean || null;
      const oceanPoints = frame?.oceanPoints || null;
      const boats = Array.isArray(boatsPayload?.boats) ? boatsPayload.boats : (Array.isArray(oceanPayload?.boats) ? oceanPayload.boats : []);
      const basePayload = { ...(oceanPayload || {}), ...(boatsPayload || {}), boats, ocean: oceanPayload, oceanPoints, boatsPayload };
      const officialBoatsPayload = boatsPayload || oceanPayload || oceanPoints;
      if (officialBoatsPayload) {
        // Prefer the official /gfs/api/boats + ocean samples for boater. The sea
        // contour sidecar can reduce to a couple of long corridor lines; those
        // are useful metadata, but should not replace the richer boater payload.
        return {
          ...basePayload,
          source: boatsPayload?.source || oceanPayload?.source || 'boater_payload',
          mode: boatsPayload?.mode || oceanPayload?.mode || 'boater_layer_official_boats_first',
        };
      }
      const seaBoats = seaBoaterPayloadFromLayer(seaLayer(frame, 'boats'), basePayload, frame);
      if (seaBoats && Array.isArray(seaBoats.current_polygons) && seaBoats.current_polygons.length >= 4) return seaBoats;
      return null;
    },
    renderer: ({ payload, map3DElement, viewportReason }) => {
      const reason = viewportReason === 'boot' ? 'steady' : viewportReason;
      const disposers = [];
      const counts = boatCounts(payload);
      console.info('[gfs boater] render request', {
        reason,
        boatsRaw: counts.raw,
        boatsRenderableHint: counts.renderableHint,
        boatsFallbackRejected: counts.fallbackRejected,
        source: counts.source,
        hasModelRenderer: true,
        hasPolygonRenderer: false,
      });
      const currentZonesDispose = renderCurrentZonesLayer({ payload, map3DElement, viewportReason: reason });
      if (typeof currentZonesDispose === 'function') disposers.push(currentZonesDispose);
      // Boater now renders as interpolated HYCOM/RTOFS current contour zones plus boat models.
      // Point-orb rendering is intentionally disabled here; current structure is shown as
      // marching-squares zones so the pill is not a sparse point grid.
      const boatsDispose = renderBoatsLayer({ payload, map3DElement });
      if (typeof boatsDispose === 'function') disposers.push(boatsDispose);
      return () => {
        disposers.reverse().forEach((dispose) => {
          try { dispose(); } catch (err) { console.warn('[gfs boater] dispose failed', err); }
        });
      };
    },
  });

  const inlandWater = new RendererLayer(globeEl, {
    name: 'inland-water',
    selector: (frame) => {
      if (isLayerUserDisabled('inland-water')) return null;
      const water = frame?.inlandWater || dataState.latest.inlandWater || null;
      if (!water) return null;
      return {
        ...water,
        conditions: frame?.inlandConditions || dataState.latest.inlandConditions || null,
        bait: frame?.inlandBait || dataState.latest.inlandBait || null,
      };
    },
    renderer: ({ payload, map3DElement }) => renderInlandWaterLayer({ payload, map3DElement }),
    signature: (_frame, payload) => [
      Array.isArray(payload?.bbox) ? payload.bbox.join(',') : '',
      Array.isArray(payload?.polygons) ? payload.polygons.length : 0,
      Array.isArray(payload?.lines) ? payload.lines.length : 0,
      Array.isArray(payload?.bait?.targets) ? payload.bait.targets.length : 0,
      Array.isArray(payload?.bait?.temperature_points) ? payload.bait.temperature_points.length : 0,
      Array.isArray(payload?.conditions?.temperature_points) ? payload.conditions.temperature_points.length : 0,
      Math.round(Number(globeEl?.range || globeEl?.getAttribute?.('range') || 0) / 50000),
      payload?.source || '',
    ].join('|'),
  });

  // Visual order matters on Maps 3D: fish CSV markers are rendered before
  // this layer system boots, then Jetstream, Bait, Boats, Clouds, and Rain.
  engine.register('jetstream', {
    async show(){
      if (layerUserPrefs().jetstream === false) return;
      window.__gfsJetstreamPillOn = true;
      if (typeof window.setJetBalloonsEnabled === 'function') await window.setJetBalloonsEnabled(true);
      else window.__gfsLayerState = { ...(window.__gfsLayerState || {}), jetstreamBalloons: true };
    },
    async hide(){
      window.__gfsLayerState = { ...(window.__gfsLayerState || {}), jetstreamBalloons: false };
      window.__gfsJetstreamDisabled = true;
      window.__gfsJetstreamPillOn = false;
      jetstreamVisualReady = false;
      lastJetstreamEnsureAt = 0;
      if (typeof window.setJetBalloonsEnabled === 'function') await window.setJetBalloonsEnabled(false);
      if (typeof window.clearJetBalloons === 'function') window.clearJetBalloons();
    },
    update(){}
  });
  engine.register('bait', bait);
  engine.register('boater', boater);
  engine.register('inland-water', inlandWater);
  engine.register('clouds', clouds);
  engine.register('rain', rain);
  engine.register('lightning', lightning);
  document.querySelectorAll('.overlay-pill[data-layer]').forEach((btn) => {
    btn.addEventListener('click', (ev) => {
      ev.preventDefault();
      ev.stopPropagation();
      const name = btn.dataset.layer;
      togglePillLayer(name, btn, engine);
    });
  });
  ['jetstream','bait','boater','inland-water','clouds','rain','lightning'].forEach((name) => {
    const enabled = layerUserPrefs()[name] !== false && !isLayerUnavailable(name);
    engine.setEnabled(name, enabled);
    syncPillState(name, enabled);
  });
  layerRuntime.engine = engine;
  const tick = () => {
    layerRuntime.rafId = window.requestAnimationFrame(tick);
    engine.update();
  };
  tick();
  return engine;
}

// frontend contract: stale response discarded when seq !== overlayState.requestSeq
const dataState = {
  inFlight: false,
  requestSeq: 0,
  activeAbort: null,
  lastSignature: '',
  lastHeavySignature: '',
  lastCloudSignature: '',
  lastBoatSignature: '',
  latest: {
    bbox: null,
    weather: null,
    clouds: null,
    baitBase: null,
    baitAdvanced: null,
    boats: null,
    oceanPoints: null,
    inlandWater: null,
    inlandConditions: null,
    inlandBait: null,
  },
};

window.__gfsDataInduction = {
  get latest() {
    return dataState.latest;
  },
  get signature() {
    return dataState.lastSignature;
  },
  refresh(reason = 'manual') {
    return refreshData(reason);
  },
};

function showStatus(text) {
  const skyLine = statusEl?.dataset?.skyLine || '';
  statusEl.textContent = skyLine ? `${text} • ${skyLine}` : text;
}

function hideLiveOverlay() {
  const overlay = document.getElementById('liveOverlay');
  if (overlay) overlay.remove();
}

function showLiveOverlay() {
  if (liveManuallyDismissed) return;
  let overlay = document.getElementById('liveOverlay');
  if (overlay) return;

  overlay = document.createElement('div');
  overlay.id = 'liveOverlay';
  overlay.className = 'live-overlay';
  overlay.innerHTML = `
    <div class="live-card glass">
      <div class="live-header">
        <div>
          <div class="eyebrow">Live</div>
          <strong>Broadcast preview</strong>
        </div>
        <button id="liveOverlayClose" type="button">Close</button>
      </div>
      <video id="livePreview" autoplay playsinline muted></video>
    </div>`;
  document.body.appendChild(overlay);

  overlay.querySelector('#liveOverlayClose')?.addEventListener('click', async () => {
    liveManuallyDismissed = true;
    if (activeLocation) await stopLive({ locationId: activeLocation.id });
    hideLiveOverlay();
  });
}

function currentLiveOverlayRefs() {
  return {
    overlayEl: document.getElementById('liveOverlay'),
    videoEl: document.getElementById('livePreview'),
  };
}

async function refreshSelectedLiveState() {
  if (!selectedLocation) return;
  const locationId = encodeURIComponent(selectedLocation.id);
  if (missingLiveLocationIds.has(selectedLocation.id)) return;
  const payload = await getJsonSafe(`/gfs/api/location/${locationId}/live`, null);
  if (!payload) return;
  if (payload?.error === 'location_not_found' || payload?.ok === false) {
    missingLiveLocationIds.add(selectedLocation.id);
    console.info('[gfs live] stop polling missing location', { locationId: selectedLocation.id });
    return;
  }
  if (payload?.live?.active) showLiveOverlay();
  else hideLiveOverlay();
}

function startLivePolling() {
  if (liveStatePollId) return;
  liveStatePollId = setInterval(refreshSelectedLiveState, 12000);
}

function stopLivePolling() {
  if (!liveStatePollId) return;
  clearInterval(liveStatePollId);
  liveStatePollId = null;
}

function parseCenter() {
  const prop = globeEl.center || globeEl.camera?.center || null;
  const plat = Number(prop?.lat);
  const plon = Number(prop?.lng ?? prop?.lon);
  if (Number.isFinite(plat) && Number.isFinite(plon)) return { lat: plat, lon: plon };

  const raw = globeEl.getAttribute('center') || '';
  const parts = raw.split(',').map((x) => Number(x.trim()));
  if (parts.length >= 2 && Number.isFinite(parts[0]) && Number.isFinite(parts[1])) {
    return { lat: parts[0], lon: parts[1] };
  }
  return { lat: 34.2, lon: -120 };
}

function viewportCenterSafe(viewport = null) {
  const cam = viewport?.camera?.center || viewport?.center || null;
  const camLat = Number(cam?.lat);
  const camLon = Number(cam?.lon ?? cam?.lng);
  if (Number.isFinite(camLat) && Number.isFinite(camLon)) return { lat: camLat, lon: camLon };
  const south = Number(viewport?.south);
  const north = Number(viewport?.north);
  const west = Number(viewport?.west);
  const east = Number(viewport?.east);
  if ([south, north, west, east].every(Number.isFinite)) {
    return { lat: (south + north) / 2, lon: normalizeLongitude((west + east) / 2) };
  }
  const fetch = viewport?.fetch_bbox || viewport?.fetchBbox || null;
  if (fetch) return viewportCenterSafe(fetch);
  return parseCenter();
}

function parseRangeMeters() {
  const prop = Number(globeEl.range ?? globeEl.camera?.range);
  if (Number.isFinite(prop) && prop > 0) return prop;
  const attr = Number(globeEl.getAttribute('range'));
  if (Number.isFinite(attr) && attr > 0) return attr;
  return 1800000;
}

function parseCameraAngleSignature() {
  const heading = Number(globeEl.heading ?? globeEl.camera?.heading ?? globeEl.getAttribute('heading') ?? 0);
  const tilt = Number(globeEl.tilt ?? globeEl.camera?.tilt ?? globeEl.getAttribute('tilt') ?? 0);
  const roll = Number(globeEl.roll ?? globeEl.camera?.roll ?? globeEl.getAttribute('roll') ?? 0);
  return {
    heading: Number.isFinite(heading) ? heading : 0,
    tilt: Number.isFinite(tilt) ? tilt : 0,
    roll: Number.isFinite(roll) ? roll : 0,
  };
}

function parseBoundsAttr(raw) {
  if (!raw || typeof raw !== 'string') return null;
  const parts = raw.split(',').map((x) => Number(x.trim()));
  if (parts.length < 4 || parts.some((n) => !Number.isFinite(n))) return null;
  return { west: parts[0], south: parts[1], east: parts[2], north: parts[3] };
}

function trueViewportFromGlobeBounds() {
  const attrCandidates = [
    globeEl.getAttribute('bounds'),
    globeEl.getAttribute('view-bounds'),
    globeEl.getAttribute('visible-bounds'),
  ];
  for (const raw of attrCandidates) {
    const parsed = parseBoundsAttr(raw);
    if (parsed) return parsed;
  }
  if (typeof globeEl.getBounds === 'function') {
    try {
      const b = globeEl.getBounds();
      if (b && Number.isFinite(b.west) && Number.isFinite(b.south) && Number.isFinite(b.east) && Number.isFinite(b.north)) {
        return { west: b.west, south: b.south, east: b.east, north: b.north };
      }
    } catch (_) {}
  }
  return null;
}

function getCanonicalViewport() {
  const c = parseCenter();
  const range = parseRangeMeters();
  const fromBounds = trueViewportFromGlobeBounds();
  if (fromBounds) {
    const rawLatSpan = Math.max(0.1, fromBounds.north - fromBounds.south);
    const rawLonSpan = Math.max(0.1, fromBounds.east - fromBounds.west);
    if (rawLatSpan <= 10 && rawLonSpan <= 14) {
      return snapViewport({
        west: Math.max(-179.9, fromBounds.west),
        south: Math.max(-89.9, fromBounds.south),
        east: Math.min(179.9, fromBounds.east),
        north: Math.min(89.9, fromBounds.north),
        quality: 'coarse',
        camera: { center: c, range, ...parseCameraAngleSignature(), source: 'visible_bounds' },
      });
    }
  }

  const latSpan = Math.max(1.2, Math.min(10, range / 75000));
  const lonSpan = Math.min(14, latSpan / Math.max(Math.cos((c.lat * Math.PI) / 180), 0.35));
  return snapViewport({
    west: Math.max(-179.9, c.lon - lonSpan / 2),
    south: Math.max(-89.9, c.lat - latSpan / 2),
    east: Math.min(179.9, c.lon + lonSpan / 2),
    north: Math.min(89.9, c.lat + latSpan / 2),
    quality: 'coarse',
    camera: { center: c, range, ...parseCameraAngleSignature(), source: 'camera_heuristic' },
  });
}


function effectiveViewportStride(v) {
  const span = Math.max(
    Math.max(0.0001, v.east - v.west),
    Math.max(0.0001, v.north - v.south),
  );
  if (span > 14) return 4;
  if (span > 6) return 2;
  return 1;
}

function snapToGrid(value, step) {
  return Math.round(value / step) * step;
}

function snapViewport(v) {
  const stride = effectiveViewportStride(v);
  const step = 0.25 * stride;
  return {
    ...v,
    west: Math.max(-179.9, snapToGrid(v.west, step)),
    south: Math.max(-89.9, snapToGrid(v.south, step)),
    east: Math.min(179.9, snapToGrid(v.east, step)),
    north: Math.min(89.9, snapToGrid(v.north, step)),
    sourceStride: stride,
  };
}

function bboxToQuery(b) {
  return `${b.west.toFixed(4)},${b.south.toFixed(4)},${b.east.toFixed(4)},${b.north.toFixed(4)}`;
}


function sceneTierForViewport(viewport) {
  const v = viewport || getCanonicalViewport();
  const width = Math.abs(Number(v.east) - Number(v.west));
  const height = Math.abs(Number(v.north) - Number(v.south));
  const span = Math.max(width || 0, height || 0);
  const area = Math.max(0, width * height);
  if (span <= 1.6 && area <= 2.6) return 'harbor';
  if (span <= 4.0 && area <= 14.0) return 'coastal';
  if (span <= 12.0 && area <= 90.0) return 'regional';
  return 'world';
}

function sceneQueryParams(fetchViewport, visibleViewport) {
  const visible = visibleViewport || fetchViewport || getCanonicalViewport();
  const tier = sceneTierForViewport(visible);
  const visibleQ = encodeURIComponent(bboxToQuery(visible));
  return `visible_bbox=${visibleQ}&scene_tier=${encodeURIComponent(tier)}`;
}

function compactViewportForShoreline(viewport, reason = 'shoreline') {
  // Shoreline should follow what the user can see, not the much larger
  // atmosphere/weather fetch bbox. Some viewport objects carry the true
  // visible box nested under fetch_bbox.visibleBbox, so prefer that first.
  const nestedVisible = viewport?.fetch_bbox?.visibleBbox || viewport?.fetch_bbox?.visible_bbox || viewport?.fetch_bbox?.visible_bbox;
  const v = viewport?.visibleBbox || viewport?.visible_bbox || nestedVisible || viewport || getCanonicalViewport();
  const west = Number(v.west);
  const south = Number(v.south);
  const east = Number(v.east);
  const north = Number(v.north);
  if (![west, south, east, north].every(Number.isFinite)) return v;
  const width = Math.max(0.01, Math.abs(east - west));
  const height = Math.max(0.01, Math.abs(north - south));
  const cx = (west + east) / 2;
  const cy = (south + north) / 2;
  // Shoreline is static geometry, not atmosphere. Use visible bbox plus a
  // small pad so initial requests are around 4-12 high-def tiles instead of
  // the huge tilted weather fetch bbox.
  let factor = 1.16;
  const tier = sceneTierForViewport(v);
  if (tier === 'harbor') factor = 1.08;
  else if (tier === 'coastal') factor = 1.12;
  else if (tier === 'regional') factor = 1.15;
  return snapViewport({
    ...v,
    west: Math.max(-179.9, cx - width * factor / 2),
    east: Math.min(179.9, cx + width * factor / 2),
    south: Math.max(-89.9, cy - height * factor / 2),
    north: Math.min(89.9, cy + height * factor / 2),
    shorelineBbox: true,
    shorelinePadFactor: factor,
  });
}

function expandedViewportForFetch(viewport, reason = 'fetch') {
  const v = viewport || getCanonicalViewport();
  const west = Number(v.west);
  const south = Number(v.south);
  const east = Number(v.east);
  const north = Number(v.north);
  if (![west, south, east, north].every(Number.isFinite)) return v;
  const width = Math.max(0.02, Math.abs(east - west));
  const height = Math.max(0.02, Math.abs(north - south));
  const cam = v.camera || {};
  const tilt = Number(cam.tilt ?? cam.headingTilt ?? 0);
  const range = Number(cam.range ?? parseRangeMeters?.() ?? 0);
  let factor = 2.15;
  if (Number.isFinite(tilt) && tilt > 35) factor += Math.min(1.4, (tilt - 35) / 28);
  if (Number.isFinite(range) && range > 2500000) factor += 0.35;
  if (String(reason || '').includes('cache')) factor += 0.35;
  factor = Math.max(1.8, Math.min(3.9, factor));
  const cx = (west + east) / 2;
  const cy = (south + north) / 2;
  const next = {
    ...v,
    west: Math.max(-179.9, cx - (width * factor / 2)),
    east: Math.min(179.9, cx + (width * factor / 2)),
    south: Math.max(-89.9, cy - (height * factor / 2)),
    north: Math.min(89.9, cy + (height * factor / 2)),
    fetchExpanded: true,
    visibleBbox: { west, south, east, north },
    fetchPadFactor: Number(factor.toFixed(2)),
  };
  return snapViewport(next);
}

function sanitizeViewportForQuery(viewport) {
  if (!viewport || !Number.isFinite(viewport.west) || !Number.isFinite(viewport.south) || !Number.isFinite(viewport.east) || !Number.isFinite(viewport.north)) {
    throw new Error('Invalid viewport object before frame request');
  }
  const camera = viewport.camera && viewport.camera.center
    ? {
        center: {
          lat: Number(viewport.camera.center.lat),
          lon: Number(viewport.camera.center.lon),
        },
        range: Number(viewport.camera.range),
        tilt: Number(viewport.camera.tilt ?? 0),
        heading: Number(viewport.camera.heading ?? 0),
        roll: Number(viewport.camera.roll ?? 0),
        source: String(viewport.camera.source || ''),
      }
    : null;
  return {
    west: Number(viewport.west),
    south: Number(viewport.south),
    east: Number(viewport.east),
    north: Number(viewport.north),
    quality: String(viewport.quality || 'coarse'),
    visibleBbox: viewport.visibleBbox || viewport.visible_bbox || viewport.visibleBbox || viewport.visible_bbox || null,
    fetch_bbox: viewport.fetch_bbox || viewport.fetchBbox || null,
    scene_tier: viewport.scene_tier || viewport.sceneTier || sceneTierForViewport(viewport),
    camera,
  };
}

function viewportToQuery(viewport) {
  return encodeURIComponent(JSON.stringify(sanitizeViewportForQuery(viewport)));
}

function sendViewportPriority(reason = 'steady') {
  try { gfsSocket?.sendViewport?.(getCanonicalViewport(), reason); } catch (_) {}
}

function bboxSignature(b) {
  const range = parseRangeMeters();
  const cam = parseCameraAngleSignature();
  return `${b.west.toFixed(2)}:${b.south.toFixed(2)}:${b.east.toFixed(2)}:${b.north.toFixed(2)}:${Math.round(range / 25000)}:${Math.round(cam.heading / 2)}:${Math.round(cam.tilt / 2)}:${b.sourceStride || 1}`;
}


const CACHE_POP_DELAYS_MS = [7000, 22000, 60000];
const OPEN_FAST_MODE = true;
const OPEN_FAST_BOOT_WARM_MAX_TILES = 96;
const OPEN_FAST_STEADY_WARM_MAX_TILES = 192;
const OPEN_FAST_TILE_LOAD_LIMIT = 24;
const OPEN_FAST_FRAME_DELAY_MS = 18000;
const VISUAL_PIPELINE_MIN_MS = 2000;
let cachePopGeneration = 0;
let lastCachePopSchedule = { signature: '', at: 0 };

function scheduleCachePopRefreshes(viewport, reason = 'cache_pop') {
  const vp = viewport || getCanonicalViewport();
  const sig = bboxSignature(vp);
  const now = Date.now();
  // Avoid stacking website_load + initial_camera_sync + steadystate pop trains
  // for the same view. Stacked trains were repeatedly rebuilding jetstream/bait
  // and amplifying any polygon path error into a major slowdown.
  if (lastCachePopSchedule.signature === sig && (now - lastCachePopSchedule.at) < 2500) {
    console.info('[gfs cache] pop schedule deduped', { reason, signature: sig });
    return;
  }
  lastCachePopSchedule = { signature: sig, at: now };
  const generation = ++cachePopGeneration;
  CACHE_POP_DELAYS_MS.forEach((delayMs) => {
    window.setTimeout(() => {
      if (generation !== cachePopGeneration) return;
      const latestVp = getCanonicalViewport();
      const sigA = bboxSignature(vp);
      const sigB = bboxSignature(latestVp);
      const useVp = sigA === sigB ? latestVp : vp;
      refreshVisualPipeline(useVp, `${reason}_pop_${delayMs}`)
        .catch((err) => console.info('[gfs cache] pop refresh skipped', { delayMs, message: err?.message || String(err) }));
    }, delayMs);
  });
}

function visualServerLayerList(reason = 'steady', activeOverride = null) {
  const openingFast = /boot_open_fast|website_load|initial|opening/i.test(String(reason || ''));
  const active = activeOverride || {
    jetstream: !openingFast && isLayerOn('jetstream'),
    bait: !openingFast && isLayerOn('bait'),
    boater: !openingFast && isLayerOn('boater'),
    inlandWater: isLayerOn('inland-water'),
    clouds: isLayerOn('clouds'),
    rain: isLayerOn('rain'),
    lightning: isLayerOn('lightning'),
  };
  const layers = ['day_night'];
  if (active.clouds) layers.push('clouds');
  if (active.rain) layers.push('rain');
  if (active.bait) layers.push('bait');
  if (active.boater) layers.push('boats', 'currents');
  if (active.jetstream) layers.push('jetstream');
  if (active.inlandWater) layers.push('inland-water');
  if (active.lightning) layers.push('lightning');
  return [...new Set(layers)];
}

function scheduleGlobeCacheWarm(viewport, reason = 'website_load') {
  try {
    const fetchViewport = expandedViewportForFetch(viewport || getCanonicalViewport(), `cache_${reason}`);
    const bboxQ = encodeURIComponent(bboxToQuery(fetchViewport));
    const sceneQ = sceneQueryParams(fetchViewport, viewport || getCanonicalViewport());
    const warmLimit = Number(
      window.GFS_CACHE_WARM_MAX_TILES ||
      (/website_load|boot|initial/i.test(String(reason || '')) ? OPEN_FAST_BOOT_WARM_MAX_TILES : OPEN_FAST_STEADY_WARM_MAX_TILES)
    );
    const layerQ = encodeURIComponent(visualServerLayerList(reason).join(','));
    const url = `/gfs/api/cache-warm?bbox=${bboxQ}&${sceneQ}&max_tiles=${encodeURIComponent(warmLimit)}&reason=${encodeURIComponent(reason)}&layers=${layerQ}`;
    getJsonSafe(url, null, { timeoutMs: 2500, abortPrevious: false })
      .then((payload) => {
        if (!payload) return;
        console.info('[gfs cache] warm scheduled', {
          scheduled: payload.scheduled,
          reason: payload.reason,
          center: payload.plan?.center,
          tiles: payload.plan?.returned_tiles,
          warm: payload.warm,
        });
      })
      .catch((err) => console.info('[gfs cache] warm request skipped', { message: err?.message || String(err) }));
  } catch (err) {
    console.info('[gfs cache] warm setup skipped', { message: err?.message || String(err) });
  }
}


function mergeSceneTileContracts(tilesPayload, viewport, fetchViewport) {
  const tiles = Array.isArray(tilesPayload?.tiles) ? tilesPayload.tiles : [];
  if (!tiles.length) return null;
  const cloudsItems = [];
  const cloudRegions = [];
  const precipColumns = [];
  const oceanPoints = [];
  const boatItems = [];
  const baitPolygons = [];
  const baitOuter = [];
  const baitInner = [];
  const baitCore = [];
  const markers = [];
  let firstClouds = null;
  let firstLightning = null;
  let firstBait = null;
  let firstBoats = null;
  let firstOcean = null;
  for (const tile of tiles) {
    const contracts = tile?.contracts || tile || {};
    const clouds = contracts.clouds || tile.clouds || null;
    const ocean = contracts.oceanPoints || tile.oceanPoints || null;
    const boats = contracts.boats || tile.boats || null;
    const lightning = contracts.lightning || tile.lightning || null;
    const bait = contracts.baitAdvanced || tile.baitAdvanced || null;
    if (clouds && !firstClouds) firstClouds = clouds;
    if (ocean && !firstOcean) firstOcean = ocean;
    if (boats && !firstBoats) firstBoats = boats;
    if (lightning && !firstLightning) firstLightning = lightning;
    if (bait && !firstBait) firstBait = bait;
    if (Array.isArray(clouds?.items)) cloudsItems.push(...clouds.items);
    else if (Array.isArray(clouds?.tiles)) cloudsItems.push(...clouds.tiles);
    if (Array.isArray(clouds?.cloud_regions)) cloudRegions.push(...clouds.cloud_regions);
    if (Array.isArray(clouds?.precip_columns)) precipColumns.push(...clouds.precip_columns);
    if (Array.isArray(ocean?.points)) oceanPoints.push(...ocean.points);
    else if (Array.isArray(ocean?.items)) oceanPoints.push(...ocean.items);
    if (Array.isArray(boats?.boats)) boatItems.push(...boats.boats);
    else if (Array.isArray(boats?.items)) boatItems.push(...boats.items);
    const baitObj = bait?.bait || bait || {};
    if (Array.isArray(baitObj.polygons)) baitPolygons.push(...baitObj.polygons);
    if (Array.isArray(baitObj.outer_polygons)) baitOuter.push(...baitObj.outer_polygons);
    if (Array.isArray(baitObj.inner_polygons)) baitInner.push(...baitObj.inner_polygons);
    if (Array.isArray(baitObj.core_polygons)) baitCore.push(...baitObj.core_polygons);
    const tileMarkers = contracts.markers || tile.markers || [];
    if (Array.isArray(tileMarkers)) markers.push(...tileMarkers);
  }
  const clouds = {
    ...(firstClouds || {}),
    schema: 'gfs_cloud_regions_v1_from_scene_tile_cache',
    source: 'scene_tile_cache_cloud_contracts',
    payload_state: 'cache_first',
    items: cloudsItems,
    tiles: cloudsItems,
    features: cloudsItems,
    cloud_regions: cloudRegions,
    cloud_region_count: cloudRegions.length,
    precip_columns: precipColumns,
    bbox: fetchViewport,
    bbox_used: fetchViewport,
  };
  const bait = {
    ...(firstBait || {}),
    source: (firstBait?.source || 'scene_tile_cache_bait_contracts'),
    payload_state: 'cache_first',
    bait: {
      ...((firstBait?.bait || firstBait) || {}),
      polygons: baitPolygons,
      outer_polygons: baitOuter,
      inner_polygons: baitInner,
      core_polygons: baitCore,
    },
    bbox: fetchViewport,
    bbox_used: fetchViewport,
  };
  const boats = {
    ...(firstBoats || {}),
    source: (firstBoats?.source || 'scene_tile_cache_boat_contracts'),
    payload_state: 'cache_first',
    boats: boatItems,
    items: boatItems,
    bbox: fetchViewport,
    bbox_used: fetchViewport,
  };
  const ocean = {
    ...(firstOcean || {}),
    source: (firstOcean?.source || 'scene_tile_cache_ocean_point_contracts'),
    payload_state: 'cache_first',
    points: oceanPoints,
    items: oceanPoints,
    bbox: fetchViewport,
    bbox_used: fetchViewport,
  };
  return {
    ok: true,
    schema: 'lftr_frame_from_scene_tile_point_cache_v1',
    source: 'scene_tile_point_cache',
    payload_state: 'cache_first',
    cache: { hit: true, mode: 'scene_tile_point_cache', tile_count: tiles.length },
    bbox: viewport,
    visible_bbox: viewport,
    fetch_bbox: fetchViewport,
    scene_plan: tilesPayload?.plan?.scene_plan || tilesPayload?.scene_plan || null,
    clouds,
    weather: { ...(clouds || {}), fields: clouds.fields || {}, precip_columns: precipColumns },
    baitAdvanced: bait,
    boats,
    oceanPoints: ocean,
    locations: markers,
    summary: {
      tiles: tiles.length,
      cloud_items: cloudsItems.length,
      cloud_regions: cloudRegions.length,
      precip_columns: precipColumns.length,
      ocean_points: oceanPoints.length,
      boats: boatItems.length,
      bait_polygons: baitPolygons.length + baitOuter.length + baitInner.length + baitCore.length,
      markers: markers.length,
    },
  };
}

async function hydrateFromSceneTileCache(viewport, fetchViewport, reason = 'cache_first') {
  try {
    const bboxQ = encodeURIComponent(bboxToQuery(fetchViewport));
    const sceneQ = sceneQueryParams(fetchViewport, viewport);
    const limit = Number(window.GFS_CACHE_FIRST_TILE_LOAD_LIMIT || OPEN_FAST_TILE_LOAD_LIMIT || 24);
    const payload = await getJsonSafe(`/gfs/api/tiles?bbox=${bboxQ}&${sceneQ}&max_tiles=${encodeURIComponent(limit)}`, null, { timeoutMs: 2200, abortPrevious: false });
    const cachedFrame = mergeSceneTileContracts(payload, viewport, fetchViewport);
    if (!cachedFrame) return null;
    cachedFrame.render_reason = 'cache_first';
    dataState.latest.frame = cachedFrame;
    dataState.latest.clouds = cachedFrame.clouds || null;
    dataState.latest.weather = cachedFrame.weather || null;
    dataState.latest.baitAdvanced = preferRenderableBaitAdvanced(cachedFrame.baitAdvanced || null, dataState.latest.baitAdvanced || null);
    cachedFrame.baitAdvanced = dataState.latest.baitAdvanced;
    dataState.latest.boats = cachedFrame.boats || { boats: [] };
    dataState.latest.oceanPoints = cachedFrame.oceanPoints || null;
    dataState.latest.bbox = viewport;
    window.__gfsLastFrame = cachedFrame;
    layerRuntime.engine?.setData?.(cachedFrame || null);
    console.info('[gfs cache] scene-tile cache hydrated', { reason, summary: cachedFrame.summary, schema: payload?.schema });
    return cachedFrame;
  } catch (err) {
    console.info('[gfs cache] scene-tile hydrate skipped', { reason, message: err?.message || String(err) });
    return null;
  }
}

async function refreshData(reason = 'manual') {
  const viewport = getCanonicalViewport();
  const signature = bboxSignature(viewport);

  if (dataState.lastSignature === signature && reason !== 'boot' && reason !== 'steady' && reason !== 'force') {
    if (GFS_DEBUG) console.debug('[gfs data] skipped refresh; signature unchanged', { reason, signature });
    return dataState.latest;
  }

  if (dataState.inFlight && reason !== 'manual' && reason !== 'force') {
    if (GFS_DEBUG) console.debug('[gfs data] refresh already in flight; keeping prior request alive', { reason, signature });
    return dataState.latest;
  }

  if (dataState.inFlight && dataState.activeAbort) {
    try { dataState.activeAbort.abort(); } catch (_) {}
  }

  const controller = new AbortController();
  const seq = dataState.requestSeq + 1;
  dataState.requestSeq = seq;
  dataState.inFlight = true;
  dataState.activeAbort = controller;
  dataState.latest.bbox = viewport;
  dataState.lastSignature = signature;

  try {
    const fetchViewport = expandedViewportForFetch(viewport, `frame_${reason}`);
    const bboxQ = encodeURIComponent(bboxToQuery(fetchViewport));
    const vpQ = viewportToQuery({ ...viewport, fetch_bbox: fetchViewport });
    const sceneQ = sceneQueryParams(fetchViewport, viewport);
    if (reason === 'boot' || reason === 'steady' || reason === 'manual') {
      // Opening fast path: read a small tile-cache shell immediately and let
      // split layer endpoints fill in later.  The old boot path also fired a
      // full /gfs/api/frame request while cache-warm, sky, jetstream, HYCOM and
      // clouds started together; on 2 vCPU this regularly timed out at 9s and
      // stole the first-draw slot.
      hydrateFromSceneTileCache(viewport, fetchViewport, reason)
        .catch((err) => console.info('[gfs cache] async hydrate skipped', { reason, message: err?.message || String(err) }));
    }
    if (OPEN_FAST_MODE && reason === 'boot') {
      console.info('[gfs boot] open-fast: skipping blocking /gfs/api/frame; visual cache/layers will warm in stages', { signature });
      window.setTimeout(() => refreshData('force').catch((err) => console.info('[gfs boot] delayed frame refresh skipped', { message: err?.message || String(err) })), OPEN_FAST_FRAME_DELAY_MS);
      refreshVisualPipeline(viewport, 'boot_open_fast')
        .catch((err) => console.info('[gfs visual] boot open-fast skipped', { message: err?.message || String(err) }));
      return dataState.latest;
    }
    const frame = await getJsonSafe(`/gfs/api/frame?bbox=${bboxQ}&${sceneQ}&viewport=${vpQ}&quality=full`, null, { signal: controller.signal, abortPrevious: false, timeoutMs: 14000 });
    if (!frame) return dataState.latest;
    if (seq !== dataState.requestSeq) return dataState.latest;

    dataState.latest.bbox = frame.visible_bbox || frame.viewport_bbox || frame.bbox || frame.bbox_object || viewport;
    dataState.latest.scenePlan = frame.scene_plan || null;
    dataState.latest.weather = frame.weather || null;
    dataState.latest.clouds = frame.clouds || null;
    dataState.latest.baitBase = frame.baitBase || null;
    dataState.latest.baitAdvanced = preferRenderableBaitAdvanced(frame.baitAdvanced || null, dataState.latest.baitAdvanced || null);
    frame.baitAdvanced = dataState.latest.baitAdvanced;
    dataState.latest.boats = frame.boats || { boats: [] };
    dataState.latest.oceanPoints = frame.oceanPoints || dataState.latest.oceanPoints || null;
    if (dataState.latest.oceanPoints) frame.oceanPoints = dataState.latest.oceanPoints;
    dataState.latest.recursiveGrid = frame.recursiveGrid || null;
    frame.render_reason = (reason === 'boot' || reason === 'manual') ? 'steady' : reason;
    dataState.latest.frame = frame;

    window.__gfsLastBbox = bboxToQuery(dataState.latest.bbox || viewport);
    window.__gfsLastFrame = frame;
    window.currentBBox = window.__gfsLastBbox;
    window.__gfsRecursiveGrid = { latest: dataState.latest.recursiveGrid, bbox: bboxToQuery(dataState.latest.bbox || viewport) };
    layerRuntime.engine?.setData?.(frame || null);
    logMissionControlState(reason);
    const cloudCounts = countRenderableClouds(frame);
    const boatSummary = boatCounts(dataState.latest.boats);
    console.info('[gfs data] refreshed', {
      reason,
      signature,
      frame: Boolean(frame),
      weather: Boolean(dataState.latest.weather),
      clouds: Boolean(dataState.latest.clouds),
      baitBase: Boolean(dataState.latest.baitBase),
      baitAdvanced: Boolean(dataState.latest.baitAdvanced),
      boatsRaw: boatSummary.raw,
      boatsRenderableHint: boatSummary.renderableHint,
      boatsFallbackRejected: boatSummary.fallbackRejected,
      cloudsRenderable: cloudCounts,
    });
    if (hud?.selected?.()) {
      hud.refreshSelected?.().catch((err) => console.info('[gfs hud] selected intel refresh skipped', { message: err?.message || String(err) }));
    }
    if (reason === 'boot' || reason === 'steady' || reason === 'manual') {
      sendViewportPriority(reason);
      if (reason !== 'boot') skyRuntime?.refresh?.(reason);
      // Visualization-first repair: the frame endpoint can intentionally return a
      // fast cache shell while heavy/cache warmer data is already available from
      // split endpoints. Pull the visual layers directly, then push them into the
      // same frame so clouds/rain/boats/bait draw without waiting for a second
      // full-frame cache hit. These calls are cache-first on the server side.
      refreshVisualPipeline(viewport, reason)
        .catch((err) => console.info('[gfs visual] ordered pipeline skipped', { message: err?.message || String(err) }));
    }
    return dataState.latest;
  } catch (err) {
    if (err?.name !== 'AbortError') {
      console.warn('[gfs data] refresh failed', err?.message || err);
    }
    return dataState.latest;
  } finally {
    if (dataState.activeAbort === controller) dataState.activeAbort = null;
    if (seq === dataState.requestSeq) dataState.inFlight = false;
  }
}


let visualPipelineSeq = 0;
let visualPipelineInFlight = false;
let visualPipelineQueued = null;
let lastVisualPipelineStartAt = 0;
let jetstreamVisualReady = false;
let lastJetstreamEnsureAt = 0;

async function ensureJetstreamVisual(reason = 'steady') {
  try {
    if (!isLayerOn('jetstream')) {
      if (GFS_DEBUG) console.debug('[gfs visual] jetstream held disabled', { reason });
      return;
    }
    if (window.__gfsJetstreamDisabled === true || layerUserPrefs().jetstream === false || window.__gfsJetstreamPillOn === false) {
      if (GFS_DEBUG) console.debug('[gfs visual] jetstream hard-disabled by pill', { reason });
      return;
    }
    const now = Date.now();
    if (jetstreamVisualReady && window.__gfsLayerState?.jetstreamBalloons && window.__gfsJetstreamDisabled !== true && (now - lastJetstreamEnsureAt) < 120000) {
      if (GFS_DEBUG) console.debug('[gfs visual] jetstream already ready', { reason });
      return;
    }
    lastJetstreamEnsureAt = now;
    window.__gfsLayerState = { ...(window.__gfsLayerState || {}), jetstreamBalloons: true };
    window.__gfsJetstreamDisabled = false;
    window.__gfsJetstreamPillOn = true;
    if (typeof window.setJetBalloonsEnabled === 'function') {
      await window.setJetBalloonsEnabled(true);
    }
    jetstreamVisualReady = true;
    console.info('[gfs visual] jetstream ready', { reason });
  } catch (err) {
    console.info('[gfs visual] jetstream enable skipped', { message: err?.message || String(err) });
  }
}

async function refreshVisualPipeline(viewport, reason = 'steady') {
  const now = Date.now();
  if (visualPipelineInFlight) {
    visualPipelineQueued = { viewport, reason };
    console.info('[gfs visual] refresh coalesced behind active pipeline', { reason });
    return null;
  }
  if ((now - lastVisualPipelineStartAt) < VISUAL_PIPELINE_MIN_MS && !/pill|toggle|manual/i.test(String(reason || ''))) {
    console.info('[gfs visual] refresh throttled during opening', { reason, ageMs: now - lastVisualPipelineStartAt });
    return null;
  }
  lastVisualPipelineStartAt = now;
  visualPipelineInFlight = true;
  const seq = ++visualPipelineSeq;
  const renderReason = 'steady';
  try {
    window.__gfsJetViewportBbox = bboxToQuery(viewport || dataState.latest?.bbox || getViewportBbox?.());
    window.__gfsJetCameraRange = parseRangeMeters?.();
  } catch (_) {}
  sendViewportPriority(reason);
  const openingFast = /boot_open_fast|website_load_pop_7000/i.test(String(reason || ''));
  const active = {
    // During first paint, keep CPU/network for visible map + clouds/rain shell.
    // Jetstream + ocean/bait/boats are warmed by the next staged pass.
    jetstream: !openingFast && isLayerOn('jetstream'),
    bait: !openingFast && isLayerOn('bait'),
    boater: !openingFast && isLayerOn('boater'),
    inlandWater: isLayerOn('inland-water'),
    clouds: isLayerOn('clouds'),
    rain: isLayerOn('rain'),
    lightning: isLayerOn('lightning'),
  };
  console.info('[gfs visual] fast staged refresh start', { reason, active });

  if (active.jetstream) {
    ensureJetstreamVisual(renderReason)
      .then(() => window.refreshJetBalloonsForViewport?.(renderReason))
      .catch((err) => console.info('[gfs visual] jetstream skipped', { message: err?.message || String(err) }));
  }

  const stillCurrent = () => seq === visualPipelineSeq;
  const runIfCurrent = (label, fn) => {
    if (!stillCurrent()) return Promise.resolve(null);
    return fn().catch((err) => console.info(`[gfs ${label}] staged fetch skipped`, { reason, message: err?.message || String(err) }));
  };

  try {
    // Strict payload path: fetch real server payloads only. Sea gives the shared
    // derived scene; split clouds and advanced bait are first-class enrichments,
    // not fallbacks. We do not fabricate polygons from sparse points/CSV rows.
    const tasks = [runIfCurrent('sea', () => refreshSeaIntelligence(viewport, renderReason, active))];
    // First paint should not wait on /gfs/api/clouds warming. The sea-engine
    // payload already has renderable cloud/rain contours; split clouds enrich later.
    if ((active.clouds || active.rain) && !openingFast) tasks.push(runIfCurrent('clouds/rain', () => refreshDeferredClouds(viewport, renderReason)));
    if (openingFast && (active.clouds || active.rain)) {
      window.setTimeout(() => refreshDeferredClouds(viewport, 'post_open_cloud_enrich').catch((err) => console.info('[gfs clouds] post-open enrich skipped', { message: err?.message || String(err) })), 18000);
    }
    if (active.inlandWater) tasks.push(runIfCurrent('inland-water', () => refreshDeferredInlandWater(viewport, openingFast ? 'boot_open_fast' : renderReason)));
    if (active.bait) tasks.push(runIfCurrent('bait-advanced', () => refreshDeferredBaitAdvanced(viewport, renderReason)));
    if (active.boater) tasks.push(runIfCurrent('boats', () => refreshDeferredBoats(viewport, renderReason)));
    if (openingFast && active.inlandWater) {
      window.setTimeout(() => refreshDeferredInlandWater(viewport, 'post_open_inland_enrich').catch((err) => console.info('[gfs inland-water] post-open enrich skipped', { message: err?.message || String(err) })), 9000);
    }
    if (active.lightning) tasks.push(runIfCurrent('lightning', () => refreshDeferredLightning(viewport, renderReason)));
    const settled = await Promise.allSettled(tasks);
    const seaPayload = settled[0]?.status === 'fulfilled' ? settled[0].value : null;
    const seaHasClouds = seaPayloadHasLayer(seaPayload, 'clouds');
    const seaHasRain = seaPayloadHasLayer(seaPayload, 'rain');
    const seaHasBait = seaPayloadHasLayer(seaPayload, 'bait');
    const seaHasBoats = seaPayloadHasLayer(seaPayload, 'boats');
    if (!stillCurrent()) return null;
    console.info('[gfs visual] strict staged refresh complete', { reason, seq, active, seaHasClouds, seaHasRain, seaHasBait, seaHasBoats, officialPayloadTasks: tasks.length, clientFallbacks: 0 });
    window.setTimeout(() => logPayloadDebug(viewport, reason).catch(() => {}), 20000);
    return true;
  } finally {
    visualPipelineInFlight = false;
    const queued = visualPipelineQueued;
    visualPipelineQueued = null;
    if (queued && bboxSignature(queued.viewport || getCanonicalViewport()) !== bboxSignature(viewport)) {
      window.setTimeout(() => refreshVisualPipeline(queued.viewport, `${queued.reason}_coalesced`).catch(() => {}), 1200);
    }
  }
}



function patchLatestFrame(slot, payload, reason, mergeFrame = null) {
  const frame = dataState.latest.frame;
  if (!frame || !payload) return;
  frame[slot] = payload;
  frame.render_reason = 'steady';
  frame.meta = {
    ...(frame.meta || {}),
    render_reason: 'steady',
    [`${slot}_refresh_reason`]: reason,
    [`${slot}_refresh_ts`]: Date.now(),
  };
  if (typeof mergeFrame === 'function') mergeFrame(frame, payload);
  try { layerRuntime.engine?.setData?.(frame); }
  catch (err) { console.warn(`[gfs ${slot}] layer push failed`, err); }
}

async function logPayloadDebug(viewport, reason = 'manual') {
  try {
    const bboxQ = encodeURIComponent(bboxToQuery(viewport));
    const sceneQ = sceneQueryParams(viewport, viewport);
    const dbg = await getJsonSafe(`/gfs/api/payload-debug?bbox=${bboxQ}&${sceneQ}`, null, { abortPrevious: false, timeoutMs: 45000 });
    if (!dbg) return null;
    const layers = dbg.layers || {};
    const providers = dbg.providers || {};
    console.info('[gfs payload-debug]', {
      reason,
      latencyMs: dbg.latency_ms,
      clouds: layers.clouds,
      bait: layers.bait,
      boats: layers.boats,
      oceanPoints: layers.ocean_points,
      gfs: providers.gfs_nomads,
      hycom: providers.hycom,
      truth: dbg.truth_contract || dbg.resolution_truth || null,
    });
    try {
      debugPanelEvent('resolution/truth', dbg.truth_contract || dbg.resolution_truth || {});
    } catch (_) {}
    return dbg;
  } catch (err) {
    console.warn('[gfs payload-debug] failed', { reason, message: err?.message || String(err) });
    return null;
  }
}

let lastCloudShellRefreshAt = 0;
let lastCloudShellRefreshKey = '';

function bboxKeyForCloudRefresh(viewport) {
  if (!viewport) return 'na';
  const parts = [viewport.west, viewport.south, viewport.east, viewport.north].map((v) => Number(v || 0).toFixed(2));
  return parts.join(',');
}

function cloudPayloadHasDrawableContent(payload) {
  if (!payload) return false;
  const seaCloudLayer = payload?.layers?.clouds || payload?.seaIntelligence?.layers?.clouds || null;
  if (seaCloudLayer && Array.isArray(seaCloudLayer.features) && seaCloudLayer.features.length) return true;
  if (Array.isArray(payload?.polygon_field_v1?.features) && payload.polygon_field_v1.features.length) return true;
  if (Array.isArray(payload?.tiles) && payload.tiles.length) return true;
  if (Array.isArray(payload?.items) && payload.items.length) return true;
  if (Array.isArray(payload?.scene?.clouds) && payload.scene.clouds.length) return true;
  if (Array.isArray(payload?.cloud_regions) && payload.cloud_regions.length) return true;
  if (Array.isArray(payload?.cloud_layers) && payload.cloud_layers.some((l) => Array.isArray(l?.density) && l.density.length)) return true;
  const fields = payload?.fields || {};
  return Boolean(fields.cloud_total || fields.cloud_low || fields.cloud_mid || fields.cloud_high || payload?.cloud_cover);
}

function cloudPayloadState(payload) {
  return String(payload?.source_state || payload?.payload_state || payload?.status || '').toLowerCase();
}

function shouldHoldCloudPayload(payload) {
  const state = cloudPayloadState(payload);
  return (state === 'warming' || state === 'pending' || state === 'queued') && !cloudPayloadHasDrawableContent(payload);
}



async function refreshSeaIntelligence(viewport, reason = 'manual', activeOverride = null) {
  try {
    if (window.__gfsSeaEngineDisabled === true) return null;
    const fetchViewport = expandedViewportForFetch(viewport, `sea_${reason}`);
    const bboxQ = encodeURIComponent(bboxToQuery(fetchViewport));
    const layerList = visualServerLayerList(reason, activeOverride).filter((x) => x !== 'inland-water' && x !== 'lightning' && x !== 'currents');
    const mobileSea = /android|iphone|ipad|mobile/i.test(navigator.userAgent || '');
    const gridSize = Number(window.LFTR_SEA_GRID_SIZE || (mobileSea ? 192 : 256));
    const url = `/gfs/api/sea?bbox=${bboxQ}&grid_size=${encodeURIComponent(gridSize)}&layers=${encodeURIComponent([...new Set(layerList)].join(','))}`;
    const payload = await getJsonSafe(url, null, { abortPrevious: false, timeoutMs: 9000 });
    if (!payload) return null;
    dataState.latest.seaIntelligence = payload;
    patchLatestFrame('seaIntelligence', payload, reason);
    console.info('[gfs sea] fastapi sea-of-intelligence refreshed', {
      reason,
      status: payload.status,
      source: payload.source,
      marchingSquares: payload.marching_squares,
      latencyMs: payload.latency_ms,
      gridShape: payload.grid_shape,
      summary: payload.summary,
    });
    const seaLayers = payload.layers || {};
    const seaSummary = Object.fromEntries(Object.entries(seaLayers).map(([name, layer]) => [name, {
      features: Array.isArray(layer?.features) ? layer.features.length : 0,
      source_grid_shape: layer?.resolution?.source_grid_shape,
      subgrid_requested: layer?.resolution?.subgrid_requested,
      subgrid_used: layer?.resolution?.subgrid_used,
      derived_grid_shape: layer?.resolution?.derived_grid_shape,
      source_cell_resolution_deg: layer?.resolution?.source_cell_resolution_deg,
      derived_cell_resolution_deg: layer?.resolution?.derived_cell_resolution_deg,
      reduced_for_budget: layer?.resolution?.reduced_for_budget,
    }]));
    debugPanelEvent('sea/status', {
      engine: 'online',
      status: payload.status,
      marching: payload.marching_squares,
      sourceGrid: payload.source_grid_shape,
      sourceCellResolutionDeg: payload.source_cell_resolution_deg,
      tier: payload.tier,
      truthContract: payload.truth_contract || null,
      layers: seaSummary,
      fallback: 'disabled: strict live payloads only; no fabricated client fallback geometry',
    });
    debugPanelEvent('sea/payload', summarizePayloadForDebug({
      status: payload.status,
      source: payload.source,
      features: Object.values(payload.layers || {}).flatMap((l) => l?.features || []),
      bbox: payload.bbox,
    }));
    return payload;
  } catch (err) {
    console.info('[gfs sea] strict sea payload unavailable', { reason, message: err?.message || String(err) });
    return null;
  }
}


async function refreshDeferredInlandWater(viewport, reason = 'manual') {
  if (isLayerUserDisabled('inland-water')) {
    clearLayerVisuals('inland-water');
    return null;
  }
  const startedAt = performance.now?.() || Date.now();
  const shorelineViewport = compactViewportForShoreline(viewport, `refreshDeferredInlandWater_${reason}`);
  const bboxQ = encodeURIComponent(bboxToQuery(shorelineViewport));
  const sceneQ = sceneQueryParams(shorelineViewport, viewport || shorelineViewport);
  const center = viewportCenterSafe(viewport || shorelineViewport);
  const liveTemp = window.GFS_INLAND_WATER_LIVE_NCSS === true;
  const liveQ = liveTemp ? '&live=1' : '';
  const bootFast = /boot_open_fast|opening|website_load/i.test(String(reason || ''));
  const tier = sceneTierForViewport(viewport || shorelineViewport);
  const inlandTileLimit = tier === 'harbor' ? 4 : (tier === 'coastal' ? 8 : (bootFast ? 12 : 16));
  const waterUrl = `/gfs/api/inland-water?bbox=${bboxQ}&${sceneQ}&source=auto&geometry=vector&lod=auto&cache=1&tile_cache=1&parallel=1&auto_build=1&max_tiles=${encodeURIComponent(inlandTileLimit)}&reason=${encodeURIComponent(reason)}`;
  const conditionsUrl = `/gfs/api/inland-conditions?bbox=${bboxQ}&lat=${encodeURIComponent(center.lat)}&lon=${encodeURIComponent(center.lon)}${liveQ}&cache=1&parallel=1&reason=${encodeURIComponent(reason)}`;
  const baitUrl = `/gfs/api/inland-bait?bbox=${bboxQ}${liveQ}&cache=1&parallel=1&reason=${encodeURIComponent(reason)}`;

  // Important: Inland water geometry is the visible layer. Conditions are now
  // real-temperature-only, so do not request them unless live sampling is enabled.
  // Bait stays fast and geometry-only unless live=1 is explicitly requested.
  const water = await getJsonSafe(waterUrl, null, { abortPrevious: false, timeoutMs: bootFast ? 4500 : 8000 });
  if (!water) return null;
  dataState.latest.inlandWater = water;
  patchLatestFrame('inlandWater', water, reason, (frame) => {
    frame.inlandConditions = dataState.latest.inlandConditions || null;
    frame.inlandBait = dataState.latest.inlandBait || null;
  });

  const waterCount = (Array.isArray(water?.polygons) ? water.polygons.length : 0) + (Array.isArray(water?.lines) ? water.lines.length : 0);
  if (waterCount <= 0 || water?.status === 'no_high_def_source') {
    const message = water?.message || 'High-def Inland Waters source missing; real NHD source tiles will be built for this viewport.';
    console.info('[gfs inland-water] high-def source not installed; starting post-install viewport build if needed', { reason, source: water?.source, message });
    markLayerUnavailable('inland-water', message);
    if (water?.build) {
      console.info('[gfs inland-water] backend auto-build status', water.build);
    }
    try {
      const buildKey = [bboxToQuery(shorelineViewport), tier].join(':');
      window.__gfsInlandBuildRequests = window.__gfsInlandBuildRequests || {};
      const last = Number(window.__gfsInlandBuildRequests[buildKey] || 0);
      const now = Date.now();
      const requestBuild = () => {
        const buildUrl = `/gfs/api/inland-water/build-cache?bbox=${bboxQ}&${sceneQ}&reason=${encodeURIComponent(reason)}`;
        return getJsonSafe(buildUrl, null, { abortPrevious: false, timeoutMs: 3500 })
          .then((job) => {
            console.info('[gfs inland-water] viewport source build requested', { bbox: bboxToQuery(shorelineViewport), tier, job });
            return job;
          })
          .catch((err) => {
            console.info('[gfs inland-water] viewport source build request skipped', { message: err?.message || String(err) });
            return null;
          });
      };
      if ((now - last) > 300000) {
        window.__gfsInlandBuildRequests[buildKey] = now;
        requestBuild();
      }

      // Progressive first-run behavior: the server writes index.json after each
      // completed source square. While the build is running, poll this same
      // viewport briefly so one finished tile can draw without a manual reload.
      window.__gfsInlandProgressPoll = window.__gfsInlandProgressPoll || {};
      const pollState = window.__gfsInlandProgressPoll[buildKey] || { tries: 0, timer: null, lastAt: 0 };
      const building = Boolean(water?.build?.running || water?.status === 'building' || water?.status === 'no_high_def_source');
      if (building && pollState.tries < 18 && !pollState.timer) {
        pollState.tries += 1;
        pollState.lastAt = now;
        const delay = Math.min(30000, 4500 + pollState.tries * 1500);
        pollState.timer = window.setTimeout(() => {
          const st = window.__gfsInlandProgressPoll?.[buildKey];
          if (st) st.timer = null;
          refreshDeferredInlandWater(shorelineViewport, `inland_build_progress_${pollState.tries}`).catch((err) => {
            console.info('[gfs inland-water] progressive poll skipped', { message: err?.message || String(err) });
          });
        }, delay);
        window.__gfsInlandProgressPoll[buildKey] = pollState;
        console.info('[gfs inland-water] progressive poll scheduled', { buildKey, try: pollState.tries, delayMs: delay, status: water?.status, build: water?.build || null });
      }
    } catch (err) {
      console.info('[gfs inland-water] source build trigger/poll skipped', { message: err?.message || String(err) });
    }
    return water;
  }
  clearLayerUnavailable('inland-water');

  const conditionsP = liveTemp
    ? getJsonSafe(conditionsUrl, null, { abortPrevious: false, timeoutMs: 10000 })
    : Promise.resolve(null);
  const baitP = getJsonSafe(baitUrl, null, { abortPrevious: false, timeoutMs: liveTemp ? 12000 : 3500 });
  console.info('[gfs inland-water] geometry refreshed', {
    reason,
    ms: Math.round((performance.now?.() || Date.now()) - startedAt),
    polygons: Array.isArray(water?.polygons) ? water.polygons.length : 0,
    lines: Array.isArray(water?.lines) ? water.lines.length : 0,
    temperaturePoints: Array.isArray(water?.temperature_points) ? water.temperature_points.length : 0,
    cache: water?.cache || null,
    source: water?.source,
  });

  Promise.allSettled([conditionsP, baitP]).then(([conditionsResult, baitResult]) => {
    const conditions = conditionsResult.status === 'fulfilled' ? conditionsResult.value : null;
    const bait = baitResult.status === 'fulfilled' ? baitResult.value : null;
    if (conditions) dataState.latest.inlandConditions = conditions;
    if (bait) dataState.latest.inlandBait = bait;
    patchLatestFrame('inlandWater', dataState.latest.inlandWater || water, `${reason}_enriched`, (frame) => {
      frame.inlandConditions = conditions || dataState.latest.inlandConditions || null;
      frame.inlandBait = bait || dataState.latest.inlandBait || null;
    });
    console.info('[gfs inland-water] enrichment refreshed', {
      reason,
      ms: Math.round((performance.now?.() || Date.now()) - startedAt),
      baitTargets: Array.isArray(bait?.targets) ? bait.targets.length : 0,
      temperaturePoints: (Array.isArray(water?.temperature_points) ? water.temperature_points.length : 0) + (Array.isArray(bait?.temperature_points) ? bait.temperature_points.length : 0) + (Array.isArray(conditions?.temperature_points) ? conditions.temperature_points.length : 0),
      surfaceTempSource: conditions?.surface_temperature?.source || conditions?.surface_temperature?.used || null,
    });
  }).catch((err) => console.info('[gfs inland-water] enrichment skipped', { reason, message: err?.message || String(err) }));

  return water;
}

async function refreshDeferredLightning(viewport, reason = 'manual') {
  if (isLayerUserDisabled('lightning')) {
    clearLayerVisuals('lightning');
    return null;
  }
  const fetchViewport = expandedViewportForFetch(viewport, `refreshDeferredLightning_${reason}`);
  const bboxQ = encodeURIComponent(bboxToQuery(fetchViewport));
  const sceneQ = sceneQueryParams(fetchViewport, viewport);
  debugPanelEvent('lightning/request', { reason, bbox: bboxToQuery(fetchViewport), scene: sceneQ, minutes: 20 });
  const payload = await getJsonSafe(`/gfs/api/lightning?bbox=${bboxQ}&${sceneQ}&minutes=20`, null, { abortPrevious: false, timeoutMs: 9000 });
  if (!payload) return null;
  dataState.latest.lightning = payload;
  patchLatestFrame('lightning', payload, reason);
  debugPanelEvent('lightning/payload', summarizePayloadForDebug(payload));
  console.info('[gfs lightning] refreshed', {
    reason,
    dataCame: Boolean(payload),
    source: payload?.source,
    state: payload?.payload_state || payload?.status,
    flashes: Array.isArray(payload?.flashes) ? payload.flashes.length : 0,
    regions: Array.isArray(payload?.regions) ? payload.regions.length : 0,
    fallback: Boolean(payload?.fallback_used),
    sceneTier: payload?.scene_tier || payload?.scene_plan?.tier,
  });
  return payload;
}

async function refreshDeferredClouds(viewport, reason = 'manual') {
  if (window.__gfsCloudsDisabled === true || isLayerUserDisabled('clouds')) {
    try { window.clearGfsCloudLayer?.(); } catch (_) {}
    try { globeEl?.querySelectorAll?.('[data-gfs-layer="clouds"],[data-cloud-shell],[data-cloud-particle],[data-gfs-layer="ocean-fx"],[data-ocean-fx-kind]')?.forEach((el) => el.remove()); } catch (_) {}
    return null;
  }
  const fetchViewport = expandedViewportForFetch(viewport, `refreshDeferredClouds_${reason}`);
  const refreshKey = `${bboxKeyForCloudRefresh(viewport)}|${sceneTierForViewport(viewport)}`;
  const now = Date.now();
  const existingDrawable = cloudPayloadHasDrawableContent(dataState.latest.clouds);
  const sameCloudScene = refreshKey === lastCloudShellRefreshKey;
  const forceReason = /boot|initial|pill|toggle|manual|first/i.test(String(reason || ''));
  if (existingDrawable && sameCloudScene && !forceReason && (now - lastCloudShellRefreshAt) < CLOUD_SHELL_REFRESH_MS) {
    console.info('[gfs clouds] holding cloud shell refresh; particles continue advecting', { reason, ageMs: now - lastCloudShellRefreshAt, minMs: CLOUD_SHELL_REFRESH_MS });
    return dataState.latest.clouds;
  }
  const bboxQ = encodeURIComponent(bboxToQuery(fetchViewport));
  const sceneQ = sceneQueryParams(fetchViewport, viewport);
  const payload = await getJsonSafe(`/gfs/api/clouds?bbox=${bboxQ}&${sceneQ}&quality=full`, null, { abortPrevious: false, timeoutMs: 11000 });
  if (!payload) return null;
  if (shouldHoldCloudPayload(payload) && cloudPayloadHasDrawableContent(dataState.latest.clouds)) {
    console.info('[gfs clouds] warming response held; existing drawable cloud scene preserved', { reason, state: cloudPayloadState(payload), source: payload?.source });
    return dataState.latest.clouds;
  }
  if (cloudPayloadHasDrawableContent(payload)) {
    lastCloudShellRefreshAt = Date.now();
    lastCloudShellRefreshKey = refreshKey;
  }
  dataState.latest.clouds = payload;
  patchLatestFrame('clouds', payload, reason, (frame, cloudsPayload) => {
    frame.weather = frame.weather || {};
    frame.weather.fields = frame.weather.fields || cloudsPayload.fields || {};
    frame.weather.precip_columns = frame.weather.precip_columns || cloudsPayload.precip_columns || [];
    frame.weather.polygon_field_v1 = frame.weather.polygon_field_v1 || cloudsPayload.polygon_field_v1 || null;
    frame.weather.bbox = frame.weather.bbox || cloudsPayload.bbox || cloudsPayload.bbox_used || frame.bbox;
    frame.weather.bbox_used = frame.weather.bbox_used || cloudsPayload.bbox_used || cloudsPayload.bbox || frame.bbox;
  });
  console.info('[gfs clouds] refreshed', {
    reason,
    dataCame: Boolean(payload),
    drawableItems: Array.isArray(payload?.items) ? payload.items.length : 0,
    sceneClouds: Array.isArray(payload?.scene?.clouds) ? payload.scene.clouds.length : 0,
    precipColumns: Array.isArray(payload?.precip_columns) ? payload.precip_columns.length : 0,
    scenePrecip: Array.isArray(payload?.scene?.precip) ? payload.scene.precip.length : 0,
    fieldKeys: Object.keys(payload?.fields || {}).length,
    fieldShapes: payload?.field_shapes || null,
    hasJetUv: Boolean(payload?.fields?.wind_u && payload?.fields?.wind_v),
    source: payload?.source,
    state: payload?.payload_state || payload?.source_state || payload?.status,
    cycle: payload?.cycle,
    forecastHour: payload?.forecast_hour,
    validTime: payload?.valid_time,
    sceneTier: payload?.scene_tier || payload?.scene_plan?.tier,
    renderBudget: payload?.render_budget || payload?.scene_plan?.render_budget,
  });
  return payload;
}

async function refreshDeferredBoats(viewport, reason = 'manual') {
  const fetchViewport = expandedViewportForFetch(viewport, `refreshDeferredBoats_${reason}`);
  const bboxQ = encodeURIComponent(bboxToQuery(fetchViewport));
  const vpQ = viewportToQuery({ ...viewport, fetch_bbox: fetchViewport });
  const sceneQ = sceneQueryParams(fetchViewport, viewport);
  const payload = await getJsonSafe(`/gfs/api/boats?bbox=${bboxQ}&${sceneQ}&viewport=${vpQ}&quality=full`, null, { abortPrevious: false, timeoutMs: 12000 });
  if (!payload) return null;
  dataState.latest.boats = payload;
  patchLatestFrame('boats', payload, reason);
  console.info('[gfs boats] refreshed', {
    reason,
    dataCame: Boolean(payload),
    rawBoats: Array.isArray(payload?.boats) ? payload.boats.length : 0,
    renderableHint: payload?.renderable_count_hint,
    fallbackRejected: payload?.fallback_rejected_count_hint,
    source: payload?.source,
    mode: payload?.mode,
    contract: payload?.render_contract,
    sceneTier: payload?.scene_tier || payload?.scene_plan?.tier,
    renderBudget: payload?.render_budget || payload?.scene_plan?.render_budget,
  });
  return payload;
}

async function refreshDeferredOceanPoints(viewport, reason = 'manual') {
  const fetchViewport = expandedViewportForFetch(viewport, `refreshDeferredOceanPoints_${reason}`);
  const bboxQ = encodeURIComponent(bboxToQuery(fetchViewport));
  const span = Math.max(Math.abs(fetchViewport.east - fetchViewport.west), Math.abs(fetchViewport.north - fetchViewport.south));
  const lod = span < 1.5 ? 'harbor' : (span > 8 ? 'world' : 'regional');
  const sceneQ = sceneQueryParams(fetchViewport, viewport);
  const payload = await getJsonSafe(`/gfs/api/ocean-points?bbox=${bboxQ}&${sceneQ}&lod=${encodeURIComponent(lod)}`, null, { abortPrevious: false, timeoutMs: 12000 });
  if (!payload) return null;
  dataState.latest.oceanPoints = payload;
  patchLatestFrame('oceanPoints', payload, reason);
  console.info('[gfs ocean-points] refreshed', {
    reason,
    lod,
    dataCame: Boolean(payload),
    points: Array.isArray(payload?.points) ? payload.points.length : 0,
    source: payload?.source,
    selectedAttempt: payload?.source_meta?.selected_attempt,
    selectedVars: payload?.source_meta?.selected_vars,
    gridShape: payload?.source_meta?.grid_shape || payload?.grid?.grid_shape,
    diagnostics: payload?.source_meta?.diagnostics,
    mask: payload?.mask,
    grid: payload?.grid,
    sceneTier: payload?.scene_tier || payload?.scene_plan?.tier,
    targetCells: payload?.scene_plan?.target_cells,
  });
  return payload;
}

// compatibility contract: /gfs/api/bait?bbox= then /gfs/api/bait/advanced?bbox=; advanced bait replaced base; installTimerRefresh
async function refreshDeferredBaitAdvanced(viewport, reason = 'manual') {
  const fetchViewport = expandedViewportForFetch(viewport, `refreshDeferredBaitAdvanced_${reason}`);
  const bboxQ = encodeURIComponent(bboxToQuery(fetchViewport));
  const vpQ = viewportToQuery({ ...viewport, fetch_bbox: fetchViewport });
  const sceneQ = sceneQueryParams(fetchViewport, viewport);
  const payload = await getJsonSafe(`/gfs/api/bait-advanced?bbox=${bboxQ}&${sceneQ}&viewport=${vpQ}&quality=full`, null, { abortPrevious: false, timeoutMs: 12000 });
  if (!payload) return null;
  dataState.latest.baitAdvanced = preferRenderableBaitAdvanced(payload, dataState.latest.baitAdvanced || null);
  console.info('[gfs bait advanced] refreshed', {
    reason,
    dataCame: Boolean(payload),
    polygons: Array.isArray(payload?.bait?.polygons) ? payload.bait.polygons.length : 0,
    outer: Array.isArray(payload?.bait?.outer_polygons) ? payload.bait.outer_polygons.length : 0,
    inner: Array.isArray(payload?.bait?.inner_polygons) ? payload.bait.inner_polygons.length : 0,
    core: Array.isArray(payload?.bait?.core_polygons) ? payload.bait.core_polygons.length : 0,
    baitScoreRows: Array.isArray(payload?.bait_score) ? payload.bait_score.length : 0,
    oceanPointRows: Array.isArray(payload?.ocean_points) ? payload.ocean_points.length : 0,
    status: payload?.bait?.status,
    source: payload?.bait?.source || payload?.source,
    mode: payload?.mode,
    sceneTier: payload?.scene_tier || payload?.scene_plan?.tier,
    renderBudget: payload?.render_budget || payload?.scene_plan?.render_budget,
  });
  pushLayerFrameWithBait(reason);
  return payload;
}
function installSteadyRefresh() {
  let dirty = true;
  let settleTimer = null;
  let lastRefreshAt = 0;

  const runSettledRefresh = (reason = 'camera_settled') => {
    if (!dirty) return;
    dirty = false;
    lastRefreshAt = Date.now();
    const vp = getCanonicalViewport();
    sendViewportPriority(reason);
    scheduleGlobeCacheWarm(vp, `viewport_${reason}`);
    scheduleCachePopRefreshes(vp, `viewport_${reason}`);
    // All settled camera/orbit updates are safe visual frames. The layer
    // renderers draw on `steady`; using camera_move here suppressed bait.
    refreshData('steady');
  };

  const scheduleSettledRefresh = (reason = 'camera_settled') => {
    dirty = true;
    if (settleTimer) clearTimeout(settleTimer);
    // Some Maps 3D builds do not emit gmp-steadystate reliably during orbit.
    // This timer keeps boats/clouds/bait tied to the visible camera after pan,
    // orbit, tilt, heading, and range changes.
    settleTimer = setTimeout(() => runSettledRefresh(reason), 300);
  };

  const onMove = () => scheduleSettledRefresh('camera_move');

  const onSteady = (ev) => {
    const isSteady = ev?.isSteady;
    if (typeof isSteady === 'boolean' && !isSteady) return;
    if (settleTimer) { clearTimeout(settleTimer); settleTimer = null; }
    runSettledRefresh('steady');
  };

  const events = ['gmp-centerchange', 'gmp-headingchange', 'gmp-rangechange', 'gmp-rollchange', 'gmp-tiltchange', 'gmp-camerapositionchange', 'centerchange', 'headingchange', 'rangechange', 'rollchange', 'tiltchange'];
  events.forEach((evt) => globeEl.addEventListener(evt, onMove));
  globeEl.addEventListener('gmp-steadystate', onSteady);
  globeEl.addEventListener('gmp-steadychange', onSteady);

  // First camera properties can land after the element upgrades; force a second
  // settled pass shortly after boot so the initial angled view and range are used.
  setTimeout(() => { if (Date.now() - lastRefreshAt > 500) scheduleSettledRefresh('initial_camera_sync'); }, 900);

  return () => {
    if (settleTimer) clearTimeout(settleTimer);
    events.forEach((evt) => globeEl.removeEventListener(evt, onMove));
    globeEl.removeEventListener('gmp-steadystate', onSteady);
    globeEl.removeEventListener('gmp-steadychange', onSteady);
  };
}

function createGfsSocket() {
  let ws = null;
  let reconnectTimer = null;
  let pingTimer = null;
  let watchdogTimer = null;
  let backoffMs = 1000;
  let manualClose = false;
  let connecting = false;
  let lastMessageAt = 0;

  const clearTimers = () => {
    if (reconnectTimer) clearTimeout(reconnectTimer);
    if (pingTimer) clearInterval(pingTimer);
    if (watchdogTimer) clearInterval(watchdogTimer);
    reconnectTimer = null;
    pingTimer = null;
    watchdogTimer = null;
  };

  const scheduleReconnect = () => {
    if (manualClose || reconnectTimer) return;
    reconnectTimer = setTimeout(() => {
      reconnectTimer = null;
      connect();
    }, backoffMs);
    backoffMs = Math.min(15000, backoffMs * 2);
  };

  const startHeartbeat = () => {
    lastMessageAt = Date.now();
    pingTimer = setInterval(() => {
      if (!ws || ws.readyState !== WebSocket.OPEN) return;
      try { ws.send(JSON.stringify({ type: 'ping' })); } catch (_) {}
    }, 20000);

    watchdogTimer = setInterval(() => {
      const stale = Date.now() - lastMessageAt > 30000;
      if (stale && ws && ws.readyState === WebSocket.OPEN) {
        try { ws.close(4000, 'inactivity timeout'); } catch (_) {}
      }
    }, 5000);
  };

  const handleMessage = (msg) => {
    if (!msg || typeof msg !== 'object') return;
    if (msg.type === 'viewport_ack') {
      if (GFS_DEBUG) console.debug('[gfs/ws] viewport prioritized', msg);
      return;
    }
    if (msg.type === 'tile_update') {
      console.info('[gfs/ws] tile update', { pill: msg.pill, tile_key: msg.tile_key, status: msg.status, features: Array.isArray(msg.features) ? msg.features.length : 0 });
      return;
    }
    if (msg.type === 'snapshot_changed' && msg.detail?.location_id) {
      if (selectedLocation && msg.detail.location_id === selectedLocation.id) {
        if (msg.detail.active) showLiveOverlay();
        else hideLiveOverlay();
      }
    }
  };

  const connect = () => {
    if (manualClose || connecting || (ws && ws.readyState === WebSocket.OPEN)) return;
    connecting = true;
    const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsPath = backoffMs > 4000 ? '/gfs/ws' : '/ws/gfs';
    ws = new WebSocket(`${proto}//${location.host}${wsPath}`);

    ws.onopen = () => {
      connecting = false;
      backoffMs = 1000;
      clearTimers();
      startHeartbeat();
      console.info('[gfs/ws] connected');
      try { sendViewportPriority('ws_open'); } catch (_) {}
    };
    ws.onmessage = (ev) => {
      lastMessageAt = Date.now();
      try { handleMessage(JSON.parse(ev.data)); } catch (_) {}
    };
    ws.onerror = (ev) => console.warn('[gfs/ws] socket error', { readyState: ws?.readyState, url: ws?.url || null });
    ws.onclose = () => {
      connecting = false;
      clearTimers();
      if (!manualClose) scheduleReconnect();
    };
  };

  const close = () => {
    manualClose = true;
    clearTimers();
    if (ws) {
      try { ws.close(1000, 'page unload'); } catch (_) {}
      ws = null;
    }
  };

  const sendViewport = (viewport, reason = 'steady') => {
    if (!ws || ws.readyState !== WebSocket.OPEN) return false;
    try {
      ws.send(JSON.stringify({
        type: 'viewport',
        bbox: sanitizeViewportForQuery(viewport || getCanonicalViewport()),
        zoom: null,
        reason,
        pills: ['bait', 'boats', 'clouds', 'rain', 'currents'],
      }));
      return true;
    } catch (_) { return false; }
  };

  return { connect, close, sendViewport };
}

const gfsSocket = createGfsSocket();

function sampleGrid(grid, bbox, lat, lon) {
  if (!bbox || !Array.isArray(grid) || !Array.isArray(grid[0])) return NaN;
  const arr = Array.isArray(grid[0][0]) ? grid[0] : grid;
  const ny = arr.length;
  const nx = Array.isArray(arr[0]) ? arr[0].length : 0;
  if (!ny || !nx) return NaN;
  const yi = Math.max(0, Math.min(ny - 1, Math.floor(((lat - bbox.south) / (bbox.north - bbox.south || 1)) * ny)));
  const xi = Math.max(0, Math.min(nx - 1, Math.floor(((lon - bbox.west) / (bbox.east - bbox.west || 1)) * nx)));
  return Number(arr[yi]?.[xi]);
}

function nearestOverlaySummary(loc) {
  const bbox = dataState.latest.bbox;
  const weather = dataState.latest.weather;
  const clouds = dataState.latest.clouds;
  const bait = dataState.latest.baitAdvanced || dataState.latest.baitBase;
  const lat = Number(loc?.lat);
  const lon = Number(loc?.lon);
  if (!bbox || !Number.isFinite(lat) || !Number.isFinite(lon)) return null;

  return {
    validTime: weather?.valid_time || clouds?.valid_time || bait?.valid_time || null,
    cloudCover: sampleGrid(weather?.fields?.cloud_total, bbox, lat, lon),
    rainRate: sampleGrid(weather?.fields?.precip_rate, bbox, lat, lon),
    lowCloud: sampleGrid(clouds?.cloud_layers?.find((layer) => layer?.name === 'low')?.density, bbox, lat, lon),
    baitOverall: Number(bait?.confidence?.overall ?? NaN),
  };
}

function sampleWeatherAt(lat, lon) {
  const bbox = dataState.latest.bbox;
  const weather = dataState.latest.weather;
  if (!bbox || !weather) return null;
  const windU = sampleGrid(weather?.fields?.wind_u, bbox, lat, lon);
  const windV = sampleGrid(weather?.fields?.wind_v, bbox, lat, lon);
  const tempK = sampleGrid(weather?.fields?.air_temp, bbox, lat, lon);
  const pressurePa = sampleGrid(weather?.fields?.pressure_msl, bbox, lat, lon);
  return {
    temperature_k: Number.isFinite(tempK) ? tempK : NaN,
    temperature_c: Number.isFinite(tempK) ? (tempK - 273.15) : NaN,
    temperature_f: Number.isFinite(tempK) ? (((tempK - 273.15) * 9) / 5) + 32 : NaN,
    pressure_pa: Number.isFinite(pressurePa) ? pressurePa : NaN,
    pressure_hpa: Number.isFinite(pressurePa) ? (pressurePa / 100) : NaN,
    wind_speed_mps: Number.isFinite(windU) && Number.isFinite(windV) ? Math.hypot(windU, windV) : NaN,
  };
}

function nearestBaitAt(lat, lon) {
  const bait = dataState.latest.baitAdvanced || dataState.latest.baitBase;
  const pts = Array.isArray(bait?.bait_score) ? bait.bait_score : [];
  if (!pts.length || !Number.isFinite(lat) || !Number.isFinite(lon)) return null;
  let best = null;
  let bestD2 = Infinity;
  for (const item of pts) {
    const plat = Number(item?.lat);
    const plon = Number(item?.lon);
    if (!Number.isFinite(plat) || !Number.isFinite(plon)) continue;
    const d2 = ((plat - lat) * (plat - lat)) + ((plon - lon) * (plon - lon));
    if (d2 < bestD2) {
      bestD2 = d2;
      best = item;
    }
  }
  return best;
}

const hud = createHud({
  root: document.getElementById('locationHud'),
  getOverlaySummary: nearestOverlaySummary,
  onSelectLocation: (loc) => {
    selectedLocation = loc;
    if (loc?.id) missingLiveLocationIds.delete(loc.id);
    gfsSocket.connect();
    refreshSelectedLiveState();
  },
  onStartLive: async (loc) => {
    activeLocation = loc;
    selectedLocation = loc;
    liveManuallyDismissed = false;
    showLiveOverlay();
    const refs = currentLiveOverlayRefs();
    await startLive({ locationId: loc.id, videoEl: refs.videoEl, overlayEl: refs.overlayEl });
    showStatus(`Live started: ${loc.name}`);
  },
  onStopLive: async (loc) => {
    await stopLive({
      locationId: loc.id,
      onBlob: async (blob) => {
        const f = new File([blob], `live-${Date.now()}.webm`, { type: 'video/webm' });
        await uploadSafe(`/gfs/api/location/${encodeURIComponent(loc.id)}/upload`, f, {}, null);
      },
    });
    hideLiveOverlay();
    showStatus(`Live stopped: ${loc.name}`);
    await hud.open(loc);
  },
});

function installHoverHud() {
  const handler = (ev) => {
    const d = ev?.detail || {};
    const lat = Number(d?.latLng?.lat ?? d?.position?.lat ?? d?.lat);
    const lon = Number(d?.latLng?.lng ?? d?.position?.lng ?? d?.lng);
    if (!Number.isFinite(lat) || !Number.isFinite(lon)) return;
    const sample = sampleWeatherAt(lat, lon);
    hud.updateHover({ lat, lon }, sample, nearestBaitAt(lat, lon));
    if (typeof window.updateHUD === 'function') {
      window.updateHUD(sample);
    }
  };
  globeEl.addEventListener('gmp-click', handler);
  globeEl.addEventListener('gmp-pointermove', handler);
  return () => {
    globeEl.removeEventListener('gmp-click', handler);
    globeEl.removeEventListener('gmp-pointermove', handler);
  };
}

window.addEventListener('beforeunload', () => {
  stopLivePolling();
  gfsSocket.close();
  if (dataState.activeAbort) {
    try { dataState.activeAbort.abort(); } catch (_) {}
  }
});

async function boot() {
  hideLiveOverlay();

  const ready = await ensureMaps3D(globeEl, fallbackEl);
  if (!ready.ok) {
    showStatus(`Globe unavailable (${ready.reason})`);
    return;
  }

  const { maps3d } = await libs();
  const payload = await getJsonSafe('/gfs/api/locations', { locations: [], items: [] }, { timeoutMs: 12000, abortPrevious: false });
  const locations = Array.isArray(payload?.locations)
    ? payload.locations
    : (Array.isArray(payload?.items) ? payload.items : []);
  console.info('[gfs boot] locations payload loaded', {
    count: locations.length,
    payloadCount: payload?.count,
    hasLocationsKey: Array.isArray(payload?.locations),
    hasItemsKey: Array.isArray(payload?.items),
    first: locations[0] ? { id: locations[0].id || locations[0].location_key, lat: locations[0].lat, lon: locations[0].lon, name: locations[0].name } : null,
  });
  const teardownMarkers = renderMarkers({ locations, globeEl, maps3d, onSelect: (loc) => { gfsSocket.connect(); hud.open(loc); } });
  // Boot order: CSV fish/orb markers first, then layer system enables
  // Jetstream -> Bait -> Boats -> Clouds -> Rain.
  initLayerSystem();
  if (!locations.length) {
    console.error('[gfs boot] no CSV fish locations were rendered; check /gfs/api/locations payload shape');
    showStatus('Ready, but 0 fish beacons loaded');
  }

  skyRuntime = startSkySystem({
    getViewport: getCanonicalViewport,
    getCameraAngles: parseCameraAngleSignature,
    getRangeMeters: parseRangeMeters,
    deferInitialMs: 6500,
  });
  const teardownSteady = installSteadyRefresh();
  const teardownHoverHud = installHoverHud();

  showStatus(`Ready • ${locations.length} fish beacons • opening fast cache`);
  refreshData('boot').catch((err) => console.info('[gfs boot] boot refresh skipped', { message: err?.message || String(err) }));
  window.setTimeout(() => scheduleGlobeCacheWarm(getCanonicalViewport(), 'website_load'), 2500);
  window.setTimeout(() => scheduleCachePopRefreshes(getCanonicalViewport(), 'website_load'), 3000);
  window.setInterval(() => {
    const vp = getCanonicalViewport();
    scheduleGlobeCacheWarm(vp, 'browser_5min_cache_pop');
    scheduleCachePopRefreshes(vp, 'browser_5min_cache_pop');
  }, 300000);
  // Extra cache-first pulls pick up the background-warmed frame/tiles without
  // blocking the initial UI. Keep these spaced out so cold GCP VMs do not thrash.
  window.setTimeout(() => refreshVisualPipeline(getCanonicalViewport(), 'post_warm_visual_25000').catch((err) => console.info('[gfs boot] post-warm visual skipped', { message: err?.message || String(err) })), 25000);
  window.setTimeout(() => refreshData('force').catch((err) => console.info('[gfs boot] second post-warm frame skipped', { message: err?.message || String(err) })), 65000);
  startLivePolling();

  window.addEventListener('beforeunload', teardownSteady, { once: true });
  window.addEventListener('beforeunload', teardownHoverHud, { once: true });
  window.addEventListener('beforeunload', () => skyRuntime?.teardown?.(), { once: true });
  window.addEventListener('beforeunload', teardownMarkers, { once: true });
}

boot().catch((e) => {
  showStatus(`Error: ${e.message}`);
  console.error(e);
});
