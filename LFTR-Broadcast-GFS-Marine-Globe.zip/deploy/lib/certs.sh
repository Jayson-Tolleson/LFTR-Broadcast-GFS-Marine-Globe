#!/usr/bin/env bash
set -euo pipefail

issue_tls_certificate_impl() {
  mkdir -p /var/www/certbot/.well-known/acme-challenge
  chown -R www-data:www-data /var/www/certbot || true

  local acme_conf="/etc/nginx/sites-available/broadcast-acme"
  cat > "$acme_conf" <<NGINX
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name ${DOMAIN};

    location /.well-known/acme-challenge/ {
        root /var/www/certbot;
        default_type "text/plain";
        try_files \$uri =404;
    }

    location / {
        return 200 "LFTR installer ACME HTTP endpoint is alive.\n";
        add_header Content-Type text/plain;
    }
}
NGINX

  rm -f /etc/nginx/sites-enabled/default \
        /etc/nginx/sites-enabled/broadcast \
        /etc/nginx/sites-enabled/broadcast.conf \
        /etc/nginx/sites-enabled/broadcast_stack \
        /etc/nginx/sites-enabled/broadcast-acme || true
  ln -sf "$acme_conf" /etc/nginx/sites-enabled/broadcast-acme
  nginx -t
  systemctl restart nginx

  certbot certonly \
    --webroot \
    -w /var/www/certbot \
    --preferred-challenges http \
    --agree-tos \
    --email "$CERTBOT_EMAIL" \
    -d "$DOMAIN" \
    --non-interactive || log_warn "certbot issuance failed (continuing)"

  if [[ -f "/etc/letsencrypt/live/${DOMAIN}/fullchain.pem" ]]; then
    log_ok "TLS certificate present for ${DOMAIN}"
  else
    log_warn "TLS certificate missing for ${DOMAIN}"
  fi

  certbot renew --dry-run || log_warn "certbot dry-run renewal failed"
}
