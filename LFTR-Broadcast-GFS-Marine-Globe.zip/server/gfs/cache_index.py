"""In-memory + on-disk metadata index for /gfs cache tiles."""
from __future__ import annotations

import asyncio
from collections import Counter, defaultdict
from typing import Any

from .cache_store import CacheStore, age_seconds, utc_now_iso

FRESH_TARGET_SEC = 300
STALE_AFTER_SEC = 900
EXPIRED_AFTER_SEC = 3600


def freshness_status(updated_at: str | None, failed: bool = False) -> str:
    if failed:
        return "failed"
    age = age_seconds(updated_at)
    if age is None:
        return "missing"
    if age <= FRESH_TARGET_SEC:
        return "fresh"
    if age <= STALE_AFTER_SEC:
        return "warm"
    if age <= EXPIRED_AFTER_SEC:
        return "stale"
    return "expired"


class CacheIndex:
    def __init__(self, store: CacheStore) -> None:
        self.store = store
        self.records: dict[str, dict[str, Any]] = {}
        self.loaded = False
        self._lock = asyncio.Lock()

    @property
    def index_path(self):
        return self.store.metadata_dir / "tile_status.json"

    async def load(self) -> None:
        await self.store.ensure_dirs()
        data = await self.store.read_json(self.index_path, default={})
        if isinstance(data, dict):
            self.records = data.get("records", data if "records" not in data else {}) or {}
        self.loaded = True

    async def save(self) -> None:
        payload = {"updated_at": utc_now_iso(), "records": self.records}
        await self.store.write_json_atomic(self.index_path, payload)

    async def update(self, key: str, record: dict[str, Any]) -> None:
        async with self._lock:
            existing = self.records.get(key, {})
            merged = {**existing, **record, "tile_key": key, "indexed_at": utc_now_iso()}
            merged["status"] = freshness_status(merged.get("updated_at"), bool(merged.get("error")))
            self.records[key] = merged
        await self.save()

    def get(self, key: str) -> dict[str, Any] | None:
        rec = self.records.get(key)
        if not rec:
            return None
        rec = dict(rec)
        rec["age_sec"] = age_seconds(rec.get("updated_at"))
        rec["status"] = freshness_status(rec.get("updated_at"), bool(rec.get("error")))
        return rec

    def status_counts(self) -> dict[str, int]:
        c = Counter()
        for rec in self.records.values():
            c[freshness_status(rec.get("updated_at"), bool(rec.get("error")))] += 1
        return dict(c)

    def by_pill_counts(self) -> dict[str, dict[str, int]]:
        out: dict[str, Counter] = defaultdict(Counter)
        for rec in self.records.values():
            pill = rec.get("pill", "unknown")
            out[pill][freshness_status(rec.get("updated_at"), bool(rec.get("error")))] += 1
        return {k: dict(v) for k, v in out.items()}

    def stale_or_missing(self, keys: list[str]) -> list[str]:
        out = []
        for key in keys:
            rec = self.get(key)
            if not rec or rec["status"] in {"missing", "stale", "expired", "failed"}:
                out.append(key)
        return out
