"""Atomic JSON cache store for LFTR /gfs tiles and frames."""
from __future__ import annotations

import asyncio
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .tile_key import safe_filename_for_key


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def parse_iso_z(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except Exception:
        return None


def age_seconds(updated_at: str | None) -> int | None:
    dt = parse_iso_z(updated_at)
    if not dt:
        return None
    return max(0, int((datetime.now(timezone.utc) - dt).total_seconds()))


class CacheStore:
    def __init__(self, root: str | os.PathLike[str] = ".cache/gfs_tiles") -> None:
        self.root = Path(root)
        self.tiles_dir = self.root / "tiles"
        self.frames_dir = self.root / "frames"
        self.metadata_dir = self.root / "metadata"
        self.failures_dir = self.root / "failures"
        self._lock = asyncio.Lock()

    async def ensure_dirs(self) -> None:
        for path in [self.tiles_dir, self.frames_dir, self.metadata_dir, self.failures_dir]:
            path.mkdir(parents=True, exist_ok=True)

    def _tile_path(self, source: str, key: str) -> Path:
        return self.tiles_dir / source / safe_filename_for_key(key)

    async def read_json(self, path: Path, default: Any = None) -> Any:
        try:
            text = await asyncio.to_thread(path.read_text, encoding="utf-8")
            return json.loads(text)
        except FileNotFoundError:
            return default
        except Exception:
            return default

    async def write_json_atomic(self, path: Path, data: Any) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + ".tmp")
        text = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
        async with self._lock:
            await asyncio.to_thread(tmp.write_text, text, encoding="utf-8")
            await asyncio.to_thread(os.replace, tmp, path)

    async def read_tile(self, source: str, key: str) -> dict[str, Any] | None:
        return await self.read_json(self._tile_path(source, key), default=None)

    async def write_tile(self, source: str, key: str, payload: dict[str, Any]) -> None:
        payload.setdefault("tile_key", key)
        payload.setdefault("source", source)
        payload.setdefault("updated_at", utc_now_iso())
        await self.write_json_atomic(self._tile_path(source, key), payload)

    async def read_frame(self, name: str) -> dict[str, Any] | None:
        return await self.read_json(self.frames_dir / f"{name}.json", default=None)

    async def write_frame(self, name: str, payload: dict[str, Any]) -> None:
        payload.setdefault("updated_at", utc_now_iso())
        await self.write_json_atomic(self.frames_dir / f"{name}.json", payload)

    async def append_failure(self, record: dict[str, Any]) -> None:
        record.setdefault("time", utc_now_iso())
        path = self.failures_dir / "provider_errors.jsonl"
        path.parent.mkdir(parents=True, exist_ok=True)
        line = json.dumps(record, ensure_ascii=False) + "\n"
        async with self._lock:
            await asyncio.to_thread(_append_text, path, line)


def _append_text(path: Path, line: str) -> None:
    with path.open("a", encoding="utf-8") as f:
        f.write(line)
