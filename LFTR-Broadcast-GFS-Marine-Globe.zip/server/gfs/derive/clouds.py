from __future__ import annotations

from typing import Any


def derive_cloud_layers(raw: dict[str, Any]) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    layers = [
        {
            "name": "low",
            "base_m": 500,
            "top_m": 2200,
            "sigma_bottom": 1.00,
            "sigma_top": 0.80,
            "density": raw.get("cloud_low", raw.get("Low_cloud_cover_low_cloud", [])),
        },
        {
            "name": "mid",
            "base_m": 2500,
            "top_m": 6000,
            "sigma_bottom": 0.80,
            "sigma_top": 0.45,
            "density": raw.get("cloud_mid", raw.get("Medium_cloud_cover_middle_cloud", [])),
        },
        {
            "name": "high",
            "base_m": 7000,
            "top_m": 12000,
            "sigma_bottom": 0.45,
            "sigma_top": 0.10,
            "density": raw.get("cloud_high", raw.get("High_cloud_cover_high_cloud", [])),
        },
    ]
    convective = {
        "reflectivity": raw.get("precip_rate", raw.get("Composite_reflectivity_entire_atmosphere", [])),
        "lift": [],
    }
    return layers, convective
