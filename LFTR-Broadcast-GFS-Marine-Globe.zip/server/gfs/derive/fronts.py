"""Frontal-analysis namespace.

Real SST front-line derivation lives in :mod:`server.gfs.derive.bait`; this
module is kept as an import-safe namespace for future split-out helpers.
"""

__all__: list[str] = []
