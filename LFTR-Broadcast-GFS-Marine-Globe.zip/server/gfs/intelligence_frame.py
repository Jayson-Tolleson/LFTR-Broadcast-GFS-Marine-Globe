"""Build cache-first /gfs API frames from cached tiles."""
from __future__ import annotations

from collections import defaultdict
from typing import Any

from .cache_index import CacheIndex
from .cache_store import CacheStore, age_seconds, utc_now_iso
from .tile_grid import tiles_for_bbox
from .tile_key import expand_bbox, make_tile_key, parse_bbox
from .tile_scheduler import DEFAULT_PILLS, SOURCE_BY_PILL, TileScheduler


class IntelligenceFrameBuilder:
    def __init__(self, store: CacheStore, index: CacheIndex, scheduler: TileScheduler, pad_factor: float = 2.0) -> None:
        self.store = store
        self.index = index
        self.scheduler = scheduler
        self.pad_factor = pad_factor

    async def build_frame(
        self,
        viewport_bbox_like: str | dict[str, float],
        pills: list[str] | None = None,
        zoom: int | None = None,
        reason: str = "api_frame",
    ) -> dict[str, Any]:
        viewport_bbox = parse_bbox(viewport_bbox_like)
        cache_bbox = expand_bbox(viewport_bbox, factor=self.pad_factor)
        pills = pills or DEFAULT_PILLS
        tiles = tiles_for_bbox(cache_bbox, z=zoom, target_tiles=24)
        pill_payload: dict[str, dict[str, Any]] = {}
        status_counts = defaultdict(int)
        max_age = 0

        for pill in pills:
            source = SOURCE_BY_PILL.get(pill, "gfs")
            features = []
            tile_records = []
            for tile in tiles:
                key = make_tile_key(source, pill, "latest", tile.z, tile.x, tile.y, "full")
                rec = self.index.get(key)
                if not rec:
                    status_counts["missing"] += 1
                    tile_records.append({"tile_key": key, "status": "missing", "bbox": tile.bbox.as_dict()})
                    continue
                status = rec.get("status", "missing")
                status_counts[status] += 1
                age = rec.get("age_sec")
                if age is not None:
                    max_age = max(max_age, int(age))
                tile_payload = await self.store.read_tile(source, key)
                if tile_payload:
                    features.extend(tile_payload.get("features", []))
                tile_records.append({
                    "tile_key": key,
                    "status": status,
                    "age_sec": age,
                    "bbox": tile.bbox.as_dict(),
                    "feature_count": rec.get("feature_count", 0),
                })

            if features:
                pill_status = "fresh" if all(t.get("status") == "fresh" for t in tile_records) else "partial"
            elif any(t.get("status") in {"fresh", "warm", "stale"} for t in tile_records):
                pill_status = "partial"
            else:
                pill_status = "queued"
            pill_payload[pill] = {"status": pill_status, "features": features, "tiles": tile_records}

        await self.scheduler.prioritize_viewport(viewport_bbox.as_dict(), pills=pills, priority=0, reason=reason, zoom=zoom)

        ready = status_counts["fresh"] + status_counts["warm"] + status_counts["stale"]
        total = sum(status_counts.values()) or len(tiles) * len(pills)
        overall = "hot_cache" if ready else "queued"
        if ready and ready < total:
            overall = "partial"

        return {
            "status": overall,
            "source": "cache",
            "server_time": utc_now_iso(),
            "max_age_sec": max_age,
            "viewport_bbox": viewport_bbox.as_dict(),
            "cache_bbox": cache_bbox.as_dict(),
            "bounds_policy": {"mode": "padded_viewport", "factor": self.pad_factor},
            "tiles": {
                "total": total,
                "ready": ready,
                "fresh": status_counts["fresh"],
                "warm": status_counts["warm"],
                "stale": status_counts["stale"],
                "expired": status_counts["expired"],
                "missing": status_counts["missing"],
                "failed": status_counts["failed"],
                "queued": status_counts["missing"] + status_counts["expired"] + status_counts["failed"],
            },
            "pills": pill_payload,
        }
