from __future__ import annotations

import asyncio
import logging
import math
from pathlib import Path
from typing import Any, Callable

from quart import Blueprint, current_app, jsonify, request, websocket

from server.gfs_service import GFSService
from server.gfs.sky import sky_payload

log = logging.getLogger("server.gfs.routes")


def _parse_bbox() -> dict[str, float] | None:
    raw = (request.args.get("bbox") or "").strip()
    if not raw:
        return None
    try:
        west, south, east, north = [float(x.strip()) for x in raw.split(",")[:4]]
        return {"west": west, "south": south, "east": east, "north": north}
    except Exception:
        return None


def _parse_visible_bbox() -> dict[str, float] | None:
    raw = (request.args.get("visible_bbox") or request.args.get("visibleBbox") or "").strip()
    if raw:
        try:
            west, south, east, north = [float(x.strip()) for x in raw.split(",")[:4]]
            return {"west": west, "south": south, "east": east, "north": north}
        except Exception:
            pass
    vp = (request.args.get("viewport") or "").strip()
    if vp:
        try:
            import json
            data = json.loads(vp)
            vb = data.get("visibleBbox") or data.get("visible_bbox")
            if isinstance(vb, dict):
                return {"west": float(vb["west"]), "south": float(vb["south"]), "east": float(vb["east"]), "north": float(vb["north"])}
            return {"west": float(data["west"]), "south": float(data["south"]), "east": float(data["east"]), "north": float(data["north"])}
        except Exception:
            return None
    return None


def _svc(static_dir: Path) -> GFSService:
    svc = current_app.extensions.get("gfs_service")
    if svc is None:
        svc = GFSService(str(static_dir))
        current_app.extensions["gfs_service"] = svc
    return svc


async def _call_sync(fn: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
    return await asyncio.to_thread(fn, *args, **kwargs)


def _json_clean(value: Any, depth: int = 0) -> Any:
    """Return a JSON-safe object so endpoint errors do not become nginx 502s.

    This intentionally accepts numpy scalars/arrays, NaN/Inf, Path objects, sets,
    and other accidental provider objects that can leak out of NCSS/netCDF paths.
    """
    if depth > 32:
        return str(value)
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    # numpy scalar/array compatibility without importing numpy.
    if hasattr(value, "item"):
        try:
            return _json_clean(value.item(), depth + 1)
        except Exception:
            pass
    if hasattr(value, "tolist"):
        try:
            return _json_clean(value.tolist(), depth + 1)
        except Exception:
            pass
    if isinstance(value, dict):
        out: dict[str, Any] = {}
        for k, v in value.items():
            try:
                key = str(k)
            except Exception:
                key = repr(k)
            out[key] = _json_clean(v, depth + 1)
        return out
    if isinstance(value, (list, tuple, set)):
        return [_json_clean(v, depth + 1) for v in value]
    try:
        return str(value)
    except Exception:
        return repr(value)


def _json(payload: Any, status: int = 200):
    return jsonify(_json_clean(payload)), status


def _endpoint_shell(endpoint: str, exc: Exception, bbox: dict[str, float] | None = None) -> dict[str, Any]:
    return {
        "ok": False,
        "endpoint": endpoint,
        "source": f"{endpoint.strip('/').replace('/', '_')}_error_caught",
        "payload_state": "provider_failed",
        "bbox": bbox,
        "error": str(exc),
        "note": "Endpoint caught exception and returned JSON status 200 so the browser does not see GET non-ok/502.",
    }


def create_gfs_blueprint(static_dir: Path) -> Blueprint:
    bp = Blueprint("gfs", __name__)

    @bp.get("/gfs")
    async def gfs_page():
        from quart import send_file
        return await send_file(str(static_dir / "indexgfs.html"))

    @bp.get("/gfs/api/health")
    async def health():
        return jsonify(await _call_sync(_svc(static_dir).health_payload))

    @bp.get("/gfs/api/config")
    async def config():
        payload = await _call_sync(_svc(static_dir).config_payload)
        # Frontend currently opens /ws/gfs, so advertise that exact endpoint.
        if isinstance(payload, dict):
            payload["ws_base"] = "/ws/gfs"
        return jsonify(payload)

    @bp.get("/gfs/api/status")
    async def status():
        return jsonify(await _call_sync(_svc(static_dir).status_payload))

    @bp.get("/gfs/api/sky")
    async def sky():
        try:
            lat = float(request.args.get("lat", ""))
            lon = float(request.args.get("lon", ""))
        except Exception:
            return _json({
                "ok": False,
                "schema": "lftr_gfs_sky_v1",
                "error": "invalid_lat_lon",
                "note": "Provide numeric lat and lon query params."
            }, 400)
        if not (math.isfinite(lat) and math.isfinite(lon)) or abs(lat) > 90 or abs(lon) > 540:
            return _json({
                "ok": False,
                "schema": "lftr_gfs_sky_v1",
                "error": "invalid_lat_lon",
                "note": "lat must be -90..90 and lon should be a finite longitude."
            }, 400)
        payload = sky_payload(lat, lon)
        log.info("[gfs/sky] updated mode=%s sun=%.2f lat=%.3f lon=%.3f", payload.get("mode"), payload.get("sun_elevation_deg"), payload.get("lat"), payload.get("lon"))
        return _json(payload)

    @bp.get("/gfs/api/weather")
    async def weather():
        return jsonify(await _call_sync(_svc(static_dir).generate_weather_payload, _parse_bbox()))

    @bp.get("/gfs/api/clouds")
    async def clouds():
        bbox = _parse_bbox()
        try:
            payload = await _call_sync(_svc(static_dir).cloud_tiles_payload, bbox, _parse_visible_bbox())
            return _json(payload)
        except Exception as exc:
            log.exception("/gfs/api/clouds failed")
            shell = _endpoint_shell("/gfs/api/clouds", exc, bbox)
            shell.update({"items": [], "tiles": [], "cloud_regions": [], "precip_columns": [], "features": []})
            return _json(shell)

    @bp.get("/gfs/api/frame")
    async def frame():
        bbox = _parse_bbox()
        try:
            return _json(await _call_sync(_svc(static_dir).frame_payload, bbox, _parse_visible_bbox()))
        except Exception as exc:
            log.exception("/gfs/api/frame failed")
            shell = _endpoint_shell("/gfs/api/frame", exc, bbox)
            shell.update({"frame": {}, "weather": {}, "clouds": {"items": [], "tiles": [], "cloud_regions": [], "payload_state": "provider_failed"}})
            return _json(shell)

    @bp.get("/gfs/api/tile-plan")
    async def tile_plan():
        try:
            max_tiles = int(request.args.get("max_tiles") or request.args.get("limit") or 512)
        except Exception:
            max_tiles = 512
        return _json(await _call_sync(_svc(static_dir).tile_plan_payload, _parse_bbox(), max_tiles))

    @bp.get("/gfs/api/tiles")
    @bp.get("/gfs/api/tile-intel")
    async def tiles_intel():
        try:
            max_tiles = int(request.args.get("max_tiles") or request.args.get("limit") or 512)
        except Exception:
            max_tiles = 512
        try:
            return _json(await _call_sync(_svc(static_dir).tiles_intel_payload, _parse_bbox(), max_tiles, _parse_visible_bbox()))
        except Exception as exc:
            log.exception("/gfs/api/tiles failed")
            return _json({
                "ok": False,
                "schema": "lftr_scene_tiles_point_cache_v1_error_caught",
                "source": "tiles_endpoint_error_caught",
                "payload_state": "read_failed",
                "error": str(exc),
                "tiles": [],
                "count": 0,
                "note": "tiles endpoint caught exception and returned JSON status 200 instead of nginx/Quart 500",
            })

    @bp.get("/gfs/api/cache-warm")
    @bp.post("/gfs/api/cache-warm")
    async def cache_warm():
        try:
            max_tiles = int(request.args.get("max_tiles") or request.args.get("limit") or 512)
        except Exception:
            max_tiles = 512
        reason = (request.args.get("reason") or "website_load").strip() or "website_load"
        bbox = _parse_bbox()
        try:
            return _json(await _call_sync(_svc(static_dir).schedule_globe_cache_warm, bbox, max_tiles, reason, _parse_visible_bbox()))
        except Exception as exc:
            log.exception("/gfs/api/cache-warm failed")
            shell = _endpoint_shell("/gfs/api/cache-warm", exc, bbox)
            shell.update({"scheduled": False, "reason": "error_caught", "tiles": max_tiles, "warm": {"running": False, "error": str(exc)}})
            return _json(shell)

    @bp.get("/gfs/api/cache-warm/status")
    async def cache_warm_status():
        return _json(await _call_sync(_svc(static_dir).cache_warm_status_payload))

    @bp.get("/gfs/api/cache/status")
    async def cache_status():
        return _json(await _call_sync(_svc(static_dir).cache_status_payload))

    @bp.post("/gfs/api/cache/warm")
    async def cache_warm_post():
        body = await request.get_json(force=True, silent=True) or {}
        bbox = body.get("bbox") or _parse_bbox()
        try:
            max_tiles = int(body.get("max_tiles") or body.get("limit") or request.args.get("max_tiles") or 512)
        except Exception:
            max_tiles = 512
        reason = str(body.get("reason") or request.args.get("reason") or "manual_warm")
        return jsonify(await _call_sync(_svc(static_dir).schedule_globe_cache_warm, bbox, max_tiles, reason, _parse_visible_bbox()))

    @bp.get("/gfs/api/tile-intel/<tile_id>")
    async def one_tile_intel(tile_id: str):
        return jsonify(await _call_sync(_svc(static_dir).tile_intel_payload, tile_id, 300, _parse_visible_bbox()))

    @bp.get("/gfs/api/ocean")
    async def ocean():
        bbox = _parse_bbox()
        try:
            return _json(await _call_sync(_svc(static_dir).ocean_payload, bbox, _parse_visible_bbox()))
        except Exception as exc:
            log.exception("/gfs/api/ocean failed")
            shell = _endpoint_shell("/gfs/api/ocean", exc, bbox)
            shell.update({"points": [], "boats": [], "items": []})
            return _json(shell)

    @bp.get("/gfs/api/ocean-points")
    async def ocean_points():
        lod = (request.args.get("lod") or "auto").strip() or "auto"
        bbox = _parse_bbox()
        try:
            return _json(await _call_sync(_svc(static_dir).ocean_points_payload, bbox, lod, _parse_visible_bbox()))
        except Exception as exc:
            log.exception("/gfs/api/ocean-points failed")
            shell = _endpoint_shell("/gfs/api/ocean-points", exc, bbox)
            shell.update({"points": [], "items": [], "grid": {"real_grid": False, "reason": "error_caught"}})
            return _json(shell)

    @bp.get("/gfs/api/boats")
    async def boats():
        bbox = _parse_bbox()
        try:
            return _json(await _call_sync(_svc(static_dir).boats_payload, bbox, _parse_visible_bbox()))
        except Exception as exc:
            log.exception("/gfs/api/boats failed")
            shell = _endpoint_shell("/gfs/api/boats", exc, bbox)
            shell.update({"boats": [], "items": [], "count": 0})
            return _json(shell)

    @bp.get("/gfs/api/lightning")
    async def lightning():
        try:
            minutes = int(request.args.get("minutes") or request.args.get("window_minutes") or 20)
        except Exception:
            minutes = 20
        bbox = _parse_bbox()
        try:
            return _json(await _call_sync(_svc(static_dir).lightning_payload, bbox, _parse_visible_bbox(), minutes))
        except Exception as exc:
            log.exception("/gfs/api/lightning failed")
            shell = _endpoint_shell("/gfs/api/lightning", exc, bbox)
            shell.update({"schema": "lftr_lightning_v1", "flashes": [], "items": [], "regions": [], "fallback_used": False})
            return _json(shell)

    @bp.get("/gfs/api/scene")
    async def scene():
        return jsonify(await _call_sync(_svc(static_dir).get_scene_payload, _parse_bbox()))

    @bp.get("/gfs/api/hazards")
    async def hazards():
        return jsonify(await _call_sync(_svc(static_dir).hazards_payload))

    @bp.get("/gfs/api/diagnostics")
    async def diagnostics():
        return jsonify(await _call_sync(_svc(static_dir).diagnostics_payload))

    @bp.get("/gfs/api/fish")
    async def fish():
        return jsonify(await _call_sync(_svc(static_dir).fish_payload))

    @bp.get("/gfs/api/sources")
    @bp.get("/gfs/api/source-diagnostics")
    async def sources():
        return jsonify(await _call_sync(_svc(static_dir).source_diagnostics_payload, _parse_bbox()))

    @bp.get("/gfs/api/locations")
    async def locations():
        payload = await _call_sync(_svc(static_dir).fish_payload)
        # Compatibility: some UI callers expect `locations`, while
        # the service payload returns `items`. Keep both keys during cleanup.
        if isinstance(payload, dict):
            items = payload.get("items")
            if isinstance(items, list) and not isinstance(payload.get("locations"), list):
                payload["locations"] = items
        return jsonify(payload)

    @bp.get("/gfs/api/source-check")
    async def source_check():
        svc = _svc(static_dir)
        return jsonify(await _call_sync(svc.validate_bbox_real_fields, _parse_bbox()))

    @bp.get("/gfs/api/payload-debug")
    @bp.get("/gfs/api/provider-debug")
    async def payload_debug():
        svc = _svc(static_dir)
        bbox = _parse_bbox()
        # Do not let provider-debug default to the whole globe.  HYCOM's NCSS
        # request grid uses 0..360 longitude and full-world bboxes are slow and
        # easy to turn into invalid west==east constraints.  Use the same SoCal
        # startup bbox unless a bbox query param is supplied.
        if bbox is None:
            bbox = {"west": -126.0, "south": 29.0, "east": -114.0, "north": 39.0}
        try:
            deep = str(request.args.get("deep") or "0").lower() in {"1", "true", "yes"}
            if deep:
                payload = await _call_sync(svc.payload_debug_payload, bbox)
            else:
                payload = {
                    "ok": True,
                    "endpoint": request.path,
                    "mode": "cheap_debug_status_no_provider_fetch",
                    "bbox": bbox,
                    "cache_warm": await _call_sync(svc.cache_warm_status_payload),
                    "cache_status": await _call_sync(svc.cache_status_payload),
                    "note": "Use ?deep=1 for heavy provider checks. Default is cheap so debug cannot stall page load.",
                }
        except Exception as exc:
            log.exception("/gfs/api/provider-debug failed")
            payload = {
                "ok": False,
                "endpoint": request.path,
                "error": str(exc),
                "bbox": bbox,
                "note": "provider-debug caught an exception and returned JSON status 200 instead of HTTP 500",
            }
        return _json(payload)

    @bp.get("/gfs/api/bait")
    @bp.get("/gfs/api/bait-advanced")
    @bp.get("/gfs/api/bait/advanced")
    async def bait():
        bbox = _parse_bbox()
        try:
            return _json(await _call_sync(_svc(static_dir).bait_advanced_payload, bbox, _parse_visible_bbox()))
        except Exception as exc:
            log.exception("/gfs/api/bait-advanced failed")
            shell = _endpoint_shell("/gfs/api/bait-advanced", exc, bbox)
            shell.update({"bait": {"polygons": [], "bait_score": []}, "bait_score": [], "polygons": []})
            return _json(shell)

    @bp.get("/gfs/api/location/<location_id>")
    async def location_detail(location_id: str):
        return jsonify(await _call_sync(_svc(static_dir).location_payload, location_id))

    @bp.get("/gfs/api/intelligence/node/<node_id>")
    @bp.get("/gfs/api/location/<node_id>/intelligence")
    async def node_intelligence(node_id: str):
        svc = _svc(static_dir)
        payload = await _call_sync(svc.node_intelligence_payload, node_id)
        return jsonify(payload)

    @bp.get("/gfs/api/location/<location_id>/live-intel")
    async def location_live_intel(location_id: str):
        return jsonify(await _call_sync(_svc(static_dir).location_live_intel_payload, location_id))

    @bp.get("/gfs/api/location/<location_id>/environment")
    @bp.get("/gfs/api/location/<location_id>/weather")
    async def location_environment(location_id: str):
        return jsonify(await _call_sync(_svc(static_dir).location_environment_payload, location_id))

    @bp.get("/gfs/api/location/<location_id>/media")
    @bp.get("/gfs/api/location/<location_id>/videos")
    @bp.get("/gfs/api/location/<location_id>/live")
    async def location_media(location_id: str):
        return jsonify(await _call_sync(_svc(static_dir).location_media, location_id))

    @bp.post("/gfs/api/location/<location_id>/report")
    @bp.post("/gfs/api/location/<location_id>/reports")
    async def location_report(location_id: str):
        body = await request.get_json(force=True, silent=True) or {}
        text = str(body.get("report_text") or body.get("text") or "")
        return jsonify(await _call_sync(_svc(static_dir).upsert_report, location_id, text))

    @bp.post("/gfs/api/location/<location_id>/live")
    async def location_live_update(location_id: str):
        body = await request.get_json(force=True, silent=True) or {}
        active = bool(body.get("active"))
        stream_url = str(body.get("stream_url") or body.get("url") or "")
        return jsonify(await _call_sync(_svc(static_dir).upsert_live, location_id, active, stream_url))

    @bp.post("/gfs/api/location/<location_id>/upload")
    async def location_upload(location_id: str):
        files = await request.files
        f = files.get("file")
        if not f:
            return jsonify({"ok": False, "error": "file required"}), 400
        raw = f.read()
        if asyncio.iscoroutine(raw):
            raw = await raw
        return jsonify(await _call_sync(_svc(static_dir).save_upload_video, location_id, f.filename or "upload.mp4", raw))

    @bp.get("/gfs/api/tile/<layer>/<int:z>/<int:x>/<int:y>.json")
    async def tile_json(layer: str, z: int, x: int, y: int):
        return jsonify(await _call_sync(_svc(static_dir).tile_layer_payload, layer, z, x, y))

    @bp.websocket("/ws/gfs")
    async def ws_gfs():
        ws = websocket._get_current_object()
        try:
            await ws.send_json({"type": "connected", "service": "gfs", "mode": "nonblocking_cache_first_ws"})
        except Exception:
            return
        while True:
            try:
                raw = await websocket.receive()
            except Exception:
                break
            try:
                import json as _json
                msg = _json.loads(raw) if isinstance(raw, str) else (raw or {})
            except Exception:
                try:
                    await ws.send_json({"type": "ignored", "reason": "bad_json"})
                except Exception:
                    break
                continue
            kind = (msg or {}).get("type") or "ping"
            if kind == "ping":
                try:
                    await ws.send_json({"type": "pong", "ts": int(asyncio.get_event_loop().time() * 1000)})
                except Exception:
                    break
            elif kind == "viewport" and isinstance((msg or {}).get("bbox"), dict):
                try:
                    bbox = (msg or {}).get("bbox")
                    reason = str((msg or {}).get("reason") or "steady")
                    svc = _svc(static_dir)
                    ack = await _call_sync(svc.note_viewport_priority, bbox, reason)
                    # Websocket viewport notes must stay cheap.  Do not launch large
                    # live tile warm jobs from the websocket path; the HTTP cache-warm
                    # scheduler handles that and dedupes already-running jobs.
                    await ws.send_json({"type": "viewport_ack", "cache_warm_started": False, **ack})
                except Exception as exc:
                    log.exception("gfs websocket viewport priority failed")
                    try:
                        await ws.send_json({"type": "error", "message": str(exc)})
                    except Exception:
                        break
            elif kind in {"snapshot", "get_snapshot", "subscribe"}:
                try:
                    payload = await _call_sync(_svc(static_dir).ws_snapshot)
                    if asyncio.iscoroutine(payload):
                        payload = await payload
                    await ws.send_json(payload)
                except Exception as exc:
                    log.exception("gfs websocket snapshot failed")
                    try:
                        await ws.send_json({"type": "error", "message": str(exc)})
                    except Exception:
                        break
            else:
                try:
                    await ws.send_json({"type": "ignored", "reason": "unknown_type", "kind": kind})
                except Exception:
                    break

    @bp.websocket("/gfs/ws")
    @bp.websocket("/gfs/ws/")
    async def ws_gfs_alias():
        await ws_gfs()

    return bp
