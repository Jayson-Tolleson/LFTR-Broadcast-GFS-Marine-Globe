"""Adapter from cache tile jobs to the existing synchronous GFSService payloads."""
from __future__ import annotations
import asyncio
from typing import Any
from .cache_store import utc_now_iso
from .tile_queue import TileJob

def _features_from_payload(pill: str, payload: dict[str, Any]) -> list[Any]:
    if not isinstance(payload, dict): return []
    if pill == "boats": return payload.get("boats") or []
    if pill == "bait":
        bait = payload.get("bait") or {}
        return bait.get("polygons") or payload.get("polygons") or payload.get("features") or []
    if pill in {"clouds", "rain"}:
        if pill == "rain": return payload.get("precip_columns") or (payload.get("rain") or {}).get("items") or []
        return payload.get("items") or payload.get("features") or (payload.get("scene") or {}).get("clouds") or []
    if pill in {"currents", "current"}:
        return payload.get("points") or (payload.get("currentZones") or {}).get("polygons") or []
    return payload.get("features") or []

def make_service_fetcher(service):
    async def fetch(job: TileJob) -> dict[str, Any]:
        bbox = dict(job.bbox or {})
        def call():
            if job.pill == "boats": return service.boats_payload(bbox)
            if job.pill == "bait": return service.bait_advanced_payload(bbox)
            if job.pill in {"clouds", "rain"}: return service.cloud_tiles_payload(bbox)
            if job.pill in {"currents", "current"}: return service.ocean_points_payload(bbox, "auto")
            return service.frame_payload(bbox)
        payload = await asyncio.to_thread(call)
        features = _features_from_payload(job.pill, payload if isinstance(payload, dict) else {})
        return {"tile_key": job.tile_key, "source": job.source, "pill": job.pill, "cycle": job.cycle, "z": job.z, "x": job.x, "y": job.y, "bbox": bbox, "features": features, "feature_count": len(features), "payload": payload, "status": "fresh", "updated_at": utc_now_iso(), "provider_debug": {"adapter": "existing_GFSService", "method_pill": job.pill}}
    return fetch
