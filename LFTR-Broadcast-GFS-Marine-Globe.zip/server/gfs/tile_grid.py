"""Small Web-Mercator tile helpers for cache selection."""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Iterable

from .tile_key import BBox, bbox_width_degrees, normalize_lon, parse_bbox


@dataclass(frozen=True)
class Tile:
    z: int
    x: int
    y: int
    bbox: BBox


def lonlat_to_tile(lon: float, lat: float, z: int) -> tuple[int, int]:
    lat = max(-85.05112878, min(85.05112878, lat))
    lon = normalize_lon(lon)
    n = 2 ** z
    x = int((lon + 180.0) / 360.0 * n)
    lat_rad = math.radians(lat)
    y = int((1.0 - math.asinh(math.tan(lat_rad)) / math.pi) / 2.0 * n)
    return max(0, min(n - 1, x)), max(0, min(n - 1, y))


def tile_to_bbox(z: int, x: int, y: int) -> BBox:
    n = 2 ** z
    west = x / n * 360.0 - 180.0
    east = (x + 1) / n * 360.0 - 180.0

    def tile_y_to_lat(tile_y: int) -> float:
        rad = math.atan(math.sinh(math.pi * (1 - 2 * tile_y / n)))
        return math.degrees(rad)

    north = tile_y_to_lat(y)
    south = tile_y_to_lat(y + 1)
    return BBox(west=west, south=south, east=east, north=north)


def effective_zoom_for_bbox(bbox_like, target_tiles: int = 24, min_z: int = 3, max_z: int = 9) -> int:
    bbox = parse_bbox(bbox_like)
    width = max(0.05, bbox_width_degrees(bbox))
    height = max(0.05, bbox.north - bbox.south)
    area = width * height
    for z in range(min_z, max_z + 1):
        tile_deg = 360.0 / (2 ** z)
        rough_count = max(1.0, area / (tile_deg * tile_deg))
        if rough_count >= target_tiles:
            return z
    return max_z


def _segments_for_dateline(bbox: BBox) -> list[tuple[float, float]]:
    if bbox.east >= bbox.west:
        return [(bbox.west, bbox.east)]
    return [(bbox.west, 180.0), (-180.0, bbox.east)]


def tiles_for_bbox(bbox_like, z: int | None = None, target_tiles: int = 24) -> list[Tile]:
    bbox = parse_bbox(bbox_like)
    if z is None:
        z = effective_zoom_for_bbox(bbox, target_tiles=target_tiles)
    n = 2 ** z
    out: dict[tuple[int, int, int], Tile] = {}
    for west, east in _segments_for_dateline(bbox):
        x0, y0 = lonlat_to_tile(west, bbox.north, z)
        x1, y1 = lonlat_to_tile(east, bbox.south, z)
        if east == 180.0:
            x1 = n - 1
        for x in range(min(x0, x1), max(x0, x1) + 1):
            for y in range(min(y0, y1), max(y0, y1) + 1):
                key = (z, x, y)
                out[key] = Tile(z=z, x=x, y=y, bbox=tile_to_bbox(z, x, y))
    return list(out.values())
