"""Stable tile/cache keys and bbox utilities for LFTR /gfs.

All public functions are dependency-light so they can be safely reused by
providers, API routes, websocket handlers, and tests.
"""
from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha1
from typing import Any, Mapping


@dataclass(frozen=True)
class BBox:
    west: float
    south: float
    east: float
    north: float

    def as_dict(self) -> dict[str, float]:
        return {
            "west": self.west,
            "south": self.south,
            "east": self.east,
            "north": self.north,
        }


def normalize_lon(lon: float) -> float:
    """Normalize longitude into [-180, 180)."""
    value = ((float(lon) + 180.0) % 360.0) - 180.0
    if value == -180.0:
        return 180.0
    return value


def clamp_lat(lat: float) -> float:
    return max(-90.0, min(90.0, float(lat)))


def parse_bbox(value: str | Mapping[str, Any] | BBox) -> BBox:
    if isinstance(value, BBox):
        return value
    if isinstance(value, str):
        parts = [float(p.strip()) for p in value.split(",")]
        if len(parts) != 4:
            raise ValueError("bbox string must be west,south,east,north")
        west, south, east, north = parts
    else:
        west = float(value["west"])
        south = float(value["south"])
        east = float(value["east"])
        north = float(value["north"])

    south = clamp_lat(south)
    north = clamp_lat(north)
    if south >= north:
        raise ValueError(f"invalid bbox latitude range: {south} >= {north}")

    west = normalize_lon(west)
    east = normalize_lon(east)
    return BBox(west=west, south=south, east=east, north=north)


def bbox_width_degrees(bbox: BBox) -> float:
    if bbox.east >= bbox.west:
        return bbox.east - bbox.west
    return (180.0 - bbox.west) + (bbox.east + 180.0)


def bbox_center_lon(bbox: BBox) -> float:
    width = bbox_width_degrees(bbox)
    return normalize_lon(bbox.west + width / 2.0)


def expand_bbox(bbox_like: str | Mapping[str, Any] | BBox, factor: float = 2.0) -> BBox:
    """Expand a bbox around its center.

    Used for anti-clipping globe polygon bounds. The viewport bbox remains the
    precise visible area; the expanded bbox is used for cache/provider/polygon
    generation so contours have data beyond the screen edge.
    """
    bbox = parse_bbox(bbox_like)
    factor = max(1.0, float(factor))
    width = bbox_width_degrees(bbox)
    height = bbox.north - bbox.south
    cx = bbox_center_lon(bbox)
    cy = (bbox.south + bbox.north) / 2.0
    new_width = min(360.0, width * factor)
    new_height = min(180.0, height * factor)
    west = normalize_lon(cx - new_width / 2.0)
    east = normalize_lon(cx + new_width / 2.0)
    south = clamp_lat(cy - new_height / 2.0)
    north = clamp_lat(cy + new_height / 2.0)
    return BBox(west=west, south=south, east=east, north=north)


def bbox_token(bbox: BBox, precision: int = 4) -> str:
    return (
        f"w{bbox.west:.{precision}f}_s{bbox.south:.{precision}f}_"
        f"e{bbox.east:.{precision}f}_n{bbox.north:.{precision}f}"
    ).replace("-", "m").replace(".", "p")


def make_tile_key(
    source: str,
    pill: str,
    cycle: str,
    z: int,
    x: int,
    y: int,
    quality: str = "full",
) -> str:
    return f"{source}:{pill}:{cycle}:z{int(z)}:x{int(x)}:y{int(y)}:{quality}"


def make_bbox_key(source: str, pill: str, cycle: str, bbox: BBox, resolution: str = "auto") -> str:
    digest = sha1(bbox_token(bbox).encode("utf-8")).hexdigest()[:12]
    return f"{source}:{pill}:{cycle}:bbox:{digest}:res_{resolution}"


def safe_filename_for_key(key: str) -> str:
    return key.replace(":", "__").replace("/", "_") + ".json"
