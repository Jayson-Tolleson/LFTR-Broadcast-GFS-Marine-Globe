"""Dedupe priority queue for /gfs tile refresh jobs."""
from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from itertools import count
from typing import Any


_counter = count()


@dataclass(order=True)
class TileJob:
    priority: int
    seq: int = field(default_factory=lambda: next(_counter), compare=True)
    tile_key: str = field(default="", compare=False)
    source: str = field(default="", compare=False)
    pill: str = field(default="", compare=False)
    cycle: str = field(default="latest", compare=False)
    z: int = field(default=0, compare=False)
    x: int = field(default=0, compare=False)
    y: int = field(default=0, compare=False)
    bbox: dict[str, float] = field(default_factory=dict, compare=False)
    reason: str = field(default="unknown", compare=False)
    extra: dict[str, Any] = field(default_factory=dict, compare=False)


class TileQueue:
    def __init__(self) -> None:
        self._queue: asyncio.PriorityQueue[TileJob] = asyncio.PriorityQueue()
        self._pending: dict[str, TileJob] = {}
        self._active: set[str] = set()
        self._lock = asyncio.Lock()

    async def put(self, job: TileJob) -> bool:
        async with self._lock:
            if job.tile_key in self._pending or job.tile_key in self._active:
                old = self._pending.get(job.tile_key)
                if old and job.priority < old.priority:
                    old.priority = job.priority
                    old.reason = job.reason
                return False
            self._pending[job.tile_key] = job
            await self._queue.put(job)
            return True

    async def put_many(self, jobs: list[TileJob]) -> tuple[int, int]:
        queued = 0
        deduped = 0
        for job in jobs:
            if await self.put(job):
                queued += 1
            else:
                deduped += 1
        return queued, deduped

    async def get(self) -> TileJob:
        while True:
            job = await self._queue.get()
            async with self._lock:
                current = self._pending.pop(job.tile_key, None)
                if current is not job:
                    continue
                self._active.add(job.tile_key)
                return job

    async def done(self, job: TileJob) -> None:
        async with self._lock:
            self._active.discard(job.tile_key)
        self._queue.task_done()

    def stats(self) -> dict[str, int]:
        return {"pending": len(self._pending), "active": len(self._active)}
