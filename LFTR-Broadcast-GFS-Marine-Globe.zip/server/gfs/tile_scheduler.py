"""Always-on viewport-prioritized cache scheduler for /gfs."""
from __future__ import annotations

import asyncio
from typing import Any

from .cache_index import CacheIndex
from .tile_grid import tiles_for_bbox
from .tile_key import BBox, expand_bbox, make_tile_key, parse_bbox
from .tile_queue import TileJob, TileQueue
from .ws_updates import GFSUpdateHub

DEFAULT_PILLS = ["bait", "boats", "clouds", "rain", "currents"]
SOURCE_BY_PILL = {
    "clouds": "gfs",
    "rain": "gfs",
    "currents": "hycom",
    "bait": "rtofs",
    "boats": "ndbc",
}


class TileScheduler:
    def __init__(
        self,
        queue: TileQueue,
        index: CacheIndex,
        hub: GFSUpdateHub,
        pad_factor: float = 2.0,
    ) -> None:
        self.queue = queue
        self.index = index
        self.hub = hub
        self.pad_factor = pad_factor
        self.running = False
        self.task: asyncio.Task | None = None
        self.last_tick: str | None = None
        self.recent_viewports: list[dict[str, Any]] = []

    async def start(self) -> None:
        if self.running:
            return
        self.running = True
        self.task = asyncio.create_task(self._loop(), name="gfs-tile-scheduler")

    async def stop(self) -> None:
        self.running = False
        if self.task:
            self.task.cancel()
            await asyncio.gather(self.task, return_exceptions=True)
            self.task = None

    async def prioritize_viewport(
        self,
        viewport_bbox: dict[str, float] | str,
        pills: list[str] | None = None,
        priority: int = 0,
        reason: str = "viewport",
        zoom: int | None = None,
    ) -> dict[str, Any]:
        viewport = parse_bbox(viewport_bbox)
        cache_bbox = expand_bbox(viewport, factor=self.pad_factor)
        jobs = self._jobs_for_bbox(cache_bbox, pills or DEFAULT_PILLS, priority, reason, zoom=zoom)
        queued, deduped = await self.queue.put_many(jobs)
        record = {
            "viewport_bbox": viewport.as_dict(),
            "cache_bbox": cache_bbox.as_dict(),
            "pills": pills or DEFAULT_PILLS,
            "priority": priority,
            "reason": reason,
            "queued": queued,
            "deduped": deduped,
        }
        self.recent_viewports = [record] + self.recent_viewports[:24]
        return record

    def _jobs_for_bbox(self, bbox: BBox, pills: list[str], priority: int, reason: str, zoom: int | None = None) -> list[TileJob]:
        tiles = tiles_for_bbox(bbox, z=zoom, target_tiles=24)
        jobs: list[TileJob] = []
        cycle = "latest"
        for pill in pills:
            source = SOURCE_BY_PILL.get(pill, "gfs")
            for tile in tiles:
                key = make_tile_key(source, pill, cycle, tile.z, tile.x, tile.y, "full")
                rec = self.index.get(key)
                if rec and rec.get("status") in {"fresh", "warm"}:
                    continue
                jobs.append(TileJob(
                    priority=priority,
                    tile_key=key,
                    source=source,
                    pill=pill,
                    cycle=cycle,
                    z=tile.z,
                    x=tile.x,
                    y=tile.y,
                    bbox=tile.bbox.as_dict(),
                    reason=reason,
                    extra={"cache_bbox": bbox.as_dict()},
                ))
        return jobs

    async def _loop(self) -> None:
        while self.running:
            # Keep working even with zero browser clients.
            for vp in self.hub.recent_viewports():
                bbox = vp.get("bbox") or vp.get("viewport_bbox")
                if bbox:
                    await self.prioritize_viewport(
                        bbox,
                        pills=vp.get("pills") or DEFAULT_PILLS,
                        priority=0,
                        reason=vp.get("reason", "steady"),
                        zoom=vp.get("zoom"),
                    )

            # Re-warm recent viewport areas with lower priority when no browser is driving them.
            for record in self.recent_viewports[:5]:
                await self.prioritize_viewport(
                    record["viewport_bbox"],
                    pills=record.get("pills") or DEFAULT_PILLS,
                    priority=2,
                    reason="recent_viewport_rewarm",
                )

            # Fish-location/global-sweep hooks should be wired to fishloclist.csv and provider cycle logic.
            await asyncio.sleep(30)
