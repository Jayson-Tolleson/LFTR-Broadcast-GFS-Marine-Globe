"""Async tile workers.

Wire `fetch_provider_tile` to existing LFTR provider modules. The default
implementation writes a valid placeholder tile so the cache pipeline can be
integration-tested before provider adapters are connected.
"""
from __future__ import annotations

import asyncio
from typing import Any, Awaitable, Callable

from .cache_index import CacheIndex
from .cache_store import CacheStore, utc_now_iso
from .tile_queue import TileJob, TileQueue
from .ws_updates import GFSUpdateHub

ProviderFetcher = Callable[[TileJob], Awaitable[dict[str, Any]]]


async def default_provider_fetcher(job: TileJob) -> dict[str, Any]:
    # Replace this adapter with calls into existing GFS/HYCOM/RTOFS/CoastWatch/NDBC modules.
    await asyncio.sleep(0.01)
    return {
        "tile_key": job.tile_key,
        "source": job.source,
        "pill": job.pill,
        "cycle": job.cycle,
        "z": job.z,
        "x": job.x,
        "y": job.y,
        "bbox": job.bbox,
        "features": [],
        "feature_count": 0,
        "status": "fresh",
        "updated_at": utc_now_iso(),
        "provider_debug": {
            "adapter": "default_provider_fetcher",
            "note": "Wire this to real provider fetch/decode logic.",
        },
    }


class TileWorkers:
    def __init__(
        self,
        queue: TileQueue,
        store: CacheStore,
        index: CacheIndex,
        hub: GFSUpdateHub,
        fetcher: ProviderFetcher | None = None,
        concurrency: int = 4,
    ) -> None:
        self.queue = queue
        self.store = store
        self.index = index
        self.hub = hub
        self.fetcher = fetcher or default_provider_fetcher
        self.concurrency = max(1, int(concurrency))
        self.tasks: list[asyncio.Task] = []
        self.running = False

    async def start(self) -> None:
        if self.running:
            return
        self.running = True
        self.tasks = [asyncio.create_task(self._loop(i), name=f"gfs-tile-worker-{i}") for i in range(self.concurrency)]

    async def stop(self) -> None:
        self.running = False
        for task in self.tasks:
            task.cancel()
        await asyncio.gather(*self.tasks, return_exceptions=True)
        self.tasks.clear()

    async def _loop(self, worker_id: int) -> None:
        while self.running:
            job = await self.queue.get()
            try:
                payload = await self.fetcher(job)
                payload.setdefault("updated_at", utc_now_iso())
                payload.setdefault("status", "fresh")
                await self.store.write_tile(job.source, job.tile_key, payload)
                await self.index.update(job.tile_key, {
                    "source": job.source,
                    "pill": job.pill,
                    "cycle": job.cycle,
                    "z": job.z,
                    "x": job.x,
                    "y": job.y,
                    "bbox": job.bbox,
                    "updated_at": payload.get("updated_at"),
                    "feature_count": payload.get("feature_count", len(payload.get("features", []))),
                    "error": None,
                })
                await self.hub.broadcast({
                    "type": "tile_update",
                    "pill": job.pill,
                    "tile_key": job.tile_key,
                    "status": "fresh",
                    "age_sec": 0,
                    "bbox": job.bbox,
                    "features": payload.get("features", []),
                    "source": job.source,
                })
            except Exception as exc:
                await self.store.append_failure({
                    "tile_key": job.tile_key,
                    "source": job.source,
                    "pill": job.pill,
                    "bbox": job.bbox,
                    "error": repr(exc),
                })
                await self.index.update(job.tile_key, {
                    "source": job.source,
                    "pill": job.pill,
                    "cycle": job.cycle,
                    "z": job.z,
                    "x": job.x,
                    "y": job.y,
                    "bbox": job.bbox,
                    "updated_at": utc_now_iso(),
                    "error": repr(exc),
                })
            finally:
                await self.queue.done(job)
