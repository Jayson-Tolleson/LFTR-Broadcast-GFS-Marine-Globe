"""Minimal websocket update hub for /gfs tile updates."""
from __future__ import annotations

import asyncio
import json
from typing import Any


class GFSUpdateHub:
    def __init__(self) -> None:
        self.clients: set[Any] = set()
        self.latest_viewports: dict[int, dict[str, Any]] = {}
        self._lock = asyncio.Lock()

    async def register(self, websocket: Any) -> None:
        async with self._lock:
            self.clients.add(websocket)

    async def unregister(self, websocket: Any) -> None:
        async with self._lock:
            self.clients.discard(websocket)
            self.latest_viewports.pop(id(websocket), None)

    async def note_viewport(self, websocket: Any, msg: dict[str, Any]) -> None:
        async with self._lock:
            self.latest_viewports[id(websocket)] = msg

    def client_count(self) -> int:
        return len(self.clients)

    def recent_viewports(self) -> list[dict[str, Any]]:
        return list(self.latest_viewports.values())

    async def broadcast(self, payload: dict[str, Any]) -> None:
        if not self.clients:
            return
        text = json.dumps(payload, ensure_ascii=False)
        dead = []
        for ws in list(self.clients):
            try:
                await ws.send(text)
            except Exception:
                dead.append(ws)
        for ws in dead:
            await self.unregister(ws)
