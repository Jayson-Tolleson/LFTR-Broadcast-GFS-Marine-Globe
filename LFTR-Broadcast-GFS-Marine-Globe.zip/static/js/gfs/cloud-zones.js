import { normalizePolygonFieldPayload } from './polygon_math.js';
import { createPolygon3D } from './polygon3d.js';

const CLOUD_PRESSURE_BANDS = {
  low: { baseHpa: 940, topHpa: 760, threshold: 20, color: '#dcefff' },
  mid: { baseHpa: 760, topHpa: 520, threshold: 18, color: '#eef6ff' },
  high: { baseHpa: 520, topHpa: 220, threshold: 14, color: '#ffffff' },
  total: { baseHpa: 880, topHpa: 520, threshold: 35, color: '#e9f4ff' },
};
const MAX_CLOUD_BODIES = 280;
const CLOUD_PARTICLE_MULTIPLIER = 4;
const MAX_CLOUD_PARTICLES = 3920;
const MAX_ADVECTION_STEP_SEC = 0.08;
const CLOUD_SHELL_MIN_REFRESH_MS = 120000;
const CLOUD_GRID_JITTER_FRACTION = 0.42;

function polygonApiPath() {
  return window.google?.maps?.maps3d?.Polygon3DElement ? 'Polygon3DElement.path' : 'gmp-polygon-3d.path';
}

function toNumber(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function wrapLongitude(lon) {
  let value = Number(lon) || 0;
  while (value < -180) value += 360;
  while (value >= 180) value -= 360;
  return value;
}


function uniqueId(prefix = 'cloud') {
  return `${prefix}-${Math.random().toString(36).slice(2, 10)}`;
}

function makeCloudParticleTemplate({ family = 'stratiform', color = '#ffffff', opacity = 0.36, scale = 1 }) {
  const uid = uniqueId('cloud-particle');
  const width = Math.round(28 * scale * (family === 'cirriform' ? 1.45 : family === 'stratiform' ? 1.22 : 1.0));
  const height = Math.round(18 * scale * (family === 'vertical' ? 1.16 : 1.0));
  const tpl = document.createElement('template');
  tpl.innerHTML = `
    <svg width="${width}" height="${height}" viewBox="0 0 64 42" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" style="pointer-events:none;overflow:visible">
      <defs>
        <radialGradient id="${uid}-core" cx="34%" cy="30%" r="76%">
          <stop offset="0%" stop-color="#ffffff" stop-opacity="${Math.min(0.92, opacity + 0.34).toFixed(2)}"/>
          <stop offset="58%" stop-color="${color}" stop-opacity="${Math.min(0.72, opacity + 0.12).toFixed(2)}"/>
          <stop offset="100%" stop-color="${color}" stop-opacity="0"/>
        </radialGradient>
      </defs>
      <ellipse cx="32" cy="21" rx="29" ry="15" fill="url(#${uid}-core)" fill-opacity="${opacity.toFixed(2)}"/>
      <ellipse cx="25" cy="15" rx="13" ry="7" fill="#fff" fill-opacity="${Math.min(0.42, opacity + 0.10).toFixed(2)}" transform="rotate(-9 25 15)"/>
    </svg>`;
  return tpl;
}

function createCloudParticleMarker(item) {
  const marker = document.createElement('gmp-marker-3d');
  marker.position = { lat: item.lat, lng: item.lon, altitude: item.altitude };
  marker.drawsWhenOccluded = true;
  marker.sizePreserved = true;
  marker.setAttribute('data-gfs-layer', 'clouds');
  marker.setAttribute('data-cloud-particle', item.family || 'cloud');
  marker.append(makeCloudParticleTemplate(item));
  return marker;
}

function cloudParticleCount(layer) {
  const weight = clamp(toNumber(layer?.opacity, 0.15) * 3.1, 0.2, 1.8);
  const familyBonus = layer?.family === 'vertical' ? 3 : (layer?.family === 'cumuliform' ? 2 : (layer?.family === 'cirriform' ? 1 : 0));
  const baseCount = clamp(Math.round(2 + weight * 2 + familyBonus), 2, 7);
  return clamp(Math.round(baseCount * CLOUD_PARTICLE_MULTIPLIER), 8, 28);
}

function buildCloudParticlesForBody(body, layer, particleBudget) {
  if (!body || particleBudget.remaining <= 0) return [];
  const particles = [];
  const count = Math.min(cloudParticleCount(layer), particleBudget.remaining);
  const heading = windHeadingDeg(body.windU, body.windV) * Math.PI / 180;
  const cosH = Math.cos(heading);
  const sinH = Math.sin(heading);
  const innerLatRadius = Math.max(0.006, toNumber(layer.latRadiusDeg, 0.04) * 0.54);
  const innerLonRadius = Math.max(0.006, toNumber(layer.lonRadiusDeg, 0.04) * 0.54);
  const shellHeight = Math.max(300, toNumber(layer.height, 900));
  const baseAltitude = toNumber(layer.baseAltitude, 1500);
  const opacity = clamp(toNumber(layer.opacity, 0.18) * 1.35, 0.16, 0.58);
  for (let idx = 0; idx < count; idx += 1) {
    const seed = hashJitter(body.anchorLat, body.anchorLon, idx + baseAltitude * 0.001 + shellHeight * 0.0001);
    const theta = (seed + idx / Math.max(1, count)) * Math.PI * 2;
    const r = 0.18 + (hashJitter(body.anchorLon, body.anchorLat, idx + 12) * 0.58);
    const localLat = Math.sin(theta) * innerLatRadius * r;
    const localLon = Math.cos(theta) * innerLonRadius * r;
    const rotLat = (localLat * cosH) - (localLon * sinH);
    const rotLon = (localLat * sinH) + (localLon * cosH);
    const vertical = 0.18 + (hashJitter(body.anchorLat, body.anchorLon, idx + 43) * 0.58);
    const altitude = Math.round(baseAltitude + shellHeight * vertical);
    particles.push({
      lat: body.anchorLat + rotLat,
      lon: wrapLongitude(body.anchorLon + rotLon),
      altitude,
      anchorLat: body.anchorLat,
      anchorLon: body.anchorLon,
      baseLocalLat: rotLat,
      baseLocalLon: rotLon,
      baseAltitude: altitude,
      shellId: body.shellId,
      shellHeight,
      windU: body.windU,
      windV: body.windV,
      localU: (hashJitter(body.anchorLat, body.anchorLon, idx + 70) - 0.5) * 0.75,
      localV: (hashJitter(body.anchorLon, body.anchorLat, idx + 84) - 0.5) * 0.75,
      wobblePhase: hashJitter(body.anchorLat, body.anchorLon, idx + 101) * Math.PI * 2,
      wobbleRate: 0.25 + hashJitter(body.anchorLon, body.anchorLat, idx + 111) * 0.55,
      wobbleLatAmp: innerLatRadius * (0.05 + hashJitter(body.anchorLat, body.anchorLon, idx + 121) * 0.08),
      wobbleLonAmp: innerLonRadius * (0.05 + hashJitter(body.anchorLon, body.anchorLat, idx + 131) * 0.08),
      latOffsetDeg: 0,
      lonOffsetDeg: 0,
      family: layer.family || 'stratiform',
      color: layer.color || '#ffffff',
      opacity,
      scale: 0.82 + hashJitter(body.anchorLat, body.anchorLon, idx + 151) * 0.62,
      marker: null,
    });
  }
  particleBudget.remaining -= particles.length;
  return particles;
}

function to2DGrid(value) {
  if (!Array.isArray(value)) return [];
  if (!Array.isArray(value[0])) return [];
  if (Array.isArray(value[0][0])) return value[0];
  return value;
}

function bboxFromPayload(payload) {
  const candidates = [payload?.bbox, payload?.bbox_used, payload?.viewport_bbox, payload?.meta?.bbox, payload?.meta?.bbox_used];
  for (const value of candidates) {
    if (Array.isArray(value) && value.length >= 4) {
      return { west: toNumber(value[0]), south: toNumber(value[1]), east: toNumber(value[2]), north: toNumber(value[3]) };
    }
    if (value && typeof value === 'object') {
      const west = toNumber(value.west, NaN);
      const south = toNumber(value.south, NaN);
      const east = toNumber(value.east, NaN);
      const north = toNumber(value.north, NaN);
      if ([west, south, east, north].every(Number.isFinite)) return { west, south, east, north };
    }
  }
  const items = Array.isArray(payload?.items) ? payload.items : [];
  const b = items.map((item) => item?.bounds || {}).filter(Boolean);
  const west = Math.min(...b.map((x) => toNumber(x.lon_min, Infinity)));
  const south = Math.min(...b.map((x) => toNumber(x.lat_min, Infinity)));
  const east = Math.max(...b.map((x) => toNumber(x.lon_max, -Infinity)));
  const north = Math.max(...b.map((x) => toNumber(x.lat_max, -Infinity)));
  if ([west, south, east, north].every(Number.isFinite)) return { west, south, east, north };
  return null;
}


function normalizeFeatureCenter(feature, bbox = null) {
  const safe = feature || {};
  let lat = toNumber(safe.lat ?? safe.latitude ?? safe.anchorLat ?? safe.centerLat ?? safe.center?.lat, NaN);
  let lon = toNumber(safe.lon ?? safe.lng ?? safe.longitude ?? safe.anchorLon ?? safe.centerLon ?? safe.center?.lon ?? safe.center?.lng, NaN);
  if (!Number.isFinite(lat) || !Number.isFinite(lon)) return null;

  // Catch the common swapped-coordinate failure: {lat:-118, lon:34}.
  if ((lat < -90 || lat > 90) && lon >= -90 && lon <= 90) {
    const oldLat = lat;
    lat = lon;
    lon = oldLat;
  }
  if (lat < -90 || lat > 90) return null;
  lon = wrapLongitude(lon);
  if (bbox && !pointNearBbox(lat, lon, bbox)) return null;
  return { lat, lon };
}

function bboxPadDeg(bbox) {
  if (!bbox) return { lat: 0.5, lon: 0.5 };
  const latSpan = Math.abs(toNumber(bbox.north, 0) - toNumber(bbox.south, 0));
  const lonSpan = Math.abs(toNumber(bbox.east, 0) - toNumber(bbox.west, 0));
  return {
    lat: clamp(latSpan * 0.18, 0.35, 3.5),
    lon: clamp(lonSpan * 0.18, 0.35, 5.0),
  };
}

function pointNearBbox(lat, lon, bbox) {
  if (!bbox) return true;
  const pad = bboxPadDeg(bbox);
  const south = Math.min(bbox.south, bbox.north) - pad.lat;
  const north = Math.max(bbox.south, bbox.north) + pad.lat;
  if (lat < south || lat > north) return false;
  const west = wrapLongitude(bbox.west - pad.lon);
  const east = wrapLongitude(bbox.east + pad.lon);
  const x = wrapLongitude(lon);
  if (west <= east) return x >= west && x <= east;
  return x >= west || x <= east;
}


function cloudPayloadHasDrawableContent(payload) {
  const items = (Array.isArray(payload?.tiles) && payload.tiles.length) ? payload.tiles : (Array.isArray(payload?.items) ? payload.items : []);
  if (items.length) return true;
  if (Array.isArray(payload?.scene?.clouds) && payload.scene.clouds.length) return true;
  const layers = Array.isArray(payload?.cloud_layers) ? payload.cloud_layers : [];
  if (layers.some((l) => Array.isArray(l?.density) && l.density.length)) return true;
  const fields = payload?.fields || {};
  return Boolean(fields.cloud_total || fields.cloud_low || fields.cloud_mid || fields.cloud_high || payload?.cloud_cover);
}

function cloudPayloadState(payload) {
  return String(payload?.source_state || payload?.payload_state || payload?.status || '').toLowerCase();
}

function stableCloudTileJitter(item, bbox = null) {
  const bounds = item?.bounds || {};
  const center = item?.center || {};
  const lat = toNumber(bounds.lat_center ?? center.lat ?? item?.lat, 0);
  const lon = toNumber(bounds.lon_center ?? center.lon ?? center.lng ?? item?.lon ?? item?.lng, 0);
  const cellLat = Math.max(0.0001, Math.abs(toNumber(bounds.lat_max, lat) - toNumber(bounds.lat_min, lat)));
  const cellLon = Math.max(0.0001, Math.abs(toNumber(bounds.lon_max, lon) - toNumber(bounds.lon_min, lon)));
  const tileKey = String(item?.tile_id || item?.id || `${lat.toFixed(4)}:${lon.toFixed(4)}`);
  let salt = 0;
  for (let i = 0; i < tileKey.length; i += 1) salt += tileKey.charCodeAt(i) * (i + 1);
  const j1 = hashJitter(lat, lon, salt + 11) - 0.5;
  const j2 = hashJitter(lon, lat, salt + 29) - 0.5;
  const scale = CLOUD_GRID_JITTER_FRACTION;
  return {
    lat: j1 * cellLat * scale,
    lon: j2 * cellLon * scale,
    cellLat,
    cellLon,
    salt,
  };
}

function organicizeCloudPath(path, seedLat, seedLon, salt = 0, jitter = null) {
  if (!Array.isArray(path) || path.length < 3) return path || [];
  const center = ringCenterAndScale(path);
  const latShift = toNumber(jitter?.lat, 0);
  const lonShift = toNumber(jitter?.lon, 0);
  const maxLatWarp = Math.max(0.001, toNumber(jitter?.cellLat, center.latRadiusDeg || 0.02) * 0.10);
  const maxLonWarp = Math.max(0.001, toNumber(jitter?.cellLon, center.lonRadiusDeg || 0.02) * 0.10);
  return path.map((pt, idx) => {
    const phase = (idx / Math.max(1, path.length)) * Math.PI * 2;
    const n1 = hashJitter(seedLat + idx * 0.017, seedLon - idx * 0.019, salt + idx * 7) - 0.5;
    const n2 = hashJitter(seedLon - idx * 0.013, seedLat + idx * 0.011, salt + idx * 13) - 0.5;
    const radial = 0.72 + 0.28 * Math.sin(phase * 2.0 + salt * 0.01);
    return {
      lat: pt.lat + latShift + n1 * maxLatWarp * radial,
      lng: wrapLongitude(pt.lng + lonShift + n2 * maxLonWarp * radial),
    };
  });
}

function clearCloudLayerNodes(map3DElement = null) {
  const roots = [];
  if (map3DElement) roots.push(map3DElement);
  if (typeof document !== 'undefined') roots.push(document);
  const selectors = [
    '[data-gfs-layer="clouds"]',
    '[data-cloud-shell]',
    '[data-cloud-particle]',
  ].join(',');
  for (const root of roots) {
    try {
      root.querySelectorAll?.(selectors)?.forEach((el) => {
        try { el.remove(); } catch (_) {}
      });
    } catch (_) {}
  }
}

if (typeof window !== 'undefined') {
  window.clearGfsCloudLayer = function clearGfsCloudLayer() {
    clearCloudLayerNodes(document.querySelector('gmp-map-3d') || document.querySelector('gmp-map') || null);
  };
}

function densityPercent(value) {
  const n = toNumber(value, 0);
  if (n <= 1.25) return clamp(n * 100, 0, 100);
  return clamp(n, 0, 100);
}

function tileFromCloudRegion(region) {
  if (!region || typeof region !== 'object') return null;
  const c = region.center || {};
  const b = region.bbox || {};
  const intensity = region.intensity || {};
  const wind = region.wind || {};
  return {
    id: region.id,
    tile_id: region.id,
    bounds: {
      lat_center: c.lat,
      lon_center: c.lon,
      lat_min: b.south,
      lat_max: b.north,
      lon_min: b.west,
      lon_max: b.east,
    },
    low_density: intensity.low,
    mid_density: intensity.mid,
    high_density: intensity.high,
    coverage: toNumber(intensity.total, 0) * 100,
    precip_rate: toNumber(intensity.rain, 0),
    wind: { mid: { u: wind.u, v: wind.v } },
    cloud_type: region.cloud_type,
    regime: region.family,
    method: region.method || 'cloud_region_marching_squares_v1',
    cloud_region: region,
    region_footprint: region.footprint || [],
  };
}

function cloudTileFeatures(payload, bbox = null) {
  let items = Array.isArray(payload?.tiles) && payload.tiles.length
    ? payload.tiles
    : (Array.isArray(payload?.items) && payload.items.length ? payload.items : []);
  if ((!items || !items.length) && Array.isArray(payload?.cloud_regions) && payload.cloud_regions.length) {
    items = payload.cloud_regions.map(tileFromCloudRegion).filter(Boolean);
  }
  const out = [];
  for (const item of items) {
    const bounds = item?.bounds || {};
    const center = item?.center || {};
    const normalizedCenter = normalizeFeatureCenter({
      lat: bounds.lat_center ?? center.lat ?? item.lat,
      lon: bounds.lon_center ?? center.lon ?? center.lng ?? item.lon ?? item.lng,
    }, bbox);
    if (!normalizedCenter) continue;
    const { lat, lon } = normalizedCenter;
    const hints = Array.isArray(item.layer_hints) ? item.layer_hints : [];
    const lowHint = hints.find((x) => x?.band === 'low') || {};
    const midHint = hints.find((x) => x?.band === 'mid') || {};
    const highHint = hints.find((x) => x?.band === 'high') || {};
    const low = densityPercent(item.low_density ?? item.cloud_low ?? item.bands?.low?.density ?? lowHint.density);
    const mid = densityPercent(item.mid_density ?? item.cloud_mid ?? item.bands?.mid?.density ?? midHint.density);
    const high = densityPercent(item.high_density ?? item.cloud_high ?? item.bands?.high?.density ?? highHint.density);
    const total = densityPercent(item.coverage ?? item.cloud_total ?? item.estimated_density ?? Math.max(low, mid, high));
    const precip = toNumber(item.precip_rate ?? item.precipitation_factor ?? item.rain_factor ?? item.source_fields?.proxy_precip_rate, 0);
    const wind = item.wind || {};
    const windMid = wind.mid || wind.low || wind.high || {};
    const jitter = stableCloudTileJitter(item, bbox);
    const jitteredCenter = normalizeFeatureCenter({ lat: lat + jitter.lat, lon: lon + jitter.lon }, bbox) || { lat, lon };
    out.push({
      lat: jitteredCenter.lat,
      lon: jitteredCenter.lon,
      grid_lat: lat,
      grid_lon: lon,
      _organicJitter: jitter,
      cloud_low: low,
      cloud_mid: mid,
      cloud_high: high,
      cloud_total: Math.max(total, low, mid, high),
      precip_rate: precip,
      wind_u: toNumber(windMid.u ?? item.wind_u, 0),
      wind_v: toNumber(windMid.v ?? item.wind_v, 0),
      cell_lat_deg: Math.max(Math.abs(toNumber(bounds.lat_max, lat) - toNumber(bounds.lat_min, lat)), 0.04),
      cell_lon_deg: Math.max(Math.abs(toNumber(bounds.lon_max, lon) - toNumber(bounds.lon_min, lon)), 0.04),
      tile_id: item.tile_id || item.id || `${lat.toFixed(3)}:${lon.toFixed(3)}`,
      rawTile: item,
      _serverShellsAvailable: !!(item?.bands && Object.values(item.bands).some((b) => Array.isArray(b?.shells) && b.shells.length && Array.isArray(b?.footprints))),
      _cloudRegionMethod: item.method || item.source_method || item.cloud_region?.method || null,
    });
  }
  return out;
}

function latLonFromIndex(i, j, ny, nx, bbox) {
  const lat = bbox.south + ((i + 0.5) / Math.max(1, ny)) * (bbox.north - bbox.south);
  const lon = bbox.west + ((j + 0.5) / Math.max(1, nx)) * (bbox.east - bbox.west);
  return { lat, lon };
}

function cloudFeaturesFromContract(payload, bbox = null) {
  const raw = normalizePolygonFieldPayload(payload?.polygon_field_v1 || null);
  const out = [];
  for (const feature of raw) {
    const center = normalizeFeatureCenter(feature, bbox);
    if (!center) continue;
    out.push({ ...feature, lat: center.lat, lon: center.lon });
  }
  return out;
}

function cellSizeDeg(bbox, ny, nx) {
  return {
    lat: Math.abs((bbox.north - bbox.south) / Math.max(1, ny)),
    lon: Math.abs((bbox.east - bbox.west) / Math.max(1, nx)),
  };
}

function hashJitter(lat, lon, salt = 0) {
  const v = Math.sin((lat * 12.9898) + (lon * 78.233) + (salt * 19.19)) * 43758.5453;
  return v - Math.floor(v);
}

function pressureToHeightMeters(hpa) {
  const pressure = clamp(toNumber(hpa, 1013.25), 80, 1050);
  return 44330 * (1 - Math.pow(pressure / 1013.25, 0.1903));
}

function metersToLatDegrees(meters) {
  return meters / 111320;
}

function metersToLonDegrees(meters, lat) {
  const lonScale = Math.max(0.2, Math.cos((Number(lat) * Math.PI) / 180));
  return meters / (111320 * lonScale);
}

function advectPath(basePath, latOffsetDeg, lonOffsetDeg) {
  return basePath.map((point) => ({
    lat: point.lat + latOffsetDeg,
    lng: wrapLongitude(point.lng + lonOffsetDeg),
  }));
}

function roundedCloudPath({ lat, lon, latRadiusDeg, lonRadiusDeg, wobble = 0.18, points = 14, elongation = 1, headingDeg = 90 }) {
  const path = [];
  const basePhase = hashJitter(lat, lon) * Math.PI * 2;
  const heading = (headingDeg * Math.PI) / 180;
  const cosH = Math.cos(heading);
  const sinH = Math.sin(heading);
  for (let i = 0; i < points; i += 1) {
    const t = (i / points) * Math.PI * 2;
    const harmonic = Math.sin((t * 2) + basePhase) * wobble;
    const secondary = Math.cos((t * 3) - basePhase) * (wobble * 0.55);
    const scale = 1 + harmonic + secondary;
    const localLat = Math.sin(t) * latRadiusDeg * scale;
    const localLon = Math.cos(t) * lonRadiusDeg * scale * elongation;
    const rotLat = (localLat * cosH) - (localLon * sinH);
    const rotLon = (localLat * sinH) + (localLon * cosH);
    path.push({ lat: lat + rotLat, lng: lon + rotLon });
  }
  return path;
}

function buildCloudPressureBand(type, density, totalBoost, family = 'stratiform') {
  const band = CLOUD_PRESSURE_BANDS[type] || CLOUD_PRESSURE_BANDS.total;
  const weight = clamp(density / 100, 0, 1);
  const deepening = clamp((totalBoost - 0.82) / 0.45, 0, 1);
  const familyStretch = family === 'vertical' ? 1.3 : (family === 'cumuliform' ? 1.14 : (family === 'cirriform' ? 0.78 : 0.96));
  const baseHpa = band.baseHpa - ((band.baseHpa - band.topHpa) * weight * 0.16);
  const topHpa = band.topHpa - ((band.topHpa * 0.07) * deepening * weight * familyStretch);
  const baseAltitude = pressureToHeightMeters(baseHpa);
  const topAltitude = pressureToHeightMeters(topHpa);
  return {
    baseAltitude: Math.round(baseAltitude),
    height: Math.max(600, Math.round((topAltitude - baseAltitude) * familyStretch)),
    color: band.color,
    weight,
  };
}

function classifyCloudMorphology(feature) {
  const low = toNumber(feature?.cloud_low, 0);
  const mid = toNumber(feature?.cloud_mid, 0);
  const high = toNumber(feature?.cloud_high, 0);
  const total = toNumber(feature?.cloud_total, Math.max(low, mid, high));
  const precip = toNumber(feature?.precip_rate, 0);
  const dominant = high >= Math.max(low, mid) ? 'high' : (mid >= low ? 'mid' : 'low');

  if (precip >= 0.85 && total >= 72) return { family: 'vertical', subtype: 'cumulonimbus' };
  if (precip >= 0.35 && mid >= 45 && total >= 68) return { family: 'stratiform', subtype: 'nimbostratus' };
  if (high >= 58 && low < 35 && mid < 45) return { family: 'cirriform', subtype: high >= 78 ? 'cirrostratus' : 'cirrus' };
  if (low >= 58 && total < 75) return { family: 'cumuliform', subtype: low >= 78 ? 'towering-cumulus' : 'cumulus' };
  if (dominant === 'mid' && total >= 62) return { family: 'stratiform', subtype: 'altostratus' };
  return { family: 'stratiform', subtype: total >= 60 ? 'stratus' : 'stratocumulus' };
}

function shellBlueprints(morphology) {
  switch (morphology.family) {
    case 'cirriform':
      return [
        { shell: 'veil', latScale: 0.82, lonScale: 1.8, opacityBase: 0.07, opacitySpan: 0.08, wobble: 0.12, points: 16, elongation: 1.6 },
        { shell: 'streak', latScale: 0.56, lonScale: 1.45, opacityBase: 0.04, opacitySpan: 0.06, wobble: 0.08, points: 12, elongation: 1.9 },
      ];
    case 'vertical':
      return [
        { shell: 'core', latScale: 0.72, lonScale: 0.76, opacityBase: 0.16, opacitySpan: 0.18, wobble: 0.2, points: 14, elongation: 1.0 },
        { shell: 'tower', latScale: 0.5, lonScale: 0.54, opacityBase: 0.14, opacitySpan: 0.14, wobble: 0.24, points: 12, elongation: 0.92, baseLift: 0.22, heightBoost: 0.42 },
        { shell: 'anvil', latScale: 0.96, lonScale: 1.42, opacityBase: 0.08, opacitySpan: 0.1, wobble: 0.16, points: 16, elongation: 1.25, baseLift: 0.78, heightBoost: 0.18 },
      ];
    case 'cumuliform':
      return [
        { shell: 'body', latScale: 0.7, lonScale: 0.84, opacityBase: 0.12, opacitySpan: 0.2, wobble: 0.24, points: 14, elongation: 1.0 },
        { shell: 'tuft', latScale: 0.46, lonScale: 0.5, opacityBase: 0.08, opacitySpan: 0.14, wobble: 0.3, points: 11, elongation: 0.94, baseLift: 0.38, heightBoost: 0.26 },
      ];
    default:
      return [
        { shell: 'deck', latScale: 0.96, lonScale: 1.3, opacityBase: 0.11, opacitySpan: 0.16, wobble: 0.14, points: 16, elongation: 1.18 },
        { shell: 'underside', latScale: 0.82, lonScale: 1.08, opacityBase: 0.06, opacitySpan: 0.1, wobble: 0.1, points: 14, elongation: 1.12, baseLift: 0.14, heightBoost: 0.08 },
      ];
  }
}


function parseCssColorAndOpacity(value, fallbackColor = '#ffffff', fallbackOpacity = 0.25) {
  const text = String(value || '').trim();
  const m = text.match(/^rgba?\(([^)]+)\)$/i);
  if (m) {
    const parts = m[1].split(',').map((x) => x.trim());
    const r = clamp(Math.round(toNumber(parts[0], 255)), 0, 255);
    const g = clamp(Math.round(toNumber(parts[1], 255)), 0, 255);
    const b = clamp(Math.round(toNumber(parts[2], 255)), 0, 255);
    const a = parts.length >= 4 ? clamp(toNumber(parts[3], fallbackOpacity), 0, 1) : fallbackOpacity;
    return { color: `rgb(${r}, ${g}, ${b})`, opacity: a };
  }
  return { color: text || fallbackColor, opacity: fallbackOpacity };
}

function normalizeBackendRing(points, bbox = null) {
  const out = [];
  for (const p of Array.isArray(points) ? points : []) {
    const lat = toNumber(p?.lat, NaN);
    const lon = wrapLongitude(toNumber(p?.lng ?? p?.lon, NaN));
    if (!Number.isFinite(lat) || !Number.isFinite(lon)) continue;
    if (lat < -90 || lat > 90 || lon < -180 || lon >= 180) continue;
    if (bbox && (lat < bbox.south - 0.25 || lat > bbox.north + 0.25 || lon < bbox.west - 0.25 || lon > bbox.east + 0.25)) continue;
    const prev = out[out.length - 1];
    if (prev && Math.abs(prev.lat - lat) < 1e-8 && Math.abs(prev.lng - lon) < 1e-8) continue;
    out.push({ lat, lng: lon });
  }
  if (out.length >= 4) {
    const a = out[0];
    const b = out[out.length - 1];
    if (Math.abs(a.lat - b.lat) < 1e-8 && Math.abs(a.lng - b.lng) < 1e-8) out.pop();
  }
  return out.length >= 3 ? out : [];
}

function ringCenterAndScale(path) {
  if (!Array.isArray(path) || path.length < 3) return { lat: 0, lon: 0, latRadiusDeg: 0.04, lonRadiusDeg: 0.04 };
  let minLat = 90; let maxLat = -90; let minLon = 180; let maxLon = -180; let sumLat = 0; let sumLon = 0;
  for (const p of path) {
    minLat = Math.min(minLat, p.lat); maxLat = Math.max(maxLat, p.lat);
    minLon = Math.min(minLon, p.lng); maxLon = Math.max(maxLon, p.lng);
    sumLat += p.lat; sumLon += p.lng;
  }
  return {
    lat: sumLat / path.length,
    lon: sumLon / path.length,
    latRadiusDeg: Math.max(0.006, (maxLat - minLat) * 0.5),
    lonRadiusDeg: Math.max(0.006, (maxLon - minLon) * 0.5),
  };
}

function serverCloudShellLayersFromTile(tile, bbox = null, feature = null) {
  const out = [];
  const bands = tile?.bands || {};
  const regime = tile?.regime || 'cloud';
  for (const bandName of ['low', 'mid', 'high']) {
    const band = bands?.[bandName];
    if (!band || !Array.isArray(band.shells) || !Array.isArray(band.footprints)) continue;
    const wind = band.wind || {};
    for (const shell of band.shells) {
      const fp = band.footprints?.[Number(shell.footprint_ref) || 0];
      const rawPath = normalizeBackendRing(fp?.points, bbox);
      if (rawPath.length < 3) continue;
      const jitter = feature?._organicJitter || stableCloudTileJitter(tile, bbox);
      const path = organicizeCloudPath(rawPath, toNumber(feature?.grid_lat ?? feature?.lat ?? tile?.lat, 0), toNumber(feature?.grid_lon ?? feature?.lon ?? tile?.lon, 0), toNumber(jitter?.salt, 0) + toNumber(shell.z_index, 0) + bandName.length * 31, jitter);
      const center = ringCenterAndScale(path);
      const fill = parseCssColorAndOpacity(shell.fill, '#eef6ff', 0.22);
      const stroke = parseCssColorAndOpacity(shell.stroke, fill.color, 0.10);
      const baseAltitude = Math.max(0, toNumber(shell.base_m, band.base_altitude_m || 1200));
      const topAltitude = Math.max(baseAltitude + 50, toNumber(shell.top_m, band.top_altitude_m || baseAltitude + 900));
      out.push({
        path,
        lat: center.lat,
        lon: center.lon,
        baseAltitude,
        height: Math.max(50, topAltitude - baseAltitude),
        latRadiusDeg: center.latRadiusDeg,
        lonRadiusDeg: center.lonRadiusDeg,
        color: fill.color,
        opacity: fill.opacity,
        strokeColor: stroke.color,
        strokeOpacity: stroke.opacity,
        strokeWidth: toNumber(shell.stroke_width, 0.5),
        pressureBand: bandName,
        family: regime,
        subtype: shell.role || bandName,
        shell: shell.role || 'shell',
        windU: toNumber(wind.u, 0),
        windV: toNumber(wind.v, 0),
        zIndex: toNumber(shell.z_index, 0),
      });
    }
  }
  out.sort((a, b) => a.zIndex - b.zIndex);
  return out;
}

function makeServerCloudShellBody(layer) {
  const element = createPolygon3D({
    path: layer.path,
    altitude: layer.baseAltitude,
    altitudeMode: 'absolute',
    fillColor: layer.color,
    fillOpacity: layer.opacity,
    strokeColor: layer.strokeColor || layer.color,
    strokeOpacity: layer.strokeOpacity ?? 0.1,
    strokeWidth: layer.strokeWidth ?? 0.5,
    extrudedHeight: layer.height,
    hover: {
      title: `${layer.family || 'cloud'} ${layer.pressureBand || ''} ${layer.shell || 'shell'}`.trim(),
      lines: [
        `Backend shell: ${layer.shell || 'shell'}`,
        `Band: ${layer.pressureBand || 'cloud'}`,
        `Base altitude: ${Math.round(layer.baseAltitude)} m`,
        `Shell height: ${Math.round(layer.height)} m`,
        `Opacity: ${Math.round(clamp(layer.opacity, 0, 1) * 100)}%`,
        `Wind: ${Math.hypot(toNumber(layer.windU, 0), toNumber(layer.windV, 0)).toFixed(1)} m/s`,
      ],
    },
  });
  if (!element) return null;
  try {
    element.setAttribute('data-gfs-layer', 'clouds');
    element.setAttribute('data-cloud-shell', layer.family || 'cloud');
    element.setAttribute('data-cloud-shell-source', 'backend');
  } catch (_) {}
  return {
    element,
    shellId: uniqueId('cloud-shell'),
    basePath: layer.path,
    anchorLat: layer.lat,
    anchorLon: layer.lon,
    windU: toNumber(layer.windU, 0),
    windV: toNumber(layer.windV, 0),
    latOffsetDeg: 0,
    lonOffsetDeg: 0,
    particleMeanLatOffsetDeg: 0,
    particleMeanLonOffsetDeg: 0,
  };
}

function cloudBodiesForFeature(feature, footprintScale) {
  const low = toNumber(feature?.cloud_low, 0);
  const mid = toNumber(feature?.cloud_mid, 0);
  const high = toNumber(feature?.cloud_high, 0);
  const total = toNumber(feature?.cloud_total, Math.max(low, mid, high));
  const totalBoost = clamp(total / 100, 0.82, 1.25);
  const morphology = classifyCloudMorphology(feature);
  const blueprints = shellBlueprints(morphology);
  const layers = [];

  const appendLayer = (type, density) => {
    const band = buildCloudPressureBand(type, density, totalBoost, morphology.family);
    const weight = band.weight;
    if (weight <= 0) return;
    for (const bp of blueprints) {
      layers.push({
        baseAltitude: Math.round(band.baseAltitude + (band.height * (bp.baseLift || 0))),
        height: Math.round(band.height * (1 + (bp.heightBoost || 0))),
        opacity: Math.min(bp.opacityBase + (weight * bp.opacitySpan), 0.58),
        latRadiusDeg: footprintScale.lat * (bp.latScale + (weight * 0.42)),
        lonRadiusDeg: footprintScale.lon * (bp.lonScale + (weight * 0.48)),
        color: band.color,
        pressureBand: type,
        family: morphology.family,
        subtype: morphology.subtype,
        wobble: bp.wobble,
        points: bp.points,
        elongation: bp.elongation,
        shell: bp.shell,
      });
    }
  };

  if (low >= CLOUD_PRESSURE_BANDS.low.threshold) appendLayer('low', low);
  if (mid >= CLOUD_PRESSURE_BANDS.mid.threshold) appendLayer('mid', mid);
  if (high >= CLOUD_PRESSURE_BANDS.high.threshold) appendLayer('high', high);
  if (!layers.length && total >= CLOUD_PRESSURE_BANDS.total.threshold) appendLayer('total', total);
  return layers;
}

function sampleGridBilinear(grid, bbox, lat, lon) {
  if (!Array.isArray(grid) || !Array.isArray(grid[0]) || !bbox) return null;
  const arr = Array.isArray(grid[0][0]) ? grid[0] : grid;
  const ny = arr.length;
  const nx = Array.isArray(arr[0]) ? arr[0].length : 0;
  if (!ny || !nx) return null;
  const y = clamp(((lat - bbox.south) / Math.max(1e-6, bbox.north - bbox.south)) * (ny - 1), 0, ny - 1);
  const x = clamp(((lon - bbox.west) / Math.max(1e-6, bbox.east - bbox.west)) * (nx - 1), 0, nx - 1);
  const y0 = Math.floor(y);
  const x0 = Math.floor(x);
  const y1 = Math.min(ny - 1, y0 + 1);
  const x1 = Math.min(nx - 1, x0 + 1);
  const fy = y - y0;
  const fx = x - x0;
  const q11 = toNumber(arr[y0]?.[x0], NaN);
  const q21 = toNumber(arr[y0]?.[x1], q11);
  const q12 = toNumber(arr[y1]?.[x0], q11);
  const q22 = toNumber(arr[y1]?.[x1], q21);
  if (![q11, q21, q12, q22].every(Number.isFinite)) return null;
  return (q11 * (1 - fx) * (1 - fy)) + (q21 * fx * (1 - fy)) + (q12 * (1 - fx) * fy) + (q22 * fx * fy);
}

function windHeadingDeg(u, v) {
  if (!Number.isFinite(u) || !Number.isFinite(v)) return 90;
  return ((Math.atan2(u, v) * 180 / Math.PI) + 360) % 360;
}

function makeCloudBody({ lat, lon, baseAltitude, height, latRadiusDeg, lonRadiusDeg, color, opacity, windU = 0, windV = 0, family = 'stratiform', wobble = 0.16, points = 14, elongation = 1.0 }) {
  const headingDeg = windHeadingDeg(windU, windV);
  const basePath = roundedCloudPath({ lat, lon, latRadiusDeg, lonRadiusDeg, wobble, points, elongation: family === 'cirriform' ? Math.max(1.25, elongation) : elongation, headingDeg });
  const element = createPolygon3D({
    path: basePath,
    altitude: baseAltitude,
    altitudeMode: 'absolute',
    fillColor: color,
    fillOpacity: opacity,
    strokeColor: color,
    strokeOpacity: 0,
    strokeWidth: 0,
    extrudedHeight: height,
    hover: {
      title: `${family} cloud shell`,
      lines: [
        `Base altitude: ${Math.round(baseAltitude)} m`,
        `Shell height: ${Math.round(height)} m`,
        `Opacity: ${Math.round(clamp(opacity, 0, 1) * 100)}%`,
        `Wind: ${Math.hypot(toNumber(windU, 0), toNumber(windV, 0)).toFixed(1)} m/s @ ${headingDeg.toFixed(0)}°`,
      ],
    },
  });
  if (!element) return null;
  try { element.setAttribute('data-gfs-layer', 'clouds'); element.setAttribute('data-cloud-shell', family); } catch (_) {}
  return {
    element,
    shellId: uniqueId('cloud-shell'),
    basePath,
    anchorLat: lat,
    anchorLon: lon,
    windU: toNumber(windU, 0),
    windV: toNumber(windV, 0),
    latOffsetDeg: 0,
    lonOffsetDeg: 0,
    particleMeanLatOffsetDeg: 0,
    particleMeanLonOffsetDeg: 0,
  };
}

function startCloudAdvection(items, particles = []) {
  if (!items.length && !particles.length) return () => {};
  let rafId = 0;
  let stopped = false;
  let lastTs = 0;
  let elapsed = 0;
  const itemsByShell = new Map();
  for (const item of items) {
    if (item?.shellId) itemsByShell.set(item.shellId, item);
  }

  const tick = (ts) => {
    if (stopped) return;
    if (!lastTs) lastTs = ts;
    const dtSec = Math.min(MAX_ADVECTION_STEP_SEC, Math.max(0.01, (ts - lastTs) * 0.001));
    lastTs = ts;
    elapsed += dtSec;

    // Particles are the advected mass. Each particle keeps its own u/v plus
    // small local drift/wobble. The shell is NOT separately advected first;
    // after particles move, each shell follows the average particle displacement.
    const means = new Map();
    for (const particle of particles) {
      if (!particle.marker) continue;
      particle.latOffsetDeg += metersToLatDegrees((particle.windV + particle.localV) * dtSec);
      particle.lonOffsetDeg += metersToLonDegrees((particle.windU + particle.localU) * dtSec, particle.anchorLat + particle.latOffsetDeg);
      const phase = particle.wobblePhase + elapsed * particle.wobbleRate;
      const wobbleLat = Math.sin(phase) * particle.wobbleLatAmp;
      const wobbleLon = Math.cos(phase * 0.83) * particle.wobbleLonAmp;
      const wobbleAlt = Math.sin(phase * 1.31) * Math.min(220, particle.shellHeight * 0.055);
      const lat = particle.anchorLat + particle.baseLocalLat + particle.latOffsetDeg + wobbleLat;
      const lng = wrapLongitude(particle.anchorLon + particle.baseLocalLon + particle.lonOffsetDeg + wobbleLon);
      particle.marker.position = {
        lat,
        lng,
        altitude: Math.max(80, Math.round(particle.baseAltitude + wobbleAlt)),
      };
      const shellId = particle.shellId || null;
      if (shellId) {
        const acc = means.get(shellId) || { lat: 0, lon: 0, count: 0 };
        acc.lat += particle.latOffsetDeg;
        acc.lon += particle.lonOffsetDeg;
        acc.count += 1;
        means.set(shellId, acc);
      }
    }

    // Shell follows the particle centroid/mean advection. If a shell has no
    // particles because of budget capping, fall back to its own u/v so it still moves.
    for (const item of items) {
      const mean = item.shellId ? means.get(item.shellId) : null;
      if (mean && mean.count > 0) {
        item.particleMeanLatOffsetDeg = mean.lat / mean.count;
        item.particleMeanLonOffsetDeg = mean.lon / mean.count;
        item.latOffsetDeg = item.particleMeanLatOffsetDeg;
        item.lonOffsetDeg = item.particleMeanLonOffsetDeg;
      } else {
        item.latOffsetDeg += metersToLatDegrees(item.windV * dtSec);
        item.lonOffsetDeg += metersToLonDegrees(item.windU * dtSec, item.anchorLat + item.latOffsetDeg);
      }
      item.element.path = advectPath(item.basePath, item.latOffsetDeg, item.lonOffsetDeg);
    }
    rafId = requestAnimationFrame(tick);
  };

  rafId = requestAnimationFrame(tick);
  return () => {
    stopped = true;
    if (rafId) cancelAnimationFrame(rafId);
  };
}

export function estimateCloudColumnAltitudes(cloudTotal = 0, layerMix = {}) {
  const low = toNumber(layerMix.low, 0);
  const mid = toNumber(layerMix.mid, 0);
  const high = toNumber(layerMix.high, 0);
  const total = Math.max(cloudTotal, low, mid, high);
  const dominant = high >= Math.max(mid, low) && high >= 16
    ? 'high'
    : (mid >= Math.max(low, high) && mid >= 18 ? 'mid' : (low >= 20 ? 'low' : 'total'));
  const morphology = classifyCloudMorphology({ cloud_low: low, cloud_mid: mid, cloud_high: high, cloud_total: total });
  const band = buildCloudPressureBand(dominant, total, clamp(total / 100, 0.82, 1.24), morphology.family);
  return {
    cloudBaseAltitude: band.baseAltitude,
    cloudTopAltitude: band.baseAltitude + band.height,
    dominantBand: dominant,
    family: morphology.family,
    subtype: morphology.subtype,
  };
}

export function renderCloudZones({ payload, map3DElement }) {
  const created = [];
  const advected = [];
  const particles = [];
  const rb = payload?.render_budget || payload?.scene_plan?.render_budget || {};
  const maxCloudBodies = Math.max(1, Math.min(800, Number(rb.max_cloud_shells || MAX_CLOUD_BODIES)));
  const maxCloudParticles = Math.max(100, Math.min(20000, Number(rb.max_cloud_particles || MAX_CLOUD_PARTICLES)));
  const particleBudget = { remaining: maxCloudParticles };
  if (!map3DElement || !payload) return () => {};
  if (typeof window !== 'undefined' && window.__gfsCloudsDisabled === true) {
    clearCloudLayerNodes(map3DElement);
    return () => {};
  }
  console.info('[gfs clouds] polygon api', { api: polygonApiPath() });

  const state = cloudPayloadState(payload);
  const hasDrawable = cloudPayloadHasDrawableContent(payload);
  if (payload?.heuristic === true || state === 'synthetic') {
    console.warn('[gfs clouds] synthetic/mock payload refused; holding existing clouds if any', { source: payload?.source, state });
    return () => {};
  }
  if ((state === 'warming' || state === 'pending' || state === 'queued') && !hasDrawable) {
    console.info('[gfs clouds] warming shell received; preserving existing cloud shells until live payload arrives', { source: payload?.source, state });
    return () => {};
  }
  const bbox = bboxFromPayload(payload);
  if (!bbox) {
    console.warn('[gfs clouds] no bbox in real cloud payload', { source: payload?.source, state });
    return () => {};
  }

  if (!hasDrawable) {
    console.info('[gfs clouds] no drawable live cloud content; preserving existing clouds', { source: payload?.source, state });
    return () => {};
  }

  // Hard cleanup only for drawable live payloads. Warming/empty shells must not
  // flash-remove the current cloud scene.
  clearCloudLayerNodes(map3DElement);

  // Prefer viewport-bounded cloud tiles/scene clouds. The polygon_field_v1 path is
  // kept only as a fallback because bad lat/lon arrays can place clouds at poles.
  const tileFeatures = cloudTileFeatures(payload, bbox);
  const allowPolygonCloudFallback = payload?.allow_polygon_cloud_fallback === true || window.__GFS_DEBUG_POLYGON_CLOUDS === true;
  const contractFeatures = (!tileFeatures.length && allowPolygonCloudFallback) ? cloudFeaturesFromContract(payload, bbox) : [];
  const featureSource = tileFeatures.length ? tileFeatures : contractFeatures;
  if (featureSource.length) {
    const frag = document.createDocumentFragment();
    let bodyCount = 0;
    for (let i = 0; i < featureSource.length; i += 1) {
      const feature = featureSource[i]?.properties || featureSource[i] || {};
      const normalizedCenter = normalizeFeatureCenter(feature, bbox);
      if (!normalizedCenter) continue;
      const { lat, lon } = normalizedCenter;
      const serverLayers = serverCloudShellLayersFromTile(feature.rawTile, bbox, feature);
      const footprint = { lat: Math.max(toNumber(feature.cell_lat_deg, 0.12) * 0.94, 0.05), lon: Math.max(toNumber(feature.cell_lon_deg, 0.12) * 0.94, 0.05) };
      const layers = serverLayers.length ? serverLayers : cloudBodiesForFeature(feature, footprint);
      for (const layer of layers) {
        const body = serverLayers.length
          ? makeServerCloudShellBody(layer)
          : makeCloudBody({ lat, lon, windU: feature.wind_u, windV: feature.wind_v, ...layer });
        if (!body) continue;
        frag.append(body.element);
        created.push(body.element);
        advected.push(body);
        for (const particle of buildCloudParticlesForBody(body, layer, particleBudget)) {
          particle.marker = createCloudParticleMarker(particle);
          frag.append(particle.marker);
          created.push(particle.marker);
          particles.push(particle);
        }
        bodyCount += 1;
        if (bodyCount >= maxCloudBodies) break;
      }
      if (bodyCount >= maxCloudBodies) break;
    }
    if (bodyCount > 0) {
      map3DElement.append(frag);
      const stopAdvection = startCloudAdvection(advected, particles);
      console.info('[gfs clouds] rendered bodies', { bodies: bodyCount, particles: particles.length, sceneTier: payload?.scene_tier || payload?.scene_plan?.tier, renderBudget: rb, source: tileFeatures.length ? (payload?.cloud_region_count ? 'backend_cloud_regions_marching_squares' : 'backend_cloud_shells_from_tiles') : 'polygon_field_v1', mode: payload?.cloud_region_count ? 'cloud_region_marching_squares_shells_particles_advect_shell_follows_centroid' : 'organic_backend_shells_particles_advect_shell_follows_centroid' });
      return () => {
        stopAdvection();
        created.forEach((el) => { try { el.remove(); } catch (_) {} });
        clearCloudLayerNodes(map3DElement);
      };
    }
    console.warn('[gfs clouds] feature payload had entries but made zero bodies; falling back to grid renderer', { featureCount: featureSource.length, source: payload?.source, state });
  }

  const low = to2DGrid(payload?.cloud_layers?.find((l) => l?.name === 'low')?.density);
  const mid = to2DGrid(payload?.cloud_layers?.find((l) => l?.name === 'mid')?.density);
  const high = to2DGrid(payload?.cloud_layers?.find((l) => l?.name === 'high')?.density);
  const total = to2DGrid(payload?.fields?.cloud_total || payload?.cloud_cover);
  const precip = to2DGrid(payload?.fields?.precip_rate || payload?.fields?.prate);
  const windUGrid = to2DGrid(payload?.fields?.wind_u);
  const windVGrid = to2DGrid(payload?.fields?.wind_v);
  const grid = low.length ? low : (mid.length ? mid : (high.length ? high : total));
  if (!grid.length) {
    console.info('[gfs clouds] no drawable real cloud grid/features yet', { source: payload?.source, state });
    return () => {};
  }

  const ny = grid.length;
  const nx = Array.isArray(grid[0]) ? grid[0].length : 0;
  if (!ny || !nx) return () => {};

  const step = Math.max(1, Math.floor(Math.max(nx, ny) / 26));
  const cell = cellSizeDeg(bbox, ny, nx);
  const frag = document.createDocumentFragment();
  let bodyCount = 0;
  let cellCount = 0;

  for (let i = 0; i < ny; i += step) {
    for (let j = 0; j < nx; j += step) {
      const lowVal = toNumber(low?.[i]?.[j], 0);
      const midVal = toNumber(mid?.[i]?.[j], 0);
      const highVal = toNumber(high?.[i]?.[j], 0);
      const precipVal = toNumber(precip?.[i]?.[j], 0);
      const totalVal = toNumber(total?.[i]?.[j], Math.max(lowVal, midVal, highVal));
      if (totalVal < 22 && precipVal < 0.06 && lowVal < 18 && midVal < 16 && highVal < 14) continue;
      const { lat, lon } = latLonFromIndex(i, j, ny, nx, bbox);
      const layers = cloudBodiesForFeature({ lat, lon, cloud_low: lowVal, cloud_mid: midVal, cloud_high: highVal, cloud_total: totalVal, precip_rate: precipVal }, {
        lat: Math.max(cell.lat * 0.92, 0.05),
        lon: Math.max(cell.lon * 0.92, 0.05),
      });
      const sampledWindU = sampleGridBilinear(windUGrid, bbox, lat, lon);
      const sampledWindV = sampleGridBilinear(windVGrid, bbox, lat, lon);
      for (const layer of layers) {
        const body = makeCloudBody({ lat, lon, windU: sampledWindU, windV: sampledWindV, ...layer });
        if (!body) continue;
        frag.append(body.element);
        created.push(body.element);
        advected.push(body);
        for (const particle of buildCloudParticlesForBody(body, layer, particleBudget)) {
          particle.marker = createCloudParticleMarker(particle);
          frag.append(particle.marker);
          created.push(particle.marker);
          particles.push(particle);
        }
        bodyCount += 1;
        if (bodyCount >= maxCloudBodies) break;
      }
      cellCount += 1;
      if (bodyCount >= maxCloudBodies) break;
    }
    if (bodyCount >= maxCloudBodies) break;
  }

  map3DElement.append(frag);
  const stopAdvection = startCloudAdvection(advected, particles);
  console.info('[gfs clouds] rendered bodies', { cells: cellCount, bodies: bodyCount, particles: particles.length, sceneTier: payload?.scene_tier || payload?.scene_plan?.tier, renderBudget: rb, mode: 'shells_with_internal_ellipsoid_particles_uv_advected' });

  return () => {
    stopAdvection();
    created.forEach((el) => { try { el.remove(); } catch (_) {} });
    clearCloudLayerNodes(map3DElement);
  };
}
