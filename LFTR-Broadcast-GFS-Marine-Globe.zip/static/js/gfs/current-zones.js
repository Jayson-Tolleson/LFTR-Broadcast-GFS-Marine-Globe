import { createPolygon3D } from './polygon3d.js';
import { contourPolygonsFromPoints } from './marching_squares.js';

const MAX_POLYGONS_PER_FRAME = 42;

function n(v, fallback = 0) {
  const out = Number(v);
  return Number.isFinite(out) ? out : fallback;
}
function clamp01(v) { return Math.max(0, Math.min(1, Number(v) || 0)); }

function payloadPoints(payload) {
  if (Array.isArray(payload?.oceanPoints?.points)) return payload.oceanPoints.points;
  if (Array.isArray(payload?.points)) return payload.points;
  if (Array.isArray(payload?.ocean?.points)) return payload.ocean.points;
  return [];
}

function speedKt(point) {
  return n(point.speedKt ?? point.current?.speedKt ?? point.current_speed_kt, 0);
}

function toPath(poly, altitude = 12) {
  const coords = Array.isArray(poly?.coordinates) ? poly.coordinates : [];
  const path = [];
  for (const p of coords) {
    if (!Array.isArray(p) || p.length < 2) continue;
    const lng = Number(p[0]);
    const lat = Number(p[1]);
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) continue;
    path.push({ lat, lng, altitude });
  }
  if (path.length >= 2) {
    const a = path[0];
    const b = path[path.length - 1];
    if (Math.abs(a.lat - b.lat) < 1e-6 && Math.abs(a.lng - b.lng) < 1e-6) path.pop();
  }
  return path;
}

function colorForBand(band) {
  if (band === 'fast') return '#ff7a3d';
  if (band === 'medium') return '#ffe16a';
  return '#40e7ff';
}
function opacityForBand(band, value) {
  const p = clamp01((Number(value) || 0) / 3.0);
  if (band === 'fast') return 0.22 + p * 0.30;
  if (band === 'medium') return 0.14 + p * 0.24;
  return 0.08 + p * 0.18;
}
function extrudeForBand(band, value) {
  const v = Math.max(0, Number(value) || 0);
  if (band === 'fast') return 38 + v * 20;
  if (band === 'medium') return 20 + v * 14;
  return 10 + v * 9;
}

function tag(el) {
  try { el?.setAttribute?.('data-gfs-layer', 'current-zones'); } catch (_) {}
  try { el?.setAttribute?.('data-gfs-sub-layer', 'current-marching-squares'); } catch (_) {}
  return el;
}

function makeCurrentPolygon(poly) {
  const path = toPath(poly, 12);
  if (path.length < 3) return null;
  const band = poly.band || 'slow';
  const color = colorForBand(band);
  const value = Number(poly.value ?? poly.probability ?? 0);
  const el = createPolygon3D({
    path,
    altitude: 12,
    altitudeMode: 'relative',
    fillColor: color,
    fillOpacity: opacityForBand(band, value),
    strokeColor: color,
    strokeOpacity: Math.min(0.88, opacityForBand(band, value) + 0.22),
    strokeWidth: band === 'fast' ? 1.3 : 0.9,
    extrudedHeight: extrudeForBand(band, value),
    preferAttributePath: true,
    hover: {
      title: `Current ${band} contour`,
      lines: [
        `Interpolated speed: ${value.toFixed(2)} kt`,
        `Cells merged: ${poly.cells || 'n/a'}`,
        'Method: interpolated marching squares',
      ],
    },
  });
  try {
    el?.setAttribute?.('title', `Current ${band} contour ${value.toFixed(2)} kt`);
    el?.setAttribute?.('data-current-band', band);
  } catch (_) {}
  return tag(el);
}


function isDrawableViewportReason(reason) {
  const r = String(reason || 'steady').toLowerCase();
  return r === 'boot' || r === 'steady' || r === 'settled' || r === 'manual' || r === 'refresh' || r.includes('steady') || r.includes('settled') || r.includes('update') || r.includes('deferred');
}

export function renderCurrentZonesLayer({ payload, map3DElement, viewportReason = 'steady' }) {
  const created = [];
  if (!map3DElement || !payload) return () => {};
  if (!isDrawableViewportReason(viewportReason)) {
    console.info('[gfs current-zones] hold visible layer during non-draw reason', { reason: viewportReason });
    return () => {};
  }
  const points = payloadPoints(payload).filter((p) => p && p.valid !== false && p.water !== false && speedKt(p) >= 0.03);
  if (points.length < 4) {
    console.info('[gfs current-zones] not enough points', { points: points.length });
    return () => {};
  }
  const bbox = payload?.bbox || payload?.bbox_used || payload?.oceanPoints?.bbox || payload?.oceanPoints?.bbox_used || null;
  const contour = contourPolygonsFromPoints({
    points,
    bbox,
    valueAccessor: speedKt,
    thresholds: [
      { name: 'slow', value: 0.18, upper: 0.75 },
      { name: 'medium', value: 0.75, upper: 1.60 },
      { name: 'fast', value: 1.60 },
    ],
    maxGrid: 50,
    capPerBand: 22,
  });
  const queue = [
    ...(contour.bands?.slow || []),
    ...(contour.bands?.medium || []),
    ...(contour.bands?.fast || []),
  ].slice(0, MAX_POLYGONS_PER_FRAME);
  if (!queue.length) {
    console.info('[gfs current-zones] no contours from field', { points: points.length, grid: contour.grid });
    return () => {};
  }
  const frag = document.createDocumentFragment();
  for (const poly of queue) {
    const el = makeCurrentPolygon(poly);
    if (!el) continue;
    frag.append(el);
    created.push(el);
  }
  if (created.length) map3DElement.append(frag);
  console.info('[gfs current-zones] rendered interpolated marching-squares current zones', {
    source: payload?.oceanPoints?.source || payload?.source,
    points: points.length,
    polygons: created.length,
    grid: contour.grid,
    slow: contour.bands?.slow?.length || 0,
    medium: contour.bands?.medium?.length || 0,
    fast: contour.bands?.fast?.length || 0,
  });
  return () => {
    created.forEach((el) => { try { el.remove(); } catch (_) {} });
    try { map3DElement.querySelectorAll?.('[data-gfs-sub-layer="current-marching-squares"]')?.forEach((el) => el.remove()); } catch (_) {}
  };
}
