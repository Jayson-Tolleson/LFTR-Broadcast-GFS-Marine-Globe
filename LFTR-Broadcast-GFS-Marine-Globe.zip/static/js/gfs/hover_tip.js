let tipEl = null;

const DEFAULT_PROMPT = 'Hover drawn bait, boat, current, cloud, rain, lightning, or scene polygons for details.';
const MAX_PAYLOAD_ROWS = 16;

function ensureTip() {
  if (tipEl) return tipEl;
  tipEl = document.createElement('div');
  tipEl.id = 'gfsPolygonHoverTip';
  tipEl.className = 'gfs-polygon-hover-tip hidden';
  document.body.appendChild(tipEl);
  return tipEl;
}

function ensureTitleHoverHud() {
  const body = document.getElementById('gfsTitleHoverHudBody');
  return body || null;
}

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function titleCase(value) {
  return String(value || '')
    .replace(/[_\-]+/g, ' ')
    .replace(/\b\w/g, (m) => m.toUpperCase())
    .trim();
}

function fmtValue(value) {
  if (value == null || value === '') return 'n/a';
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) return 'n/a';
    if (Math.abs(value) >= 1000) return value.toFixed(0);
    if (Math.abs(value) >= 10) return value.toFixed(2);
    return value.toFixed(3);
  }
  if (typeof value === 'boolean') return value ? 'true' : 'false';
  if (Array.isArray(value)) {
    if (!value.length) return '[]';
    if (value.length <= 4 && value.every((v) => typeof v !== 'object')) return value.map(fmtValue).join(', ');
    return `[${value.length} items]`;
  }
  if (typeof value === 'object') {
    const keys = Object.keys(value);
    if (!keys.length) return '{}';
    const simple = keys.slice(0, 4).filter((k) => typeof value[k] !== 'object').map((k) => `${k}:${fmtValue(value[k])}`);
    return simple.length ? simple.join(' ') : `{${keys.slice(0, 4).join(', ')}}`;
  }
  const s = String(value);
  return s.length > 80 ? `${s.slice(0, 77)}…` : s;
}

function parseMaybeJson(value) {
  if (!value || typeof value !== 'string') return null;
  try { return JSON.parse(value); } catch (_) { return null; }
}

function attrsPayload(el) {
  const payload = {};
  try {
    for (const attr of Array.from(el?.attributes || [])) {
      const name = attr.name || '';
      if (!name.startsWith('data-')) continue;
      const key = name.replace(/^data-/, '').replace(/-/g, '_');
      if (key === 'gfs_hover_payload') continue;
      payload[key] = attr.value;
    }
  } catch (_) {}
  return payload;
}

function inferHoverFromElement(el) {
  if (!el) return null;
  const ds = el.dataset || {};
  const json = parseMaybeJson(ds.gfsHoverPayload || ds.payload || '');
  const layer = ds.gfsLayer || ds.layer || ds.gfsSubLayer || el.getAttribute?.('data-gfs-layer') || 'drawn graphic';
  const sub = ds.gfsSubLayer || ds.cloudShell || ds.lightningRegion || ds.currentBand || '';
  const title = ds.gfsHoverTitle || el.getAttribute?.('aria-label') || el.getAttribute?.('title') || `${titleCase(layer)}${sub ? ` ${titleCase(sub)}` : ''}`;
  const rawPathMode = el.__gfsPathMode || el.getAttribute?.('data-gfs-path-mode');
  const points = el.__gfsPathPointCount || el.getAttribute?.('data-gfs-path-points');
  const metrics = {
    layer,
    sub_layer: sub || undefined,
    source: ds.source || ds.gfsSource || ds.cloudShellSource || ds.lightningSource || undefined,
    path_mode: rawPathMode || undefined,
    path_points: points || undefined,
    altitude_mode: el.getAttribute?.('altitude-mode') || undefined,
    fill_opacity: el.getAttribute?.('fill-opacity') || undefined,
    extrusion_m: el.getAttribute?.('extruded-height') || undefined,
  };
  const attrPayload = attrsPayload(el);
  return {
    title,
    detail: ds.gfsHoverDetail || '',
    lines: [
      layer ? `Layer: ${titleCase(layer)}` : null,
      sub ? `Graphic: ${titleCase(sub)}` : null,
      points ? `Path points: ${points}` : null,
    ].filter(Boolean),
    metrics,
    payload: json || attrPayload,
  };
}

function normalizeHover(hover, el = null) {
  if (!hover || hover === true || hover.auto) return inferHoverFromElement(el);
  if (typeof hover === 'string') return { title: hover, lines: [] };
  if (hover && typeof hover === 'object') return hover;
  return inferHoverFromElement(el);
}

function payloadRows(payload) {
  if (!payload || typeof payload !== 'object') return [];
  return Object.entries(payload)
    .filter(([_, v]) => v != null && v !== '')
    .slice(0, MAX_PAYLOAD_ROWS)
    .map(([k, v]) => `<div class="gfs-hover-kv"><span>${escapeHtml(titleCase(k))}</span><b>${escapeHtml(fmtValue(v))}</b></div>`);
}

function htmlFromHover(hover, el = null) {
  const h = normalizeHover(hover, el);
  if (!h) return '';
  const title = h.title || h.layer || 'GFS graphic';
  const lines = Array.isArray(h.lines) ? h.lines : [];
  const detail = h.detail ? [h.detail] : [];
  const metrics = h.metrics && typeof h.metrics === 'object'
    ? Object.entries(h.metrics).filter(([_, v]) => v != null && v !== '').map(([k, v]) => `${titleCase(k)}: ${fmtValue(v)}`)
    : [];
  const payload = payloadRows(h.payload || h.data || h.raw || null);
  return [
    `<div class="gfs-hover-title">${escapeHtml(title)}</div>`,
    ...detail.map((line) => `<div>${escapeHtml(line)}</div>`),
    ...lines.filter(Boolean).map((line) => `<div>${escapeHtml(line)}</div>`),
    ...metrics.filter(Boolean).map((line) => `<div>${escapeHtml(line)}</div>`),
    payload.length ? '<div class="gfs-hover-section">Payload</div>' : '',
    ...payload,
  ].join('');
}

function positionTip(event) {
  const tip = ensureTip();
  const pad = 16;
  const x = Number(event?.clientX ?? 0) + pad;
  const y = Number(event?.clientY ?? 0) + pad;
  const rect = tip.getBoundingClientRect();
  const maxX = Math.max(0, window.innerWidth - rect.width - 10);
  const maxY = Math.max(0, window.innerHeight - rect.height - 10);
  tip.style.left = `${Math.min(x, maxX)}px`;
  tip.style.top = `${Math.min(y, maxY)}px`;
}

function showHoverHtml(html, event) {
  const titleBody = ensureTitleHoverHud();
  if (titleBody) {
    titleBody.innerHTML = html || escapeHtml(DEFAULT_PROMPT);
    titleBody.scrollTop = 0;
    if (tipEl) tipEl.classList.add('hidden');
    return;
  }
  const tip = ensureTip();
  tip.innerHTML = html;
  tip.classList.remove('hidden');
  positionTip(event);
}

export function setTitleHoverHud(hover) {
  const html = htmlFromHover(hover);
  const titleBody = ensureTitleHoverHud();
  if (titleBody) {
    titleBody.innerHTML = html || escapeHtml(DEFAULT_PROMPT);
    titleBody.scrollTop = 0;
  }
}

export function describeLayerPayload(el, payload) {
  if (!el || !payload || typeof payload !== 'object') return el;
  try { el.dataset.gfsHoverPayload = JSON.stringify(payload); } catch (_) {}
  return el;
}

export function attachPolygonHover(el, hover = null) {
  if (!el) return el;
  if (el.__gfsHoverAttached) {
    if (hover) el.__gfsHover = hover;
    return el;
  }
  el.__gfsHoverAttached = true;
  el.__gfsHover = hover || true;

  const initial = normalizeHover(hover, el);
  const title = initial?.title || initial?.layer || el.getAttribute?.('title') || 'GFS graphic';
  try {
    el.setAttribute?.('title', title);
    el.setAttribute?.('aria-label', title);
    el.setAttribute?.('data-gfs-hover-title', title);
    if (el.style) el.style.cursor = 'pointer';
  } catch (_) {}

  const show = (event) => {
    const html = htmlFromHover(el.__gfsHover || true, el);
    if (html) showHoverHtml(html, event);
  };
  const move = (event) => {
    if (!tipEl || tipEl.classList.contains('hidden')) return;
    positionTip(event);
  };
  const hide = () => {
    if (tipEl) tipEl.classList.add('hidden');
  };

  try {
    el.addEventListener?.('pointerenter', show);
    el.addEventListener?.('pointermove', move);
    el.addEventListener?.('pointerleave', hide);
    el.addEventListener?.('mouseenter', show);
    el.addEventListener?.('mousemove', move);
    el.addEventListener?.('mouseleave', hide);
    el.addEventListener?.('gmp-click', show);
    el.addEventListener?.('click', show);
    el.addEventListener?.('focus', show);
  } catch (_) {}
  return el;
}

export function hidePolygonHoverTip() {
  if (tipEl) tipEl.classList.add('hidden');
}

export function installUniversalPolygonHover(root = document) {
  const attachExisting = () => {
    try {
      root.querySelectorAll?.('gmp-polygon-3d,[data-gfs-layer]')?.forEach((el) => attachPolygonHover(el, el.__gfsHover || true));
    } catch (_) {}
  };
  attachExisting();
  try {
    const mo = new MutationObserver((records) => {
      for (const rec of records) {
        for (const node of Array.from(rec.addedNodes || [])) {
          if (!node || node.nodeType !== 1) continue;
          if (node.matches?.('gmp-polygon-3d,[data-gfs-layer]')) attachPolygonHover(node, node.__gfsHover || true);
          node.querySelectorAll?.('gmp-polygon-3d,[data-gfs-layer]')?.forEach((el) => attachPolygonHover(el, el.__gfsHover || true));
        }
      }
    });
    mo.observe(root === document ? document.body : root, { childList: true, subtree: true });
    window.__gfsUniversalPolygonHoverObserver = mo;
  } catch (_) {}
}

try {
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => installUniversalPolygonHover(document));
  else installUniversalPolygonHover(document);
} catch (_) {}
