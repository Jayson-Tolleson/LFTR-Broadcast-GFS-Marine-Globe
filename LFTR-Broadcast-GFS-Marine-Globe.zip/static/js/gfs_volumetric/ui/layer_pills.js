export function initLayerPills(engine){

document.querySelectorAll(".pill").forEach(btn=>{

btn.addEventListener("click",(ev)=>{
ev.preventDefault()
btn.classList.add("tap-armed")
setTimeout(()=>btn.classList.remove("tap-armed"),430)
})

btn.addEventListener("dblclick",(ev)=>{
ev.preventDefault()
const layer=btn.dataset.layer
engine.toggle(layer)
btn.classList.toggle("active")
btn.classList.remove("tap-armed")
})

})

}
