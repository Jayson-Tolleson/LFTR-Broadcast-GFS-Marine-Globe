from datetime import datetime, timezone

from server.gfs.sky import sky_mode, sky_payload


def test_sky_mode_thresholds():
    assert sky_mode(6.1) == "day"
    assert sky_mode(3.0) == "golden"
    assert sky_mode(-3.0) == "civil"
    assert sky_mode(-9.0) == "nautical"
    assert sky_mode(-15.0) == "astronomical"
    assert sky_mode(-18.1) == "night"


def test_sky_payload_contract():
    payload = sky_payload(34.2, -120.0, datetime(2026, 6, 1, 7, 25, tzinfo=timezone.utc))
    assert payload["ok"] is True
    assert payload["schema"] == "lftr_gfs_sky_v1"
    assert payload["server_time_utc"].endswith("Z")
    assert payload["mode"] in {"day", "golden", "civil", "nautical", "astronomical", "night"}
    assert isinstance(payload["sun_elevation_deg"], float)
    assert 0 <= payload["atmosphere_opacity"] <= 1
    assert 0 <= payload["cloud_opacity"] <= 1
    assert 0 <= payload["horizon_glow"] <= 1
