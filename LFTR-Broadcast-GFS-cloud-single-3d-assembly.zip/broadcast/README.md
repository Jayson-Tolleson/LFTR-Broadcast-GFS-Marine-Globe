# LFTR Broadcast / GFS Marine Intelligence Globe

Python 3 Quart + Hypercorn web app with HTML / JS / CSS routes for live broadcasting, viewer watch, and the `/gfs` marine intelligence globe.

## Routes

```text
/           landing / primary app
/broadcast  broadcaster camera and screen route
/watch      viewer route
/gfs        marine intelligence globe
```

## Install / update

This zip is packaged to unzip into `~/broadcast`.

```bash
cd ~
unzip -o LFTR-Broadcast-GFS-bbox-contract-jetballoons-clean.zip -d ~
cd ~/broadcast
sudo bash scripts/repair_broadcast_service.sh
```

Full installer:

```bash
cd ~/broadcast
sudo bash deploy/install.sh
```

Health checks:

```bash
systemctl status broadcast --no-pager
curl -s http://127.0.0.1:8000/health
curl -s http://127.0.0.1:8000/gfs/api/health
journalctl -u broadcast -n 160 --no-pager
```

## Runtime service

The expected service command is:

```text
/home/jayson_tolleson/broadcast/venv/bin/python -m hypercorn --bind 127.0.0.1:8000 --workers 1 main:app
```

Single-worker Hypercorn is intentional because the app keeps scene/cache state in-process.

## Architecture contract

```text
requests create cache
cache creates frame
frame creates rendering
pills choose visibility/subscription only
```

Pills should not directly own provider downloads. They should subscribe to layers and let scene-cache / renderer code decide what to draw.

Layer groups:

```text
weather padded bbox:
  clouds
  rain
  lightning
  jetstream
  inland_water_temp

ocean visible bbox:
  bait
  shark-intel
  boater

static/read-first geometry:
  locations
  inland-water
```


## BBox contract v2

This build makes bbox meanings explicit so padded atmosphere fetches do not leak into boats, bait, shorelines, or labels.

```text
visible_bbox        exact/current viewport draw box
render_bbox         same as visible_bbox for renderer placement
scene_read_bbox     cache read box; visible unless the request is weather-only
weather_fetch_bbox  padded box for clouds/rain/lightning/jetstream sampling
ocean_fetch_bbox    visible bbox for bait, boater, shark-intel
shoreline_bbox      compact visible bbox with small shoreline pad only
jetstream_bbox      visible bbox where balloons are placed
jetstream_fetch_bbox padded weather box used only for jet wind sampling
```

Debug now emits `bbox/contract`, `bbox_contract`, `visible_bbox`, and bbox role notes on scene-cache and cache-refresh calls.

## Jetstream balloons check/fix

Jet balloons now use the bbox contract directly:

```text
balloon placement:     jetstream_bbox / visible viewport
wind sampling fetch:   jetstream_fetch_bbox / padded weather fetch
DOM marker flag:       data-jetstream-balloon="true"
invalid positions:     skipped instead of creating bad gmp-marker-3d positions
animation loop:        dead/replaced balloons are compacted so removed markers do not stay in the item list
```

## Current visual patch

This build includes the style patch requested after the risky cleanup:

```text
inland-water shorelines: bright teal core + soft teal glow, shoreline-only, no lake fill
cloud shells: full filled shell default, top/bottom shell surfaces default-on
cloud shell edges: 4x thicker/glowier shell edges
cloud fill policy: fill remains authoritative so clouds do not become border-only outlines
README policy: this is the only markdown/readme file in the package
```

Important cloud knobs are available in the browser before boot if needed:

```js
window.GFS_CLOUD_SHELL_SURFACES_ENABLED = true;
window.GFS_CLOUD_SHELL_BOTTOM_SURFACE_ENABLED = true;
window.GFS_CLOUD_SHELL_EDGE_WIDTH_MULTIPLIER = 4;
window.GFS_CLOUD_SHELL_EDGE_OPACITY_MULTIPLIER = 4;
window.GFS_CLOUD_SHELL_OPACITY = 1.0;
```

## Inland water behavior

Inland water is cache-first and builder-backed:

```text
/gfs/api/inland-water              read-only geometry cache
/gfs/api/inland-water/build-cache  explicit builder
```

Healthy debug sequence:

```text
inland-water/cache-read
inland-water/build-cache-start
inland-water/build-cache-response
inland-water/cache-read-end polygons > 0 or lines > 0
inland-water/render polygons > 0 or lines > 0
inland-water/shoreline-complete mode=shoreline_only_teal_glow
```

Manual build-cache test:

```bash
curl -s "http://127.0.0.1:8000/gfs/api/inland-water/build-cache?bbox=-127,28,-113,40&visible_bbox=-127,28,-113,40&scene_tier=world&geometry=coarse&lod=auto&parallel=1&max_tiles=96&reason=manual_build" | python3 -m json.tool
```

Manual read test:

```bash
curl -s "http://127.0.0.1:8000/gfs/api/inland-water?bbox=-127,28,-113,40&visible_bbox=-127,28,-113,40&scene_tier=world&source=auto&geometry=coarse&lod=auto&cache=1&tile_cache=1&parallel=1&auto_build=0&max_tiles=96&reason=manual_read" | python3 -m json.tool
```

## Cloud rendering behavior

Clouds are intended to render as:

```text
one filled extruded shell
+ full shell cap surfaces
+ integrated 4x shell edge glow
+ subordinate animated particles inside the shell
```

The fill-first material is reapplied by a browser watchdog so a Maps 3D style refresh should not leave only borders behind.

Expected debug / DOM markers:

```text
data-cloud-solid-shell="true"
data-cloud-full-shell-default="top_and_bottom_caps_on"
data-cloud-edge-glow-4x="true"
renderPath: unified_filled_shell_with_subordinate_texture_particles
```

## Risky cleanup summary

This package intentionally removed old/parallel code paths from the earlier build:

```text
removed pycache / pyc files
removed old FastAPI sea sidecar and sidecar service/nginx pieces
removed unused tile-runtime scaffolding that was not the live authority
removed unused service wrapper packages and experimental AI queue pieces
removed /gfs/api/sea compatibility shell entirely
kept live Quart routes, GFSService, inland builder, broadcast/watch, and active /gfs render modules
```

The live authority is now the Quart app plus `GFSService`, scene-cache routes, active inland-water builder/cache, and active frontend renderers.

## Useful commands

```bash
# service repair
sudo bash scripts/repair_broadcast_service.sh

# service logs
journalctl -u broadcast -n 200 --no-pager

# quick health
sudo bash scripts/check_broadcast_health.sh

# syntax smoke checks from ~/broadcast
python3 -m compileall -q .
find static/js -name '*.js' -print0 | xargs -0 -n1 node --check
```

## Notes

The package is cleaned for the current LFTR `/broadcast`, `/watch`, and `/gfs` direction. If an older removed sidecar/tool is needed again, restore it deliberately instead of allowing it to quietly compete with the live scene-cache/render path.

### Cloud visual mode: edge/particle no-cover

This build keeps clouds darker/cooler and more affected-looking while restoring both the top and bottom shell cap polygons by default. Cloud mass is still carried by billowy particle texture plus a cold side tint, but the shell now renders with top and bottom caps on and 4x edge glow. Debug markers include `data-cloud-no-cover-polygon="false"`, `data-cloud-full-shell-default="top_and_bottom_caps_on"`, and `data-cloud-edge-glow-4x="true"`. Operators can still disable a cap explicitly by setting `window.GFS_CLOUD_SHELL_SURFACES_ENABLED = false` or `window.GFS_CLOUD_SHELL_BOTTOM_SURFACE_ENABLED = false` before the module loads.



## Cloud polygon root fix

This build fixes the root Maps 3D polygon contract instead of adding more cloud geometry. `gmp-polygon-3d` supports `extruded` as a boolean ground-connection only; there is no supported finite `extrudedHeight` attribute. The shared polygon helper now treats boolean attributes correctly, removes `extruded="false"` instead of leaving it present, and stores requested extrusion height only as debug metadata. Cloud polygons explicitly set `extrudeToGround: false`, so high-altitude clouds no longer create hidden/heavy ground curtains. Top and bottom cloud caps remain on, 4x edge glow remains on, and particle defaults are reduced for lighter rendering.

Cloud debug markers include `data-cloud-full-shell-default="top_and_bottom_caps_on"`, `data-cloud-native-ground-extrude="false"`, and `data-cloud-edge-glow-4x="true"`.

## Cleanup build notes

This package keeps one README and moves the detailed refactor notes to `CLEANUP_NOTES.md`.

Current architectural direction:

```text
providers -> provider cache -> scene cache -> persistent renderer objects
```

Pills should only choose visibility/subscription. They should not own provider fetches.

Inland Waters is now isolated behind `server/gfs/inland/` while the old `server/gfs/inland_water.py` import remains as a compatibility facade.

Clouds now use the persistent scene registry in `static/js/gfs/scene_registry.js` so refreshes reconcile live objects instead of blanking the whole cloud layer first.


## Universal 24x24 provider tile contract

The GFS/provider path now uses one congruent viewport splitter:

```text
visible bbox -> 24 x 24 = 576 universal tiles
576 tiles x 6 providers = 3,456 possible provider-tile jobs
```

The six provider families are:

```text
ncss_gfs
rtofs
hycom
inland_geometry
usgs_waterflow
shoreline
```

Every provider receives the same `tile_id` and the same tile bbox for a given viewport.  This is intentionally less clever than provider-specific tiling: it gives us one bbox truth, one cache key shape, one debug story, and no hidden legacy/global tile math in the normal provider contract.

Useful debug calls:

```bash
curl -s "http://127.0.0.1:8000/gfs/api/tile-plan?bbox=-119,33.5,-118,34.5" | python3 -m json.tool
curl -s "http://127.0.0.1:8000/gfs/api/provider-tiles?bbox=-119,33.5,-118,34.5" | python3 -m json.tool
curl -s "http://127.0.0.1:8000/gfs/api/provider-tiles?bbox=-119,33.5,-118,34.5&providers=ncss_gfs,hycom&urls=1&limit=4" | python3 -m json.tool
```

## GFS service split cleanup

The former monolithic `server/gfs_service.py` has been reduced to a small coordinator class plus behavior-preserving mixins under `server/gfs_service_parts/`:

- `core.py` — shared app/service helpers, fish/environment intelligence, health/config payloads.
- `atmosphere.py` — GFS decode, cloud/rain/lightning/wind derivation, weather scene composition.
- `tiles_scene.py` — tile bounds, scene tile cache, inland-water tile merging, tile intel.
- `ocean_bait_frame.py` — provider diagnostics, ocean/current/boats/bait, frame cache and warming.
- `lightning_cache_media.py` — GOES GLM lightning cache, always-on warming, media/report helpers, scene-cache facade.

This is intentionally not a new legacy layer. It is a readability split around the existing runtime behavior so the next cleanup can delete or consolidate individual subsystems without editing a 9k-line file.

## Cleanup Notes

### 2026-06-08 reduction/deletion pass 2

- Removed unused browser helpers from `static/js/gfs/main.js`.
- Removed unused cloud helper paths from `static/js/gfs/cloud-zones.js`.
- Removed the legacy `/gfs/api/cache/warm` compatibility route; browser warming now nudges `/gfs/api/cache/refresh`.
- Removed orphan service methods from the split GFS service parts.
- Re-ran Python compile and JavaScript syntax validation.

## 2026-06-07 boot safety + earth-first priority

- Fixed three ES-module syntax regressions that could stop `/gfs` from booting:
  - `static/js/gfs/api.js` restored `jget(...)`.
  - `static/js/gfs/boats.js` restored `fetchBoatsPayload(...)`.
  - `static/js/gfs/inland-water.js` restored inland bait/temp helper function headers.
- Added an earth-first boot policy: the photorealistic globe gets first paint/update priority, while scene-cache/inland/background overlay warming is deferred slightly.
- Canonical viewport metadata now marks `quality: high` and `earth_priority: high_res_first` so debug payloads show the intended base-earth priority.
- Validation now checks JS files as ES modules, not just loose scripts, so missing function headers are caught.
