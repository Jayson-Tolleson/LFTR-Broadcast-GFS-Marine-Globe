#!/usr/bin/env bash
set -euo pipefail

configure_google_apis_impl() {
  local google_env="$APP_DIR/config/google.env"
  local maps_key="${MAPS_API_KEY:-}"
  local project_id="${GCP_PROJECT_ID:-}"
  local region="${VERTEX_AI_REGION:-global}"

  if [[ -t 0 ]]; then
    if [[ -z "$maps_key" ]]; then read -r -p "Google Maps API Key (optional): " maps_key || true; fi
    if [[ -z "$project_id" ]]; then read -r -p "GCP Project ID (optional): " project_id || true; fi
    if [[ -z "$region" ]]; then read -r -p "Vertex AI region [global]: " region || true; region="${region:-global}"; fi
  fi

  cat > "$google_env" <<EOF
MAPS_API_KEY=${maps_key}
GOOGLE_MAPS_API_KEY=${maps_key}
GOOGLE_CLOUD_PROJECT=${project_id}
GOOGLE_CLOUD_LOCATION=${region}

# LFTR machine profile tuning: GCP e2 custom / e2-standard style, 2 vCPU + 16 GB RAM + 25 GB SSD.
# Keep Hypercorn single-worker for in-memory WebRTC/signaling correctness, but allow
# bounded parallel I/O for GFS/HYCOM/ERDDAP cache warming.
LFTR_MACHINE_PROFILE=e2-vcpu2-16gb-25gbssd
APP_WORKERS=${APP_WORKERS:-1}
MALLOC_ARENA_MAX=2
OMP_NUM_THREADS=1
OPENBLAS_NUM_THREADS=1
NUMEXPR_NUM_THREADS=1
GFS_HTTP_TIMEOUT_SECONDS=6
GFS_TIMEOUT_SECONDS=22
GFS_CACHE_TTL_SECONDS=2400
GFS_TILE_READ_WORKERS=16
GFS_TILE_WARM_WORKERS=3
GFS_TILE_WARM_BUILD_LIMIT=32
GFS_ALWAYS_ON_CACHE=true
GFS_ALWAYS_ON_INTERVAL_SEC=600
GFS_ALWAYS_ON_MAX_TILES=384
GFS_CACHE_FRESH_TARGET_SEC=240
GFS_VIEWPORT_PAD_FACTOR=1.25
GFS_OCEAN_POINTS_MAX=720
GFS_OCEAN_NCSS_MAX_BOATS=18
GFS_CLOUD_MAX_REGIONS=120
GFS_CLOUD_LIVE_DEDUPE_SECONDS=8
GFS_CLOUD_RETAINED_MAX_AGE_SECONDS=86400
GFS_CLOUDS_FORCE_LIVE_FETCH=true
GFS_OCEAN_POINTS_CACHE_TTL_SECONDS=240
GFS_OCEAN_CACHE_TTL_SECONDS=240
GFS_BAIT_CACHE_TTL_SECONDS=240
GFS_HYCOM_HTTP_TIMEOUT_S=22
GFS_HYCOM_CURL_CONNECT_TIMEOUT_S=8
GFS_HYCOM_CURL_MAX_TIME_S=45
GFS_HYCOM_CURL_RETRY=1
GFS_HYCOM_CURL_RETRY_DELAY_S=1
EOF

  local creds="${GOOGLE_APPLICATION_CREDENTIALS:-}"
  if [[ -n "$creds" && -f "$creds" ]]; then
    echo "GOOGLE_APPLICATION_CREDENTIALS=$creds" >> "$google_env"
  fi
  chmod 600 "$google_env"
  chown "$APP_USER:$APP_GROUP" "$google_env"

  if [[ -n "${GOOGLE_APPLICATION_CREDENTIALS:-}" && ! -f "$GOOGLE_APPLICATION_CREDENTIALS" ]]; then
    log_warn "Optional service account key missing: $GOOGLE_APPLICATION_CREDENTIALS (ADC will be used if available)"
  fi
}
