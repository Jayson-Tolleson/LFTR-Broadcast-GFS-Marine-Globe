#!/usr/bin/env bash
set -euo pipefail
APP_DIR="${APP_DIR:-/home/jayson_tolleson/broadcast}"
VENV_DIR="${VENV_DIR:-$APP_DIR/venv}"
APP_USER="${APP_USER:-jayson_tolleson}"
APP_GROUP="${APP_GROUP:-$APP_USER}"
cd "$APP_DIR"
if [[ ! -x "$VENV_DIR/bin/python" ]]; then
  echo "[repair] recreating missing virtualenv: $VENV_DIR"
  rm -rf "$VENV_DIR"
  python3 -m venv "$VENV_DIR"
fi
"$VENV_DIR/bin/python" -m pip install --upgrade pip setuptools wheel
"$VENV_DIR/bin/python" -m pip install -r "$APP_DIR/requirements.txt" netCDF4 pydap cfgrib eccodes
"$VENV_DIR/bin/python" -c 'import hypercorn, quart; print("[repair] hypercorn/quart ok")'
cat >/etc/systemd/system/broadcast.service <<EOF
[Unit]
Description=Broadcast API Service
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=$APP_USER
Group=$APP_GROUP
WorkingDirectory=$APP_DIR
Environment=PYTHONUNBUFFERED=1
Environment=MALLOC_ARENA_MAX=2
Environment=OMP_NUM_THREADS=1
Environment=OPENBLAS_NUM_THREADS=1
Environment=NUMEXPR_NUM_THREADS=1
EnvironmentFile=/etc/broadcast/install.env
ExecStartPre=/bin/bash -lc 'test -x $VENV_DIR/bin/python && $VENV_DIR/bin/python -c "import hypercorn, quart"'
ExecStart=$VENV_DIR/bin/python -m hypercorn --bind 127.0.0.1:8000 --workers 1 main:app
Restart=always
RestartSec=3
LimitNOFILE=20000
MemoryMax=10G

[Install]
WantedBy=multi-user.target
EOF
chown -R "$APP_USER:$APP_GROUP" "$APP_DIR" 2>/dev/null || true
systemctl daemon-reload
systemctl reset-failed broadcast.service 2>/dev/null || true
systemctl enable broadcast.service
systemctl restart broadcast.service
systemctl status broadcast.service --no-pager
