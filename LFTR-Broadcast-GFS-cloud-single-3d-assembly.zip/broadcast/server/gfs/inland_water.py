"""Compatibility facade for the Inland Waters subsystem.

Kept so older routes/imports continue to work while the implementation lives
under ``server.gfs.inland``.
"""
from server.gfs.inland.payloads import *  # noqa: F401,F403
