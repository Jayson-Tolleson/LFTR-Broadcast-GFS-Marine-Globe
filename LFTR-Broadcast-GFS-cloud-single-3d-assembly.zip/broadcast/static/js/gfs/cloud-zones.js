import { createPolygon3D } from './polygon3d.js';
import { attachSceneKey, reconcileSceneLayer } from './scene_registry.js';

const CLOUD_PRESSURE_BANDS = {
  low: { baseHpa: 940, topHpa: 760, threshold: 20, color: '#dcefff' },
  mid: { baseHpa: 760, topHpa: 520, threshold: 18, color: '#eef6ff' },
  high: { baseHpa: 520, topHpa: 220, threshold: 14, color: '#ffffff' },
  total: { baseHpa: 880, topHpa: 520, threshold: 35, color: '#e9f4ff' },
};
const MAX_CLOUD_BODIES = Number(window.GFS_CLOUD_MAX_REGIONS || 120);
// User-preferred dense cloud texture: 4x particles, with rendering caps still bounded.
const CLOUD_PARTICLE_MULTIPLIER = Number(window.GFS_CLOUD_PARTICLE_MULTIPLIER || 1.0);
const CLOUD_PARTICLE_SIZE_SCALE = Number(window.GFS_CLOUD_PARTICLE_SIZE_SCALE || 1.45);
const CLOUD_PARTICLE_MASS_MODE = String(window.GFS_CLOUD_PARTICLE_MASS_MODE || 'billowy').toLowerCase();
const CLOUD_PARTICLE_OPACITY_SCALE = Number(window.GFS_CLOUD_PARTICLE_OPACITY_SCALE || 0.44);
// Cloud visual contract: one authoritative 3D cloud assembly per feature.
// Side shell is translucent smoke + single teal glow edge; caps are fill-only;
// particles provide billowy jitter/wobble texture. No second grid fallback draw.
const CLOUD_PARTICLE_RENDERER_ENABLED = window.GFS_CLOUD_PARTICLE_RENDERER_ENABLED !== false;
// CSS drop-shadow on the custom element can render as a detached glow silhouette.
// Keep glow integrated as stroke on the same Polygon3DElement unless explicitly enabled.
const CLOUD_SHELL_CSS_DROP_SHADOW_ENABLED = window.GFS_CLOUD_SHELL_CSS_DROP_SHADOW_ENABLED === true;
const CLOUD_PARTICLE_SLIDER_LINKED = window.GFS_CLOUD_PARTICLE_SLIDER_LINKED !== false;
const CLOUD_PARTICLE_SLIDER_MIN_VISIBLE = Number(window.GFS_CLOUD_PARTICLE_SLIDER_MIN_VISIBLE || 0.10);
const CLOUD_PARTICLE_DARKNESS_SLIDER_SCALE = Number(window.GFS_CLOUD_PARTICLE_DARKNESS_SLIDER_SCALE || 0.72);
const CLOUD_SHELL_DARKNESS_SCALE = Number(window.GFS_CLOUD_SHELL_DARKNESS_SCALE || 1.0);
const CLOUD_SHELL_STROKE_SCALE = Number(window.GFS_CLOUD_SHELL_STROKE_SCALE || 1.0);
const CLOUD_SHELL_EDGE_WIDTH_MULTIPLIER = Number(window.GFS_CLOUD_SHELL_EDGE_WIDTH_MULTIPLIER || 4);
const CLOUD_SHELL_EDGE_OPACITY_MULTIPLIER = Number(window.GFS_CLOUD_SHELL_EDGE_OPACITY_MULTIPLIER || 4);
// Cloud shell renderer: keep the 4x edge glow and enable both top and bottom
// cap polygons by default. Operators can still disable either cap explicitly
// by setting the corresponding window flag to false before this module loads.
const CLOUD_SHELL_SURFACES_ENABLED = window.GFS_CLOUD_SHELL_SURFACES_ENABLED !== false;
const CLOUD_SHELL_BOTTOM_SURFACE_ENABLED = window.GFS_CLOUD_SHELL_BOTTOM_SURFACE_ENABLED !== false;
const CLOUD_SHELL_EDGE_GLOW_ENABLED = window.GFS_CLOUD_SHELL_EDGE_GLOW_ENABLED !== false;
const CLOUD_SHELL_TOP_CAP_SCALE = Number(window.GFS_CLOUD_SHELL_TOP_CAP_SCALE || 0.56);
const CLOUD_SHELL_BOTTOM_CAP_SCALE = Number(window.GFS_CLOUD_SHELL_BOTTOM_CAP_SCALE || 0.72);
const CLOUD_SHELL_SIDEWALL_SCALE = Number(window.GFS_CLOUD_SHELL_SIDEWALL_SCALE || 0.34);
// Material contract: bottom is darkest/lowest fill, side is translucent smoke
// and carries the only glow edge, top is lighter fill.
const CLOUD_SHELL_BOTTOM_FILL_SCALE = Number(window.GFS_CLOUD_SHELL_BOTTOM_FILL_SCALE || 0.22);
const CLOUD_SHELL_SIDE_FILL_SCALE = Number(window.GFS_CLOUD_SHELL_SIDE_FILL_SCALE || 0.34);
const CLOUD_SHELL_TOP_FILL_SCALE = Number(window.GFS_CLOUD_SHELL_TOP_FILL_SCALE || 0.44);
const CLOUD_SHELL_MIN_VISIBLE_FILL = Number(window.GFS_CLOUD_SHELL_MIN_VISIBLE_FILL || 0.18);
const CLOUD_SHELL_COVERAGE_FILL_MAX = Number(window.GFS_CLOUD_SHELL_COVERAGE_FILL_MAX || 0.70);
const CLOUD_SHELL_TOP_CAP_MIN_FRACTION = Number(window.GFS_CLOUD_SHELL_TOP_CAP_MIN_FRACTION || 0.02);
const CLOUD_PARTICLE_INSET_SCALE = Number(window.GFS_CLOUD_PARTICLE_INSET_SCALE || 0.66);
const CLOUD_SHELL_EDGE_COLOR = String(window.GFS_CLOUD_SHELL_EDGE_COLOR || '#16f7d8');
const CLOUD_SHELL_CAP_EDGE_WIDTH_SCALE = Number(window.GFS_CLOUD_SHELL_CAP_EDGE_WIDTH_SCALE || 0.90);
const DESKTOP_MAX_CLOUD_PARTICLES = Number(window.GFS_MAX_CLOUD_PARTICLES_DESKTOP || 1500);
const MOBILE_MAX_CLOUD_PARTICLES = Number(window.GFS_MAX_CLOUD_PARTICLES_MOBILE || 700);
const MAX_CLOUD_PARTICLES = DESKTOP_MAX_CLOUD_PARTICLES;
const CLOUD_PARTICLE_DROP_SHADOW_ENABLED = window.GFS_CLOUD_PARTICLE_DROP_SHADOW_ENABLED === true;
// Cloud shells are expensive Google 3D polygons. Keep animation gentle:
// Particles drift; shells stay static by default. Updating gmp-polygon-3d path
// during advection can make beta Maps 3D flash or redraw as outline-only.
const MAX_ADVECTION_STEP_SEC = Number(window.GFS_CLOUD_MAX_ADVECTION_STEP_SEC ?? 0.04);
const CLOUD_ADVECTION_INTERVAL_MS = Number(window.GFS_CLOUD_ADVECTION_INTERVAL_MS ?? 250);
const CLOUD_SHELL_PATH_UPDATE_MS = Number(window.GFS_CLOUD_SHELL_PATH_UPDATE_MS ?? 0);
const CLOUD_GRID_JITTER_FRACTION = 0.42;
const CLOUD_PATH_SMOOTHING_ITERATIONS = 1;
const CLOUD_PATH_SMOOTHING_MAX_POINTS = 160;

function polygonApiPath() {
  return window.google?.maps?.maps3d?.Polygon3DElement ? 'Polygon3DElement.path' : 'gmp-polygon-3d.path';
}


// Clouds must not use the shared neon polygon helper.  Bait/shark contours can
// be neon outlines, but cloud bodies need a fill-first material.  This wrapper
// forces no-neon creation and stamps the element so later refreshes can keep the
// fill stronger than the stroke.
function createCloudPolygon3D(options = {}) {
  const el = createPolygon3D({ ...options, extrudeToGround: false, neonGlow: false });
  if (!el) return null;
  try {
    el.setAttribute?.('data-cloud-fill-first', 'true');
    el.setAttribute?.('data-gfs-neon-edge', 'false');
    el.removeAttribute?.('data-gfs-neon-color');
  } catch (_) {}
  return el;
}

function toNumber(v, fallback = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function normalizeFraction(value, fallback = 0.6) {
  const n = Number(value);
  if (!Number.isFinite(n)) return clamp(fallback, 0, 1);
  if (n > 1) return clamp(n / 100, 0, 1);
  return clamp(n, 0, 1);
}


// Cloud shell transparency is intentionally simple:
// final shell alpha = local cloud_fraction × operator slider(0..1) × fade.
// A cloud fraction of 0.60 should look like roughly 60% shell opacity at slider=1.
const CLOUD_SHELL_OPACITY = {
  strokeMin: 0.18,
  // Cloud shell edges are intentionally 4x glow now; the cap fills are also
  // visible, so clouds read as shaded bodies instead of wire outlines.
  strokeMax: 0.82,
};

const CLOUD_HEIGHT_VISUAL_SCALE = Number(window.GFS_CLOUD_HEIGHT_VISUAL_SCALE || 1.42);
const CLOUD_EXTRUSION_VISUAL_SCALE = Number(window.GFS_CLOUD_EXTRUSION_VISUAL_SCALE || 1.35);

export function setCloudShellOpacityScale(value) {
  const n = Number(value);
  // Accept either new 0..1 values or stale old UI values like 92 / 135.
  const normalized = Number.isFinite(n) && n > 1 ? (n / 100) : n;
  const scale = Number.isFinite(normalized) ? clamp(normalized, 0, 1) : 1.0;
  try { window.__gfsCloudShellOpacityScale = scale; } catch (_) {}
  try { window.GFS_CLOUD_SHELL_OPACITY = scale; } catch (_) {}
  try { localStorage.setItem('gfs.cloudShellOpacity', String(scale)); } catch (_) {}
  try { document.documentElement.style.setProperty('--gfs-cloud-shell-opacity-scale', String(scale)); } catch (_) {}
  try { window.__gfsDebugEvent?.('clouds/opacity-slider', { scale, value: scale }); } catch (_) {}
  refreshCloudShellOpacityScale();
  return scale;
}

function cloudShellOpacityScale() {
  const n = Number(window.__gfsCloudShellOpacityScale ?? window.GFS_CLOUD_SHELL_OPACITY);
  const normalized = Number.isFinite(n) && n > 1 ? (n / 100) : n;
  return Number.isFinite(normalized) ? clamp(normalized, 0, 1) : 1.0;
}

function cloudParticleOpacityMultiplier() {
  if (!CLOUD_PARTICLE_SLIDER_LINKED) return 1.0;
  const scale = cloudShellOpacityScale();
  if (scale <= 0.0001) return 0;
  return clamp(Math.max(CLOUD_PARTICLE_SLIDER_MIN_VISIBLE, scale), 0, 1);
}

function cloudParticleDarknessBlend() {
  if (!CLOUD_PARTICLE_SLIDER_LINKED) return 1.0;
  // At slider 1, particles stay dark/billowy. At lower slider values they fade
  // and lighten slightly before disappearing, matching the shell control.
  const scale = cloudShellOpacityScale();
  return clamp((scale * CLOUD_PARTICLE_DARKNESS_SLIDER_SCALE) + (1 - CLOUD_PARTICLE_DARKNESS_SLIDER_SCALE), 0, 1);
}

function finalCloudShellOpacity(baseOpacity, fadeScale = 1, max = 1.0) {
  const scale = cloudShellOpacityScale();
  if (scale <= 0.0001) return 0;
  const darknessScale = CLOUD_PARTICLE_MASS_MODE === 'billowy' ? CLOUD_SHELL_DARKNESS_SCALE : 1.0;
  return clamp(toNumber(baseOpacity, 0.6) * scale * darknessScale * clamp(toNumber(fadeScale, 1), 0, 1), 0.0, max);
}
function cloudShellDarkFillColor(element, alpha) {
  const base = String(element?.__gfsCloudFamily || element?.getAttribute?.('data-cloud-family') || '').toLowerCase();
  const role = String(element?.getAttribute?.('data-cloud-surface-role') || element?.__gfsCloudSurfaceRole || 'side').toLowerCase();
  const frac = normalizeFraction(element?.getAttribute?.('data-cloud-fraction') ?? element?.__gfsCloudFraction, 0.6);
  // Darker cloud_fraction = darker cap/underside. Slider changes alpha; fraction
  // changes both alpha and visual darkness so dense clouds feel heavier.
  if (alpha <= 0.0001) return 'rgba(0,0,0,0)';
  const dense = clamp(frac, 0, 1);
  if (role === 'top') {
    if (base.includes('high') || base.includes('cirrus')) return dense > 0.68 ? '#263244' : '#38475c';
    return dense > 0.68 ? '#202a36' : '#33404d';
  }
  if (role === 'bottom') {
    if (dense > 0.78) return '#020409';
    if (dense > 0.55) return '#050911';
    return '#0a111a';
  }
  if (role === 'side') {
    if (dense > 0.78) return '#05070c';
    if (dense > 0.55) return '#0b1017';
    return '#121a24';
  }
  if (base.includes('high') || base.includes('cirrus')) return '#151c24';
  if (base.includes('mid')) return '#111820';
  return '#0b1017';
}

function roleAdjustedCloudShellOpacity(element, baseFill, fade) {
  const role = String(element?.getAttribute?.('data-cloud-surface-role') || element?.__gfsCloudSurfaceRole || 'side').toLowerCase();
  const frac = normalizeFraction(element?.getAttribute?.('data-cloud-fraction') ?? element?.__gfsCloudFraction, baseFill);
  const scale = cloudShellOpacityScale();
  if (scale <= 0.0001) return 0;

  // Cloud material contract:
  //   bottom cap = darkest/lowest fill
  //   side shell = translucent smoke-glass fill, higher than bottom
  //   top cap    = lighter fill
  // Only the side shell owns the teal glow edge; caps are fill-only.
  let roleScale = CLOUD_SHELL_SIDE_FILL_SCALE;
  let minVisible = Math.max(0.05, frac * 0.12);
  if (role === 'bottom') {
    roleScale = CLOUD_SHELL_BOTTOM_FILL_SCALE;
    minVisible = Math.max(0.04, frac * 0.08);
  } else if (role === 'top') {
    roleScale = CLOUD_SHELL_TOP_FILL_SCALE;
    minVisible = Math.max(0.07, frac * 0.14);
  }

  const material = Math.max(baseFill * roleScale, frac * roleScale, minVisible);
  const cap = role === 'side' ? 0.38 : (role === 'bottom' ? 0.30 : 0.46);
  return finalCloudShellOpacity(Math.min(material, cap), fade, cap);
}


function applyCloudShellOpacity(element, fadeScale = null) {
  if (!element) return;
  const fade = fadeScale == null
    ? clamp(toNumber(element.__gfsFadeScale ?? element.getAttribute?.('data-cloud-fade-scale'), 1), 0, 1)
    : clamp(toNumber(fadeScale, 1), 0, 1);
  const baseFill = clamp(toNumber(element.__gfsBaseFillOpacity ?? element.getAttribute?.('data-cloud-base-fill-opacity') ?? element.getAttribute?.('fill-opacity'), 0.22), 0, 1);
  const baseStroke = clamp(toNumber(element.__gfsBaseStrokeOpacity ?? element.getAttribute?.('data-cloud-base-stroke-opacity') ?? element.getAttribute?.('stroke-opacity'), 0.12), 0, 1);
  const scale = cloudShellOpacityScale();
  const fill = roleAdjustedCloudShellOpacity(element, baseFill, fade);
  const isParty = cloudPartyModeEnabled();
  const surfaceRole = String(element?.getAttribute?.('data-cloud-surface-role') || element?.__gfsCloudSurfaceRole || 'side').toLowerCase();
  const isCapSurface = surfaceRole === 'top' || surfaceRole === 'bottom';
  // One edge authority: side shell glows; top/bottom caps never redraw grey outlines.
  const strokeMax = isParty ? 0.92 : Math.min(0.86, CLOUD_SHELL_OPACITY.strokeMax);
  const edgeOpacityScale = Math.max(1, CLOUD_SHELL_EDGE_OPACITY_MULTIPLIER) * CLOUD_SHELL_STROKE_SCALE;
  const strokeRaw = (scale <= 0.0001 || isCapSurface) ? 0 : Math.min(strokeMax, Math.max(CLOUD_SHELL_OPACITY.strokeMin, finalCloudShellOpacity(Math.max(baseStroke, 0.16) * 0.42 * edgeOpacityScale, fade, strokeMax)));
  const stroke = (scale <= 0.0001 || isCapSurface) ? 0 : Math.max(CLOUD_SHELL_OPACITY.strokeMin, strokeRaw);
  const fillColor = cloudShellDarkFillColor(element, fill);
  const fillCssColor = rgbaFromHex(fillColor, fill);
  const strokeCssColor = isCapSurface
    ? rgbaFromHex(CLOUD_SHELL_EDGE_COLOR, 0)
    : rgbaFromHex(String(element.getAttribute?.('stroke-color') || element.strokeColor || CLOUD_SHELL_EDGE_COLOR), stroke);
  try { element.__gfsFadeScale = fade; } catch (_) {}
  setVisualAttr(element, 'data-cloud-fade-scale', fade.toFixed(3));
  setVisualAttr(element, 'data-cloud-solid-shell', 'top_bottom_caps_side_smoke_particles_single_glow_edge');
  setVisualAttr(element, 'data-cloud-full-shell-default', 'top_and_bottom_caps_on');
  setVisualAttr(element, 'data-cloud-single-render-path', 'true');
  setVisualAttr(element, 'data-cloud-native-ground-extrude', 'false');
  setVisualAttr(element, 'data-cloud-coverage-fill-max', CLOUD_SHELL_COVERAGE_FILL_MAX.toFixed(3));
  setVisualAttr(element, 'fill-opacity', fill.toFixed(3));
  setVisualAttr(element, 'stroke-opacity', stroke.toFixed(3));
  setVisualAttr(element, 'fill', fillCssColor);
  setVisualAttr(element, 'fill-color', fillCssColor);
  setVisualProp(element, 'fillColor', fillCssColor);
  setVisualProp(element, 'fillOpacity', fill);
  setVisualProp(element, 'fill', fillCssColor);
  setVisualProp(element, 'fill-color', fillCssColor);
  setVisualAttr(element, 'stroke-color', strokeCssColor);
  setVisualProp(element, 'strokeColor', strokeCssColor);
  setVisualProp(element, 'strokeOpacity', stroke);
  setVisualAttr(element, 'data-gfs-neon-edge', 'false');
  setVisualAttr(element, 'data-cloud-fill-first', 'true');
  try {
    if (fill <= 0.0001) {
      element.style.opacity = '0';
      element.style.pointerEvents = 'none';
    } else {
      element.style.opacity = '';
      element.style.pointerEvents = '';
    }
  } catch (_) {}
}

window.refreshCloudShellOpacity = refreshCloudShellOpacityScale;
window.setGfsCloudShellOpacity = setCloudShellOpacityScale;

export function refreshCloudShellOpacityScale() {
  try {
    document.querySelectorAll?.('[data-cloud-shell]').forEach((el) => {
      applyCloudShellOpacity(el);
    });
    document.querySelectorAll?.('[data-cloud-particle]').forEach((el) => applyCloudParticleVisualMode(el));
  } catch (_) {}
}


let cloudMaterialWatchdogId = null;
function ensureCloudMaterialWatchdog() {
  if (cloudMaterialWatchdogId || typeof window === 'undefined') return;
  cloudMaterialWatchdogId = window.setInterval?.(() => {
    try {
      document.querySelectorAll?.('[data-cloud-shell][data-cloud-fill-first="true"]').forEach((el) => applyCloudShellOpacity(el));
    } catch (_) {}
  }, 1200) || null;
}

function cloudExtrudedHeight(height, cloudFraction = 0.6, extra = 0) {
  const h = Math.max(90, toNumber(height, 900));
  const scaledH = h * CLOUD_HEIGHT_VISUAL_SCALE;
  const fraction = normalizeFraction(cloudFraction, 0.6);
  const ratio = (0.58 + fraction * 0.42 + toNumber(extra, 0)) * CLOUD_EXTRUSION_VISUAL_SCALE;
  return Math.max(140, Math.min(scaledH * ratio, scaledH, 2400));
}

try {
  if (window.__gfsCloudShellOpacityScale == null) {
    const saved = Number(localStorage.getItem('gfs.cloudShellOpacity'));
    const normalized = Number.isFinite(saved) && saved > 1 ? saved / 100 : saved;
    window.__gfsCloudShellOpacityScale = Number.isFinite(normalized) ? clamp(normalized, 0, 1) : 1.0;
    if (Number.isFinite(saved) && saved > 1) localStorage.setItem('gfs.cloudShellOpacity', String(window.__gfsCloudShellOpacityScale));
  }
} catch (_) { try { window.__gfsCloudShellOpacityScale = 1.0; } catch (__) {} }

const PARTY_TIME_CLOUD_EDGE_COLORS = ['#ff3b30', '#34c759', '#0a84ff', '#ffd60a', '#bf5af2', '#30d5c8', '#111111'];
const PARTY_TIME_FRAME_MS = 260;
let partyTimeIntervalId = null;


function setVisualProp(target, prop, value) {
  try { target[prop] = value; } catch (_) {}
}

function setVisualAttr(target, attr, value) {
  if (value == null) return;
  try { target.setAttribute(attr, String(value)); } catch (_) {}
}

function cloudPartyModeEnabled() {
  return typeof window !== 'undefined' && window.__gfsPartyTime === true;
}

function stablePartySeed(input = '') {
  const str = String(input || 'cloud-party');
  let hash = 0;
  for (let i = 0; i < str.length; i += 1) hash = ((hash * 31) + str.charCodeAt(i)) >>> 0;
  return hash >>> 0;
}


function parseHexColor(value, fallback = { r: 255, g: 255, b: 255 }) {
  const input = String(value || '').trim();
  const m = input.match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/i);
  if (!m) return { ...fallback };
  const hex = m[1].length === 3 ? m[1].split('').map((ch) => ch + ch).join('') : m[1];
  const n = parseInt(hex, 16);
  return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
}

function rgbToHex(r, g, b) {
  const toHex = (n) => Math.max(0, Math.min(255, Math.round(n || 0))).toString(16).padStart(2, '0');
  return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}

function mixHexColors(a, b, amount = 0.5) {
  const t = clamp(toNumber(amount, 0.5), 0, 1);
  const ca = parseHexColor(a);
  const cb = parseHexColor(b);
  return rgbToHex((ca.r * (1 - t)) + (cb.r * t), (ca.g * (1 - t)) + (cb.g * t), (ca.b * (1 - t)) + (cb.b * t));
}

function rgbaFromHex(hex, alpha = 1) {
  const c = parseHexColor(hex, { r: 255, g: 255, b: 255 });
  return `rgba(${c.r},${c.g},${c.b},${clamp(toNumber(alpha, 1), 0, 1).toFixed(2)})`;
}

function windChaseOffsetForElement(element) {
  if (!element) return 0;
  const u = toNumber(element.getAttribute?.('data-cloud-wind-u'), 0);
  const v = toNumber(element.getAttribute?.('data-cloud-wind-v'), 0);
  const lat = toNumber(element.getAttribute?.('data-cloud-anchor-lat'), 0);
  const lon = toNumber(element.getAttribute?.('data-cloud-anchor-lon'), 0);
  const speed = Math.hypot(u, v);
  if (speed < 0.05) return 0;
  const nx = u / speed;
  const ny = v / speed;
  const projected = (lon * nx) + (lat * ny);
  const spatialBands = Math.round(projected * 3.25);
  const speedBands = Math.round(clamp(speed * 0.45, 0, 5));
  return spatialBands + speedBands;
}
function partyEdgeColorForElement(element) {
  const key = element?.getAttribute?.('data-cloud-party-key') || element?.getAttribute?.('data-cloud-base-stroke-color') || 'cloud-party';
  const phase = Math.max(0, toNumber((typeof window !== 'undefined' ? window.__gfsPartyTimePhase : 0), 0));
  const chaseOffset = windChaseOffsetForElement(element);
  const idx = (stablePartySeed(key) + phase - chaseOffset) % PARTY_TIME_CLOUD_EDGE_COLORS.length;
  const wrapped = ((idx % PARTY_TIME_CLOUD_EDGE_COLORS.length) + PARTY_TIME_CLOUD_EDGE_COLORS.length) % PARTY_TIME_CLOUD_EDGE_COLORS.length;
  return PARTY_TIME_CLOUD_EDGE_COLORS[wrapped] || '#ff3b30';
}


function partyColorForParticleMarker(marker) {
  const key = marker?.getAttribute?.('data-cloud-party-key') || marker?.getAttribute?.('data-cloud-particle') || 'cloud-particle';
  const idx = stablePartySeed(`${key}|particle`) % PARTY_TIME_CLOUD_EDGE_COLORS.length;
  return PARTY_TIME_CLOUD_EDGE_COLORS[idx] || '#0a84ff';
}

function stopCloudPartyAnimation() {
  if (partyTimeIntervalId != null) {
    try { window.clearInterval(partyTimeIntervalId); } catch (_) {}
    partyTimeIntervalId = null;
  }
}

function startCloudPartyAnimation(root = null) {
  stopCloudPartyAnimation();
  if (!cloudPartyModeEnabled()) return;
  if (typeof window !== 'undefined') {
    if (!Number.isFinite(Number(window.__gfsPartyTimePhase))) window.__gfsPartyTimePhase = 0;
  }
  partyTimeIntervalId = window.setInterval(() => {
    if (!cloudPartyModeEnabled()) {
      stopCloudPartyAnimation();
      return;
    }
    try { window.__gfsPartyTimePhase = (toNumber(window.__gfsPartyTimePhase, 0) + 1) % PARTY_TIME_CLOUD_EDGE_COLORS.length; } catch (_) {}
    applyCloudPartyModeToDom(root || document.querySelector('gmp-map-3d') || document);
  }, PARTY_TIME_FRAME_MS);
}

function decorateCloudShellElement(element, { shellKey = '', baseStrokeColor = null, baseFillOpacity = null, baseStrokeOpacity = null, baseStrokeWidth = null, windU = null, windV = null, anchorLat = null, anchorLon = null } = {}) {
  if (!element) return element;
  const resolvedColor = String(baseStrokeColor || element.getAttribute?.('stroke-color') || element.strokeColor || element.getAttribute?.('data-gfs-neon-color') || '#ffffff');
  const resolvedFillOpacity = clamp(toNumber(baseFillOpacity, toNumber(element.getAttribute?.('fill-opacity'), toNumber(element.fillOpacity, 0.22))), 0, 1);
  const resolvedOpacity = clamp(toNumber(baseStrokeOpacity, toNumber(element.getAttribute?.('stroke-opacity'), toNumber(element.strokeOpacity, 0.98))), 0, 1);
  const resolvedWidth = Math.max(0.25, Math.min(2.4, toNumber(baseStrokeWidth, toNumber(element.getAttribute?.('stroke-width'), toNumber(element.strokeWidth, 0.55)))));
  setVisualAttr(element, 'data-cloud-party-key', shellKey || `${resolvedColor}|${resolvedWidth}`);
  setVisualAttr(element, 'data-cloud-base-stroke-color', resolvedColor);
  setVisualAttr(element, 'data-cloud-base-fill-opacity', resolvedFillOpacity);
  try { element.__gfsBaseFillOpacity = resolvedFillOpacity; } catch (_) {}
  setVisualAttr(element, 'data-cloud-base-stroke-opacity', resolvedOpacity);
  try { element.__gfsBaseStrokeOpacity = resolvedOpacity; } catch (_) {}
  setVisualAttr(element, 'data-cloud-base-stroke-width', resolvedWidth);
  if (windU != null) setVisualAttr(element, 'data-cloud-wind-u', toNumber(windU, 0));
  if (windV != null) setVisualAttr(element, 'data-cloud-wind-v', toNumber(windV, 0));
  if (anchorLat != null) setVisualAttr(element, 'data-cloud-anchor-lat', toNumber(anchorLat, 0));
  if (anchorLon != null) setVisualAttr(element, 'data-cloud-anchor-lon', toNumber(anchorLon, 0));
  applyCloudShellVisualMode(element);
  return element;
}

function applyCloudShellVisualMode(element) {
  if (!element) return;
  const surfaceRole = String(element.getAttribute?.('data-cloud-surface-role') || '').toLowerCase();
  const isCapSurface = surfaceRole === 'top' || surfaceRole === 'bottom';
  const baseStrokeWidth = Math.max(0.2, toNumber(element.getAttribute?.('data-cloud-base-stroke-width'), 0.5));
  const isParty = cloudPartyModeEnabled();
  const edgeColor = isParty ? partyEdgeColorForElement(element) : CLOUD_SHELL_EDGE_COLOR;

  // One edge authority: the side shell owns the teal 4x glow. Top/bottom caps
  // are fill-only so their grey strokes cannot overwrite the teal edge.
  if (isCapSurface) {
    setVisualProp(element, 'strokeColor', rgbaFromHex(CLOUD_SHELL_EDGE_COLOR, 0));
    setVisualProp(element, 'strokeWidth', 0);
    setVisualProp(element, 'strokeOpacity', 0);
    setVisualAttr(element, 'stroke-color', rgbaFromHex(CLOUD_SHELL_EDGE_COLOR, 0));
    setVisualAttr(element, 'stroke-width', 0);
    setVisualAttr(element, 'stroke-opacity', 0);
    setVisualAttr(element, 'data-cloud-edge-glow', 'false');
    setVisualAttr(element, 'data-cloud-edge-glow-4x', 'false');
    setVisualAttr(element, 'data-cloud-cap-fill-only', 'true');
    try { element.style.filter = ''; } catch (_) {}
    applyCloudShellOpacity(element);
    return;
  }

  const edgeWidthScale = Math.max(1, CLOUD_SHELL_EDGE_WIDTH_MULTIPLIER);
  const solidShellWidth = isParty
    ? clamp(Math.max(baseStrokeWidth * edgeWidthScale, 2.6), 2.0, 12.0)
    : clamp(Math.max(baseStrokeWidth * edgeWidthScale, 2.0), 1.4, 10.5);
  setVisualProp(element, 'strokeColor', edgeColor);
  setVisualProp(element, 'strokeWidth', solidShellWidth);
  setVisualAttr(element, 'stroke-color', edgeColor);
  setVisualAttr(element, 'stroke-width', solidShellWidth);
  applyCloudShellOpacity(element);
  setVisualAttr(element, 'data-cloud-edge-color', edgeColor);
  setVisualAttr(element, 'data-cloud-edge-glow', CLOUD_SHELL_EDGE_GLOW_ENABLED ? 'true' : 'false');
  setVisualAttr(element, 'data-cloud-edge-glow-4x', CLOUD_SHELL_EDGE_GLOW_ENABLED ? 'true' : 'false');
  setVisualAttr(element, 'data-cloud-side-smoke-fill', 'true');
  if (isParty) setVisualAttr(element, 'data-cloud-party-color', edgeColor);
  else { try { element.removeAttribute?.('data-cloud-party-color'); } catch (_) {} }
  try {
    element.style.filter = (CLOUD_SHELL_EDGE_GLOW_ENABLED && CLOUD_SHELL_CSS_DROP_SHADOW_ENABLED)
      ? `drop-shadow(0 0 ${isParty ? 8 : 4}px ${edgeColor}) drop-shadow(0 0 ${isParty ? 24 : 12}px ${edgeColor}) drop-shadow(0 0 ${isParty ? 40 : 22}px ${edgeColor})`
      : '';
  } catch (_) {}
}

function applyCloudPartyModeToDom(root = null) {
  const scope = root || document;
  try {
    scope.querySelectorAll?.('[data-cloud-shell]').forEach((el) => applyCloudShellVisualMode(el));
  } catch (_) {}
  try {
    scope.querySelectorAll?.('[data-cloud-particle]').forEach((el) => applyCloudParticleVisualMode(el));
  } catch (_) {}
  if (cloudPartyModeEnabled()) startCloudPartyAnimation(scope);
  else stopCloudPartyAnimation();
}

function cloudShellFillOpacity({ baseOpacity = 0.18, cloudFraction = 0.6, shell = '', family = '' } = {}) {
  // First-paint material should already be visibly filled. The watchdog and
  // opacity slider can still soften it, but initial render must not collapse
  // into outline-only cloud rings.
  const frac = normalizeFraction(cloudFraction, 0.6);
  const legacy = normalizeFraction(baseOpacity, 0.18);
  const shellScale = String(shell || '').includes('bottom') ? 0.74 : (String(shell || '').includes('top') ? 0.54 : 0.62);
  return clamp(Math.max(CLOUD_SHELL_MIN_VISIBLE_FILL, frac * shellScale, legacy * 0.82), 0.06, CLOUD_SHELL_COVERAGE_FILL_MAX);
}

function cloudShellCapShadeOpacity({ cloudFraction = 0.6, shell = '' } = {}) {
  const cover = normalizeFraction(cloudFraction, 0.6);
  return clamp(CLOUD_SHELL_OPACITY.strokeMin + (cover * (CLOUD_SHELL_OPACITY.strokeMax - CLOUD_SHELL_OPACITY.strokeMin)), CLOUD_SHELL_OPACITY.strokeMin, CLOUD_SHELL_OPACITY.strokeMax);
}
function makeCloudSurfaceElement({ path, altitude, role, cloudFraction = 0.6, family = 'stratiform', windU = 0, windV = 0, anchorLat = null, anchorLon = null, color = '#101824', strokeColor = '#243244', strokeWidth = 0.25, hover = null } = {}) {
  if (!CLOUD_SHELL_SURFACES_ENABLED || !Array.isArray(path) || path.length < 3) return null;
  const frac = normalizeFraction(cloudFraction, 0.6);
  if (role === 'top' && frac < CLOUD_SHELL_TOP_CAP_MIN_FRACTION) return null;
  const roleScale = role === 'bottom' ? CLOUD_SHELL_BOTTOM_CAP_SCALE : (role === 'top' ? CLOUD_SHELL_TOP_CAP_SCALE : CLOUD_SHELL_SIDEWALL_SCALE);
  const el = createCloudPolygon3D({
    path,
    altitude,
    altitudeMode: 'absolute',
    fillColor: color,
    fillOpacity: frac * roleScale,
    strokeColor,
    strokeOpacity: 0,
    strokeWidth: 0,
    extrudedHeight: 0,
    neonGlow: false,
    hover,
  });
  if (!el) return null;
  try {
    el.setAttribute('data-gfs-layer', 'clouds');
    el.setAttribute('data-cloud-surface', 'true');
    el.setAttribute('data-cloud-surface-role', role);
    el.setAttribute('data-cloud-shell', family || 'cloud');
    el.setAttribute('data-cloud-family', family || 'cloud');
    el.setAttribute('data-cloud-fraction', String(frac));
    el.__gfsCloudSurfaceRole = role;
    el.__gfsCloudFamily = family || 'cloud';
    el.__gfsCloudFraction = frac;
  } catch (_) {}
  decorateCloudShellElement(el, {
    shellKey: ['surface', role, family || 'cloud', Math.round(toNumber(anchorLat, 0) * 100), Math.round(toNumber(anchorLon, 0) * 100), Math.round(toNumber(altitude, 0))].join('|'),
    baseFillOpacity: frac,
    baseStrokeColor: strokeColor,
    baseStrokeOpacity: 0,
    baseStrokeWidth: 0,
    windU, windV, anchorLat, anchorLon,
  });
  applyCloudShellOpacity(el);
  return el;
}

function buildCloudSurfaceElements({ path, baseAltitude, topAltitude, cloudFraction, family, windU, windV, anchorLat, anchorLon, color, hover } = {}) {
  const surfaces = [];
  if (!CLOUD_SHELL_SURFACES_ENABLED || !Array.isArray(path) || path.length < 3) return surfaces;
  const frac = normalizeFraction(cloudFraction, 0.6);
  if (CLOUD_SHELL_BOTTOM_SURFACE_ENABLED) {
    const bottom = makeCloudSurfaceElement({
      path,
      altitude: baseAltitude,
      role: 'bottom',
      cloudFraction: frac,
      family,
      windU, windV, anchorLat, anchorLon,
      color: '#050911',
      strokeColor: CLOUD_SHELL_EDGE_COLOR,
      strokeWidth: 0.42,
      hover,
    });
    if (bottom) surfaces.push(bottom);
  }
  const height = Math.max(0, toNumber(topAltitude, baseAltitude) - toNumber(baseAltitude, 0));
  if (height > 180 && frac >= CLOUD_SHELL_TOP_CAP_MIN_FRACTION) {
    const top = makeCloudSurfaceElement({
      path,
      altitude: topAltitude,
      role: 'top',
      cloudFraction: frac,
      family,
      windU, windV, anchorLat, anchorLon,
      color: '#263244',
      strokeColor: CLOUD_SHELL_EDGE_COLOR,
      strokeWidth: 0.36,
      hover,
    });
    if (top) surfaces.push(top);
  }
  return surfaces;
}

function pressureAtFraction(baseHpa, topHpa, fraction) {
  const base = Number(baseHpa);
  const top = Number(topHpa);
  if (!Number.isFinite(base) || !Number.isFinite(top)) return null;
  const t = clamp(Number(fraction) || 0, 0, 1);
  // pressure falls with height; keep interpolation in pressure space and convert to height
  return base + ((top - base) * t);
}

function wrapLongitude(lon) {
  let value = Number(lon) || 0;
  while (value < -180) value += 360;
  while (value >= 180) value -= 360;
  return value;
}

function mixPoint(a, b, t) {
  const altitudeA = toNumber(a?.altitude ?? a?.altitude_m, NaN);
  const altitudeB = toNumber(b?.altitude ?? b?.altitude_m, altitudeA);
  const out = {
    lat: toNumber(a?.lat, 0) + (toNumber(b?.lat, 0) - toNumber(a?.lat, 0)) * t,
    lng: wrapLongitude(toNumber(a?.lng ?? a?.lon, 0) + (toNumber(b?.lng ?? b?.lon, 0) - toNumber(a?.lng ?? a?.lon, 0)) * t),
  };
  if (Number.isFinite(altitudeA) || Number.isFinite(altitudeB)) {
    out.altitude = toNumber(altitudeA, 0) + (toNumber(altitudeB, altitudeA) - toNumber(altitudeA, 0)) * t;
  }
  return out;
}

function smoothClosedCloudPath(path, iterations = CLOUD_PATH_SMOOTHING_ITERATIONS, maxPoints = CLOUD_PATH_SMOOTHING_MAX_POINTS) {
  if (!Array.isArray(path) || path.length < 4 || iterations <= 0) return path || [];
  let ring = path.map((p) => ({
    lat: toNumber(p?.lat, 0),
    lng: wrapLongitude(toNumber(p?.lng ?? p?.lon, 0)),
    ...(Number.isFinite(toNumber(p?.altitude ?? p?.altitude_m, NaN)) ? { altitude: toNumber(p?.altitude ?? p?.altitude_m, 0) } : {}),
  }));
  for (let iter = 0; iter < iterations; iter += 1) {
    if (ring.length * 2 > maxPoints) break;
    const next = [];
    for (let i = 0; i < ring.length; i += 1) {
      const a = ring[i];
      const b = ring[(i + 1) % ring.length];
      next.push(mixPoint(a, b, 0.25));
      next.push(mixPoint(a, b, 0.75));
    }
    ring = next;
  }
  return ring;
}

function uniqueId(prefix = 'cloud') {
  return `${prefix}-${Math.random().toString(36).slice(2, 10)}`;
}

function makeCloudParticleTemplate({ family = 'stratiform', color = '#ffffff', tintColor = null, glowColor = null, opacity = 0.36, opacityMultiplier = null, darknessBlend = null, scale = 1, sparkle = 0.25, shear = 0, seed = 0 }) {
  const uid = uniqueId('cloud-particle');
  const familyStretch = family === 'cirriform' ? 1.75 : (family === 'stratiform' ? 1.32 : (family === 'vertical' ? 0.94 : 1.12));
  const familyLift = family === 'vertical' ? 1.32 : (family === 'cirriform' ? 0.78 : 1.0);
  const visualScale = Math.max(0.2, Number(scale || 1)) * CLOUD_PARTICLE_SIZE_SCALE;
  const width = Math.round(15 * visualScale * familyStretch);
  const height = Math.round(10 * visualScale * familyLift);
  const rot = Math.max(-28, Math.min(28, shear + ((seed - 0.5) * 10)));
  const partyTint = tintColor || null;
  const linkedOpacity = opacityMultiplier == null ? cloudParticleOpacityMultiplier() : clamp(toNumber(opacityMultiplier, 1), 0, 1);
  const linkedDarkness = darknessBlend == null ? cloudParticleDarknessBlend() : clamp(toNumber(darknessBlend, 1), 0, 1);
  const darkCoreBase = partyTint
    ? mixHexColors(partyTint, '#04070d', 0.78)
    : (family === 'cirriform' ? '#243041' : (family === 'vertical' ? '#111923' : '#18212c'));
  const midToneBase = partyTint
    ? mixHexColors(partyTint, '#dfe9ff', 0.18)
    : (family === 'cirriform' ? '#9fb3c9' : (family === 'vertical' ? '#52606c' : '#74808c'));
  const highlightBase = partyTint
    ? mixHexColors(partyTint, '#ffffff', 0.42)
    : (family === 'vertical' ? '#f0f6ff' : '#ffffff');
  const darkCore = mixHexColors(highlightBase, darkCoreBase, linkedDarkness);
  const midTone = mixHexColors(highlightBase, midToneBase, linkedDarkness);
  const highlight = highlightBase;
  const opacitySafe = linkedOpacity <= 0.0001 ? 0 : clamp(opacity * CLOUD_PARTICLE_OPACITY_SCALE * linkedOpacity, 0.0, 0.24);
  const coreOpacity = opacitySafe <= 0 ? 0 : Math.min(0.40, opacitySafe + 0.10 + sparkle * 0.025);
  const midOpacity = opacitySafe <= 0 ? 0 : Math.min(0.32, opacitySafe + 0.055 + sparkle * 0.022);
  const edgeOpacity = Math.max(0.0, opacitySafe * 0.08);
  const glowAlpha = CLOUD_PARTICLE_DROP_SHADOW_ENABLED && opacitySafe > 0 ? Math.min(partyTint ? 0.24 : 0.12, opacitySafe + (partyTint ? 0.06 : 0.025)) : 0;
  const glowResolved = glowColor || partyTint || '#060c14';
  const tpl = document.createElement('template');
  tpl.innerHTML = `
    <svg width="${width}" height="${height}" viewBox="0 0 72 46" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" data-cloud-particle-svg="true" style="pointer-events:none;overflow:visible;${CLOUD_PARTICLE_DROP_SHADOW_ENABLED ? `filter:drop-shadow(0 0 ${Math.round(3 + sparkle * 4)}px ${rgbaFromHex(glowResolved, glowAlpha)})` : 'filter:none'}">
      <defs>
        <radialGradient id="${uid}-core" cx="38%" cy="34%" r="82%">
          <stop offset="0%" stop-color="${highlight}" stop-opacity="${Math.min(0.46, coreOpacity).toFixed(2)}"/>
          <stop offset="36%" stop-color="${midTone}" stop-opacity="${midOpacity.toFixed(2)}"/>
          <stop offset="76%" stop-color="${darkCore}" stop-opacity="${coreOpacity.toFixed(2)}"/>
          <stop offset="100%" stop-color="${darkCore}" stop-opacity="${edgeOpacity.toFixed(2)}"/>
        </radialGradient>
        <linearGradient id="${uid}-underside" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stop-color="${highlight}" stop-opacity="${Math.min(0.20, opacitySafe + 0.05).toFixed(2)}"/>
          <stop offset="62%" stop-color="${darkCore}" stop-opacity="${Math.min(0.50, opacitySafe + 0.13).toFixed(2)}"/>
          <stop offset="100%" stop-color="#05070b" stop-opacity="${Math.min(0.42, opacitySafe + 0.10).toFixed(2)}"/>
        </linearGradient>
        <linearGradient id="${uid}-shear" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="${highlight}" stop-opacity="${Math.min(0.22, opacitySafe + 0.08).toFixed(2)}"/>
          <stop offset="100%" stop-color="${darkCore}" stop-opacity="0"/>
        </linearGradient>
      </defs>
      <g transform="rotate(${rot.toFixed(1)} 36 23)">
        <ellipse cx="36" cy="24" rx="34" ry="16" fill="url(#${uid}-core)" fill-opacity="${opacitySafe.toFixed(2)}"/>
        <ellipse cx="38" cy="29" rx="30" ry="12" fill="url(#${uid}-underside)" fill-opacity="${Math.min(0.52, opacitySafe + 0.12).toFixed(2)}"/>
        <ellipse cx="25" cy="16" rx="14" ry="6" fill="${highlight}" fill-opacity="${Math.min(0.25, opacitySafe + 0.055).toFixed(2)}"/>
        <ellipse cx="48" cy="18" rx="13" ry="6" fill="url(#${uid}-shear)" fill-opacity="${Math.min(0.30, opacitySafe + 0.05).toFixed(2)}"/>
      </g>
    </svg>`;
  return tpl;
}

function renderCloudParticleTemplateIntoMarker(marker, item, { partyColor = null } = {}) {
  if (!marker || !item) return marker;
  const opacityMultiplier = cloudParticleOpacityMultiplier();
  const darknessBlend = cloudParticleDarknessBlend();
  const template = makeCloudParticleTemplate({
    ...item,
    tintColor: partyColor || null,
    glowColor: partyColor || null,
    opacityMultiplier,
    darknessBlend,
  });
  try { marker.replaceChildren(template); } catch (_) {
    try {
      while (marker.firstChild) marker.removeChild(marker.firstChild);
      marker.append(template);
    } catch (__) {}
  }
  try {
    if (opacityMultiplier <= 0.0001) {
      marker.style.opacity = '0';
      marker.style.pointerEvents = 'none';
    } else {
      marker.style.opacity = '';
      marker.style.pointerEvents = '';
    }
    marker.setAttribute('data-cloud-particle-opacity-scale', opacityMultiplier.toFixed(3));
  } catch (_) {}
  return marker;
}

function applyCloudParticleVisualMode(marker) {
  if (!marker) return;
  const spec = marker.__gfsCloudParticleSpec || null;
  if (!spec) return;
  const sliderSig = `${cloudParticleOpacityMultiplier().toFixed(3)}:${cloudParticleDarknessBlend().toFixed(3)}`;
  if (cloudPartyModeEnabled()) {
    const partyColor = partyColorForParticleMarker(marker);
    if (marker.__gfsCloudParticleMode !== 'party' || marker.__gfsCloudParticlePartyColor !== partyColor || marker.__gfsCloudParticleSliderSig !== sliderSig) {
      renderCloudParticleTemplateIntoMarker(marker, spec, { partyColor });
      marker.__gfsCloudParticleMode = 'party';
      marker.__gfsCloudParticlePartyColor = partyColor;
      marker.__gfsCloudParticleSliderSig = sliderSig;
    }
    try {
      marker.style.filter = `drop-shadow(0 0 3px ${partyColor}) drop-shadow(0 0 8px ${partyColor}) drop-shadow(0 0 16px ${partyColor})`;
      marker.style.opacity = '';
    } catch (_) {}
  } else {
    if (marker.__gfsCloudParticleMode !== 'base' || marker.__gfsCloudParticleSliderSig !== sliderSig) {
      renderCloudParticleTemplateIntoMarker(marker, spec, { partyColor: null });
      marker.__gfsCloudParticleMode = 'base';
      marker.__gfsCloudParticlePartyColor = '';
      marker.__gfsCloudParticleSliderSig = sliderSig;
    }
    try { marker.style.filter = ''; marker.style.opacity = ''; } catch (_) {}
  }
}

function createCloudParticleMarker(item) {
  const marker = document.createElement('gmp-marker-3d');
  marker.position = { lat: item.lat, lng: item.lon, altitude: item.altitude };
  marker.drawsWhenOccluded = true;
  marker.sizePreserved = true;
  marker.setAttribute('data-gfs-layer', 'clouds');
  marker.setAttribute('data-cloud-particle', item.family || 'cloud');
  marker.setAttribute('data-cloud-party-key', item.partyKey || `${item.shellId || 'cloud'}|${item.family || 'cloud'}|${Math.round((item.seed || 0) * 100000)}`);
  marker.__gfsCloudParticleSpec = { ...item };
  marker.__gfsCloudParticleMode = 'base';
  renderCloudParticleTemplateIntoMarker(marker, item, { partyColor: null });
  applyCloudParticleVisualMode(marker);
  return marker;
}

function cloudParticleCount(layer) {
  const weight = clamp(toNumber(layer?.opacity, 0.15) * 3.8, 0.25, 2.2);
  const familyBonus = layer?.family === 'vertical' ? 5 : (layer?.family === 'cumuliform' ? 3 : (layer?.family === 'cirriform' ? 2 : 1));
  const footprintBoost = clamp((toNumber(layer?.latRadiusDeg, 0.04) + toNumber(layer?.lonRadiusDeg, 0.04)) * 12, 0, 4);
  const baseCount = clamp(Math.round(2 + weight * 2.1 + familyBonus + footprintBoost), 2, 9);
  const mobile = /android|iphone|ipad|mobile/i.test(navigator.userAgent || '');
  return clamp(Math.round(baseCount * CLOUD_PARTICLE_MULTIPLIER), mobile ? 3 : 5, mobile ? 12 : 22);
}

function buildCloudParticlesForBody(body, layer, particleBudget) {
  if (!CLOUD_PARTICLE_RENDERER_ENABLED) return [];
  if (!body || particleBudget.remaining <= 0) return [];
  const particles = [];
  const count = Math.min(cloudParticleCount(layer), particleBudget.remaining);
  const heading = windHeadingDeg(body.windU, body.windV) * Math.PI / 180;
  const cosH = Math.cos(heading);
  const sinH = Math.sin(heading);
  const innerLatRadius = Math.max(0.006, toNumber(layer.latRadiusDeg, 0.04) * CLOUD_PARTICLE_INSET_SCALE);
  const innerLonRadius = Math.max(0.006, toNumber(layer.lonRadiusDeg, 0.04) * CLOUD_PARTICLE_INSET_SCALE);
  const shellHeight = Math.max(300, toNumber(layer.height, 900));
  const baseAltitude = toNumber(layer.baseAltitude, 1500);
  const topAltitude = Math.max(baseAltitude + 50, toNumber(layer.topAltitude, baseAltitude + shellHeight));
  const cloudFraction = normalizeFraction(layer.cloudFraction ?? layer.cover ?? layer.coverage, clamp(toNumber(layer.opacity, 0.12) * 3.8, 0.22, 0.92));
  const opacity = clamp((0.05 + cloudFraction * 0.26) * (0.88 + toNumber(layer.opacity, 0.12) * 0.5), 0.06, 0.42);
  for (let idx = 0; idx < count; idx += 1) {
    const seed = hashJitter(body.anchorLat, body.anchorLon, idx + baseAltitude * 0.001 + shellHeight * 0.0001);
    const theta = (seed + idx / Math.max(1, count)) * Math.PI * 2;
    const r = Math.pow(hashJitter(body.anchorLon, body.anchorLat, idx + 12), 0.62) * 0.92;
    const band = 0.72 + hashJitter(body.anchorLat, body.anchorLon, idx + 18) * 0.42;
    const localLat = Math.sin(theta) * innerLatRadius * r * band;
    const localLon = Math.cos(theta) * innerLonRadius * r * (0.84 + hashJitter(body.anchorLon, body.anchorLat, idx + 24) * 0.38);
    const rotLat = (localLat * cosH) - (localLon * sinH);
    const rotLon = (localLat * sinH) + (localLon * cosH);
    const verticalSeed = hashJitter(body.anchorLat, body.anchorLon, idx + 43);
    // Deliberately seed particles through bottom/mid/top bands so the filled
    // cap surfaces read as textured cloud mass, not empty lids with outline.
    const capBand = idx % 3;
    const vertical = capBand === 0
      ? clamp(0.08 + verticalSeed * 0.22, 0.06, 0.34)
      : (capBand === 1
        ? clamp(0.39 + verticalSeed * 0.24, 0.34, 0.68)
        : clamp(0.72 + verticalSeed * 0.24, 0.66, 0.98));
    const pressureHpa = pressureAtFraction(layer.basePressureHpa, layer.topPressureHpa, vertical);
    const pressureAltitude = Number.isFinite(pressureHpa) ? pressureToHeightMeters(pressureHpa) : NaN;
    const linearAltitude = baseAltitude + ((topAltitude - baseAltitude) * vertical);
    const altitude = Math.round(Number.isFinite(pressureAltitude) ? clamp(pressureAltitude, Math.min(baseAltitude, topAltitude), Math.max(baseAltitude, topAltitude)) : linearAltitude);
    const particleOpacity = clamp(opacity * (0.78 + cloudFraction * 0.44) * (0.82 + hashJitter(body.anchorLon, body.anchorLat, idx + 171) * 0.24) * (0.84 + vertical * 0.18), 0.05, 0.50);
    particles.push({
      lat: body.anchorLat + rotLat,
      lon: wrapLongitude(body.anchorLon + rotLon),
      altitude,
      anchorLat: body.anchorLat,
      anchorLon: body.anchorLon,
      baseLocalLat: rotLat,
      baseLocalLon: rotLon,
      baseAltitude: altitude,
      shellId: body.shellId,
      shellHeight,
      windU: body.windU,
      windV: body.windV,
      localU: (hashJitter(body.anchorLat, body.anchorLon, idx + 70) - 0.5) * 0.72,
      localV: (hashJitter(body.anchorLon, body.anchorLat, idx + 84) - 0.5) * 0.72,
      wobblePhase: hashJitter(body.anchorLat, body.anchorLon, idx + 101) * Math.PI * 2,
      wobbleRate: 0.18 + hashJitter(body.anchorLon, body.anchorLat, idx + 111) * 0.42,
      wobbleLatAmp: innerLatRadius * (0.035 + hashJitter(body.anchorLat, body.anchorLon, idx + 121) * 0.075),
      wobbleLonAmp: innerLonRadius * (0.035 + hashJitter(body.anchorLon, body.anchorLat, idx + 131) * 0.075),
      latOffsetDeg: 0,
      lonOffsetDeg: 0,
      family: layer.family || 'stratiform',
      color: layer.color || '#ffffff',
      opacity: particleOpacity,
      cloudFraction,
      scale: (0.60 + hashJitter(body.anchorLat, body.anchorLon, idx + 151) * 0.98) * (0.88 + cloudFraction * 0.28),
      sparkle: hashJitter(body.anchorLon, body.anchorLat, idx + 159),
      shear: clamp((body.windU || 0) * 0.7, -18, 18),
      seed: hashJitter(body.anchorLat, body.anchorLon, idx + 167),
      partyKey: `${body.shellId || 'cloud'}|${layer.family || 'cloud'}|${idx}`,
      marker: null,
    });
  }
  particleBudget.remaining -= particles.length;
  return particles;
}

function to2DGrid(value) {
  if (!Array.isArray(value)) return [];
  if (!Array.isArray(value[0])) return [];
  if (Array.isArray(value[0][0])) return value[0];
  return value;
}

function bboxFromPayload(payload) {
  const candidates = [payload?.bbox, payload?.bbox_used, payload?.viewport_bbox, payload?.meta?.bbox, payload?.meta?.bbox_used];
  for (const value of candidates) {
    if (Array.isArray(value) && value.length >= 4) {
      return { west: toNumber(value[0]), south: toNumber(value[1]), east: toNumber(value[2]), north: toNumber(value[3]) };
    }
    if (value && typeof value === 'object') {
      const west = toNumber(value.west, NaN);
      const south = toNumber(value.south, NaN);
      const east = toNumber(value.east, NaN);
      const north = toNumber(value.north, NaN);
      if ([west, south, east, north].every(Number.isFinite)) return { west, south, east, north };
    }
  }
  const items = Array.isArray(payload?.items) ? payload.items : [];
  const b = items.map((item) => item?.bounds || {}).filter(Boolean);
  const west = Math.min(...b.map((x) => toNumber(x.lon_min, Infinity)));
  const south = Math.min(...b.map((x) => toNumber(x.lat_min, Infinity)));
  const east = Math.max(...b.map((x) => toNumber(x.lon_max, -Infinity)));
  const north = Math.max(...b.map((x) => toNumber(x.lat_max, -Infinity)));
  if ([west, south, east, north].every(Number.isFinite)) return { west, south, east, north };
  return null;
}


function normalizeFeatureCenter(feature, bbox = null) {
  const safe = feature || {};
  let lat = toNumber(safe.lat ?? safe.latitude ?? safe.anchorLat ?? safe.centerLat ?? safe.center?.lat, NaN);
  let lon = toNumber(safe.lon ?? safe.lng ?? safe.longitude ?? safe.anchorLon ?? safe.centerLon ?? safe.center?.lon ?? safe.center?.lng, NaN);
  if (!Number.isFinite(lat) || !Number.isFinite(lon)) return null;

  // Catch the common swapped-coordinate failure: {lat:-118, lon:34}.
  if ((lat < -90 || lat > 90) && lon >= -90 && lon <= 90) {
    const oldLat = lat;
    lat = lon;
    lon = oldLat;
  }
  if (lat < -90 || lat > 90) return null;
  lon = wrapLongitude(lon);
  if (bbox && !pointNearBbox(lat, lon, bbox)) return null;
  return { lat, lon };
}

function bboxPadDeg(bbox) {
  if (!bbox) return { lat: 0.5, lon: 0.5 };
  const latSpan = Math.abs(toNumber(bbox.north, 0) - toNumber(bbox.south, 0));
  const lonSpan = Math.abs(toNumber(bbox.east, 0) - toNumber(bbox.west, 0));
  return {
    lat: clamp(latSpan * 0.18, 0.35, 3.5),
    lon: clamp(lonSpan * 0.18, 0.35, 5.0),
  };
}

function pointNearBbox(lat, lon, bbox) {
  if (!bbox) return true;
  const pad = bboxPadDeg(bbox);
  const south = Math.min(bbox.south, bbox.north) - pad.lat;
  const north = Math.max(bbox.south, bbox.north) + pad.lat;
  if (lat < south || lat > north) return false;
  const west = wrapLongitude(bbox.west - pad.lon);
  const east = wrapLongitude(bbox.east + pad.lon);
  const x = wrapLongitude(lon);
  if (west <= east) return x >= west && x <= east;
  return x >= west || x <= east;
}


export function cloudPayloadHasDrawableContent(payload) {
  if (!payload) return false;
  const seaCloudLayer = payload?.layers?.clouds || payload?.seaIntelligence?.layers?.clouds || null;
  if (seaCloudLayer && Array.isArray(seaCloudLayer.features) && seaCloudLayer.features.length) return true;
  if (Array.isArray(payload?.polygon_field_v1?.features) && payload.polygon_field_v1.features.length) return true;
  const items = (Array.isArray(payload?.tiles) && payload.tiles.length) ? payload.tiles : (Array.isArray(payload?.items) ? payload.items : []);
  if (items.length) return true;
  if (Array.isArray(payload?.scene?.clouds) && payload.scene.clouds.length) return true;
  if (Array.isArray(payload?.cloud_regions) && payload.cloud_regions.length) return true;
  const layers = Array.isArray(payload?.cloud_layers) ? payload.cloud_layers : [];
  if (layers.some((l) => Array.isArray(l?.density) && l.density.length)) return true;
  const fields = payload?.fields || {};
  return Boolean(fields.cloud_total || fields.cloud_low || fields.cloud_mid || fields.cloud_high || payload?.cloud_cover);
}

function cloudPayloadState(payload) {
  return String(payload?.source_state || payload?.payload_state || payload?.status || '').toLowerCase();
}

function stableCloudTileJitter(item, bbox = null) {
  const bounds = item?.bounds || {};
  const center = item?.center || {};
  const lat = toNumber(bounds.lat_center ?? center.lat ?? item?.lat, 0);
  const lon = toNumber(bounds.lon_center ?? center.lon ?? center.lng ?? item?.lon ?? item?.lng, 0);
  const cellLat = Math.max(0.0001, Math.abs(toNumber(bounds.lat_max, lat) - toNumber(bounds.lat_min, lat)));
  const cellLon = Math.max(0.0001, Math.abs(toNumber(bounds.lon_max, lon) - toNumber(bounds.lon_min, lon)));
  const tileKey = String(item?.tile_id || item?.id || `${lat.toFixed(4)}:${lon.toFixed(4)}`);
  let salt = 0;
  for (let i = 0; i < tileKey.length; i += 1) salt += tileKey.charCodeAt(i) * (i + 1);
  const j1 = hashJitter(lat, lon, salt + 11) - 0.5;
  const j2 = hashJitter(lon, lat, salt + 29) - 0.5;
  const scale = CLOUD_GRID_JITTER_FRACTION;
  return {
    lat: j1 * cellLat * scale,
    lon: j2 * cellLon * scale,
    cellLat,
    cellLon,
    salt,
  };
}

function organicizeCloudPath(path, seedLat, seedLon, salt = 0, jitter = null) {
  if (!Array.isArray(path) || path.length < 3) return path || [];
  const center = ringCenterAndScale(path);
  const latShift = toNumber(jitter?.lat, 0);
  const lonShift = toNumber(jitter?.lon, 0);
  const maxLatWarp = Math.max(0.001, toNumber(jitter?.cellLat, center.latRadiusDeg || 0.02) * 0.10);
  const maxLonWarp = Math.max(0.001, toNumber(jitter?.cellLon, center.lonRadiusDeg || 0.02) * 0.10);
  const warped = path.map((pt, idx) => {
    const phase = (idx / Math.max(1, path.length)) * Math.PI * 2;
    const n1 = hashJitter(seedLat + idx * 0.017, seedLon - idx * 0.019, salt + idx * 7) - 0.5;
    const n2 = hashJitter(seedLon - idx * 0.013, seedLat + idx * 0.011, salt + idx * 13) - 0.5;
    const radial = 0.72 + 0.28 * Math.sin(phase * 2.0 + salt * 0.01);
    return {
      lat: pt.lat + latShift + n1 * maxLatWarp * radial,
      lng: wrapLongitude(pt.lng + lonShift + n2 * maxLonWarp * radial),
    };
  });
  return smoothClosedCloudPath(warped, CLOUD_PATH_SMOOTHING_ITERATIONS);
}

function clearCloudLayerNodes(map3DElement = null) {
  const roots = [];
  if (map3DElement) roots.push(map3DElement);
  if (typeof document !== 'undefined') roots.push(document);
  const selectors = [
    '[data-gfs-layer="clouds"]',
    '[data-cloud-shell]',
    '[data-cloud-particle]',
    '[data-gfs-layer="ocean-fx"]',
    '[data-ocean-fx-kind]',
    'gmp-marker-3d[data-cloud-particle]',
    'gmp-polygon-3d[data-cloud-shell]',
  ].join(',');
  for (const root of roots) {
    try {
      root.querySelectorAll?.(selectors)?.forEach((el) => {
        try { el.remove(); } catch (_) {}
      });
    } catch (_) {}
  }
}

if (typeof window !== 'undefined') {
  window.__gfsPartyTime = window.__gfsPartyTime === true;
  window.__gfsPartyTimePhase = 0;
  window.clearGfsCloudLayer = function clearGfsCloudLayer() {
    clearCloudLayerNodes(document.querySelector('gmp-map-3d') || document.querySelector('gmp-map') || null);
  };
  window.setCloudPartyMode = function setCloudPartyMode(enabled) {
    window.__gfsPartyTime = enabled === true;
    if (window.__gfsPartyTime !== true) window.__gfsPartyTimePhase = 0;
    applyCloudPartyModeToDom(document.querySelector('gmp-map-3d') || document);
    return window.__gfsPartyTime;
  };
}

function densityPercent(value) {
  const n = toNumber(value, 0);
  if (n <= 1.25) return clamp(n * 100, 0, 100);
  return clamp(n, 0, 100);
}

function tileFromCloudRegion(region) {
  if (!region || typeof region !== 'object') return null;
  const c = region.center || {};
  const b = region.bbox || {};
  const intensity = region.intensity || {};
  const wind = region.wind || {};
  return {
    id: region.id,
    tile_id: region.id,
    bounds: {
      lat_center: c.lat,
      lon_center: c.lon,
      lat_min: b.south,
      lat_max: b.north,
      lon_min: b.west,
      lon_max: b.east,
    },
    low_density: intensity.low,
    mid_density: intensity.mid,
    high_density: intensity.high,
    coverage: toNumber(intensity.total, 0) * 100,
    precip_rate: toNumber(intensity.rain, 0),
    wind: { mid: { u: wind.u, v: wind.v } },
    cloud_type: region.cloud_type,
    regime: region.family,
    method: region.method || 'cloud_region_marching_squares_v1',
    cloud_region: region,
    region_footprint: region.footprint || [],
  };
}

function cloudTileFeatures(payload, bbox = null) {
  let items = Array.isArray(payload?.tiles) && payload.tiles.length
    ? payload.tiles
    : (Array.isArray(payload?.items) && payload.items.length ? payload.items : []);
  if ((!items || !items.length) && Array.isArray(payload?.cloud_regions) && payload.cloud_regions.length) {
    items = payload.cloud_regions.map(tileFromCloudRegion).filter(Boolean);
  }
  const out = [];
  for (const item of items) {
    const bounds = item?.bounds || {};
    const center = item?.center || {};
    const normalizedCenter = normalizeFeatureCenter({
      lat: bounds.lat_center ?? center.lat ?? item.lat,
      lon: bounds.lon_center ?? center.lon ?? center.lng ?? item.lon ?? item.lng,
    }, bbox);
    if (!normalizedCenter) continue;
    const { lat, lon } = normalizedCenter;
    const hints = Array.isArray(item.layer_hints) ? item.layer_hints : [];
    const lowHint = hints.find((x) => x?.band === 'low') || {};
    const midHint = hints.find((x) => x?.band === 'mid') || {};
    const highHint = hints.find((x) => x?.band === 'high') || {};
    const low = densityPercent(item.low_density ?? item.cloud_low ?? item.bands?.low?.density ?? lowHint.density);
    const mid = densityPercent(item.mid_density ?? item.cloud_mid ?? item.bands?.mid?.density ?? midHint.density);
    const high = densityPercent(item.high_density ?? item.cloud_high ?? item.bands?.high?.density ?? highHint.density);
    const total = densityPercent(item.coverage ?? item.cloud_total ?? item.estimated_density ?? Math.max(low, mid, high));
    const precip = toNumber(item.precip_rate ?? item.precipitation_factor ?? item.rain_factor ?? item.source_fields?.proxy_precip_rate, 0);
    const wind = item.wind || {};
    const windMid = wind.mid || wind.low || wind.high || {};
    const jitter = stableCloudTileJitter(item, bbox);
    const jitteredCenter = normalizeFeatureCenter({ lat: lat + jitter.lat, lon: lon + jitter.lon }, bbox) || { lat, lon };
    out.push({
      lat: jitteredCenter.lat,
      lon: jitteredCenter.lon,
      grid_lat: lat,
      grid_lon: lon,
      _organicJitter: jitter,
      cloud_low: low,
      cloud_mid: mid,
      cloud_high: high,
      cloud_total: Math.max(total, low, mid, high),
      precip_rate: precip,
      wind_u: toNumber(windMid.u ?? item.wind_u, 0),
      wind_v: toNumber(windMid.v ?? item.wind_v, 0),
      cell_lat_deg: Math.max(Math.abs(toNumber(bounds.lat_max, lat) - toNumber(bounds.lat_min, lat)), 0.04),
      cell_lon_deg: Math.max(Math.abs(toNumber(bounds.lon_max, lon) - toNumber(bounds.lon_min, lon)), 0.04),
      tile_id: item.tile_id || item.id || `${lat.toFixed(3)}:${lon.toFixed(3)}`,
      rawTile: item,
      _serverShellsAvailable: !!(item?.bands && Object.values(item.bands).some((b) => Array.isArray(b?.shells) && b.shells.length && Array.isArray(b?.footprints))),
      _cloudRegionMethod: item.method || item.source_method || item.cloud_region?.method || null,
    });
  }
  return out;
}

function latLonFromIndex(i, j, ny, nx, bbox) {
  const lat = bbox.south + ((i + 0.5) / Math.max(1, ny)) * (bbox.north - bbox.south);
  const lon = bbox.west + ((j + 0.5) / Math.max(1, nx)) * (bbox.east - bbox.west);
  return { lat, lon };
}

function contourPathFromFeature(feature, altitude = 0) {
  const raw = Array.isArray(feature?.path) ? feature.path : [];
  const path = [];
  for (const pt of raw) {
    const lat = toNumber(pt?.lat ?? pt?.latitude, NaN);
    const lng = toNumber(pt?.lng ?? pt?.lon ?? pt?.longitude, NaN);
    const alt = toNumber(pt?.altitude ?? pt?.altitude_m, altitude);
    if (!Number.isFinite(lat) || !Number.isFinite(lng) || lat < -90 || lat > 90 || lng < -180 || lng > 180) continue;
    const prev = path[path.length - 1];
    if (prev && Math.abs(prev.lat - lat) < 1e-8 && Math.abs(prev.lng - lng) < 1e-8) continue;
    path.push({ lat, lng, altitude: Number.isFinite(alt) ? alt : altitude });
  }
  if (path.length >= 2) {
    const first = path[0];
    const last = path[path.length - 1];
    if (Math.abs(first.lat - last.lat) < 1e-8 && Math.abs(first.lng - last.lng) < 1e-8) path.pop();
  }
  return path.length >= 3 ? smoothClosedCloudPath(path, CLOUD_PATH_SMOOTHING_ITERATIONS) : [];
}

function featureCentroidFromPath(path) {
  if (!Array.isArray(path) || !path.length) return null;
  let lat = 0;
  let lon = 0;
  for (const p of path) { lat += toNumber(p.lat, 0); lon += toNumber(p.lng, 0); }
  return { lat: lat / path.length, lon: lon / path.length };
}

function seaContourCloudFeatures(payload) {
  const raw = Array.isArray(payload?.polygon_field_v1?.features)
    ? payload.polygon_field_v1.features
    : (Array.isArray(payload?.layers?.clouds?.features) ? payload.layers.clouds.features : []);
  const features = [];
  for (const feature of raw) {
    if (!Array.isArray(feature?.path) || feature.path.length < 3) continue;
    const path = contourPathFromFeature(feature, toNumber(feature.altitude_m, 2600));
    if (path.length < 3) continue;
    const centroid = featureCentroidFromPath(path);
    if (!centroid) continue;
    features.push({ ...feature, path, lat: centroid.lat, lon: centroid.lon });
  }
  return features;
}

function cellSizeDeg(bbox, ny, nx) {
  return {
    lat: Math.abs((bbox.north - bbox.south) / Math.max(1, ny)),
    lon: Math.abs((bbox.east - bbox.west) / Math.max(1, nx)),
  };
}

function hashJitter(lat, lon, salt = 0) {
  const v = Math.sin((lat * 12.9898) + (lon * 78.233) + (salt * 19.19)) * 43758.5453;
  return v - Math.floor(v);
}

function pressureToHeightMeters(hpa) {
  const pressure = clamp(toNumber(hpa, 1013.25), 80, 1050);
  return 44330 * (1 - Math.pow(pressure / 1013.25, 0.1903));
}

function metersToLatDegrees(meters) {
  return meters / 111320;
}

function metersToLonDegrees(meters, lat) {
  const lonScale = Math.max(0.2, Math.cos((Number(lat) * Math.PI) / 180));
  return meters / (111320 * lonScale);
}

function cloudPathAttrString(path, fallbackAltitude = 0) {
  return (Array.isArray(path) ? path : [])
    .map((p) => {
      const lat = toNumber(p?.lat ?? p?.latitude, NaN);
      const lng = wrapLongitude(toNumber(p?.lng ?? p?.lon ?? p?.longitude, NaN));
      const altitude = toNumber(p?.altitude ?? p?.altitude_m ?? p?.alt ?? p?.z, fallbackAltitude);
      if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
      if (lat < -90 || lat > 90 || lng < -180 || lng >= 180) return null;
      return `${lat.toFixed(8)},${lng.toFixed(8)},${(Number.isFinite(altitude) ? altitude : fallbackAltitude).toFixed(2)}`;
    })
    .filter(Boolean)
    .join(' ');
}

function setCloudElementPath(element, path, fallbackAltitude = 0) {
  if (!element || !Array.isArray(path) || path.length < 3) return false;
  const safePath = path
    .map((p) => {
      const lat = toNumber(p?.lat ?? p?.latitude, NaN);
      const lng = wrapLongitude(toNumber(p?.lng ?? p?.lon ?? p?.longitude, NaN));
      const altitude = toNumber(p?.altitude ?? p?.altitude_m ?? p?.alt ?? p?.z, fallbackAltitude);
      if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
      if (lat < -90 || lat > 90 || lng < -180 || lng >= 180) return null;
      return { lat, lng, altitude: Number.isFinite(altitude) ? altitude : fallbackAltitude };
    })
    .filter(Boolean);
  if (safePath.length < 3) return false;
  const attrPath = cloudPathAttrString(safePath, fallbackAltitude);
  if (!attrPath) return false;
  try { element.path = safePath; } catch (_) {}
  try { element.setAttribute?.('path', attrPath); } catch (_) {}
  try { element.setAttribute?.('data-gfs-path-points', String(safePath.length)); } catch (_) {}
  return true;
}

function advectPath(basePath, latOffsetDeg, lonOffsetDeg, fallbackAltitude = 0) {
  return (Array.isArray(basePath) ? basePath : []).map((point) => ({
    lat: toNumber(point?.lat ?? point?.latitude, 0) + latOffsetDeg,
    lng: wrapLongitude(toNumber(point?.lng ?? point?.lon ?? point?.longitude, 0) + lonOffsetDeg),
    altitude: toNumber(point?.altitude ?? point?.altitude_m ?? point?.alt ?? point?.z, fallbackAltitude),
  }));
}

function roundedCloudPath({ lat, lon, latRadiusDeg, lonRadiusDeg, wobble = 0.18, points = 14, elongation = 1, headingDeg = 90 }) {
  const path = [];
  const basePhase = hashJitter(lat, lon) * Math.PI * 2;
  const heading = (headingDeg * Math.PI) / 180;
  const cosH = Math.cos(heading);
  const sinH = Math.sin(heading);
  for (let i = 0; i < points; i += 1) {
    const t = (i / points) * Math.PI * 2;
    const harmonic = Math.sin((t * 2) + basePhase) * wobble;
    const secondary = Math.cos((t * 3) - basePhase) * (wobble * 0.55);
    const scale = 1 + harmonic + secondary;
    const localLat = Math.sin(t) * latRadiusDeg * scale;
    const localLon = Math.cos(t) * lonRadiusDeg * scale * elongation;
    const rotLat = (localLat * cosH) - (localLon * sinH);
    const rotLon = (localLat * sinH) + (localLon * cosH);
    path.push({ lat: lat + rotLat, lng: lon + rotLon });
  }
  return smoothClosedCloudPath(path, 1, CLOUD_PATH_SMOOTHING_MAX_POINTS);
}

function buildCloudPressureBand(type, density, totalBoost, family = 'stratiform') {
  const band = CLOUD_PRESSURE_BANDS[type] || CLOUD_PRESSURE_BANDS.total;
  const weight = clamp(density / 100, 0, 1);
  const deepening = clamp((totalBoost - 0.82) / 0.45, 0, 1);
  const familyStretch = family === 'vertical' ? 1.55 : (family === 'cumuliform' ? 1.34 : (family === 'cirriform' ? 0.96 : 1.16));
  const baseHpa = band.baseHpa - ((band.baseHpa - band.topHpa) * weight * 0.16);
  const topHpa = band.topHpa - ((band.topHpa * 0.07) * deepening * weight * familyStretch);
  const baseAltitude = pressureToHeightMeters(baseHpa);
  const topAltitude = pressureToHeightMeters(topHpa);
  return {
    baseAltitude: Math.round(baseAltitude),
    topAltitude: Math.round(topAltitude),
    height: Math.max(850, Math.round((topAltitude - baseAltitude) * familyStretch * CLOUD_HEIGHT_VISUAL_SCALE)),
    color: band.color,
    weight,
    baseHpa,
    topHpa,
  };
}

function classifyCloudMorphology(feature) {
  const low = toNumber(feature?.cloud_low, 0);
  const mid = toNumber(feature?.cloud_mid, 0);
  const high = toNumber(feature?.cloud_high, 0);
  const total = toNumber(feature?.cloud_total, Math.max(low, mid, high));
  const precip = toNumber(feature?.precip_rate, 0);
  const dominant = high >= Math.max(low, mid) ? 'high' : (mid >= low ? 'mid' : 'low');

  if (precip >= 0.85 && total >= 72) return { family: 'vertical', subtype: 'cumulonimbus' };
  if (precip >= 0.35 && mid >= 45 && total >= 68) return { family: 'stratiform', subtype: 'nimbostratus' };
  if (high >= 58 && low < 35 && mid < 45) return { family: 'cirriform', subtype: high >= 78 ? 'cirrostratus' : 'cirrus' };
  if (low >= 58 && total < 75) return { family: 'cumuliform', subtype: low >= 78 ? 'towering-cumulus' : 'cumulus' };
  if (dominant === 'mid' && total >= 62) return { family: 'stratiform', subtype: 'altostratus' };
  return { family: 'stratiform', subtype: total >= 60 ? 'stratus' : 'stratocumulus' };
}

function shellBlueprints(morphology) {
  switch (morphology.family) {
    case 'cirriform':
      return [
        { shell: 'veil', latScale: 0.82, lonScale: 1.8, opacityBase: 0.045, opacitySpan: 0.045, wobble: 0.12, points: 16, elongation: 1.6 },
        { shell: 'streak', latScale: 0.56, lonScale: 1.45, opacityBase: 0.03, opacitySpan: 0.035, wobble: 0.08, points: 12, elongation: 1.9 },
      ];
    case 'vertical':
      return [
        { shell: 'core', latScale: 0.72, lonScale: 0.76, opacityBase: 0.09, opacitySpan: 0.10, wobble: 0.2, points: 14, elongation: 1.0 },
        { shell: 'tower', latScale: 0.5, lonScale: 0.54, opacityBase: 0.08, opacitySpan: 0.08, wobble: 0.24, points: 12, elongation: 0.92, baseLift: 0.22, heightBoost: 0.42 },
        { shell: 'anvil', latScale: 0.96, lonScale: 1.42, opacityBase: 0.052, opacitySpan: 0.06, wobble: 0.16, points: 16, elongation: 1.25, baseLift: 0.78, heightBoost: 0.18 },
      ];
    case 'cumuliform':
      return [
        { shell: 'body', latScale: 0.7, lonScale: 0.84, opacityBase: 0.075, opacitySpan: 0.10, wobble: 0.24, points: 14, elongation: 1.0 },
        { shell: 'tuft', latScale: 0.46, lonScale: 0.5, opacityBase: 0.055, opacitySpan: 0.075, wobble: 0.3, points: 11, elongation: 0.94, baseLift: 0.38, heightBoost: 0.26 },
      ];
    default:
      return [
        { shell: 'deck', latScale: 0.96, lonScale: 1.3, opacityBase: 0.07, opacitySpan: 0.09, wobble: 0.14, points: 16, elongation: 1.18 },
        { shell: 'underside', latScale: 0.82, lonScale: 1.08, opacityBase: 0.04, opacitySpan: 0.055, wobble: 0.1, points: 14, elongation: 1.12, baseLift: 0.14, heightBoost: 0.08 },
      ];
  }
}


function parseCssColorAndOpacity(value, fallbackColor = '#ffffff', fallbackOpacity = 0.25) {
  const text = String(value || '').trim();
  const m = text.match(/^rgba?\(([^)]+)\)$/i);
  if (m) {
    const parts = m[1].split(',').map((x) => x.trim());
    const r = clamp(Math.round(toNumber(parts[0], 255)), 0, 255);
    const g = clamp(Math.round(toNumber(parts[1], 255)), 0, 255);
    const b = clamp(Math.round(toNumber(parts[2], 255)), 0, 255);
    const a = parts.length >= 4 ? clamp(toNumber(parts[3], fallbackOpacity), 0, 1) : fallbackOpacity;
    return { color: `rgb(${r}, ${g}, ${b})`, opacity: a };
  }
  return { color: text || fallbackColor, opacity: fallbackOpacity };
}

function normalizeBackendRing(points, bbox = null) {
  const out = [];
  for (const p of Array.isArray(points) ? points : []) {
    const lat = toNumber(p?.lat, NaN);
    const lon = wrapLongitude(toNumber(p?.lng ?? p?.lon, NaN));
    if (!Number.isFinite(lat) || !Number.isFinite(lon)) continue;
    if (lat < -90 || lat > 90 || lon < -180 || lon >= 180) continue;
    if (bbox && (lat < bbox.south - 0.25 || lat > bbox.north + 0.25 || lon < bbox.west - 0.25 || lon > bbox.east + 0.25)) continue;
    const prev = out[out.length - 1];
    if (prev && Math.abs(prev.lat - lat) < 1e-8 && Math.abs(prev.lng - lon) < 1e-8) continue;
    out.push({ lat, lng: lon });
  }
  if (out.length >= 4) {
    const a = out[0];
    const b = out[out.length - 1];
    if (Math.abs(a.lat - b.lat) < 1e-8 && Math.abs(a.lng - b.lng) < 1e-8) out.pop();
  }
  return out.length >= 3 ? out : [];
}

function ringCenterAndScale(path) {
  if (!Array.isArray(path) || path.length < 3) return { lat: 0, lon: 0, latRadiusDeg: 0.04, lonRadiusDeg: 0.04 };
  let minLat = 90; let maxLat = -90; let minLon = 180; let maxLon = -180; let sumLat = 0; let sumLon = 0;
  for (const p of path) {
    minLat = Math.min(minLat, p.lat); maxLat = Math.max(maxLat, p.lat);
    minLon = Math.min(minLon, p.lng); maxLon = Math.max(maxLon, p.lng);
    sumLat += p.lat; sumLon += p.lng;
  }
  return {
    lat: sumLat / path.length,
    lon: sumLon / path.length,
    latRadiusDeg: Math.max(0.006, (maxLat - minLat) * 0.5),
    lonRadiusDeg: Math.max(0.006, (maxLon - minLon) * 0.5),
  };
}

function serverCloudShellLayersFromTile(tile, bbox = null, feature = null) {
  const out = [];
  const bands = tile?.bands || {};
  const regime = tile?.regime || 'cloud';
  for (const bandName of ['low', 'mid', 'high']) {
    const band = bands?.[bandName];
    if (!band || !Array.isArray(band.shells) || !Array.isArray(band.footprints)) continue;
    const wind = band.wind || {};
    for (const shell of band.shells) {
      const fp = band.footprints?.[Number(shell.footprint_ref) || 0];
      const rawPath = normalizeBackendRing(fp?.points, bbox);
      if (rawPath.length < 3) continue;
      const jitter = feature?._organicJitter || stableCloudTileJitter(tile, bbox);
      const path = organicizeCloudPath(rawPath, toNumber(feature?.grid_lat ?? feature?.lat ?? tile?.lat, 0), toNumber(feature?.grid_lon ?? feature?.lon ?? tile?.lon, 0), toNumber(jitter?.salt, 0) + toNumber(shell.z_index, 0) + bandName.length * 31, jitter);
      const center = ringCenterAndScale(path);
      const fill = parseCssColorAndOpacity(shell.fill, '#eef6ff', 0.22);
      const rawFillOpacity = clamp(fill.opacity, 0.08, 0.62);
      const stroke = parseCssColorAndOpacity(shell.stroke, fill.color, 0.06);
      stroke.opacity = clamp(stroke.opacity * 0.45, 0.04, 0.16);
      const baseAltitude = Math.max(0, toNumber(shell.base_m, band.base_altitude_m || 1200));
      const topAltitude = Math.max(baseAltitude + 50, toNumber(shell.top_m, band.top_altitude_m || baseAltitude + 900));
      const fracRaw = shell.cloud_fraction ?? shell.cover_fraction ?? shell.coverage ?? shell.cover ?? feature?.cloud_total ?? tile?.cloud_total ?? 60;
      const cloudFraction = normalizeFraction(fracRaw, 0.62);
      const pressureBandCfg = CLOUD_PRESSURE_BANDS[bandName] || CLOUD_PRESSURE_BANDS.total;
      out.push({
        path,
        lat: center.lat,
        lon: center.lon,
        baseAltitude,
        topAltitude,
        height: Math.max(50, topAltitude - baseAltitude),
        latRadiusDeg: center.latRadiusDeg,
        lonRadiusDeg: center.lonRadiusDeg,
        color: fill.color,
        opacity: cloudShellFillOpacity({ baseOpacity: rawFillOpacity, cloudFraction, shell: shell.role || 'shell', family: regime }),
        cloudFraction,
        strokeColor: stroke.color,
        strokeOpacity: cloudShellCapShadeOpacity({ cloudFraction, shell: shell.role || 'shell' }),
        basePressureHpa: pressureBandCfg.baseHpa,
        topPressureHpa: pressureBandCfg.topHpa,
        strokeWidth: toNumber(shell.stroke_width, 0.5),
        pressureBand: bandName,
        family: regime,
        subtype: shell.role || bandName,
        shell: shell.role || 'shell',
        windU: toNumber(wind.u, 0),
        windV: toNumber(wind.v, 0),
        zIndex: toNumber(shell.z_index, 0),
      });
    }
  }
  out.sort((a, b) => a.zIndex - b.zIndex);
  return out;
}

function makeServerCloudShellBody(layer) {
  const element = createCloudPolygon3D({
    path: layer.path,
    altitude: layer.baseAltitude,
    altitudeMode: 'absolute',
    fillColor: layer.color,
    fillOpacity: cloudShellFillOpacity({ baseOpacity: layer.opacity, cloudFraction: layer.cloudFraction, shell: layer.shell || 'shell', family: layer.family || 'cloud' }),
    strokeColor: CLOUD_SHELL_EDGE_COLOR || layer.strokeColor || layer.color,
    strokeOpacity: cloudShellCapShadeOpacity({ cloudFraction: layer.cloudFraction ?? layer.opacity, shell: layer.shell || 'shell' }),
    strokeWidth: layer.strokeWidth ?? 0.5,
    extrudedHeight: cloudExtrudedHeight(layer.height, layer.cloudFraction),
    neonGlow: false,
    hover: {
      title: `${layer.family || 'cloud'} ${layer.pressureBand || ''} ${layer.shell || 'shell'}`.trim(),
      lines: [
        `Backend shell: ${layer.shell || 'shell'}`,
        `Band: ${layer.pressureBand || 'cloud'}`,
        `Base altitude: ${Math.round(layer.baseAltitude)} m`,
        `Shell height: ${Math.round(layer.height)} m`,
        `Shell alpha: ${Math.round(normalizeFraction(layer.cloudFraction ?? layer.opacity, 0.6) * cloudShellOpacityScale() * 100)}%`,
        `Cloud fraction: ${Math.round(normalizeFraction(layer.cloudFraction, 0.6) * 100)}%`,
        `Wind: ${Math.hypot(toNumber(layer.windU, 0), toNumber(layer.windV, 0)).toFixed(1)} m/s`,
      ],
      metrics: { layer: 'clouds', source: 'backend', path_points: layer.path?.length || 0, altitude_m: layer.baseAltitude },
      payload: { family: layer.family, band: layer.pressureBand, subtype: layer.subtype, base_altitude_m: layer.baseAltitude, top_altitude_m: layer.topAltitude || (layer.baseAltitude + layer.height), height_m: layer.height, cover: layer.opacity, cloud_fraction: layer.cloudFraction, base_pressure_hpa: layer.basePressureHpa, top_pressure_hpa: layer.topPressureHpa, wind_u: layer.windU, wind_v: layer.windV, path_points: layer.path?.length || 0 },
    },
  });
  if (!element) return null;
  try {
    element.setAttribute('data-cloud-surface-role', 'side');
    element.setAttribute('data-cloud-fraction', String(normalizeFraction(layer.cloudFraction, 0.6)));
    element.setAttribute('data-cloud-family', layer.family || 'cloud');
    element.__gfsCloudSurfaceRole = 'side';
    element.__gfsCloudFraction = normalizeFraction(layer.cloudFraction, 0.6);
    element.__gfsCloudFamily = layer.family || 'cloud';
  } catch (_) {}
  decorateCloudShellElement(element, {
    shellKey: [layer.family || 'cloud', layer.pressureBand || 'band', layer.shell || 'shell', Math.round(toNumber(layer.lat, 0) * 100), Math.round(toNumber(layer.lon, 0) * 100), Math.round(toNumber(layer.baseAltitude, 0))].join('|'),
    baseFillOpacity: toNumber(element.getAttribute?.('fill-opacity'), layer.opacity ?? 0.2),
    baseStrokeColor: CLOUD_SHELL_EDGE_COLOR,
    baseStrokeOpacity: toNumber(element.getAttribute?.('stroke-opacity'), layer.strokeOpacity ?? 0.1),
    baseStrokeWidth: toNumber(element.getAttribute?.('stroke-width'), layer.strokeWidth ?? 0.5),
    windU: layer.windU,
    windV: layer.windV,
    anchorLat: layer.lat,
    anchorLon: layer.lon,
  });
  try {
    element.setAttribute('data-gfs-layer', 'clouds');
    element.setAttribute('data-cloud-shell', layer.family || 'cloud');
    element.setAttribute('data-cloud-shell-source', 'backend');
  } catch (_) {}
  const resolvedTopAltitude = layer.topAltitude || (layer.baseAltitude + layer.height);
  const surfaceElements = buildCloudSurfaceElements({
    path: layer.path,
    baseAltitude: layer.baseAltitude,
    topAltitude: resolvedTopAltitude,
    cloudFraction: layer.cloudFraction,
    family: layer.family || 'cloud',
    windU: layer.windU,
    windV: layer.windV,
    anchorLat: layer.lat,
    anchorLon: layer.lon,
    color: layer.color,
    hover: true,
  });
  return {
    element,
    surfaceElements,
    shellId: uniqueId('cloud-shell'),
    basePath: layer.path,
    anchorLat: layer.lat,
    anchorLon: layer.lon,
    windU: toNumber(layer.windU, 0),
    windV: toNumber(layer.windV, 0),
    latOffsetDeg: 0,
    lonOffsetDeg: 0,
    particleMeanLatOffsetDeg: 0,
    particleMeanLonOffsetDeg: 0,
    cloudFraction: normalizeFraction(layer.cloudFraction, 0.6),
    topAltitude: resolvedTopAltitude,
    baseAltitude: layer.baseAltitude,
    basePressureHpa: layer.basePressureHpa,
    topPressureHpa: layer.topPressureHpa,
  };
}

function makeSeaContourCloudBody(feature, shellIndex = 0) {
  const level = clamp(toNumber(feature?.level, toNumber(feature?.cloud_total, 60) / 100), 0.05, 1);
  const total = Math.max(35, toNumber(feature?.cloud_total, level * 100));
  const low = toNumber(feature?.cloud_low, level * 42);
  const mid = toNumber(feature?.cloud_mid, level * 58);
  const high = toNumber(feature?.cloud_high, level * 72);
  const morphology = classifyCloudMorphology({ ...feature, cloud_total: total, cloud_low: low, cloud_mid: mid, cloud_high: high });
  const preferredBand = high >= Math.max(low, mid) ? 'high' : (mid >= low ? 'mid' : 'low');
  const band = buildCloudPressureBand(preferredBand, Math.max(low, mid, high, total), 1.0, morphology.family);
  const lift = shellIndex * Math.max(140, band.height * 0.18);
  const baseAltitude = Math.round(band.baseAltitude + lift);
  const path = contourPathFromFeature(feature, baseAltitude);
  if (path.length < 3) return null;
  const cloudFraction = normalizeFraction(total, clamp(level, 0.2, 0.95));
  const opacity = cloudShellFillOpacity({
    baseOpacity: 0.12 + level * 0.10 + shellIndex * 0.018,
    cloudFraction,
    shell: shellIndex === 0 ? 'contour-sidewall' : 'contour-cap',
    family: morphology.family,
  });
  const element = createCloudPolygon3D({
    path,
    altitude: baseAltitude,
    altitudeMode: 'absolute',
    fillColor: band.color,
    fillOpacity: opacity,
    strokeColor: CLOUD_SHELL_EDGE_COLOR || band.color,
    strokeOpacity: cloudShellCapShadeOpacity({ cloudFraction, shell: shellIndex === 0 ? 'contour-sidewall' : 'contour-cap' }),
    strokeWidth: shellIndex === 0 ? 0.7 : 0.45,
    extrudedHeight: cloudExtrudedHeight(band.height, cloudFraction, shellIndex * 0.08),
    neonGlow: false,
    hover: {
      title: 'scene-cache cloud contour shell',
      lines: [
        `Contour level: ${Math.round(level * 100)}%`,
        `Path points: ${path.length}`,
        `Raw points: ${feature.raw_path_len || feature.path_len || path.length}`,
        `Path stride: ${feature.path_stride || 1}`,
        `Detail: ${feature.path_detail || 'contour footprint'}`,
        `Band: ${preferredBand}`,
        `Cloud fraction: ${Math.round(cloudFraction * 100)}%`,
      ],
      metrics: { layer: 'clouds', source: 'scene_cache_contour', path_points: path.length, raw_path_points: feature.raw_path_len || path.length, path_stride: feature.path_stride || 1 },
      payload: { level, cloud_fraction: cloudFraction, base_pressure_hpa: band.baseHpa, top_pressure_hpa: band.topHpa, base_altitude_m: baseAltitude, top_altitude_m: baseAltitude + band.height, path_points: path.length, raw_path_points: feature.raw_path_len || path.length, path_stride: feature.path_stride || 1, detail_tier: feature.detail_tier, resolution: feature.sea_resolution },
    },
  });
  if (!element) return null;
  decorateCloudShellElement(element, {
    shellKey: [morphology.family || 'cloud', preferredBand || 'band', feature.path_detail || 'contour', Math.round(toNumber(feature.lat, 0) * 100), Math.round(toNumber(feature.lon, 0) * 100), shellIndex].join('|'),
    baseStrokeColor: CLOUD_SHELL_EDGE_COLOR,
    baseStrokeOpacity: toNumber(element.getAttribute?.('stroke-opacity'), cloudShellCapShadeOpacity({ cloudFraction, shell: shellIndex === 0 ? 'contour-sidewall' : 'contour-cap' })),
    baseStrokeWidth: toNumber(element.getAttribute?.('stroke-width'), shellIndex === 0 ? 0.7 : 0.45),
    windU: feature.wind_u,
    windV: feature.wind_v,
    anchorLat: feature.lat,
    anchorLon: feature.lon,
  });
  try {
    element.setAttribute('data-gfs-layer', 'clouds');
    element.setAttribute('data-cloud-shell', morphology.family || 'cloud');
    element.setAttribute('data-cloud-shell-source', 'scene-cache-contour');
    element.setAttribute('data-cloud-path-detail', feature.path_detail || 'contour');
  } catch (_) {}
  const resolvedTopAltitude = baseAltitude + band.height;
  const surfaceElements = buildCloudSurfaceElements({
    path,
    baseAltitude,
    topAltitude: resolvedTopAltitude,
    cloudFraction,
    family: 'stratiform',
    windU: toNumber(feature.wind_u, 0),
    windV: toNumber(feature.wind_v, 0),
    anchorLat: feature.lat,
    anchorLon: feature.lon,
    color: '#eef6ff',
    hover: true,
  });
  return {
    element,
    surfaceElements,
    shellId: uniqueId('cloud-contour-shell'),
    basePath: path,
    anchorLat: feature.lat,
    anchorLon: feature.lon,
    windU: toNumber(feature.wind_u, 0),
    windV: toNumber(feature.wind_v, 0),
    latOffsetDeg: 0,
    lonOffsetDeg: 0,
    particleMeanLatOffsetDeg: 0,
    particleMeanLonOffsetDeg: 0,
    cloudFraction: normalizeFraction(cloudFraction, 0.6),
    topAltitude: baseAltitude + band.height,
    basePressureHpa: band.baseHpa,
    topPressureHpa: band.topHpa,
  };
}

function cloudBodiesForFeature(feature, footprintScale) {
  const low = toNumber(feature?.cloud_low, 0);
  const mid = toNumber(feature?.cloud_mid, 0);
  const high = toNumber(feature?.cloud_high, 0);
  const total = toNumber(feature?.cloud_total, Math.max(low, mid, high));
  const totalBoost = clamp(total / 100, 0.82, 1.25);
  const morphology = classifyCloudMorphology(feature);
  const blueprints = shellBlueprints(morphology);
  const layers = [];

  const appendLayer = (type, density) => {
    const band = buildCloudPressureBand(type, density, totalBoost, morphology.family);
    const weight = band.weight;
    if (weight <= 0) return;
    for (const bp of blueprints) {
      const cloudFraction = normalizeFraction(Math.max(density, total), clamp(weight, 0.25, 0.95));
      const baseAltitude = Math.round(band.baseAltitude + (band.height * (bp.baseLift || 0)));
      const height = Math.round(band.height * (1 + (bp.heightBoost || 0)));
      layers.push({
        baseAltitude,
        topAltitude: baseAltitude + height,
        height,
        opacity: cloudShellFillOpacity({
          baseOpacity: (bp.opacityBase + (weight * bp.opacitySpan)),
          cloudFraction,
          shell: bp.shell,
          family: morphology.family,
        }),
        cloudFraction,
        latRadiusDeg: footprintScale.lat * (bp.latScale + (weight * 0.42)),
        lonRadiusDeg: footprintScale.lon * (bp.lonScale + (weight * 0.48)),
        color: band.color,
        pressureBand: type,
        basePressureHpa: band.baseHpa,
        topPressureHpa: band.topHpa,
        family: morphology.family,
        subtype: morphology.subtype,
        wobble: bp.wobble,
        points: bp.points,
        elongation: bp.elongation,
        shell: bp.shell,
      });
    }
  };

  if (low >= CLOUD_PRESSURE_BANDS.low.threshold) appendLayer('low', low);
  if (mid >= CLOUD_PRESSURE_BANDS.mid.threshold) appendLayer('mid', mid);
  if (high >= CLOUD_PRESSURE_BANDS.high.threshold) appendLayer('high', high);
  if (!layers.length && total >= CLOUD_PRESSURE_BANDS.total.threshold) appendLayer('total', total);
  return layers;
}

function sampleGridBilinear(grid, bbox, lat, lon) {
  if (!Array.isArray(grid) || !Array.isArray(grid[0]) || !bbox) return null;
  const arr = Array.isArray(grid[0][0]) ? grid[0] : grid;
  const ny = arr.length;
  const nx = Array.isArray(arr[0]) ? arr[0].length : 0;
  if (!ny || !nx) return null;
  const y = clamp(((lat - bbox.south) / Math.max(1e-6, bbox.north - bbox.south)) * (ny - 1), 0, ny - 1);
  const x = clamp(((lon - bbox.west) / Math.max(1e-6, bbox.east - bbox.west)) * (nx - 1), 0, nx - 1);
  const y0 = Math.floor(y);
  const x0 = Math.floor(x);
  const y1 = Math.min(ny - 1, y0 + 1);
  const x1 = Math.min(nx - 1, x0 + 1);
  const fy = y - y0;
  const fx = x - x0;
  const q11 = toNumber(arr[y0]?.[x0], NaN);
  const q21 = toNumber(arr[y0]?.[x1], q11);
  const q12 = toNumber(arr[y1]?.[x0], q11);
  const q22 = toNumber(arr[y1]?.[x1], q21);
  if (![q11, q21, q12, q22].every(Number.isFinite)) return null;
  return (q11 * (1 - fx) * (1 - fy)) + (q21 * fx * (1 - fy)) + (q12 * (1 - fx) * fy) + (q22 * fx * fy);
}

function windHeadingDeg(u, v) {
  if (!Number.isFinite(u) || !Number.isFinite(v)) return 90;
  return ((Math.atan2(u, v) * 180 / Math.PI) + 360) % 360;
}

function makeCloudBody({ lat, lon, baseAltitude, topAltitude = null, height, latRadiusDeg, lonRadiusDeg, color, opacity, cloudFraction = null, basePressureHpa = null, topPressureHpa = null, windU = 0, windV = 0, family = 'stratiform', wobble = 0.16, points = 14, elongation = 1.0 }) {
  const headingDeg = windHeadingDeg(windU, windV);
  const basePath = roundedCloudPath({ lat, lon, latRadiusDeg, lonRadiusDeg, wobble, points, elongation: family === 'cirriform' ? Math.max(1.25, elongation) : elongation, headingDeg });
  const element = createCloudPolygon3D({
    path: basePath,
    altitude: baseAltitude,
    altitudeMode: 'absolute',
    fillColor: color,
    fillOpacity: opacity,
    strokeColor: CLOUD_SHELL_EDGE_COLOR || color,
    strokeOpacity: cloudShellCapShadeOpacity({ cloudFraction, shell: family }),
    strokeWidth: 0.45,
    extrudedHeight: cloudExtrudedHeight(height, cloudFraction),
    neonGlow: false,
    hover: {
      title: `${family} cloud shell`,
      lines: [
        `Base altitude: ${Math.round(baseAltitude)} m`,
        `Shell height: ${Math.round(height)} m`,
        `Shell alpha: ${Math.round(normalizeFraction(cloudFraction ?? opacity, 0.6) * cloudShellOpacityScale() * 100)}%`,
        `Wind: ${Math.hypot(toNumber(windU, 0), toNumber(windV, 0)).toFixed(1)} m/s @ ${headingDeg.toFixed(0)}°`,
      ],
      metrics: { layer: 'clouds', source: 'frontend_cloud_shell', path_points: basePath?.length || 0, altitude_m: baseAltitude },
      payload: { family, base_altitude_m: baseAltitude, top_altitude_m: topAltitude || (baseAltitude + height), height_m: height, cover: opacity, cloud_fraction: cloudFraction, base_pressure_hpa: basePressureHpa, top_pressure_hpa: topPressureHpa, wind_u: windU, wind_v: windV, heading_deg: headingDeg, path_points: basePath?.length || 0 },
    },
  });
  if (!element) return null;
  try {
    element.setAttribute('data-gfs-layer', 'clouds');
    element.setAttribute('data-cloud-shell', family);
    element.setAttribute('data-cloud-surface-role', 'side');
    element.setAttribute('data-cloud-fraction', String(normalizeFraction(cloudFraction, 0.6)));
    element.setAttribute('data-cloud-family', family || 'cloud');
    element.__gfsCloudSurfaceRole = 'side';
    element.__gfsCloudFraction = normalizeFraction(cloudFraction, 0.6);
    element.__gfsCloudFamily = family || 'cloud';
  } catch (_) {}
  decorateCloudShellElement(element, {
    shellKey: [family || 'cloud', Math.round(toNumber(lat, 0) * 100), Math.round(toNumber(lon, 0) * 100), Math.round(toNumber(baseAltitude, 0))].join('|'),
    baseFillOpacity: opacity,
    baseStrokeColor: CLOUD_SHELL_EDGE_COLOR,
    baseStrokeOpacity: cloudShellCapShadeOpacity({ cloudFraction, shell: family }),
    baseStrokeWidth: 0.45,
    windU, windV, anchorLat: lat, anchorLon: lon,
  });
  const resolvedTopAltitude = topAltitude || (baseAltitude + height);
  const surfaceElements = buildCloudSurfaceElements({
    path: basePath,
    baseAltitude,
    topAltitude: resolvedTopAltitude,
    cloudFraction,
    family,
    windU,
    windV,
    anchorLat: lat,
    anchorLon: lon,
    color,
    hover: true,
  });
  return {
    element,
    surfaceElements,
    shellId: uniqueId('cloud-shell'),
    basePath,
    anchorLat: lat,
    anchorLon: lon,
    windU: toNumber(windU, 0),
    windV: toNumber(windV, 0),
    latOffsetDeg: 0,
    lonOffsetDeg: 0,
    particleMeanLatOffsetDeg: 0,
    particleMeanLonOffsetDeg: 0,
    cloudFraction: normalizeFraction(cloudFraction, 0.6),
    topAltitude: resolvedTopAltitude,
    baseAltitude,
    basePressureHpa,
    topPressureHpa,
  };
}


const cloudAdvectionCarry = [];

function rememberCloudAdvectionCarry(items = []) {
  cloudAdvectionCarry.length = 0;
  for (const item of items) {
    if (!item) continue;
    cloudAdvectionCarry.push({
      lat: Number(item.anchorLat),
      lon: Number(item.anchorLon),
      latOffsetDeg: Number(item.latOffsetDeg) || 0,
      lonOffsetDeg: Number(item.lonOffsetDeg) || 0,
      t: Date.now(),
    });
  }
  if (cloudAdvectionCarry.length > 300) cloudAdvectionCarry.splice(300);
}

function nearestCloudCarry(lat, lon) {
  let best = null;
  let bestD = Infinity;
  for (const c of cloudAdvectionCarry) {
    if (!Number.isFinite(c.lat) || !Number.isFinite(c.lon)) continue;
    const d = Math.hypot((Number(lat) || 0) - c.lat, (Number(lon) || 0) - c.lon);
    if (d < bestD) { best = c; bestD = d; }
  }
  if (!best || bestD > 1.6 || Date.now() - best.t > 180000) return null;
  return best;
}

function applyCloudCarry(body, particles = []) {
  const carry = nearestCloudCarry(body?.anchorLat, body?.anchorLon);
  if (!carry) return;
  body.latOffsetDeg = carry.latOffsetDeg;
  body.lonOffsetDeg = carry.lonOffsetDeg;
  try { if (body.element) setCloudElementPath(body.element, advectPath(body.basePath, body.latOffsetDeg, body.lonOffsetDeg, body.baseAltitude), body.baseAltitude); } catch (_) {}
  for (const particle of particles) {
    particle.latOffsetDeg = carry.latOffsetDeg;
    particle.lonOffsetDeg = carry.lonOffsetDeg;
  }
}

function startCloudAdvection(items, particles = []) {
  if (!items.length && !particles.length) return () => {};
  let rafId = 0;
  let stopped = false;
  let lastTs = 0;
  let lastDrawTs = 0;
  let elapsed = 0;
  const itemsByShell = new Map();
  for (const item of items) {
    if (item?.shellId) itemsByShell.set(item.shellId, item);
  }

  const tick = (ts) => {
    if (stopped) return;
    if (!lastTs) lastTs = ts;
    if (lastDrawTs && (ts - lastDrawTs) < CLOUD_ADVECTION_INTERVAL_MS) {
      rafId = requestAnimationFrame(tick);
      return;
    }
    const dtSec = Math.min(MAX_ADVECTION_STEP_SEC, Math.max(0.01, (ts - lastTs) * 0.001));
    lastTs = ts;
    lastDrawTs = ts;
    elapsed += dtSec;

    // Particles are the advected mass. Each particle keeps its own u/v plus
    // small local drift/wobble. The shell is NOT separately advected first;
    // after particles move, each shell follows the average particle displacement.
    const means = new Map();
    for (const particle of particles) {
      if (!particle.marker) continue;
      particle.latOffsetDeg += metersToLatDegrees((particle.windV + particle.localV) * dtSec);
      particle.lonOffsetDeg += metersToLonDegrees((particle.windU + particle.localU) * dtSec, particle.anchorLat + particle.latOffsetDeg);
      const phase = particle.wobblePhase + elapsed * particle.wobbleRate;
      const wobbleLat = Math.sin(phase) * particle.wobbleLatAmp;
      const wobbleLon = Math.cos(phase * 0.83) * particle.wobbleLonAmp;
      const wobbleAlt = Math.sin(phase * 1.31) * Math.min(220, particle.shellHeight * 0.055);
      const lat = particle.anchorLat + particle.baseLocalLat + particle.latOffsetDeg + wobbleLat;
      const lng = wrapLongitude(particle.anchorLon + particle.baseLocalLon + particle.lonOffsetDeg + wobbleLon);
      particle.marker.position = {
        lat,
        lng,
        altitude: Math.max(80, Math.round(particle.baseAltitude + wobbleAlt)),
      };
      const shellId = particle.shellId || null;
      if (shellId) {
        const acc = means.get(shellId) || { lat: 0, lon: 0, count: 0 };
        acc.lat += particle.latOffsetDeg;
        acc.lon += particle.lonOffsetDeg;
        acc.count += 1;
        means.set(shellId, acc);
      }
    }

    // Shell path updates are intentionally slow. Rewriting Google 3D polygon paths
    // at animation-frame speed causes the visible cloud flashing Jay reported.
    const shouldUpdateShellPaths = CLOUD_SHELL_PATH_UPDATE_MS > 0 && (!tick.lastShellPathUpdateTs || (ts - tick.lastShellPathUpdateTs) >= CLOUD_SHELL_PATH_UPDATE_MS);
    for (const item of items) {
      const mean = item.shellId ? means.get(item.shellId) : null;
      if (mean && mean.count > 0) {
        item.particleMeanLatOffsetDeg = mean.lat / mean.count;
        item.particleMeanLonOffsetDeg = mean.lon / mean.count;
        item.latOffsetDeg = item.particleMeanLatOffsetDeg;
        item.lonOffsetDeg = item.particleMeanLonOffsetDeg;
      } else {
        item.latOffsetDeg += metersToLatDegrees(item.windV * dtSec);
        item.lonOffsetDeg += metersToLonDegrees(item.windU * dtSec, item.anchorLat + item.latOffsetDeg);
      }
      if (shouldUpdateShellPaths) {
        const advectedPath = advectPath(item.basePath, item.latOffsetDeg, item.lonOffsetDeg, item.baseAltitude);
        if (item.element) {
          setCloudElementPath(item.element, advectedPath, item.baseAltitude);
        }
        if (Array.isArray(item.surfaceElements)) {
          for (const surface of item.surfaceElements) {
            const surfaceAltitude = toNumber(surface?.getAttribute?.('altitude') ?? surface?.altitude ?? item.baseAltitude, item.baseAltitude);
            setCloudElementPath(surface, advectedPath, surfaceAltitude);
          }
        }
      }
    }
    if (shouldUpdateShellPaths) tick.lastShellPathUpdateTs = ts;
    rafId = requestAnimationFrame(tick);
  };

  rafId = requestAnimationFrame(tick);
  return () => {
    rememberCloudAdvectionCarry(items);
    stopped = true;
    if (rafId) cancelAnimationFrame(rafId);
  };
}

export function estimateCloudColumnAltitudes(cloudTotal = 0, layerMix = {}) {
  const low = toNumber(layerMix.low, 0);
  const mid = toNumber(layerMix.mid, 0);
  const high = toNumber(layerMix.high, 0);
  const total = Math.max(cloudTotal, low, mid, high);
  const dominant = high >= Math.max(mid, low) && high >= 16
    ? 'high'
    : (mid >= Math.max(low, high) && mid >= 18 ? 'mid' : (low >= 20 ? 'low' : 'total'));
  const morphology = classifyCloudMorphology({ cloud_low: low, cloud_mid: mid, cloud_high: high, cloud_total: total });
  const band = buildCloudPressureBand(dominant, total, clamp(total / 100, 0.82, 1.24), morphology.family);
  return {
    cloudBaseAltitude: band.baseAltitude,
    cloudTopAltitude: band.baseAltitude + band.height,
    dominantBand: dominant,
    family: morphology.family,
    subtype: morphology.subtype,
  };
}




function stableCloudNodeKey(el, index) {
  try {
    const role = el?.getAttribute?.('data-cloud-surface-role') || el?.getAttribute?.('data-cloud-particle') || el?.tagName || 'cloud';
    const family = el?.getAttribute?.('data-cloud-family') || el?.__gfsCloudFamily || 'cloud';
    const frac = el?.getAttribute?.('data-cloud-fraction') || el?.__gfsCloudFraction || '';
    const path = el?.path || el?.coordinates || el?.__gfsBasePath || [];
    const p0 = Array.isArray(path) && path.length ? path[0] : null;
    const lat = Number(p0?.lat ?? p0?.latitude ?? 0).toFixed(3);
    const lon = Number(p0?.lng ?? p0?.lon ?? p0?.longitude ?? 0).toFixed(3);
    return `clouds:${role}:${family}:${lat}:${lon}:${String(frac).slice(0, 5)}:${index}`;
  } catch (_) {
    return `clouds:${index}`;
  }
}

function persistentCloudDisposer(map3DElement, created, stopAdvection) {
  created.forEach((el, index) => attachSceneKey(el, stableCloudNodeKey(el, index)));
  const disposer = reconcileSceneLayer(map3DElement, 'clouds', created, {
    fadeMs: 2400,
    disposeNode: () => {},
  });
  const wrapped = () => {
    try { if (typeof stopAdvection === 'function') stopAdvection(); } catch (_) {}
    try { disposer?.(); } catch (_) {}
  };
  wrapped.__gfsKeepExisting = true;
  wrapped.__gfsDidRender = true;
  return wrapped;
}
function preserveCloudDisposer(reason = 'preserve_existing_clouds') {
  const disposer = () => {};
  disposer.__gfsPreservePrevious = true;
  disposer.__gfsReason = reason;
  return disposer;
}
function renderCloudZonesImpl({ payload, map3DElement }) {
  const created = [];
  const advected = [];
  const particles = [];
  const rb = payload?.render_budget || payload?.scene_plan?.render_budget || {};
  const mobile = /android|iphone|ipad|mobile/i.test(navigator.userAgent || '');
  const viewportTier = String(payload?.sea_resolution?.tier || payload?.scene_tier || payload?.scene_plan?.tier || '').toLowerCase();
  const bodyTierCap = mobile
    ? (viewportTier === 'harbor' ? 100 : (viewportTier === 'local' ? 90 : 72))
    : (viewportTier === 'harbor' ? 180 : (viewportTier === 'local' ? 160 : (viewportTier === 'regional' ? 140 : 120)));
  const maxCloudBodies = Math.max(1, Math.min(bodyTierCap, Number(rb.max_cloud_shells || MAX_CLOUD_BODIES)));
  const requestedCloudParticles = Number(rb.max_cloud_particles || MAX_CLOUD_PARTICLES);
  const mobileCap = MOBILE_MAX_CLOUD_PARTICLES;
  const desktopCap = DESKTOP_MAX_CLOUD_PARTICLES;
  const tierCap = mobile
    ? (viewportTier === 'harbor' ? 1400 : (viewportTier === 'local' ? 1300 : 1200))
    : (viewportTier === 'harbor' ? 6200 : (viewportTier === 'local' ? 5200 : (viewportTier === 'regional' ? 4100 : 3200)));
  const maxCloudParticles = Math.max(360, Math.min(mobile ? mobileCap : desktopCap, tierCap, Math.round(requestedCloudParticles || MAX_CLOUD_PARTICLES)));
  const particleBudget = { remaining: maxCloudParticles };
  if (!map3DElement || !payload) return () => {};
  if (typeof window !== 'undefined' && window.__gfsCloudsDisabled === true) {
    clearCloudLayerNodes(map3DElement);
    return () => {};
  }
  ensureCloudMaterialWatchdog();
  console.info('[gfs clouds] polygon api', {
    api: polygonApiPath(),
    advectionMs: CLOUD_ADVECTION_INTERVAL_MS,
    shellPathUpdateMs: CLOUD_SHELL_PATH_UPDATE_MS,
    opacityScale: cloudShellOpacityScale(),
    renderPath: 'cloud_top_bottom_caps_side_smoke_one_teal_edge_4x_glow',
    fillSkinTopCap: CLOUD_SHELL_SURFACES_ENABLED,
    bottomCap: CLOUD_SHELL_BOTTOM_SURFACE_ENABLED,
    particleRenderer: CLOUD_PARTICLE_RENDERER_ENABLED,
    particleMode: 'billowy_particles_inside_single_shell_assembly',
    particleDropShadow: CLOUD_PARTICLE_DROP_SHADOW_ENABLED,
    cssDropShadow: CLOUD_SHELL_CSS_DROP_SHADOW_ENABLED,
  });

  const state = cloudPayloadState(payload);
  const hasDrawable = cloudPayloadHasDrawableContent(payload);
  if (payload?.heuristic === true || state === 'synthetic') {
    console.warn('[gfs clouds] synthetic/mock payload refused; holding existing clouds if any', { source: payload?.source, state });
    return preserveCloudDisposer('synthetic_mock_payload');
  }
  if ((state === 'warming' || state === 'pending' || state === 'queued') && !hasDrawable) {
    console.info('[gfs clouds] warming shell received; preserving existing cloud shells until live payload arrives', { source: payload?.source, state });
    return preserveCloudDisposer('warming_empty_payload');
  }
  const bbox = bboxFromPayload(payload);
  if (!bbox) {
    console.warn('[gfs clouds] no bbox in real cloud payload', { source: payload?.source, state });
    return preserveCloudDisposer('missing_bbox');
  }

  if (!hasDrawable) {
    console.info('[gfs clouds] no drawable live cloud content; preserving existing clouds', { source: payload?.source, state });
    return preserveCloudDisposer('no_drawable_payload');
  }

  const tileFeatures = cloudTileFeatures(payload, bbox);
  const seaContourFeatures = seaContourCloudFeatures(payload);
  const preferSeaContours = payload?.prefer_sea_contours === true || payload?.prefer_derived_contours === true || payload?.derived_render_geometry === true || seaContourFeatures.length > 0;
  const featureSource = (!preferSeaContours && tileFeatures.length) ? tileFeatures : [];

  if ((preferSeaContours || !tileFeatures.length) && seaContourFeatures.length) {
    const frag = document.createDocumentFragment();
    let bodyCount = 0;
    const cap = Math.min(maxCloudBodies, payload?.sea_resolution?.tier === 'harbor' ? (mobile ? 180 : 280) : (payload?.sea_resolution?.tier === 'local' ? (mobile ? 150 : 240) : (mobile ? 110 : 180)));
    for (let i = 0; i < seaContourFeatures.length && bodyCount < cap; i += 1) {
      const feature = seaContourFeatures[i];
      const shellCopies = 1;
      for (let shell = 0; shell < shellCopies && bodyCount < cap; shell += 1) {
        const body = makeSeaContourCloudBody(feature, shell);
        if (!body) continue;
        frag.append(body.element);
        created.push(body.element);
        if (Array.isArray(body.surfaceElements)) {
          for (const surface of body.surfaceElements) {
            if (!surface) continue;
            frag.append(surface);
            created.push(surface);
          }
        }
        advected.push(body);
        const seaBand = buildCloudPressureBand((toNumber(feature?.cloud_high, 0) >= Math.max(toNumber(feature?.cloud_low, 0), toNumber(feature?.cloud_mid, 0))) ? 'high' : (toNumber(feature?.cloud_mid, 0) >= toNumber(feature?.cloud_low, 0) ? 'mid' : 'low'), Math.max(toNumber(feature?.cloud_total, 60), toNumber(feature?.level, 0.5) * 100), 1.0, 'stratiform');
        const particleLayer = {
          latRadiusDeg: Math.max(0.025, toNumber(feature.cell_lat_deg, 0.08)),
          lonRadiusDeg: Math.max(0.025, toNumber(feature.cell_lon_deg, 0.08)),
          height: seaBand.height,
          baseAltitude: body.baseAltitude || seaBand.baseAltitude,
          topAltitude: body.topAltitude || seaBand.topAltitude,
          basePressureHpa: body.basePressureHpa || seaBand.baseHpa,
          topPressureHpa: body.topPressureHpa || seaBand.topHpa,
          opacity: 0.08 + toNumber(feature.level, 0.5) * 0.07,
          cloudFraction: normalizeFraction(Math.max(toNumber(feature?.cloud_total, 0), toNumber(feature?.level, 0.5) * 100), 0.6),
          family: 'stratiform',
          color: '#eef6ff',
        };
        const bodyParticles = buildCloudParticlesForBody(body, particleLayer, particleBudget);
        applyCloudCarry(body, bodyParticles);
        for (const particle of bodyParticles) {
          particle.marker = createCloudParticleMarker(particle);
          frag.append(particle.marker);
          created.push(particle.marker);
          particles.push(particle);
        }
        bodyCount += 1;
      }
    }
    if (bodyCount > 0) {
      const stopAdvection = startCloudAdvection(advected, particles);
      try { window.__gfsDebugEvent?.('clouds/render', { source: 'scene_cache_contour_footprints', bodies: bodyCount, particles: particles.length, maxCloudParticles, maxCloudBodies, contours: seaContourFeatures.length, renderedPathPoints: advected.reduce((n, b) => n + (Array.isArray(b.basePath) ? b.basePath.length : 0), 0), tier: payload?.sea_resolution?.tier || viewportTier }); } catch (_) {}
      console.info('[gfs clouds] rendered scene-cache contour-footprint shells', {
        bodies: bodyCount,
        particles: particles.length,
        particleCap: maxCloudParticles,
        bodyCap: maxCloudBodies,
        contours: seaContourFeatures.length,
        tier: payload?.sea_resolution?.tier,
        subgrid: payload?.sea_resolution?.subgrid_used,
        detail: seaContourFeatures[0]?.path_detail || 'contour_path',
        pathStride: seaContourFeatures[0]?.path_stride || 1,
        source: 'scene_cache_contour_footprints_visible_preferred',
      });
      return persistentCloudDisposer(map3DElement, created, stopAdvection);
    }
  }

  if (featureSource.length) {
    const frag = document.createDocumentFragment();
    let bodyCount = 0;
    for (let i = 0; i < featureSource.length; i += 1) {
      const feature = featureSource[i]?.properties || featureSource[i] || {};
      const normalizedCenter = normalizeFeatureCenter(feature, bbox);
      if (!normalizedCenter) continue;
      const { lat, lon } = normalizedCenter;
      const serverLayers = serverCloudShellLayersFromTile(feature.rawTile, bbox, feature);
      const footprint = { lat: Math.max(toNumber(feature.cell_lat_deg, 0.12) * 0.94, 0.05), lon: Math.max(toNumber(feature.cell_lon_deg, 0.12) * 0.94, 0.05) };
      const layers = serverLayers.length ? serverLayers : cloudBodiesForFeature(feature, footprint);
      for (const layer of layers) {
        const body = serverLayers.length
          ? makeServerCloudShellBody(layer)
          : makeCloudBody({ lat, lon, windU: feature.wind_u, windV: feature.wind_v, ...layer });
        if (!body) continue;
        frag.append(body.element);
        created.push(body.element);
        if (Array.isArray(body.surfaceElements)) {
          for (const surface of body.surfaceElements) {
            if (!surface) continue;
            frag.append(surface);
            created.push(surface);
          }
        }
        advected.push(body);
        const bodyParticles = buildCloudParticlesForBody(body, layer, particleBudget);
        applyCloudCarry(body, bodyParticles);
        for (const particle of bodyParticles) {
          particle.marker = createCloudParticleMarker(particle);
          frag.append(particle.marker);
          created.push(particle.marker);
          particles.push(particle);
        }
        bodyCount += 1;
        if (bodyCount >= maxCloudBodies) break;
      }
      if (bodyCount >= maxCloudBodies) break;
    }
    if (bodyCount > 0) {
      // Replace only after the new scene is already built in memory. This
      // avoids a blank frame while cloud shells are being constructed.
      const stopAdvection = startCloudAdvection(advected, particles);
      try { window.__gfsDebugEvent?.('clouds/render', { source: 'backend_cloud_shells_from_tiles', bodies: bodyCount, particles: particles.length, maxCloudParticles, maxCloudBodies, sourceFeatures: featureSource.length, renderedPathPoints: advected.reduce((n, b) => n + (Array.isArray(b.basePath) ? b.basePath.length : 0), 0), tier: payload?.scene_tier || payload?.scene_plan?.tier || viewportTier }); } catch (_) {}
      console.info('[gfs clouds] rendered bodies', { bodies: bodyCount, particles: particles.length, particleCap: maxCloudParticles, bodyCap: maxCloudBodies, sceneTier: payload?.scene_tier || payload?.scene_plan?.tier, renderBudget: rb, source: payload?.cloud_region_count ? 'backend_cloud_regions_marching_squares' : 'backend_cloud_shells_from_tiles', mode: payload?.cloud_region_count ? 'cloud_region_marching_squares_shells_particles_advect_shell_follows_centroid' : 'organic_backend_shells_particles_advect_shell_follows_centroid' });
      return persistentCloudDisposer(map3DElement, created, stopAdvection);
    }
    console.warn('[gfs clouds] feature payload had entries but made zero single-path bodies; preserving existing cloud assembly', { featureCount: featureSource.length, seaContourFeatures: seaContourFeatures.length, source: payload?.source, state });
    return preserveCloudDisposer('single_path_feature_zero_bodies');
  }

  // No grid fallback renderer here. The grid path was the usual source of the
  // apparent double-cloud/grey-outline overwrite because it could build a second
  // cloud assembly after the contour/tile shell path. Cloud data must arrive as
  // contour/tile cloud features; if it does not, keep the previous clouds alive
  // until the provider/cache produces real drawable cloud features.
  console.info('[gfs clouds] no single-path drawable cloud features yet; preserving previous cloud assembly', { source: payload?.source, state, tileFeatures: tileFeatures.length, seaContourFeatures: seaContourFeatures.length });
  return preserveCloudDisposer('single_path_no_drawable_features');
}


// Public wrapper: never let one malformed cloud frame kill the whole renderer.
export function renderCloudZones(args = {}) {
  try {
    return renderCloudZonesImpl(args);
  } catch (err) {
    try {
      const payload = args?.payload || {};
      const msg = String(err?.message || err || 'unknown_cloud_render_error');
      console.error('[gfs clouds] render error guarded', { message: msg, stack: err?.stack, source: payload?.source, status: payload?.status, keys: Object.keys(payload || {}).slice(0, 30) });
      window.__gfsDebugEvent?.('clouds/render-error', { message: msg, source: payload?.source, status: payload?.status });
    } catch (_) {}
    // Do not mark this as rendered. RendererLayer will preserve the previous
    // cloud scene and will retry the next drawable payload instead of clearing
    // clouds because a single frame was malformed.
    return preserveCloudDisposer('render_error_guard');
  }
}
