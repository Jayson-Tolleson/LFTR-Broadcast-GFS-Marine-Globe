# LFTR GFS Patch Kit — Ocean tile-only + Cloud no-full-rerender + Inland NCSS surface temps

This is a drop-in guidance/patch kit, not a full application source ZIP. It is meant to be copied into the current LFTR app tree and applied manually or by Codex.

## Main fixes included

1. **Delete wide ocean provider requests**
   - HYCOM/RTOFS/SST/current provider calls should never request the full visible/world bbox.
   - Visible bbox is for render/cache lookup only.
   - Provider bbox must be split into small tiles.
   - Wide request failures were poisoning bait/boater/shark-intel with `points: 0`.

2. **Clouds should not fully rerender every refresh**
   - Cloud shells stay on map unless pill is turned off.
   - Same layer version = no full rebuild.
   - New version = reconcile/morph existing cloud bodies.
   - Sprites advect every frame using cached u/v and wobble/jitter.
   - Target: up to 500 sprite markers, not thousands.

3. **Inland water temps should come from cached NCSS surface**
   - Global lake temp var is not separately available.
   - Use the existing GFS/NCSS surface temperature cache.
   - Lake temp is one closed-lake average sampled from surface grid points inside the lake polygon.
   - At world zoom: build/keep outlines/cache only.
   - Off global zoom: render/enrich lake bait/temp overlays.

4. **Diagnostics**
   - Includes a terminal command script to test SST/current/bait advanced/boater readiness.

## Expected debug changes

You should see logs like:

```text
ocean/provider-wide-request-skipped policy=tile_cache_only
ocean/tile-refresh scheduled=N tile_deg=1.0
render/noop-same-layer-version layer=clouds
clouds/morph-existing-bodies
inland-water/temp-source ncss_surface_cache
```

You should no longer see useful work attempted on large HYCOM boxes such as:

```text
[-117,34,-112,37]
```

unless that bbox is only used as a cache/read/render bbox and is split before provider calls.
