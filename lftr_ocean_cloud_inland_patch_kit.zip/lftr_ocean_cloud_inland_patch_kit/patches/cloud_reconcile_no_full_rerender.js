/*
LFTR patch target: /static/js/gfs/cloud-zones.js or equivalent cloud renderer.

Intent:
- Stop full cloud rerender on every frame/cache heartbeat.
- Preserve cloud shells and sprites unless pill off.
- Same version/signature = no-op.
- New version = reconcile/morph existing bodies.
- Sprite pool capped around 500.
*/

const LFTR_CLOUD_RENDER_STATE = window.LFTR_CLOUD_RENDER_STATE || (window.LFTR_CLOUD_RENDER_STATE = {
  version: null,
  bodiesById: new Map(),
  spritePool: [],
  spriteCap: 500,
  lastAdvectionTs: 0,
  enabled: true,
});

function stableCloudId(feature, idx) {
  return (
    feature.id ||
    feature.cloud_id ||
    feature.hash ||
    `${Math.round((feature.centroid?.lat ?? feature.lat ?? 0) * 100)}:${Math.round((feature.centroid?.lon ?? feature.lon ?? 0) * 100)}:${idx}`
  );
}

function shouldSkipCloudApply(payload) {
  const version = payload?.cache?.version || payload?.version || payload?.layerVersion;
  if (!version) return false;
  if (LFTR_CLOUD_RENDER_STATE.version === version) {
    console.debug("[GFS] render/noop-same-layer-version", { layer: "clouds", version });
    return true;
  }
  return false;
}

function reconcileCloudBodies(payload) {
  const version = payload?.cache?.version || payload?.version || payload?.layerVersion || String(Date.now());
  if (shouldSkipCloudApply(payload)) return;

  const features = payload?.features || payload?.clouds || payload?.items || [];
  const nextIds = new Set();

  features.forEach((feature, idx) => {
    const id = stableCloudId(feature, idx);
    nextIds.add(id);

    let body = LFTR_CLOUD_RENDER_STATE.bodiesById.get(id);
    if (!body) {
      body = createCloudBodyShell(feature, id);
      LFTR_CLOUD_RENDER_STATE.bodiesById.set(id, body);
    } else {
      morphCloudBodyShell(body, feature);
    }
  });

  // Do not hard-clear missing clouds during normal refresh.
  // Fade missing bodies so there is no flash.
  for (const [id, body] of LFTR_CLOUD_RENDER_STATE.bodiesById.entries()) {
    if (!nextIds.has(id)) {
      fadeCloudBody(body);
    }
  }

  ensureCloudSpritePool(Math.min(500, Math.max(80, features.length * 4)));
  LFTR_CLOUD_RENDER_STATE.version = version;

  console.debug("[GFS] clouds/morph-existing-bodies", {
    version,
    features: features.length,
    bodies: LFTR_CLOUD_RENDER_STATE.bodiesById.size,
    sprites: LFTR_CLOUD_RENDER_STATE.spritePool.length,
    spriteCap: LFTR_CLOUD_RENDER_STATE.spriteCap,
  });
}

function ensureCloudSpritePool(targetCount) {
  const cap = LFTR_CLOUD_RENDER_STATE.spriteCap || 500;
  targetCount = Math.max(0, Math.min(cap, targetCount));

  while (LFTR_CLOUD_RENDER_STATE.spritePool.length < targetCount) {
    LFTR_CLOUD_RENDER_STATE.spritePool.push(createCloudSprite());
  }

  while (LFTR_CLOUD_RENDER_STATE.spritePool.length > targetCount) {
    const sprite = LFTR_CLOUD_RENDER_STATE.spritePool.pop();
    removeCloudSprite(sprite);
  }
}

function tickCloudAdvection(nowMs) {
  if (!LFTR_CLOUD_RENDER_STATE.enabled) return;

  const dt = Math.min(2.0, Math.max(0.0, (nowMs - (LFTR_CLOUD_RENDER_STATE.lastAdvectionTs || nowMs)) / 1000));
  LFTR_CLOUD_RENDER_STATE.lastAdvectionTs = nowMs;

  for (const body of LFTR_CLOUD_RENDER_STATE.bodiesById.values()) {
    advectCloudBody(body, dt);
    wobbleCloudBody(body, nowMs);
  }

  for (const sprite of LFTR_CLOUD_RENDER_STATE.spritePool) {
    advectCloudSprite(sprite, dt);
    wobbleCloudSprite(sprite, nowMs);
  }

  requestAnimationFrame(tickCloudAdvection);
}

// Integration point:
// Replace old full renderer entry call with:
//   reconcileCloudBodies(cloudLayerPayload)
//
// Pill-off only:
//   clearCloudBodiesAndSprites()
//
// Empty/warming payload:
//   DO NOT CLEAR. Keep last good cloud bodies.
