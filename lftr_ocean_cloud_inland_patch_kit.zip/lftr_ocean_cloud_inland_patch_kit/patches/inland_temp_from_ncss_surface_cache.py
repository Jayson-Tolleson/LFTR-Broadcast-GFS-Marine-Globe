"""
LFTR patch target: inland water temp companion layer.

Intent:
- Stop looking for a special "global lake temp var".
- Use cached NCSS/GFS surface air/water proxy grid already in scene/weather cache.
- Compute one closed-lake average temp from surface grid samples inside polygon.
- World zoom: cache/build outlines only; do not render inland temp/bait.
"""

from __future__ import annotations

from typing import Iterable, Mapping, Any
import math


def f_to_c(f: float) -> float:
    return (f - 32.0) * 5.0 / 9.0


def k_to_f(k: float) -> float:
    return (float(k) - 273.15) * 9.0 / 5.0 + 32.0


def normalize_surface_temp_f(value: float, units: str | None = None) -> float | None:
    if value is None:
        return None
    try:
        v = float(value)
    except Exception:
        return None
    if not math.isfinite(v):
        return None

    u = (units or "").lower()
    if "k" in u or v > 170:
        return k_to_f(v)
    if "c" in u or (-50 <= v <= 60):
        # Ambiguous but most NCSS air_temp is Kelvin; if explicit C, convert.
        if "c" in u:
            return v * 9.0 / 5.0 + 32.0
    return v


def point_in_ring(lon: float, lat: float, ring: list[list[float]]) -> bool:
    inside = False
    n = len(ring)
    if n < 3:
        return False
    j = n - 1
    for i in range(n):
        xi, yi = ring[i][0], ring[i][1]
        xj, yj = ring[j][0], ring[j][1]
        intersects = ((yi > lat) != (yj > lat)) and (
            lon < (xj - xi) * (lat - yi) / ((yj - yi) or 1e-12) + xi
        )
        if intersects:
            inside = not inside
        j = i
    return inside


def lake_temp_from_ncss_surface_cache(
    lake_polygon: list[list[float]],
    surface_points: Iterable[Mapping[str, Any]],
    *,
    temp_keys=("surface_temp", "air_temp", "tmp", "temperature", "temp"),
    units_key="units",
) -> dict[str, Any]:
    """
    Returns one closed-lake temp estimate from cached NCSS surface grid samples.

    `surface_points` should be read from existing cache, not fetched live per lake.
    Expected points:
      { "lat": ..., "lon": ..., "air_temp": ..., "units": "K" }
    """
    samples_f: list[float] = []

    for p in surface_points:
        try:
            lat = float(p.get("lat"))
            lon = float(p.get("lon"))
        except Exception:
            continue

        if not point_in_ring(lon, lat, lake_polygon):
            continue

        raw = None
        for k in temp_keys:
            if k in p:
                raw = p.get(k)
                break

        temp_f = normalize_surface_temp_f(raw, str(p.get(units_key, "")))
        if temp_f is not None:
            samples_f.append(temp_f)

    if not samples_f:
        return {
            "ok": False,
            "source": "ncss_surface_cache",
            "status": "no_surface_samples_inside_lake_polygon",
            "temp_f": None,
            "sample_count": 0,
        }

    avg = sum(samples_f) / len(samples_f)
    return {
        "ok": True,
        "source": "ncss_surface_cache",
        "status": "estimated_closed_lake_average",
        "temp_f": round(avg, 1),
        "sample_count": len(samples_f),
    }


def should_render_inland_water(scene_tier: str, range_m: float | None = None) -> bool:
    """
    User policy:
    - World zoom: build/cache outlines, but do not render inland bait/temp overlays.
    - Off global zoom: render/enrich.
    """
    tier = (scene_tier or "").lower()
    if tier == "world":
        return False
    return tier in {"regional", "coastal", "local", "harbor"} or (range_m is not None and range_m < 900_000)


# Debug text replacement:
# OLD:
#   global lake temp var is not available
#
# NEW:
#   inland-water/temp-source source=ncss_surface_cache status=...
