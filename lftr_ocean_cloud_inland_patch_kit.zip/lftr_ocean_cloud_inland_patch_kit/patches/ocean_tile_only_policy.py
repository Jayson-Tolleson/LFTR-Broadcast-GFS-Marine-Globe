"""
LFTR patch target: ocean providers / scene cache warmers.

Intent:
- Remove/disable wide HYCOM/RTOFS/SST/current provider requests.
- Use visible bbox for cache lookup/render only.
- Split provider work into small tiles.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import ceil
from typing import Iterable, Sequence

MAX_OCEAN_PROVIDER_TILE_DEG = 1.0
ABSOLUTE_MAX_OCEAN_PROVIDER_TILE_DEG = 2.0


@dataclass(frozen=True)
class BBox:
    west: float
    south: float
    east: float
    north: float

    @classmethod
    def from_any(cls, bbox: Sequence[float] | dict) -> "BBox":
        if isinstance(bbox, dict):
            return cls(float(bbox["west"]), float(bbox["south"]), float(bbox["east"]), float(bbox["north"]))
        west, south, east, north = bbox
        return cls(float(west), float(south), float(east), float(north))

    @property
    def width(self) -> float:
        return max(0.0, self.east - self.west)

    @property
    def height(self) -> float:
        return max(0.0, self.north - self.south)

    def as_list(self) -> list[float]:
        return [self.west, self.south, self.east, self.north]


def is_wide_ocean_provider_bbox(bbox: Sequence[float] | dict, max_deg: float = ABSOLUTE_MAX_OCEAN_PROVIDER_TILE_DEG) -> bool:
    b = BBox.from_any(bbox)
    return b.width > max_deg or b.height > max_deg


def split_ocean_bbox_for_provider(
    bbox: Sequence[float] | dict,
    tile_deg: float = MAX_OCEAN_PROVIDER_TILE_DEG,
) -> list[list[float]]:
    """
    Split render/visible bbox into provider-safe ocean tiles.

    IMPORTANT:
    - This function is for provider fetches only.
    - Scene cache and render may still use the larger visible bbox.
    """
    b = BBox.from_any(bbox)
    tile_deg = max(0.1, min(float(tile_deg), ABSOLUTE_MAX_OCEAN_PROVIDER_TILE_DEG))

    tiles: list[list[float]] = []
    lon = b.west
    while lon < b.east:
        next_lon = min(lon + tile_deg, b.east)
        lat = b.south
        while lat < b.north:
            next_lat = min(lat + tile_deg, b.north)
            tiles.append([
                round(lon, 6),
                round(lat, 6),
                round(next_lon, 6),
                round(next_lat, 6),
            ])
            lat = next_lat
        lon = next_lon

    return tiles


def provider_fetch_guard(fetch_fn, bbox, *, layer: str, logger=None, tile_deg: float = MAX_OCEAN_PROVIDER_TILE_DEG):
    """
    Wrap provider fetch calls with this guard.

    Bad old behavior:
        fetch_fn(visible_bbox)

    New behavior:
        for tile in split_ocean_bbox_for_provider(visible_bbox):
            fetch_fn(tile)
    """
    b = BBox.from_any(bbox)
    if is_wide_ocean_provider_bbox(b.as_list(), tile_deg):
        tiles = split_ocean_bbox_for_provider(b.as_list(), tile_deg=tile_deg)
        if logger:
            logger.info(
                "ocean/provider-wide-request-skipped",
                extra={
                    "layer": layer,
                    "policy": "tile_cache_only",
                    "visible_bbox": b.as_list(),
                    "tile_deg": tile_deg,
                    "tiles": len(tiles),
                },
            )
        results = []
        for tile in tiles:
            results.append(fetch_fn(tile))
        return results

    return [fetch_fn(b.as_list())]


# Search/delete targets in current code:
#
# fetch_hycom_bbox(ocean_fetch_bbox)
# fetch_rtofs_bbox(ocean_fetch_bbox)
# fetch_sst_bbox(ocean_fetch_bbox)
# fetch_current_bbox(ocean_fetch_bbox)
# request_hycom(wide_bbox)
#
# Replace with:
#
# provider_fetch_guard(fetch_hycom_tile, ocean_fetch_bbox, layer="sst", logger=logger)
# provider_fetch_guard(fetch_current_tile, ocean_fetch_bbox, layer="current", logger=logger)
